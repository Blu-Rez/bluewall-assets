"""Blue Wall owner panel - the HTTP side (OC1).  Everything under /api/owner/ is OWNER-ONLY, checked on the server for every call (reads too):
anyone else gets the same 403 {"ok": false, "reason": "locked"} the other private routes give, so the client never even builds the sheet for them.

server.py adds ONE line in make_app():   OW.add_routes(app, bearer_uid=_bearer_uid, is_owner=_is_owner, limited=_limited, nocache=_nocache)
(the logic is all here + liveops.py; see server_patch/ROUTES.md for every route).

Players: search by code (the Telegram id) or by name, a short profile, a gift (through the same inbox the bot uses: `state.push_inbox`, unique id,
a request id makes a retried tap harmless), a chat mute (liveops keeps the list; `chat.mute` of CH1 is called when that module exists), and the
report / suspicious queues, which show what CH1 / FR1 / RK1 offer once they are merged (stubs until then).
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional

from aiohttp import web

from . import liveops as LO

log = logging.getLogger("bluewall.ownerapi")

def _plain(v: Any, depth: int = 0) -> Any:
    """a queue item from another module, made safe to send (plain JSON, bounded)."""
    if depth > 4:
        return None
    if v is None or isinstance(v, (bool, int, float)):
        return v
    if isinstance(v, str):
        return v[:300]
    if isinstance(v, (list, tuple)):
        return [_plain(x, depth + 1) for x in list(v)[:50]]
    if isinstance(v, dict):
        return {str(k)[:40]: _plain(x, depth + 1) for k, x in list(v.items())[:40]}
    return str(v)[:100]


def add_routes(app: web.Application, *, bearer_uid: Callable, is_owner: Callable, limited: Callable, nocache: Callable, store: Any = None, lo: Optional[LO.LiveOps] = None) -> None:
    lo = lo or LO.L

    def S():
        if store is not None:
            return store
        from .state import STORE
        return STORE

    def J(obj: Dict[str, Any], status: int = 200) -> web.StreamResponse:
        return nocache(web.json_response(obj, status=status))

    async def body(req: web.Request) -> Optional[Dict[str, Any]]:
        try:
            b = await req.json()
        except Exception:  # noqa: BLE001
            return None
        return b if isinstance(b, dict) else None

    def owner_only(fn: Callable) -> Callable:
        async def wrapped(req: web.Request) -> web.StreamResponse:
            uid = bearer_uid(req)
            if uid is None or not is_owner(uid):
                return J({"ok": False, "reason": "locked"}, 403)                   # (same answer for a stranger and for a player who is not the owner)
            if limited("ow:%d" % uid, 240):
                return J({"ok": False, "reason": "slow"}, 429)
            try:
                return await fn(req, int(uid))
            except web.HTTPException:
                raise
            except Exception:  # noqa: BLE001
                log.exception("owner route %s failed", req.path)
                return J({"ok": False, "reason": "server"}, 500)
        return wrapped

    def lo_result(res: Dict[str, Any]) -> web.StreamResponse:
        if res.get("ok"):
            return J(res)
        why = res.get("why")
        status = {"invalid": 400, "format": 400, "stale": 409, "busy": 409, "section": 404, "gone": 404, "store": 503, "size": 413}.get(str(why), 400)
        return J(res, status)

    # ---------------------------------------------------------------- what every player may read: the switches
    async def h_flags(req: web.Request) -> web.StreamResponse:
        uid = bearer_uid(req)
        if uid is None:
            return J({"ok": False, "reason": "locked"}, 403)
        if limited("fl:%d" % uid, 60):
            return J({"ok": False, "reason": "slow"}, 429)
        return J({"ok": True, "flags": lo.get("flags"), "season": lo.season(), "rev": lo.rev(), "now": int(lo.clock())})

    # ---------------------------------------------------------------- live-ops config
    @owner_only
    async def h_overview(req: web.Request, uid: int) -> web.StreamResponse:
        secs = [{"name": n, "title": lo.info(n)["title"], "srev": lo.srev(n), "custom": lo.has_overrides(n)} for n in lo.sections()]
        return J({"ok": True, "rev": lo.rev(), "now": int(lo.clock()), "sections": secs, "checklist": lo.checklist()})

    @owner_only
    async def h_section(req: web.Request, uid: int) -> web.StreamResponse:
        name = req.match_info["name"]
        info = lo.info(name)
        if info is None:
            return J({"ok": False, "why": "section"}, 404)
        return J(dict(info, ok=True, rev=lo.rev(), srev=lo.srev(name), values=lo.get(name)))

    @owner_only
    async def h_check(req: web.Request, uid: int) -> web.StreamResponse:
        name = req.match_info["name"]
        b = await body(req)
        if b is None or "values" not in b:
            return J({"ok": False, "why": "bad"}, 400)
        return lo_result(await lo.save(name, b["values"], uid, dry=True))

    @owner_only
    async def h_save(req: web.Request, uid: int) -> web.StreamResponse:
        name = req.match_info["name"]
        b = await body(req)
        if b is None or "values" not in b:
            return J({"ok": False, "why": "bad"}, 400)
        base = b.get("base_rev")
        if base is not None and (isinstance(base, bool) or not isinstance(base, int)):
            return J({"ok": False, "why": "bad"}, 400)
        res = await lo.save(name, b["values"], uid, base_rev=base, note=str(b.get("note") or "")[:120])
        if res.get("ok"):
            log.info("liveops: uid=%s saved %s -> rev %s%s", uid, name, res.get("rev"), " (no change)" if res.get("noop") else "")
        return lo_result(res)

    @owner_only
    async def h_revert(req: web.Request, uid: int) -> web.StreamResponse:
        b = await body(req)
        if b is None or isinstance(b.get("version"), bool) or not isinstance(b.get("version"), int):
            return J({"ok": False, "why": "bad"}, 400)
        sec = b.get("section")
        if sec is not None and not isinstance(sec, str):
            return J({"ok": False, "why": "bad"}, 400)
        res = await lo.revert(b["version"], uid, section=sec or None)
        if res.get("ok"):
            log.info("liveops: uid=%s reverted %s to v%s -> rev %s", uid, sec or "all", b["version"], res.get("rev"))
        return lo_result(res)

    @owner_only
    async def h_versions(req: web.Request, uid: int) -> web.StreamResponse:
        return J({"ok": True, "rev": lo.rev(), "versions": await lo.versions()})

    @owner_only
    async def h_audit(req: web.Request, uid: int) -> web.StreamResponse:
        try:
            limit, off = int(req.query.get("limit", 50)), int(req.query.get("offset", 0))
        except ValueError:
            return J({"ok": False, "why": "bad"}, 400)
        return J({"ok": True, "items": await lo.audit(limit, off)})

    @owner_only
    async def h_export(req: web.Request, uid: int) -> web.StreamResponse:
        return J({"ok": True, "doc": lo.export()})

    @owner_only
    async def h_import(req: web.Request, uid: int) -> web.StreamResponse:
        b = await body(req)
        if b is None or "doc" not in b:
            return J({"ok": False, "why": "bad"}, 400)
        res = await lo.import_(b["doc"], uid, dry=bool(b.get("dry")), note=str(b.get("note") or "")[:120])
        if res.get("ok") and not res.get("dry"):
            log.info("liveops: uid=%s imported -> rev %s", uid, res.get("rev"))
        return lo_result(res)

    @owner_only
    async def h_checklist(req: web.Request, uid: int) -> web.StreamResponse:
        return J({"ok": True, "checklist": lo.checklist()})

    # ---------------------------------------------------------------- players  (the logic lives in liveops.py: the bot's admin panel uses the very same functions)
    def uid_of(req: web.Request) -> Optional[int]:
        s = req.match_info.get("uid", "")
        return int(s) if s.isdigit() and 0 < len(s) <= 15 else None

    def player_result(res: Dict[str, Any]) -> web.StreamResponse:
        if res.get("ok"):
            return J(res)
        why = str(res.get("why"))
        return J(res, {"player": 404, "store": 503}.get(why, 400))

    @owner_only
    async def h_players(req: web.Request, uid: int) -> web.StreamResponse:
        q = (req.query.get("q") or "").strip()[:40]
        return J({"ok": True, "items": await lo.player_search(S(), q), "q": q})

    @owner_only
    async def h_player(req: web.Request, uid: int) -> web.StreamResponse:
        u = uid_of(req)
        if u is None or not await lo.player_exists(S(), u):
            return J({"ok": False, "why": "player"}, 404)
        p = await lo.player_profile(S(), u)
        p["mute"] = next((x for x in await lo.mutes() if x["id"] == u), None)
        return J({"ok": True, "player": p})

    @owner_only
    async def h_gift(req: web.Request, uid: int) -> web.StreamResponse:
        u = uid_of(req)
        b = await body(req)
        if u is None or b is None:
            return J({"ok": False, "why": "bad"}, 400)
        return player_result(await lo.gift(S(), u, b.get("gems"), b.get("rid"), uid, str(b.get("note") or "")[:120]))

    @owner_only
    async def h_mute(req: web.Request, uid: int) -> web.StreamResponse:
        u = uid_of(req)
        b = await body(req)
        if u is None or b is None:
            return J({"ok": False, "why": "bad"}, 400)
        return player_result(await lo.mute_player(S(), u, b.get("minutes"), uid, str(b.get("reason") or "")))

    @owner_only
    async def h_mutes(req: web.Request, uid: int) -> web.StreamResponse:
        return J({"ok": True, "items": await lo.mutes()})

    async def queue(module: str, fn: str) -> Dict[str, Any]:
        h = await LO.call_hook(module, fn)
        if h["state"] != "called" or not isinstance(h.get("value"), (list, tuple)):
            return {"ok": True, "items": [], "stub": True}
        return {"ok": True, "items": _plain(list(h["value"])[:100]), "stub": False}

    @owner_only
    async def h_reports(req: web.Request, uid: int) -> web.StreamResponse:
        out = await queue("chat", "reports")                                              # CH1: chat.reports() -> list of {id, t, by, target, text, kind}
        fr = await queue("friends", "reports")                                            # FR1: friends.reports() -> list of {id, t, by, target, reason}
        return J({"ok": True, "items": (out["items"] + fr["items"])[:100], "stub": out["stub"] and fr["stub"]})

    @owner_only
    async def h_suspicious(req: web.Request, uid: int) -> web.StreamResponse:
        return J(await queue("ladder", "suspicious"))                                     # RK1: ladder.suspicious() -> list of {uid, why, t}

    @owner_only
    async def h_reindex(req: web.Request, uid: int) -> web.StreamResponse:
        return J(await lo.reindex_names(S()))                                             # (once after the first install; later `touch` keeps the index current)

    # ---------------------------------------------------------------- routes + lifecycle
    app.router.add_get("/api/flags", h_flags)
    app.router.add_get("/api/owner/liveops", h_overview)
    app.router.add_get("/api/owner/liveops/section/{name}", h_section)
    app.router.add_post("/api/owner/liveops/section/{name}/check", h_check)
    app.router.add_post("/api/owner/liveops/section/{name}", h_save)
    app.router.add_post("/api/owner/liveops/revert", h_revert)
    app.router.add_get("/api/owner/liveops/versions", h_versions)
    app.router.add_get("/api/owner/liveops/audit", h_audit)
    app.router.add_get("/api/owner/liveops/export", h_export)
    app.router.add_post("/api/owner/liveops/import", h_import)
    app.router.add_get("/api/owner/checklist", h_checklist)
    app.router.add_get("/api/owner/players", h_players)
    app.router.add_post("/api/owner/players/reindex", h_reindex)
    app.router.add_get("/api/owner/players/{uid}", h_player)
    app.router.add_post("/api/owner/players/{uid}/gift", h_gift)
    app.router.add_post("/api/owner/players/{uid}/mute", h_mute)
    app.router.add_get("/api/owner/mutes", h_mutes)
    app.router.add_get("/api/owner/reports", h_reports)
    app.router.add_get("/api/owner/suspicious", h_suspicious)

    async def _start(_app: web.Application) -> None:
        await lo._sync()                                                                    # (the first config is in memory before the first request)
        lo.start()

    async def _stop(_app: web.Application) -> None:
        await lo.stop()

    app.on_startup.append(_start)
    app.on_cleanup.append(_stop)
