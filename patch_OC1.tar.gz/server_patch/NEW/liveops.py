"""Blue Wall live-ops: the owner's monthly control panel, server half (OC1).

ONE place where every feature's tunable numbers live, editable by the owner from inside the game, with no deploy.

Contract for the other modules (ROUND8_COMMON §3) - all four are synchronous and cheap:

    liveops.get(section)                    -> dict   the section = its registered defaults with the owner's saved overrides on top (a fresh copy, safe to mutate)
    liveops.flag(name)                      -> bool   the on/off switches (``flags`` section)
    liveops.season()                        -> {"id","start","end", ...} | None     the running season (start / end = epoch seconds)
    liveops.register(section, defaults, validate)   call once at import time; ``validate(d) -> list[str]`` (errors) judges the WHOLE section

A change the owner saves is seen by every process in <= 30 s without a restart (a 10 s poll of one tiny Redis key + a safety net in ``get``).

Storage (Redis, or memory when BLUEWALL_STATE=memory - same shape as state.py):
    bluewall:lo:cfg     JSON {"v": rev, "sec": {name: {"d": overrides-only, "r": section rev, "t": time, "by": uid}}}
    bluewall:lo:rev     the rev alone (what the poll reads)
    bluewall:lo:ver     LIST, newest first, the last 20 versions (a snapshot of every section's overrides: one-button revert)
    bluewall:lo:audit   LIST, newest first, the last 1000 changes {t, by, act, sec, v, diff[{p,o,n}], note}
    bluewall:lo:rid:<id>  SET NX EX 7 d - a request id already served (a retried POST can never gift twice)
    bluewall:lo:names   HASH uid -> display name   (the owner's player search)
    bluewall:lo:mute    HASH uid -> JSON {until, by, reason, t}

What a save does, in this order: the shape of the values is checked against the registered defaults (unknown key -> refused, wrong type -> refused,
numbers clamped to the registered limits and reported), then the section's own ``validate``; only then it is written, as one new revision, with a
version snapshot and an audit line.  Only overrides are stored (a value equal to its default is not), so a default changed in code still reaches
every value the owner never touched.

Nothing in here talks to the bot or to a player; the routes are in ownerapi.py (owner-only, checked on the server).
"""
from __future__ import annotations

import asyncio
import copy
import importlib
import inspect
import json
import logging
import math
import re
import time
import unicodedata
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("bluewall.liveops")

CFG_KEY = "bluewall:lo:cfg"
REV_KEY = "bluewall:lo:rev"
VER_KEY = "bluewall:lo:ver"
AUD_KEY = "bluewall:lo:audit"
RID_KEY = "bluewall:lo:rid:%s"
NAMES_KEY = "bluewall:lo:names"
MUTE_KEY = "bluewall:lo:mute"

POLL_S = 10.0                 # the background poll
MAX_AGE_S = 25.0              # `get` starts a refresh itself when the last good poll is older than this (so the 30 s promise holds even if the loop died)
KEEP_VERSIONS = 20
KEEP_AUDIT = 1000
RID_TTL = 7 * 86400
MAX_SECTION_BYTES = 32 * 1024
MAX_CONFIG_BYTES = 256 * 1024
MAX_DEPTH = 6
MAX_STR = 200
MAX_LIST = 200
GLOBAL_NUM = 1e12
MAX_MUTE_S = 30 * 86400
NAME_RX = re.compile(r"^[a-z][a-z0-9_]{0,23}$")
ID_RX = re.compile(r"^[A-Za-z0-9_.+-]{1,24}$")
FMT = "bluewall-liveops/1"

try:                                                           # (Iran has had no daylight saving since 2022, so the fixed offset below is exact for every date that matters)
    from zoneinfo import ZoneInfo
    TEHRAN = ZoneInfo("Asia/Tehran")
except Exception:  # noqa: BLE001
    TEHRAN = timezone(timedelta(hours=3, minutes=30))


GIFT_GEMS = ("turq", "emerald", "ruby", "sap", "onyx")
RID_RX = re.compile(r"^[A-Za-z0-9_-]{8,36}$")
MAX_MUTE_MIN = MAX_MUTE_S // 60
REINDEX_MAX = 100000
REINDEX_SECONDS = 20.0


async def call_hook(module: str, fn: str, *args: Any) -> Dict[str, Any]:
    """call `bluewall.<module>.<fn>(*args)` if that module / function exists (CH1 / FR1 / RK1 are merged later).  Never raises:
    {"state": "absent"} | {"state": "called", "value": ...} | {"state": "error"}."""
    try:
        mod = importlib.import_module((__package__ or "bluewall") + "." + module)
    except ImportError:
        return {"state": "absent"}
    f = getattr(mod, fn, None)
    if not callable(f):
        return {"state": "absent"}
    try:
        v = f(*args)
        return {"state": "called", "value": await v if inspect.isawaitable(v) else v}
    except Exception as e:  # noqa: BLE001
        log.warning("hook %s.%s failed: %s", module, fn, e)
        return {"state": "error"}


# ---------------------------------------------------------------------------------------------------- time (Asia/Tehran, rule 9)
def parse_tehran(s: Any) -> Optional[int]:
    """'YYYY-MM-DD HH:MM' (also with 'T' or seconds) in Tehran time -> epoch seconds; None when it does not parse."""
    if not isinstance(s, str):
        return None
    t = s.strip().replace("T", " ")
    for f in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return int(datetime.strptime(t, f).replace(tzinfo=TEHRAN).timestamp())
        except ValueError:
            continue
    return None


def fmt_tehran(ts: float) -> str:
    return datetime.fromtimestamp(float(ts), TEHRAN).strftime("%Y-%m-%d %H:%M")


# ---------------------------------------------------------------------------------------------------- generic JSON-tree helpers
def _isnum(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _isscalar(v: Any) -> bool:
    return v is None or isinstance(v, (bool, str)) or _isnum(v)


def _strip_ctrl(s: str) -> str:
    return "".join(ch for ch in s if unicodedata.category(ch) not in ("Cc", "Cf", "Cs", "Co", "Cn", "Zl", "Zp")).strip()


def _jsonable(v: Any, depth: int = 0) -> bool:
    if depth > MAX_DEPTH + 2:
        return False
    if _isscalar(v):
        return True
    if isinstance(v, list):
        return all(_jsonable(x, depth + 1) for x in v)
    if isinstance(v, dict):
        return all(isinstance(k, str) and _jsonable(x, depth + 1) for k, x in v.items())
    return False


def _norm(path: str) -> str:
    return re.sub(r"\[\d+\]", "[]", path)


def _pat_re(pat: str):
    return re.compile("^" + re.escape(pat).replace(r"\*", "[^.\\[\\]]*") + "$")


class _Ctx:
    def __init__(self, limits: Dict[str, Tuple[float, float]], templates: Dict[str, Any]) -> None:
        self.errs: List[str] = []
        self.clamped: List[Dict[str, Any]] = []
        self.limits = [(_pat_re(k), k, v) for k, v in (limits or {}).items()]
        self.templates = templates or {}

    def lim(self, npath: str, suffix: str = "") -> Optional[Tuple[float, float]]:
        key = npath + suffix
        for rx, _k, v in self.limits:
            if rx.match(key):
                return v
        return None


def _clean(d: Any, v: Any, path: str, npath: str, ctx: _Ctx, depth: int = 0) -> Any:
    """`v` (what the owner sent) judged against `d` (the registered default of the same place).  Returns the cleaned value; problems go to ctx.errs, never raise."""
    p = path or "(section)"
    if depth > MAX_DEPTH:
        ctx.errs.append("%s: nested too deep" % p)
        return copy.deepcopy(d)
    if isinstance(d, dict):
        if not isinstance(v, dict):
            ctx.errs.append("%s: expected an object" % p)
            return copy.deepcopy(d)
        for k in v:
            if k not in d:
                ctx.errs.append("%s: unknown key '%s'" % (p, k))
        out = {}
        for k, dv in d.items():
            out[k] = _clean(dv, v[k], (path + "." + k) if path else k, (npath + "." + k) if npath else k, ctx, depth + 1) if k in v else copy.deepcopy(dv)
        return out
    if isinstance(d, list):
        if not isinstance(v, list):
            ctx.errs.append("%s: expected a list" % p)
            return copy.deepcopy(d)
        lo, hi = ctx.lim(npath, "#len") or (0, MAX_LIST)
        hi = min(int(hi), MAX_LIST)
        if len(v) > hi:
            ctx.errs.append("%s: at most %d rows (got %d)" % (p, hi, len(v)))
            return copy.deepcopy(d)
        if len(v) < int(lo):
            ctx.errs.append("%s: at least %d rows (got %d)" % (p, int(lo), len(v)))
            return copy.deepcopy(d)
        tmpl = d[0] if d else ctx.templates.get(npath)
        out = []
        for i, row in enumerate(v):
            if tmpl is None:                                                           # (no row shape known: plain values only)
                if not _isscalar(row):
                    ctx.errs.append("%s[%d]: expected a plain value" % (p, i))
                    continue
                out.append(_clean(row if row is not None else "", row if row is not None else "", "%s[%d]" % (path, i), npath + "[]", ctx, depth + 1))
            else:
                out.append(_clean(tmpl, row, "%s[%d]" % (path, i), npath + "[]", ctx, depth + 1))
        return out
    if isinstance(d, bool):
        if not isinstance(v, bool):
            ctx.errs.append("%s: expected true / false" % p)
            return d
        return v
    if _isnum(d):
        if not _isnum(v):
            ctx.errs.append("%s: expected a number" % p)
            return d
        lo, hi = ctx.lim(npath) or (-GLOBAL_NUM, GLOBAL_NUM)
        x = min(max(float(v), float(lo)), float(hi))
        if isinstance(d, int) and not isinstance(d, bool):
            x = int(round(x))
        elif isinstance(d, float):
            x = float(x)
        if x != v:
            ctx.clamped.append({"p": p, "from": v, "to": x})
        return x
    if isinstance(d, str):
        if not isinstance(v, str):
            ctx.errs.append("%s: expected text" % p)
            return d
        s = _strip_ctrl(v)
        lo, hi = ctx.lim(npath, "#len") or (0, MAX_STR)
        if len(s) > int(hi):
            ctx.clamped.append({"p": p, "from": s[:24] + "...", "to": "%d chars" % int(hi)})
            s = s[:int(hi)]
        if len(s) < int(lo):
            ctx.errs.append("%s: at least %d characters" % (p, int(lo)))
        return s
    if d is None:
        if not _isscalar(v):
            ctx.errs.append("%s: expected a plain value" % p)
            return None
        return _strip_ctrl(v)[:MAX_STR] if isinstance(v, str) else v
    ctx.errs.append("%s: cannot be edited" % p)
    return copy.deepcopy(d)


def _merge(d: Any, o: Any, npath: str = "", templates: Optional[Dict[str, Any]] = None) -> Any:
    """defaults `d` + saved overrides `o` -> the live value.  Total: a stale / wrong-typed override falls back to the default of that one place."""
    templates = templates or {}
    if isinstance(d, dict):
        if not isinstance(o, dict):
            return copy.deepcopy(d)
        return {k: (_merge(v, o[k], (npath + "." + k) if npath else k, templates) if k in o else copy.deepcopy(v)) for k, v in d.items()}
    if isinstance(d, list):
        if not isinstance(o, list):
            return copy.deepcopy(d)
        tmpl = d[0] if d else templates.get(npath)
        if isinstance(tmpl, dict):                                                    # (rows: fill a key a newer code version added, drop one it removed)
            return [_merge(tmpl, r, npath + "[]", templates) if isinstance(r, dict) else copy.deepcopy(tmpl) for r in o]
        return copy.deepcopy(o)
    if isinstance(d, bool):
        return o if isinstance(o, bool) else d
    if _isnum(d):
        if not _isnum(o):
            return d
        return int(round(o)) if (isinstance(d, int) and not isinstance(d, bool)) else float(o)
    if isinstance(d, str):
        return o if isinstance(o, str) else d
    return o if _isscalar(o) else d


def _overrides(d: Any, m: Any) -> Any:
    """the part of `m` that differs from `d` ({} / absent = nothing)."""
    if isinstance(d, dict) and isinstance(m, dict):
        out = {}
        for k in d:
            if k in m and (m[k] != d[k] or type(m[k]) is not type(d[k])):
                out[k] = _overrides(d[k], m[k]) if isinstance(d[k], dict) and isinstance(m[k], dict) else copy.deepcopy(m[k])
        return out
    return copy.deepcopy(m)


def _clip(v: Any) -> Any:
    if isinstance(v, (dict, list)):
        s = json.dumps(v, ensure_ascii=False, separators=(",", ":"))
        return s if len(s) <= 120 else s[:117] + "..."
    if isinstance(v, str) and len(v) > 120:
        return v[:117] + "..."
    return v


def diff(old: Any, new: Any, path: str = "", out: Optional[List[Dict[str, Any]]] = None, cap: int = 60) -> List[Dict[str, Any]]:
    """path-level changes {p, o, n} between two section values (at most `cap`; the last item says how many more)."""
    out = [] if out is None else out
    if len(out) > cap:
        return out
    if isinstance(old, dict) and isinstance(new, dict):
        for k in list(old) + [k for k in new if k not in old]:
            diff(old.get(k), new.get(k), (path + "." + k) if path else k, out, cap)
    elif isinstance(old, list) and isinstance(new, list):
        for i in range(max(len(old), len(new))):
            diff(old[i] if i < len(old) else None, new[i] if i < len(new) else None, "%s[%d]" % (path, i), out, cap)
    elif old != new:
        if len(out) >= cap:
            out.append({"p": "...", "o": None, "n": None})
        else:
            out.append({"p": path or "(section)", "o": _clip(old), "n": _clip(new)})
    return out


# ---------------------------------------------------------------------------------------------------- the built-in sections
FLAG_NAMES = ("friends", "chat_global", "chat_dm", "chat_clan", "friendly", "clan_war", "pass", "wheel", "missions", "daily", "season")
FLAGS_DEFAULTS: Dict[str, Any] = {k: (k != "clan_war") for k in FLAG_NAMES}       # (everything on except the clan war)
SEASON_ROW = {"id": "", "start": "", "end": "", "pass_ready": False, "league_ready": False}
SEASON_DEFAULTS: Dict[str, Any] = {"auto_chain": False, "warn_days": 3, "seasons": []}
SEASON_LIMITS = {"warn_days": (0, 30), "seasons#len": (0, 60), "seasons[].id#len": (1, 24), "seasons[].start#len": (0, 20), "seasons[].end#len": (0, 20)}
SEASON_TEMPLATES = {"seasons": SEASON_ROW}


def _flags_validate(d: Dict[str, Any]) -> List[str]:
    return ["%s: must be true or false" % k for k, v in d.items() if not isinstance(v, bool)]


def _season_rows(d: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[str]]:
    errs: List[str] = []
    rows: List[Dict[str, Any]] = []
    seen = set()
    for i, r in enumerate(d.get("seasons") or []):
        if not isinstance(r, dict):
            continue
        sid = str(r.get("id") or "")
        a, b = parse_tehran(r.get("start")), parse_tehran(r.get("end"))
        if not ID_RX.match(sid):
            errs.append("seasons[%d]: id must be 1-24 letters, digits or _ . + -" % i)
        if sid in seen:
            errs.append("seasons[%d]: id '%s' is used twice" % (i, sid))
        seen.add(sid)
        if a is None or b is None:
            errs.append("seasons[%d]: start / end must look like 2026-11-01 00:00 (Tehran time)" % i)
            continue
        if not (86400 <= b - a <= 100 * 86400):
            errs.append("seasons[%d]: a season lasts 1 to 100 days" % i)
            continue
        rows.append({"id": sid, "start": a, "end": b, "i": i, "pass_ready": bool(r.get("pass_ready")), "league_ready": bool(r.get("league_ready"))})
    rows.sort(key=lambda r: r["start"])
    for x, y in zip(rows, rows[1:]):
        if y["start"] < x["end"]:
            errs.append("seasons '%s' and '%s' overlap" % (x["id"], y["id"]))
    return rows, errs


def _season_validate(d: Dict[str, Any]) -> List[str]:
    return _season_rows(d)[1]


class _Section:
    def __init__(self, name: str, defaults: Dict[str, Any], validate: Optional[Callable], limits: Optional[Dict[str, Any]], templates: Optional[Dict[str, Any]], title: str) -> None:
        self.name, self.defaults, self.validate = name, defaults, validate
        self.limits, self.templates, self.title = dict(limits or {}), dict(templates or {}), title


class LiveOps:
    def __init__(self, redis_fn: Optional[Callable[[], Any]] = None) -> None:
        self._redis_fn = redis_fn                       # async () -> redis client | None ; default = the game's own STORE (lazy: state.py imports half the server)
        self.clock: Callable[[], float] = time.time
        self.mono: Callable[[], float] = time.monotonic
        self._reg: Dict[str, _Section] = {}
        self._blob: Dict[str, Any] = {"v": 0, "sec": {}}
        self._cache: Dict[str, str] = {}                # section -> JSON of the merged value (a fresh dict per `get`)
        self._flags: Dict[str, bool] = dict(FLAGS_DEFAULTS)
        self._rows_cache: Optional[Tuple[int, List[Dict[str, Any]]]] = None
        self._checked = -1e9
        self._loaded = False
        self._task: Optional[asyncio.Task] = None
        self._loop_task: Optional[asyncio.Task] = None
        self._wlock: Optional[asyncio.Lock] = None
        self._wloop: Any = None
        self._mem_ver: List[str] = []
        self._mem_aud: List[str] = []
        self._mem_rid: Dict[str, float] = {}
        self._mem_names: Dict[int, str] = {}
        self._mem_mute: Dict[int, Dict[str, Any]] = {}
        self._mutes: Dict[int, float] = {}
        self._names_seen: Dict[int, str] = {}
        self.register("flags", FLAGS_DEFAULTS, _flags_validate, title="Feature switches")
        self.register("season", SEASON_DEFAULTS, _season_validate, limits=SEASON_LIMITS, templates=SEASON_TEMPLATES, title="Seasons")

    # ------------------------------------------------------------------ registry
    def register(self, section: str, defaults: Dict[str, Any], validate: Optional[Callable] = None, *, limits: Optional[Dict[str, Any]] = None,
                 templates: Optional[Dict[str, Any]] = None, title: Optional[str] = None) -> None:
        """Call once at import time.  `defaults` = the section's JSON shape and its default values (dict of dicts / lists / numbers / text / true-false);
        `validate(d) -> list[str]` judges a whole merged section (an empty list = fine); `limits` = {"path": (lo, hi)} number bounds that save CLAMPS to
        (path like "prizes.top[].gems"; "*" = any one name), "path#len" = (min, max) length of a list or a text;  `templates` = {"path": row} the shape of a
        row for a list whose default is empty."""
        if not isinstance(section, str) or not NAME_RX.match(section):
            raise ValueError("liveops section name must match %s" % NAME_RX.pattern)
        if not isinstance(defaults, dict) or not _jsonable(defaults):
            raise ValueError("liveops defaults of '%s' must be a dict of plain JSON values" % section)
        if validate is not None and not callable(validate):
            raise ValueError("validate must be callable")
        sec = _Section(section, copy.deepcopy(defaults), validate, limits, templates, title or section.replace("_", " ").title())
        self._reg[section] = sec
        ctx = _Ctx(sec.limits, sec.templates)
        probe = _clean(sec.defaults, copy.deepcopy(sec.defaults), "", "", ctx)
        errs = ctx.errs + (self._run_validate(sec, probe) if validate else [])
        if errs:
            log.error("liveops: the defaults of '%s' do not pass their own checks: %s", section, errs[:5])
        self._rebuild_one(section)

    def sections(self) -> List[str]:
        return list(self._reg)

    def info(self, section: str) -> Optional[Dict[str, Any]]:
        """what a form needs to draw a section: {name, title, defaults, limits, templates} (None = not registered).  Used by the HTTP routes and by the bot panel."""
        sec = self._reg.get(section)
        if sec is None:
            return None
        return {"name": section, "title": sec.title, "defaults": json.loads(json.dumps(sec.defaults)),
                "limits": {k: list(v) for k, v in sec.limits.items()}, "templates": json.loads(json.dumps(sec.templates))}

    def _run_validate(self, sec: _Section, merged: Dict[str, Any]) -> List[str]:
        if sec.validate is None:
            return []
        try:
            res = sec.validate(copy.deepcopy(merged))
        except Exception as e:  # noqa: BLE001
            log.exception("liveops: validate of '%s' crashed", sec.name)
            return ["%s: the checker crashed (%s)" % (sec.name, type(e).__name__)]
        if res is None:
            return []
        if isinstance(res, str):
            return [res[:200]]
        return [str(x)[:200] for x in list(res)[:50]]

    # ------------------------------------------------------------------ reads (sync)
    def _rebuild_one(self, name: str) -> None:
        sec = self._reg[name]
        ov = ((self._blob.get("sec") or {}).get(name) or {}).get("d")
        self._cache[name] = json.dumps(_merge(sec.defaults, ov, "", sec.templates), separators=(",", ":"))
        if name == "flags":
            m = json.loads(self._cache[name])
            self._flags = {k: bool(v) for k, v in m.items()}
        if name == "season":
            self._rows_cache = None

    def _rebuild(self) -> None:
        for n in self._reg:
            self._rebuild_one(n)

    def _stale_guard(self) -> None:
        if self.mono() - self._checked <= MAX_AGE_S:
            return
        if self._task is None or self._task.done():
            try:
                self._task = asyncio.get_running_loop().create_task(self.refresh())
            except RuntimeError:
                pass                                                                  # (no loop: a script / a test; the caller refreshes by hand)

    def get(self, section: str) -> Dict[str, Any]:
        self._stale_guard()
        c = self._cache.get(section)
        if c is None:
            raise KeyError("liveops section '%s' is not registered" % section)
        return json.loads(c)

    def flag(self, name: str) -> bool:
        self._stale_guard()
        return bool(self._flags.get(name, False))

    def rev(self) -> int:
        return int(self._blob.get("v") or 0)

    def srev(self, section: str) -> int:
        return int(((self._blob.get("sec") or {}).get(section) or {}).get("r") or 0)

    def has_overrides(self, section: str) -> bool:
        return bool(((self._blob.get("sec") or {}).get(section) or {}).get("d"))

    # ------------------------------------------------------------------ seasons
    def _season_list(self, now: float) -> List[Dict[str, Any]]:
        """the season rows (epoch seconds), plus - when `auto_chain` is on and the last one is over - the follow-ups of the same length made up on the fly."""
        key = self.rev()
        if self._rows_cache is None or self._rows_cache[0] != key:
            cfg = json.loads(self._cache["season"])
            rows, _e = _season_rows(cfg)
            self._rows_cache = (key, rows)
        rows = [dict(r, auto=False) for r in self._rows_cache[1]]
        cfg_chain = bool(json.loads(self._cache["season"]).get("auto_chain"))
        if cfg_chain and rows and now >= rows[-1]["end"]:
            last = rows[-1]
            span = last["end"] - last["start"]
            k = int((now - last["end"]) // span) + 1
            for j in range(1, k + 1):
                a = last["end"] + (j - 1) * span
                rows.append({"id": "%s+%d" % (last["id"], j), "start": a, "end": a + span, "i": -1, "pass_ready": False, "league_ready": False, "auto": True})
        return rows

    def season(self, now: Optional[float] = None) -> Optional[Dict[str, Any]]:
        """the running Battle Pass season {id, start, end (epoch s), start_s, end_s (Tehran text), auto} or None."""
        self._stale_guard()
        t = self.clock() if now is None else float(now)
        for r in self._season_list(t):
            if r["start"] <= t < r["end"]:
                return {"id": r["id"], "start": int(r["start"]), "end": int(r["end"]), "start_s": fmt_tehran(r["start"]), "end_s": fmt_tehran(r["end"]), "auto": bool(r["auto"])}
        return None

    def checklist(self, now: Optional[float] = None) -> Dict[str, Any]:
        """the owner's monthly checklist: the season now, whether the next one (and its prizes) is ready, and a warning when time is short."""
        t = self.clock() if now is None else float(now)
        cfg = json.loads(self._cache["season"])
        warn_days = float(cfg.get("warn_days") or 3)
        rows = self._season_list(t)
        cur = next((r for r in rows if r["start"] <= t < r["end"]), None)
        items: List[Dict[str, str]] = []

        def add(i: str, level: str, text: str) -> None:
            items.append({"id": i, "level": level, "text": text})
        out: Dict[str, Any] = {"now": int(t), "now_s": fmt_tehran(t), "warn_days": warn_days, "current": None, "next": None, "days_left": None, "items": items, "rev": self.rev()}
        if cur is None:
            nxt0 = next((r for r in rows if r["start"] > t), None)
            if nxt0:
                add("season", "warn", "No season is running now. '%s' starts %s." % (nxt0["id"], fmt_tehran(nxt0["start"])))
            else:
                add("season", "alert", "No season is running and none is set. Add one under Seasons.")
            out["next"] = {"id": nxt0["id"], "start_s": fmt_tehran(nxt0["start"]), "end_s": fmt_tehran(nxt0["end"])} if nxt0 else None
        else:
            left = (cur["end"] - t) / 86400.0
            out["current"] = {"id": cur["id"], "start_s": fmt_tehran(cur["start"]), "end_s": fmt_tehran(cur["end"]), "auto": cur["auto"]}
            out["days_left"] = round(left, 2)
            add("season", "ok", "Season '%s': %s -> %s (%.1f days left)%s." % (cur["id"], fmt_tehran(cur["start"]), fmt_tehran(cur["end"]), left, ", made up automatically (auto-chain)" if cur["auto"] else ""))
            if cur["auto"]:
                add("auto", "warn", "The running season was made up by auto-chain: set the real next season and its prizes.")
            nxt = next((r for r in rows if r["start"] >= cur["end"] and not r["auto"]), None)
            short = left < warn_days
            if nxt is None:
                add("next", "alert" if short else "todo", "Next season is not set%s." % (" and the current one ends in %.1f days" % left if short else " yet"))
            else:
                out["next"] = {"id": nxt["id"], "start_s": fmt_tehran(nxt["start"]), "end_s": fmt_tehran(nxt["end"])}
                gap = nxt["start"] - cur["end"]
                add("next", "ok" if gap <= 3600 else "warn", "Next season '%s': %s -> %s%s." % (nxt["id"], fmt_tehran(nxt["start"]), fmt_tehran(nxt["end"]), "" if gap <= 3600 else " (a %.1f day gap after the current season)" % (gap / 86400.0)))
                for sec, tick in (("pass", "pass_ready"), ("league", "league_ready")):
                    if sec not in self._reg:
                        continue                                                      # (that feature is not in this build: nothing to prepare)
                    auto = False
                    try:
                        m = (json.loads(self._cache[sec]).get("seasons"))
                        auto = isinstance(m, dict) and bool(m.get(nxt["id"]))
                    except Exception:  # noqa: BLE001
                        auto = False
                    if auto or nxt.get(tick):
                        add("prizes_" + sec, "ok", "%s prizes for '%s' are set%s." % (sec.title(), nxt["id"], "" if auto else " (ticked by you)"))
                    else:
                        add("prizes_" + sec, "alert" if short else "todo", "%s prizes for '%s' are not set%s." % (sec.title(), nxt["id"], " - the season ends in %.1f days" % left if short else " yet"))
        if "pass" in self._reg and self.flag("pass") and cur is None:
            add("pass_flag", "warn", "The Battle Pass switch is on but no season is running.")
        off = [k for k in FLAG_NAMES if not self._flags.get(k)]
        add("flags", "ok" if not off else "todo", "Switched off: %s." % ", ".join(off) if off else "Every feature switch is on.")
        order = {"ok": 0, "todo": 1, "warn": 2, "alert": 3}
        out["worst"] = max((i["level"] for i in items), key=lambda x: order[x])
        return out

    # ------------------------------------------------------------------ storage plumbing
    async def _redis(self):
        try:
            if self._redis_fn is not None:
                return await self._redis_fn()
            from .state import STORE
            return await STORE._redis()
        except Exception as e:  # noqa: BLE001
            log.warning("liveops: no redis (%s)", e)
            return None

    @staticmethod
    async def _t(coro, t: float = 2.0):
        return await asyncio.wait_for(coro, t)

    def _apply_blob(self, blob: Dict[str, Any]) -> None:
        self._blob = {"v": int(blob.get("v") or 0), "sec": {k: v for k, v in (blob.get("sec") or {}).items() if isinstance(v, dict) and isinstance(v.get("d"), dict)}}
        self._rebuild()

    def _lock(self) -> asyncio.Lock:
        loop = asyncio.get_running_loop()
        if self._wlock is None or self._wloop is not loop:                              # (one lock per event loop: tests start several)
            self._wlock, self._wloop = asyncio.Lock(), loop
        return self._wlock

    async def _sync(self) -> bool:
        """load the newest config from Redis right now.  False = it could not be read (a writer must then refuse: it would write on a stale copy)."""
        r = await self._redis()
        if r is None:                                                                  # (memory mode: this process is the only copy)
            self._checked, self._loaded = self.mono(), True
            return True
        try:
            raw = await self._t(r.get(CFG_KEY))
            blob = json.loads(raw) if raw else {"v": 0, "sec": {}}
            if not isinstance(blob, dict):
                raise ValueError("bad config blob")
            self._apply_blob(blob)
            await self._load_mutes(r)
            self._checked, self._loaded = self.mono(), True
            return True
        except Exception as e:  # noqa: BLE001
            log.warning("liveops: config not read: %s (the last good copy stays)", e)
            return False

    async def refresh(self, force: bool = False) -> bool:
        """re-read the config when another process changed it (one tiny GET); keeps the last good copy on any failure.  True = something new was loaded."""
        r = await self._redis()
        if r is None:
            self._checked, self._loaded = self.mono(), True
            return False
        try:
            rv = int(await self._t(r.get(REV_KEY)) or 0)
        except Exception as e:  # noqa: BLE001
            log.warning("liveops refresh failed: %s (the last good copy stays)", e)
            return False
        if not force and self._loaded and rv == self.rev():
            self._checked = self.mono()
            return False
        return await self._sync()

    async def _load_mutes(self, r: Any) -> None:
        try:
            h = await self._t(r.hgetall(MUTE_KEY))
            now = self.clock()
            m = {}
            for u, raw in (h or {}).items():
                try:
                    until = float(json.loads(raw).get("until") or 0)
                    if until > now:
                        m[int(u)] = until
                except Exception:  # noqa: BLE001
                    continue
            self._mutes = m
        except Exception as e:  # noqa: BLE001
            log.warning("liveops: mute list not read: %s", e)

    async def run(self) -> None:
        """the background poll (started by ownerapi.add_routes on the app's start-up)."""
        while True:
            try:
                await self.refresh()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception("liveops poll")
            await asyncio.sleep(POLL_S)

    def start(self) -> None:
        if self._loop_task is None or self._loop_task.done():
            self._loop_task = asyncio.get_running_loop().create_task(self.run())

    async def stop(self) -> None:
        if self._loop_task is not None:
            self._loop_task.cancel()
            try:
                await self._loop_task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
            self._loop_task = None

    # ------------------------------------------------------------------ writing
    def _check_section(self, name: str, values: Any) -> Tuple[Optional[Dict[str, Any]], List[str], List[Dict[str, Any]]]:
        sec = self._reg[name]
        ctx = _Ctx(sec.limits, sec.templates)
        if not _jsonable(values):
            return None, ["%s: not plain JSON" % name], []
        if len(json.dumps(values, separators=(",", ":"))) > MAX_SECTION_BYTES:
            return None, ["%s: too large (max %d KB)" % (name, MAX_SECTION_BYTES // 1024)], []
        clean = _clean(sec.defaults, values, "", "", ctx)
        errs = list(ctx.errs)
        if not errs:
            errs += self._run_validate(sec, clean)
        return (None if errs else clean), errs, ctx.clamped

    def _current(self, name: str) -> Dict[str, Any]:
        return json.loads(self._cache[name])

    def _commit_blob(self, blob: Dict[str, Any], changed: List[str], by: int, act: str, note: str, diffs: Dict[str, List[Dict[str, Any]]]) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
        ver = {"v": blob["v"], "t": int(self.clock()), "by": int(by), "act": act, "secs": changed, "note": str(note or "")[:120], "snap": {k: {"d": v["d"], "r": v["r"]} for k, v in blob["sec"].items()}}
        auds = []
        for s in changed:
            dd = diffs.get(s) or []
            more = 0
            if dd and dd[-1].get("p") == "...":
                dd, more = dd[:-1], 1
            auds.append({"t": int(self.clock()), "by": int(by), "act": act, "sec": s, "v": blob["v"], "diff": dd, "more": more, "note": str(note or "")[:120]})
        return ver, auds

    async def _write(self, blob: Dict[str, Any], ver: Dict[str, Any], auds: List[Dict[str, Any]], prev_rev: int) -> str:
        """'ok' | 'conflict' (another process saved since we read: nothing written) | 'size' | 'store'.  Redis: WATCH on the rev + one MULTI/EXEC, so two
        processes (or two of the owner's devices) can never overwrite each other."""
        raw = json.dumps(blob, separators=(",", ":"))
        if len(raw) > MAX_CONFIG_BYTES:
            return "size"
        vraw = json.dumps(ver, separators=(",", ":"))
        araws = [json.dumps(a, separators=(",", ":"), ensure_ascii=False) for a in auds]
        r = await self._redis()
        if r is None:
            self._mem_ver.insert(0, vraw)
            del self._mem_ver[KEEP_VERSIONS:]
            for a in araws:
                self._mem_aud.insert(0, a)
            del self._mem_aud[KEEP_AUDIT:]
            return "ok"
        try:
            async with r.pipeline(transaction=True) as pipe:
                await self._t(pipe.watch(REV_KEY), 2.0)
                cur = int(await self._t(pipe.get(REV_KEY), 2.0) or 0)
                if cur != int(prev_rev):
                    await self._t(pipe.unwatch(), 2.0)
                    return "conflict"
                pipe.multi()
                pipe.set(CFG_KEY, raw)
                pipe.set(REV_KEY, str(blob["v"]))
                pipe.lpush(VER_KEY, vraw)
                pipe.ltrim(VER_KEY, 0, KEEP_VERSIONS - 1)
                for a in araws:
                    pipe.lpush(AUD_KEY, a)
                pipe.ltrim(AUD_KEY, 0, KEEP_AUDIT - 1)
                await self._t(pipe.execute(), 3.0)
            return "ok"
        except Exception as e:  # noqa: BLE001
            if type(e).__name__ == "WatchError":
                return "conflict"
            log.error("liveops: write failed: %s", e)
            return "store"

    def _next_blob(self, updates: Dict[str, Dict[str, Any]], by: int) -> Dict[str, Any]:
        blob = {"v": self.rev() + 1, "sec": copy.deepcopy(self._blob.get("sec") or {})}
        now = int(self.clock())
        for name, ov in updates.items():
            if ov:
                blob["sec"][name] = {"d": ov, "r": self.srev(name) + 1, "t": now, "by": int(by)}
            else:
                blob["sec"][name] = {"d": {}, "r": self.srev(name) + 1, "t": now, "by": int(by)}
        return blob

    async def _apply(self, updates: Dict[str, Dict[str, Any]], by: int, act: str, note: str, before: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """`updates`: section -> overrides.  One new revision for all of them.  (use inside self._wlock)"""
        blob = self._next_blob(updates, by)
        diffs = {n: diff(before[n], _merge(self._reg[n].defaults, updates[n], "", self._reg[n].templates)) for n in updates}
        changed = [n for n in updates if diffs[n]]
        if not changed:
            return {"ok": True, "noop": True, "rev": self.rev()}
        for n in updates:                                                              # (sections that did not change keep their revision)
            if n not in changed:
                if n in (self._blob.get("sec") or {}):
                    blob["sec"][n] = copy.deepcopy(self._blob["sec"][n])
                else:
                    blob["sec"].pop(n, None)
        ver, auds = self._commit_blob(blob, changed, by, act, note, diffs)
        res = await self._write(blob, ver, auds, self.rev())
        if res != "ok":
            if res == "conflict":
                await self._sync()                                                    # (catch up; the owner's screen reloads and asks again)
                return {"ok": False, "why": "busy"}
            return {"ok": False, "why": "size" if res == "size" else "store"}
        self._apply_blob(blob)
        self._checked = self.mono()
        return {"ok": True, "rev": blob["v"], "changed": changed, "diff": diffs}

    async def save(self, section: str, values: Any, by: int, base_rev: Optional[int] = None, note: str = "", dry: bool = False) -> Dict[str, Any]:
        """validate (+ save).  Errors -> {ok False, why 'invalid', errors}; a section changed by someone else since `base_rev` -> {why 'stale'}."""
        if section not in self._reg:
            return {"ok": False, "why": "section"}
        if not dry:
            async with self._lock():
                return await self._save_locked(section, values, by, base_rev, note, False)
        return await self._save_locked(section, values, by, base_rev, note, True)

    async def _save_locked(self, section: str, values: Any, by: int, base_rev: Optional[int], note: str, dry: bool) -> Dict[str, Any]:
        if not dry and not await self._sync():
            return {"ok": False, "why": "store"}
        clean, errs, clamped = self._check_section(section, values)
        if errs:
            return {"ok": False, "why": "invalid", "errors": errs[:50]}
        before = self._current(section)
        dd = diff(before, clean)
        if dry:
            return {"ok": True, "dry": True, "errors": [], "diff": dd, "clamped": clamped, "values": clean, "noop": not dd}
        if base_rev is not None and int(base_rev) != self.srev(section):
            return {"ok": False, "why": "stale", "srev": self.srev(section), "values": before}
        res = await self._apply({section: _overrides(self._reg[section].defaults, clean)}, by, "save", note, {section: before})
        if res.get("ok"):
            res.update({"section": section, "srev": self.srev(section), "values": self._current(section), "clamped": clamped, "diff": res.get("diff", {}).get(section, [])})
        return res

    async def revert(self, version: int, by: int, section: Optional[str] = None, note: str = "") -> Dict[str, Any]:
        """put one section (or every section) back to what it was in version `version` (one of the last 20)."""
        async with self._lock():
            if not await self._sync():
                return {"ok": False, "why": "store"}
            vs = await self.versions(full=True)
            rec = next((v for v in vs if int(v.get("v", -1)) == int(version)), None)
            if rec is None:
                return {"ok": False, "why": "gone"}
            snap = rec.get("snap") or {}
            names = [section] if section else list(self._reg)
            if section and section not in self._reg:
                return {"ok": False, "why": "section"}
            updates, before, errs = {}, {}, []
            for n in names:
                ov = (snap.get(n) or {}).get("d") or {}
                merged = _merge(self._reg[n].defaults, ov, "", self._reg[n].templates)
                clean, e, _c = self._check_section(n, merged)
                if e:
                    errs += ["%s: %s" % (n, x) for x in e]
                    continue
                updates[n] = _overrides(self._reg[n].defaults, clean)
                before[n] = self._current(n)
            if errs:
                return {"ok": False, "why": "invalid", "errors": errs[:50]}
            res = await self._apply(updates, by, "revert", note or ("to v%d" % int(version)), before)
            if res.get("ok") and not res.get("noop"):
                res["sections"] = {n: self._current(n) for n in res.get("changed", [])}
            return res

    def export(self) -> Dict[str, Any]:
        return {"format": FMT, "rev": self.rev(), "t": int(self.clock()), "sections": {n: self._current(n) for n in self._reg}}

    async def import_(self, doc: Any, by: int, dry: bool = False, note: str = "") -> Dict[str, Any]:
        """the whole config from text (copy / paste).  All sections are checked first; one error anywhere = nothing is applied."""
        if not isinstance(doc, dict) or doc.get("format") != FMT or not isinstance(doc.get("sections"), dict):
            return {"ok": False, "why": "format", "errors": ["not a Blue Wall live-ops export (format %s)" % FMT]}
        secs = doc["sections"]
        errs: List[str] = []
        clean: Dict[str, Dict[str, Any]] = {}
        clamped: List[Dict[str, Any]] = []
        for n, v in secs.items():
            if n not in self._reg:
                errs.append("%s: unknown section" % n)
                continue
            c, e, cl = self._check_section(n, v)
            if e:
                errs += ["%s: %s" % (n, x) for x in e]
            else:
                clean[n] = c
                clamped += [dict(x, p="%s.%s" % (n, x["p"])) for x in cl]
        if errs:
            return {"ok": False, "why": "invalid", "errors": errs[:80]}
        before = {n: self._current(n) for n in clean}
        dd = {n: diff(before[n], clean[n]) for n in clean}
        if dry:
            return {"ok": True, "dry": True, "sections": [n for n in clean if dd[n]], "diff": {n: d for n, d in dd.items() if d}, "clamped": clamped}
        async with self._lock():
            if not await self._sync():
                return {"ok": False, "why": "store"}
            res = await self._apply({n: _overrides(self._reg[n].defaults, c) for n, c in clean.items()}, by, "import", note, {n: self._current(n) for n in clean})
            if res.get("ok"):
                res["clamped"] = clamped
            return res

    # ------------------------------------------------------------------ history
    async def versions(self, full: bool = False) -> List[Dict[str, Any]]:
        r = await self._redis()
        raws: List[str] = []
        if r is None:
            raws = list(self._mem_ver)
        else:
            try:
                raws = await self._t(r.lrange(VER_KEY, 0, KEEP_VERSIONS - 1))
            except Exception as e:  # noqa: BLE001
                log.warning("liveops: versions not read: %s", e)
        out = []
        for raw in raws:
            try:
                v = json.loads(raw)
                if not full:
                    v.pop("snap", None)
                out.append(v)
            except Exception:  # noqa: BLE001
                continue
        return out

    async def audit(self, limit: int = 50, offset: int = 0) -> List[Dict[str, Any]]:
        limit, offset = max(1, min(int(limit), 200)), max(0, int(offset))
        r = await self._redis()
        raws: List[str] = []
        if r is None:
            raws = self._mem_aud[offset:offset + limit]
        else:
            try:
                raws = await self._t(r.lrange(AUD_KEY, offset, offset + limit - 1))
            except Exception as e:  # noqa: BLE001
                log.warning("liveops: audit not read: %s", e)
        out = []
        for raw in raws:
            try:
                out.append(json.loads(raw))
            except Exception:  # noqa: BLE001
                continue
        return out

    async def audit_add(self, by: int, act: str, section: str, note: str = "", **extra: Any) -> bool:
        """a line for something that is not a config change (a gift, a mute)."""
        a = dict({"t": int(self.clock()), "by": int(by), "act": act, "sec": section, "v": self.rev(), "diff": [], "more": 0, "note": str(note or "")[:200]}, **extra)
        raw = json.dumps(a, separators=(",", ":"), ensure_ascii=False)
        r = await self._redis()
        if r is None:
            self._mem_aud.insert(0, raw)
            del self._mem_aud[KEEP_AUDIT:]
            return True
        try:
            await self._t(r.lpush(AUD_KEY, raw))
            await self._t(r.ltrim(AUD_KEY, 0, KEEP_AUDIT - 1))
            return True
        except Exception as e:  # noqa: BLE001
            log.warning("liveops: audit line lost: %s", e)
            return False

    # ------------------------------------------------------------------ request ids (a retried POST must not pay twice)
    async def claim_rid(self, rid: str) -> bool:
        """True the first time a request id is seen, False after (7 days)."""
        r = await self._redis()
        if r is None:
            now = self.clock()
            for k in [k for k, t in self._mem_rid.items() if t < now]:
                self._mem_rid.pop(k, None)
            if rid in self._mem_rid:
                return False
            self._mem_rid[rid] = now + RID_TTL
            return True
        try:
            return bool(await self._t(r.set(RID_KEY % rid, "1", nx=True, ex=RID_TTL)))
        except Exception as e:  # noqa: BLE001
            log.warning("liveops: request id not recorded: %s", e)
            raise

    async def release_rid(self, rid: str) -> None:
        r = await self._redis()
        if r is None:
            self._mem_rid.pop(rid, None)
            return
        try:
            await self._t(r.delete(RID_KEY % rid))
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------ chat mute (the owner's list; CH1 reads `is_muted`)
    def is_muted(self, uid: int) -> float:
        """the time (epoch s) a player is muted until, 0 when not.  Sync, from memory (<= 10 s behind another process)."""
        u = self._mutes.get(int(uid), 0.0)
        return u if u > self.clock() else 0.0

    async def mute(self, uid: int, seconds: int, by: int, reason: str = "") -> Dict[str, Any]:
        seconds = int(seconds)
        if seconds <= 0:
            return await self.unmute(uid, by)
        seconds = min(seconds, MAX_MUTE_S)
        until = int(self.clock()) + seconds
        rec = {"until": until, "by": int(by), "reason": str(reason or "")[:120], "t": int(self.clock())}
        r = await self._redis()
        if r is None:
            self._mem_mute[int(uid)] = rec
        else:
            try:
                await self._t(r.hset(MUTE_KEY, str(int(uid)), json.dumps(rec, separators=(",", ":"), ensure_ascii=False)))
            except Exception as e:  # noqa: BLE001
                log.error("liveops: mute not stored: %s", e)
                return {"ok": False, "why": "store"}
        self._mutes[int(uid)] = float(until)
        return {"ok": True, "until": until}

    async def unmute(self, uid: int, by: int) -> Dict[str, Any]:
        r = await self._redis()
        if r is None:
            self._mem_mute.pop(int(uid), None)
        else:
            try:
                await self._t(r.hdel(MUTE_KEY, str(int(uid))))
            except Exception as e:  # noqa: BLE001
                log.error("liveops: unmute not stored: %s", e)
                return {"ok": False, "why": "store"}
        self._mutes.pop(int(uid), None)
        return {"ok": True, "until": 0}

    async def mutes(self) -> List[Dict[str, Any]]:
        r = await self._redis()
        now = self.clock()
        rows = []
        if r is None:
            items = [(u, dict(v)) for u, v in self._mem_mute.items()]
        else:
            items = []
            try:
                for u, raw in (await self._t(r.hgetall(MUTE_KEY)) or {}).items():
                    items.append((int(u), json.loads(raw)))
            except Exception as e:  # noqa: BLE001
                log.warning("liveops: mutes not read: %s", e)
        for u, rec in items:
            if float(rec.get("until") or 0) > now:
                rows.append({"id": int(u), "until": int(rec["until"]), "by": int(rec.get("by") or 0), "reason": str(rec.get("reason") or ""), "t": int(rec.get("t") or 0)})
        rows.sort(key=lambda x: -x["until"])
        return rows

    # ------------------------------------------------------------------ player names (the owner's search)
    async def note_name(self, uid: int, name: str) -> None:
        """called from Store.touch (one marked line in state.py): remembers the display name.  Never raises."""
        try:
            uid = int(uid)
            nm = str(name or "")[:24]
            if uid <= 0 or not nm or self._names_seen.get(uid) == nm:
                return
            self._names_seen[uid] = nm
            if len(self._names_seen) > 20000:
                self._names_seen.clear()
            r = await self._redis()
            if r is None:
                self._mem_names[uid] = nm
            else:
                await self._t(r.hset(NAMES_KEY, str(uid), nm), 1.5)
        except Exception as e:  # noqa: BLE001
            log.debug("liveops: name not indexed: %s", e)

    async def find_names(self, q: str, limit: int = 20) -> List[Tuple[int, str]]:
        q = str(q or "").strip().lower()
        if len(q) < 2:
            return []
        out: List[Tuple[int, str]] = []
        r = await self._redis()
        try:
            if r is None:
                items = list(self._mem_names.items())
            else:
                items = []
                async for u, nm in r.hscan_iter(NAMES_KEY, count=500):
                    items.append((int(u), nm))
                    if len(items) >= 50000:
                        break
        except Exception as e:  # noqa: BLE001
            log.warning("liveops: name index not read: %s", e)
            items = []
        for u, nm in items:
            if q in str(nm).lower():
                out.append((int(u), str(nm)))
        out.sort(key=lambda x: (0 if x[1].lower().startswith(q) else 1, x[1].lower(), x[0]))
        return out[:limit]

    async def index_names(self, rows: List[Tuple[int, str]]) -> int:
        n = 0
        r = await self._redis()
        for u, nm in rows:
            nm = str(nm or "")[:24]
            if int(u) <= 0 or not nm:
                continue
            try:
                if r is None:
                    self._mem_names[int(u)] = nm
                else:
                    await self._t(r.hset(NAMES_KEY, str(int(u)), nm), 1.5)
                self._names_seen[int(u)] = nm
                n += 1
            except Exception:  # noqa: BLE001
                continue
        return n


    # ------------------------------------------------------------------ players (used by the game's owner routes AND by the bot's admin panel: same checks, same audit)
    @staticmethod
    def _store(store: Any) -> Any:
        if store is not None:
            return store
        from .state import STORE
        return STORE

    async def player_exists(self, store: Any, uid: int) -> bool:
        from .state import KEY
        st = self._store(store)
        uid = int(uid)
        if uid <= 0:
            return False
        if uid in st._mem:
            return True
        r = await st._redis()
        if r is None:
            return False
        try:
            return bool(await asyncio.wait_for(r.exists(KEY.format(uid)), 1.5))
        except Exception:  # noqa: BLE001
            return False

    async def player_profile(self, store: Any, uid: int, short: bool = False) -> Dict[str, Any]:
        """what the owner sees of a kingdom (read only; raises StateUnavailable when it cannot be read)."""
        from . import progress as PR
        from . import social as SO
        from .state import _owner_ids
        st = await self._store(store).load(int(uid))
        uid = int(uid)
        tro = int(st.get("tro", 0) or 0)
        lg = SO.league_index(tro)
        out = {"id": uid, "n": str(st.get("name") or "")[:24], "k": int(PR.keep_level(st)), "tro": tro, "lg": lg, "lgn": SO.LEAGUES[lg][1], "muted": int(self.is_muted(uid))}
        if short:
            return out
        out.update({"trb": int(st.get("trb", tro) or 0), "clan": int(st.get("clan") or 0), "created": int(float(st.get("created") or 0)), "seen": int(float(st.get("seen") or 0)),
                    "gems": {g: int((st.get("gems") or {}).get(g, 0) or 0) for g in ("turq", "emerald", "ruby")},
                    "prem": {g: int((st.get("prem") or {}).get(g, 0) or 0) for g in ("sap", "onyx")},
                    "friends": len(st.get("frs") or []), "invited": int(st.get("rfn", 0) or 0),
                    "ref_by": int((st.get("ref") or {}).get("by") or 0) if isinstance(st.get("ref"), dict) else 0,
                    "attacks": len(st.get("rep") or []), "hits": len(st.get("hits") or []), "test": bool(st.get("devu")), "owner": uid in _owner_ids()})
        return out

    async def player_search(self, store: Any, q: str, limit: int = 20) -> List[Dict[str, Any]]:
        """by code (a Telegram id) or by name (substring, any case, >= 2 characters); short profiles."""
        q = str(q or "").strip()[:40]
        if len(q) < 2:
            return []
        ids: List[int] = []
        if q.isdigit() and len(q) <= 15 and await self.player_exists(store, int(q)):
            ids.append(int(q))
        for u, _n in await self.find_names(q, limit):
            if u not in ids:
                ids.append(u)
        rows = []
        for u in ids[:limit]:
            try:
                rows.append(await self.player_profile(store, u, short=True))
            except Exception:  # noqa: BLE001
                continue
        return rows

    async def gift(self, store: Any, uid: int, gems: Any, rid: Any, by: int, note: str = "") -> Dict[str, Any]:
        """a gift to one kingdom through the inbox (the list the bot also writes to).  Amounts are checked, never changed: over the caps = refused.
        `rid` = a request id made once per gift by the caller: the same rid again is `dup` (paid once, however often the tap is retried).
        -> {ok, gid, gems} | {ok, dup, gid} | {ok False, why: bad|rid|gems|cap|player|store, ...}"""
        from .state import INBOX_MAX_PREM, INBOX_MAX_TURQ
        st = self._store(store)
        rid = str(rid or "")
        if isinstance(uid, bool) or not isinstance(uid, int) or uid <= 0:
            return {"ok": False, "why": "bad"}
        if not RID_RX.match(rid):
            return {"ok": False, "why": "rid"}
        if not isinstance(gems, dict) or not gems:
            return {"ok": False, "why": "gems"}
        clean: Dict[str, int] = {}
        for g, n in gems.items():
            if g not in GIFT_GEMS or isinstance(n, bool) or not isinstance(n, int):
                return {"ok": False, "why": "gems", "bad": str(g)[:12]}
            cap = INBOX_MAX_PREM if g in ("sap", "onyx") else INBOX_MAX_TURQ
            if n < 0 or n > cap:
                return {"ok": False, "why": "cap", "gem": g, "max": cap}
            if n:
                clean[g] = n
        if not clean:
            return {"ok": False, "why": "gems"}
        if not await self.player_exists(st, uid):
            return {"ok": False, "why": "player"}
        try:
            first = await self.claim_rid("gift:" + rid)
        except Exception:  # noqa: BLE001
            return {"ok": False, "why": "store"}
        gid = "oc1:" + rid
        if not first:
            return {"ok": True, "dup": True, "gid": gid}
        if not await st.push_inbox(uid, dict({"id": gid, "src": "owner", "t": int(self.clock())}, **clean)):
            await self.release_rid("gift:" + rid)
            return {"ok": False, "why": "store"}
        await self.audit_add(by, "gift", "players", note, uid=uid, gems=clean, gid=gid)
        log.info("owner gift by=%s -> %s %s (%s)", by, uid, clean, gid)
        return {"ok": True, "gid": gid, "gems": clean}

    async def mute_player(self, store: Any, uid: int, minutes: Any, by: int, reason: str = "") -> Dict[str, Any]:
        """minutes 0 = unmute.  Keeps the owner's list here (`is_muted`) and calls `chat.mute(uid, until, by, reason)` when CH1's module exists."""
        if isinstance(minutes, bool) or not isinstance(minutes, int) or minutes < 0 or minutes > MAX_MUTE_MIN:
            return {"ok": False, "why": "minutes", "max": MAX_MUTE_MIN}
        if isinstance(uid, bool) or not isinstance(uid, int) or uid <= 0:
            return {"ok": False, "why": "bad"}
        if not await self.player_exists(store, uid):
            return {"ok": False, "why": "player"}
        reason = _strip_ctrl(str(reason or ""))[:120]
        res = await (self.mute(uid, minutes * 60, by, reason) if minutes else self.unmute(uid, by))
        if not res.get("ok"):
            return res
        hook = await call_hook("chat", "mute", uid, float(res["until"]), by, reason)
        await self.audit_add(by, "mute" if minutes else "unmute", "players", reason, uid=uid, minutes=minutes)
        log.info("owner mute by=%s -> %s %s min (chat hook: %s)", by, uid, minutes, hook["state"])
        return {"ok": True, "until": res["until"], "chat": hook["state"]}

    async def reindex_names(self, store: Any) -> Dict[str, Any]:
        """build the name index from every stored kingdom (once after the first install; `touch` keeps it current afterwards)."""
        from .state import KEY
        st = self._store(store)
        t0 = time.monotonic()
        rows: List[Any] = []
        r = await st._redis()
        seen = 0
        if r is None:
            rows = [(u, s.get("name")) for u, s in list(st._mem.items())]
            seen = len(rows)
        else:
            prefix = KEY.format("")
            try:
                async for k in r.scan_iter(match=prefix + "*", count=500):
                    seen += 1
                    try:
                        u = int(str(k)[len(prefix):])
                        raw = await asyncio.wait_for(r.get(k), 1.5)
                        nm = (json.loads(raw) if raw else {}).get("name")
                    except Exception:  # noqa: BLE001
                        continue
                    rows.append((u, nm))
                    if seen >= REINDEX_MAX or time.monotonic() - t0 > REINDEX_SECONDS:
                        break
            except Exception as e:  # noqa: BLE001
                log.warning("reindex scan failed: %s", e)
        n = await self.index_names([(u, nm) for u, nm in rows if nm])
        return {"ok": True, "seen": seen, "indexed": n, "complete": seen < REINDEX_MAX and time.monotonic() - t0 <= REINDEX_SECONDS}


# the one shared instance + the contract functions (ROUND8_COMMON §3)
L = LiveOps()


def get(section: str) -> Dict[str, Any]:
    return L.get(section)


def flag(name: str) -> bool:
    return L.flag(name)


def season() -> Optional[Dict[str, Any]]:
    return L.season()


def register(section: str, defaults: Dict[str, Any], validate: Optional[Callable] = None, **kw: Any) -> None:
    L.register(section, defaults, validate, **kw)


def is_muted(uid: int) -> float:
    return L.is_muted(uid)
