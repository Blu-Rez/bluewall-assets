# OC1 — server patch: routes + how other chats plug into `liveops`

Files: `NEW/liveops.py` (core, no HTTP) · `NEW/ownerapi.py` (HTTP layer) · `server.py.diff` (2 lines, `# OC1:`) · `state.py.diff` (2 lines, `# OC1:`).
Apply: copy `NEW/*.py` to `bluewall/`, `git apply server.py.diff state.py.diff`. Nothing else in the server changes.
Tests: `dev/oc1_test.sh` → `OC1 SERVER OK` (unit memory · unit real Redis · two real server processes on one Redis).

---------------------------------------------------------------------------------------------------

## 1. The contract (ROUND8_COMMON §3) — what other chats call

```python
from . import liveops                      # (state.py is imported by liveops lazily, so no import cycle)

liveops.get("pass")                        # -> dict: defaults + owner overrides, merged.  A FRESH copy each call (safe to mutate).
                                           #    Cheap: no I/O, no JSON parsing of Redis.  Reads the in-process cache, refreshed <= 30 s.
liveops.flag("wheel")                      # -> bool   (a name that does not exist -> False)
liveops.season()                           # -> {"id","start","end","start_s","end_s","auto"} | None     (start/end = epoch seconds, *_s = Tehran text)
liveops.register("pass", DEFAULTS, validate=None, *, limits=None, templates=None, title=None)
liveops.is_muted(uid)                      # -> bool (sync).  CH1 asks this before accepting a chat line.
```

### register — call it ONCE at import time of your module
```python
DEFAULTS = {"xp_per_win": 40, "tiers": [{"xp": 100, "gem": "turq", "n": 5}], "label": "Spring pass", "on": True}

def _validate(v):                           # optional, extra rules AFTER the generic ones; return a list of error strings ([] = ok)
    return [] if v["xp_per_win"] <= v["tiers"][0]["xp"] else ["xp_per_win must not exceed the first tier"]

liveops.register("pass", DEFAULTS, _validate,
                 limits={"xp_per_win": (1, 500), "tiers#len": (1, 60), "tiers[].xp": (1, 100000), "tiers[].n": (0, 5000), "label#len": (1, 40)},
                 templates={"tiers": {"xp": 100, "gem": "turq", "n": 5}},      # what "add a row" creates
                 title="Battle pass")
```
Rules the server applies to every save (so you need no checking of your own for these):
* **Shape = the defaults.** A key that is not in the defaults is **rejected** (`path: unknown key 'x'`, never ignored). A wrong type (text for a number, bool for a number, list for an object) is rejected. A key **missing** from the sent `values` goes back to its default — the form always sends the whole section.
* **Numbers are clamped** into `limits[path]` and every clamp is *reported* (`clamped:[{p,from,to}]` in the answer). No limit given → a global ±1e12 bound. `NaN/Inf` and booleans-as-numbers are rejected. An integer default stays an integer (rounded).
* **Text**: control/format chars stripped, clipped to 200 chars (`path#len` = (min, max) replaces that bound; too short = error, too long = clipped + reported). **Lists**: ≤ 200 rows by default; `path#len` = (min, max) rows, outside = error.
* **Paths** in `limits`: `a.b` for object keys, `rows[].x` for a field of every row, `*` = any one key name, `rows#len` / `label#len` for lengths. A row's shape = the **first default row**, or `templates[path]` when the default list is empty (also what “add a row” creates). Unknown keys inside a row are rejected too.
* `validate(merged_values)` runs last (on the cleaned whole section); its strings are shown to the owner with the field-level errors and the save is refused as a whole (**all-or-nothing per section**; and for import: all-or-nothing for the whole file).
* Storage keeps **only what differs from your defaults**. When you change a default in code, every owner field he never touched follows it. Fields he did touch stay his.
* Defaults that fail their own checks are logged (`liveops: the defaults of 'x' do not pass`) — not fatal.
* Section name: `^[a-z][a-z0-9_]{0,23}$`; depth ≤ 6; a section ≤ 32 KB. Registering the same name twice replaces the first (tests do this).

### Reading in hot paths
`get()` is a dict lookup + `json.loads` of a small cached string; call it per request, do not cache the dict yourself. Do **not** hold the result across `await`s expecting it to update — call `get()` again.
If the Redis poll has been failing (> 25 s since the last good one) `get()` itself starts a refresh and serves the last good config meanwhile: a dead Redis never takes the game down, it only freezes the last known settings.

### 3-line test stub (when your tests do not start the whole server)
```python
from bluewall import liveops
liveops.register("pass", DEFAULTS, _validate, limits=LIMITS)           # nothing else: no Redis needed, get() returns the defaults
assert liveops.get("pass") == DEFAULTS
```
To test an override without a store: `await liveops.L.save("pass", {...}, by=777)` works in `BLUEWALL_STATE=memory` mode.

---------------------------------------------------------------------------------------------------

## 2. Season + checklist conventions

* Section `season` (built in): `{"auto_chain": false, "warn_days": 3, "seasons": [{"id","start","end","pass_ready","league_ready"}]}`.
  `start`/`end` are **Tehran** wall-clock text `"YYYY-MM-DD HH:MM"` (rule 9). `season()` converts to epoch. 1–100 days long, no overlaps, ids unique `[A-Za-z0-9_.+-]{1,24}`.
* `auto_chain: true` → when the running season ends and nothing else is set, the same length is chained automatically (marked `auto: true`; the checklist then warns “set the real next season”). **Default off** — assumption, change in the section if wanted.
* **Prizes “set”** (checklist): `pass_ready` / `league_ready` ticked by the owner on the season row, **or** your section (`pass` / `league`) has a dict `seasons` keyed by the season id with a non-empty value (`{"seasons": {"2026-11": {...}}}`). Only for sections that are **registered** — a feature that is not in the build is not asked about. BP1/RK1: if you prefer another shape, tell mother; the tick still works without it.
* Checklist levels: `ok` · `todo` · `warn` · `alert` (alert = < `warn_days` days to season end and the next season/prizes missing). `worst` = the highest.

## 3. Hooks (stubs until the other chats are merged — nothing breaks if they are absent)

| Who | Function the owner panel calls | Used for |
|---|---|---|
| CH1 | `chat.mute(uid:int, until:float, by:int, reason:str)`  (`until == 0` → unmute) | the mute button. The owner's list lives in liveops either way; CH1 should **also** ask `liveops.is_muted(uid)`. Answer field `chat`: `absent` / `called` / `error`. |
| CH1 | `chat.reports()` → list of `{id,t,by,target,text,kind}` | “Reports” queue |
| FR1 | `friends.reports()` → list of `{id,t,by,target,reason}` | “Reports” queue |
| RK1 | `ladder.suspicious()` → list of `{uid,why,t}` | “Suspicious” list |

Functions may be sync or async; exceptions are caught and logged. Lists are cut to 100 items, strings to 300 chars.

## 4. Other hooks in existing files (2 + 2 lines)
* `server.py`: `from . import ownerapi as OW` + `OW.add_routes(app, bearer_uid=…, is_owner=…, limited=…, nocache=…)` right before `return app` in `make_app()`.
* `state.py`: in `Store.touch`, after the save: `await LOP.L.note_name(uid, nm)` → keeps the owner's **name index** current (hash `bluewall:lo:names`: uid → lowercase name). Players who never log in again after the install are only found by code, or after **Rebuild name index** (button; scans ≤ 100 000 kingdoms / 20 s).
* The aiohttp `client_max_size` of the app (64 KB today) caps every body; a section is ≤ 32 KB, the whole config ≤ 256 KB, so a very large import is answered `413 size`.

---------------------------------------------------------------------------------------------------

## 5. Routes

Auth: `Authorization: Bearer <session>` (the normal game session). **Every `/api/owner/*` call, reads included, is checked on the server**: not the owner (`config.settings.SUPER_ADMIN_UID` via `_is_owner`) or no login → **`403 {"ok":false,"reason":"locked"}`**, same answer for both, and the client does not build the sheet. Owner rate limit 240/min → `429 {"ok":false,"reason":"slow"}`. Unexpected error → `500 {"ok":false,"reason":"server"}`. All answers `Cache-Control: no-store`.

Error body of the liveops routes: `{"ok":false,"why":<code>, …}`. Status by `why`: `invalid`/`format`/`bad`/`rid`/`gems`/`cap`/`minutes` 400 · `stale`/`busy` 409 · `section`/`gone`/`player` 404 · `store` 503 (Redis unreadable: reading keeps working, writing is refused) · `size` 413.

### Everybody (logged in)
| Route | Answer |
|---|---|
| `GET /api/flags` (60/min per player) | `{ok, flags:{friends,chat_global,chat_dm,chat_clan,friendly,clan_war,pass,wheel,missions,daily,season: bool}, season:{…}\|null, rev, now}` — clients hide what is off (no disabled buttons). Refresh when `rev` changes or every ≤ 60 s. |

### Owner — live config
| Route | Body | Answer |
|---|---|---|
| `GET /api/owner/liveops` | – | `{ok, rev, now, sections:[{name,title,srev,custom}], checklist}` |
| `GET /api/owner/liveops/section/{name}` | – | `{ok, name, title, rev, srev, values, defaults, limits:{path:[min,max]}, templates}` · 404 `section` |
| `POST /api/owner/liveops/section/{name}/check` | `{values}` | dry run: `{ok:true, dry:true, errors:[], diff:[{p,o,n}], clamped:[…], values:<cleaned>, noop}` or 400 `{why:"invalid", errors:[…]}` |
| `POST /api/owner/liveops/section/{name}` | `{values, base_rev?, note?}` | save: `{ok, rev, changed:[sections], diff:{section:[{p,o,n}]}}` · `{ok, noop:true}` when nothing differs · 400 invalid · **409 `stale`** when `base_rev` ≠ the section's current `srev` (someone else changed it; answer carries the current `values`) · 409 `busy` (another write won the race: retry) |
| `POST /api/owner/liveops/revert` | `{version, section?}` | back to a kept version (whole config, or only one section); revert is itself a new version: `{ok, rev, …}` · 404 `gone` (older than the last 20) |
| `GET /api/owner/liveops/versions` | – | `{ok, rev, versions:[{v,t,by,act,secs,note}]}` newest first, last **20** |
| `GET /api/owner/liveops/audit?limit=50&offset=0` | – | `{ok, items:[{t,by,act,sec,v,diff:[{p,o,n}],more,note, …extra (uid, gems, gid for a gift / mute)}]}` newest first, limit ≤ 200, last 1000 kept |
| `GET /api/owner/liveops/export` | – | `{ok, doc:{format:"bluewall-liveops/1", rev, t, sections:{name:{…full values…}}}}` |
| `POST /api/owner/liveops/import` | `{doc, dry?}` | all sections validated first; any error → nothing applied: 400 `{why:"invalid", errors}` / 400 `format`. `dry:true` → `{ok, dry, sections:[changed names], diff, clamped}` |
| `GET /api/owner/checklist` | – | `{ok, checklist:{now, now_s, warn_days, current, next, days_left, items:[{id,level,text}], worst, rev}}` |

Propagation: other server processes pick a change up by their own poll (every 10 s) → the promise is **≤ 30 s** (measured between two real processes: 10.0 s; unit tests assert the 25 s safety net too). The process that saved sees it at once.

Concurrency: one lock per process + Redis `WATCH`/`MULTI` on the revision key between processes. Two owners (or the bot + the game) saving at the same moment cannot lose each other's change; the loser gets `409 busy`/`stale`.

### Owner — players
| Route | Body | Answer |
|---|---|---|
| `GET /api/owner/players?q=` | – | `q` ≥ 2 chars: digits → by code (and names containing it); else by name substring. `{ok, q, items:[{id,n,k,tro,lg,lgn,muted}]}` ≤ 20 |
| `GET /api/owner/players/{uid}` | – | `{ok, player:{id,n,k,tro,lg,lgn,muted,trb,clan,created,seen,gems:{turq,emerald,ruby},prem:{sap,onyx},friends,invited,ref_by,attacks,hits,test,owner, mute:{id,until,by,reason,t}\|null}}` · 404 `player` |
| `POST /api/owner/players/{uid}/gift` | `{gems:{turq?,emerald?,ruby?,sap?,onyx?}, rid, note?}` | pays through `state.push_inbox` (the same inbox the bot uses; caps 5000 / 1000 premium). Over the cap → **refused** (400 `cap`, `gem`, `max`), never silently changed. `rid` = id the CLIENT makes once per gift (`^[A-Za-z0-9_-]{8,36}$`); gift id `oc1:<rid>`; the same `rid` again → `{ok:true, dup:true}` and nothing is paid twice. Audit line written. |
| `POST /api/owner/players/{uid}/mute` | `{minutes:0..43200, reason?}` | `0` = unmute. `{ok, until, chat:"absent"\|"called"\|"error"}` |
| `GET /api/owner/mutes` | – | `{ok, items:[{id,until,by,reason,t}]}` (running mutes only) |
| `GET /api/owner/reports` | – | `{ok, items, stub}` (`stub:true` = CH1/FR1 not merged yet) |
| `GET /api/owner/suspicious` | – | `{ok, items, stub}` |
| `POST /api/owner/players/reindex` | – | `{ok, seen, indexed, complete}` |

### The bot (same logic, no HTTP)
`OC1_BOT_SPEC.md` — the bot's admin panel calls the same `liveops.L.*` methods (`save/check/revert/export/import_/versions/audit/checklist`, `player_search/player_profile/gift/mute_player/reindex_names`) with `by=<owner uid>`, so validation, versions and audit are identical.

---------------------------------------------------------------------------------------------------

## 6. Redis keys (all prefixed `bluewall:lo:`)
`cfg` (whole overrides blob, JSON) · `rev` (int; the CAS key) · `ver` (list, last 20 snapshots) · `audit` (list, last 1000) · `rid:<id>` (7-day idempotency marks) · `names` (hash uid → lowercase name) · `mute` (hash uid → json). With `BLUEWALL_STATE=memory` everything is in-process.
If Redis loses its data the config goes back to the defaults (inherent: that is where the overrides live) — the owner re-imports his last export. **Export after every big change** is the backup.

## 7. Limits you may rely on / assumptions to confirm
* ≤ 30 s from save to every process (poll 10 s + 25 s safety net).
* Season ids and dates are Asia/Tehran; `season()` hands epoch ints.
* BP1/RK1 table shapes are *not* known to OC1: any registered section is edited by the generic form (number / switch / text / table-of-rows); the only convention OC1 reads is the optional `seasons` dict above.
* `GET /api/flags` is an extra route (not in the contract) so clients can hide switched-off features without the owner route.
