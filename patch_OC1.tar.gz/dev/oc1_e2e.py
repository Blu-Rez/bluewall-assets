#!/usr/bin/env python3
"""OC1 end-to-end: the REAL server (python -m bluewall, with the OC1 lines in server.py / state.py) as TWO processes on ONE real redis-server.
Proves, over HTTP with the real session auth: strangers get 403 on every owner route, the owner's saves reach the other process in <= 30 s (measured),
gifts cross processes through the inbox, config survives a restart, and a dead Redis never lets a save pretend to work.   prints `OC1 E2E OK`.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

TOK = "123456:TESTTOKENabcdefghijk"
APP = "/home/claude/bot/bluebot_v2"
REDIS_PORT = 6391
PORTS = {"A": 8593, "B": 8594}
OWNER, PLAYER = 777, 888
BAD = []
N = [0]
PROCS = {}


def need(c, m):
    N[0] += 1
    if not c:
        BAD.append(m)
        print("FAIL", m)


def init_data(uid, name="Blꢊe"):
    d = {"auth_date": str(int(time.time())), "query_id": "AAE", "user": json.dumps({"id": uid, "first_name": name}, separators=(",", ":"))}
    dcs = "\n".join("%s=%s" % (k, v) for k, v in sorted(d.items()))
    sk = hmac.new(b"WebAppData", TOK.encode(), hashlib.sha256).digest()
    d["hash"] = hmac.new(sk, dcs.encode(), hashlib.sha256).hexdigest()
    return urllib.parse.urlencode(d)


def req(srv, path, body=None, tok=None, method=None):
    h = {"Content-Type": "application/json"}
    if tok:
        h["Authorization"] = "Bearer " + tok
    r = urllib.request.Request("http://127.0.0.1:%d%s" % (PORTS[srv], path), data=json.dumps(body).encode() if body is not None else None, headers=h, method=method or ("POST" if body is not None else "GET"))
    try:
        with urllib.request.urlopen(r, timeout=10) as f:
            return f.status, json.loads(f.read())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:  # noqa: BLE001
            return e.code, None


def start(srv):
    env = dict(os.environ, PYTHONPATH="/home/claude/dev/stubcfg", BLUEBOT_REDIS_URL="redis://127.0.0.1:%d" % REDIS_PORT, BLUEWALL_PORT=str(PORTS[srv]), SUPER_ADMIN_UID=str(OWNER))
    env.pop("BLUEWALL_STATE", None)
    log = open("/tmp/oc1_e2e_%s.log" % srv, "w")
    PROCS[srv] = subprocess.Popen([sys.executable, "-m", "bluewall"], cwd=APP, env=env, stdout=log, stderr=subprocess.STDOUT)
    for _ in range(60):
        time.sleep(0.5)
        try:
            with urllib.request.urlopen("http://127.0.0.1:%d/healthz" % PORTS[srv], timeout=2) as f:
                if f.read() == b"ok":
                    return
        except Exception:  # noqa: BLE001
            pass
    raise SystemExit("server %s did not start: %s" % (srv, open("/tmp/oc1_e2e_%s.log" % srv).read()[-800:]))


def stop(srv):
    p = PROCS.pop(srv, None)
    if p:
        p.terminate()
        try:
            p.wait(8)
        except Exception:  # noqa: BLE001
            p.kill()


def rcli(*a):
    return subprocess.run(["redis-cli", "-p", str(REDIS_PORT), *a], capture_output=True, text=True).stdout.strip()


def login(srv, uid, name="Blꢊe"):
    s, j = req(srv, "/api/auth", {"init_data": init_data(uid, name)})
    need(s == 200 and j.get("ok"), "auth %s on %s" % (uid, srv))
    return j["token"], j


def main():
    if rcli("ping") != "PONG":
        subprocess.Popen(["redis-server", "--port", str(REDIS_PORT), "--save", "", "--appendonly", "no", "--bind", "127.0.0.1"], stdout=open("/tmp/redis6391.log", "w"), stderr=subprocess.STDOUT)
        time.sleep(1.5)
    rcli("flushall")
    try:
        start("A")
        start("B")
        ot_a, oj = login("A", OWNER, "Owner Person")
        need(oj.get("owner") is True, "auth tells the owner he is the owner (the client builds the sheet only then)")
        pt_a, pj = login("A", PLAYER, "Plain Player")
        need(pj.get("owner") is False, "auth tells a player he is not")
        ot_b, _ = login("B", OWNER, "Owner Person")
        pt_b, _ = login("B", PLAYER, "Plain Player")
        # --- strangers: every owner route, GET and POST, both processes
        routes = [("GET", "/api/owner/liveops"), ("GET", "/api/owner/liveops/section/flags"), ("POST", "/api/owner/liveops/section/flags"), ("POST", "/api/owner/liveops/section/flags/check"),
                  ("POST", "/api/owner/liveops/revert"), ("GET", "/api/owner/liveops/versions"), ("GET", "/api/owner/liveops/audit"), ("GET", "/api/owner/liveops/export"),
                  ("POST", "/api/owner/liveops/import"), ("GET", "/api/owner/checklist"), ("GET", "/api/owner/players?q=Plain"), ("GET", "/api/owner/players/%d" % PLAYER),
                  ("POST", "/api/owner/players/%d/gift" % PLAYER), ("POST", "/api/owner/players/%d/mute" % PLAYER), ("GET", "/api/owner/mutes"), ("GET", "/api/owner/reports"),
                  ("GET", "/api/owner/suspicious"), ("POST", "/api/owner/players/reindex")]
        for srv, tok in (("A", pt_a), ("B", pt_b), ("A", None)):
            for m, p in routes:
                s, j = req(srv, p, {"values": {}, "gems": {"turq": 99}, "rid": "stranger-0001", "minutes": 5, "version": 1, "doc": {}} if m == "POST" else None, tok=tok, method=m)
                need(s == 403 and j == {"ok": False, "reason": "locked"}, "%s %s on %s as %s -> 403 (got %s %s)" % (m, p, srv, "player" if tok else "nobody", s, j))
        s, st = req("A", "/api/state", tok=pt_a)
        need(s == 200 and st["gems"]["turq"] < 1000 and not st.get("gift"), "the strangers' gift attempts paid nothing")
        s, j = req("A", "/api/flags", tok=pt_a)
        need(s == 200 and j["flags"]["friends"] is True and j["flags"]["clan_war"] is False and j["season"] is None, "GET /api/flags: switches + season for any player")
        # --- the owner sees the panel data
        s, j = req("A", "/api/owner/liveops", tok=ot_a)
        need(s == 200 and [x["name"] for x in j["sections"]] == ["flags", "season"] and j["checklist"]["worst"] == "alert", "overview: the two built-in sections; no season set yet = alert")
        # --- <= 30 s from one process to the other (measured)
        s, j = req("A", "/api/owner/liveops/section/flags", tok=ot_a)
        vals, sr = j["values"], j["srev"]
        vals["friends"] = False
        vals["pass"] = False
        t0 = time.time()
        s, j = req("A", "/api/owner/liveops/section/flags", dict(values=vals, base_rev=sr, note="e2e"), tok=ot_a)
        need(s == 200 and j["values"]["friends"] is False, "save on A")
        s, f = req("A", "/api/flags", tok=pt_a)
        need(f["flags"]["friends"] is False, "A applies it at once")
        seen = None
        while time.time() - t0 < 35:
            s, f = req("B", "/api/flags", tok=pt_b)
            if s == 200 and f["flags"]["friends"] is False:
                seen = time.time() - t0
                break
            time.sleep(1.0)                                                    # (the route allows 60 reads a minute per player)
        need(seen is not None and seen <= 30, "the OTHER process applies the owner's save within 30 s (measured %s s)" % (None if seen is None else round(seen, 2)))
        print("  cross-process propagation: %.2f s" % (seen or -1))
        s, f = req("B", "/api/flags", tok=pt_b)
        need(f["flags"]["pass"] is False and f["flags"]["wheel"] is True, "both changes arrived, the rest untouched")
        # --- the other process saves on top; versions / revert across processes
        s, j = req("B", "/api/owner/liveops/section/flags", tok=ot_b)
        v2 = j["values"]
        v2["wheel"] = False
        s, j = req("B", "/api/owner/liveops/section/flags", dict(values=v2, base_rev=j["srev"]), tok=ot_b)
        need(s == 200, "save on B")
        s, j = req("B", "/api/owner/liveops/versions", tok=ot_b)
        need(s == 200 and len(j["versions"]) == 2 and j["versions"][1]["note"] == "e2e", "versions are shared: %s" % [v["note"] for v in j["versions"]])
        first = j["versions"][1]["v"]
        s, j = req("A", "/api/owner/liveops/revert", {"version": first, "section": "flags"}, tok=ot_a)
        need(s == 200 and j["sections"]["flags"]["wheel"] is True and j["sections"]["flags"]["friends"] is False, "revert on A to the first version (wheel back on)")
        t0 = time.time()
        f = {"flags": {}}
        while time.time() - t0 < 35:
            s, f = req("B", "/api/flags", tok=pt_b)
            if s == 200 and f["flags"]["wheel"] is True:
                break
            time.sleep(1.0)
        need(f["flags"].get("wheel") is True and time.time() - t0 <= 30, "the revert reaches B in %.1f s" % (time.time() - t0))
        s, j = req("A", "/api/owner/liveops/audit?limit=10", tok=ot_a)
        need([a["act"] for a in j["items"][:3]] == ["revert", "save", "save"] and j["items"][0]["by"] == OWNER, "audit shared by both processes, with who: %s" % [a["act"] for a in j["items"]])
        # --- a season through the real route -> checklist
        s, j = req("A", "/api/owner/liveops/section/season", tok=ot_a)
        sv = j["values"]
        now = time.time()
        import datetime as dt
        z = dt.timezone(dt.timedelta(hours=3, minutes=30))
        a = (dt.datetime.fromtimestamp(now, z) - dt.timedelta(days=28)).strftime("%Y-%m-%d %H:%M")
        b = (dt.datetime.fromtimestamp(now, z) + dt.timedelta(days=2)).strftime("%Y-%m-%d %H:%M")
        sv["seasons"] = [{"id": "e2e-1", "start": a, "end": b, "pass_ready": False, "league_ready": False}]
        s, j = req("A", "/api/owner/liveops/section/season", dict(values=sv), tok=ot_a)
        need(s == 200, "a season saves through the route: %s" % j)
        s, j = req("A", "/api/owner/checklist", tok=ot_a)
        lv = {i["id"]: i["level"] for i in j["checklist"]["items"]}
        need(j["checklist"]["current"]["id"] == "e2e-1" and lv["next"] == "alert" and j["checklist"]["worst"] == "alert", "checklist: 2 days left and no next season = alert: %s" % lv)
        s, f = req("A", "/api/flags", tok=pt_a)
        need(f["season"] and f["season"]["id"] == "e2e-1" and f["season"]["end"] > now, "GET /api/flags carries the running season")
        # --- players: search by code and by name (the name index fills on login), gift across processes, mute
        s, j = req("A", "/api/owner/players?q=%d" % PLAYER, tok=ot_a)
        need(s == 200 and [x["id"] for x in j["items"]] == [PLAYER], "search by code")
        s, j = req("B", "/api/owner/players?q=plain", tok=ot_b)
        need(s == 200 and [x["id"] for x in j["items"]] == [PLAYER], "search by name (another process: the index lives in Redis)")
        s, j = req("A", "/api/owner/players/%d" % PLAYER, tok=ot_a)
        need(s == 200 and j["player"]["n"] == "Plain Player" and j["player"]["owner"] is False, "profile")
        s, st0 = req("A", "/api/state", tok=pt_a)
        g0 = st0["gems"]["turq"]
        s, j = req("B", "/api/owner/players/%d/gift" % PLAYER, {"gems": {"turq": 300, "onyx": 5}, "rid": "e2e-gift-0001", "note": "e2e"}, tok=ot_b)
        need(s == 200 and j["gid"] == "oc1:e2e-gift-0001", "gift made on B")
        s, j = req("A", "/api/owner/players/%d/gift" % PLAYER, {"gems": {"turq": 300, "onyx": 5}, "rid": "e2e-gift-0001"}, tok=ot_a)
        need(s == 200 and j.get("dup") is True, "the same request id on the OTHER process is still a duplicate (Redis)")
        s, st1 = req("A", "/api/state", tok=pt_a)
        need(st1["gems"]["turq"] == g0 + 300 and st1["prem"]["onyx"] == 5 and st1["gift"]["turq"] == 300, "the player on A gets the gift made on B, once: %s -> %s" % (g0, st1["gems"]["turq"]))
        s, st2 = req("A", "/api/state", tok=pt_a)
        need(st2["gems"]["turq"] == g0 + 300, "... and not twice")
        s, j = req("A", "/api/owner/players/%d/mute" % PLAYER, {"minutes": 30, "reason": "e2e"}, tok=ot_a)
        need(s == 200 and j["chat"] == "absent" and j["until"] > time.time(), "mute")
        s, j = req("B", "/api/owner/mutes", tok=ot_b)
        need(s == 200 and j["items"][0]["id"] == PLAYER, "the mute list is shared")
        # --- restart: the config is read from Redis at start-up, before the first request
        stop("A")
        start("A")
        ot_a, _ = login("A", OWNER, "Owner Person")
        pt_a, _ = login("A", PLAYER, "Plain Player")
        s, f = req("A", "/api/flags", tok=pt_a)
        need(f["flags"]["friends"] is False and f["flags"]["pass"] is False and f["season"]["id"] == "e2e-1", "a restarted server serves the saved config at once")
        # --- Redis gone: the last good config keeps serving; a save is refused (never pretends)
        rcli("shutdown", "nosave")
        time.sleep(1.0)
        s, f = req("A", "/api/flags", tok=pt_a)
        need(s == 200 and f["flags"]["friends"] is False, "Redis down: the players still get the last good switches")
        s, j = req("A", "/api/owner/liveops/section/flags", tok=ot_a)
        need(s == 200 and j["values"]["friends"] is False, "Redis down: the owner can still read the section")
        j["values"]["daily"] = False
        s, jj = req("A", "/api/owner/liveops/section/flags", dict(values=j["values"]), tok=ot_a)
        need(s == 503 and jj["why"] == "store", "Redis down: a save is REFUSED with 503 store (%s %s)" % (s, jj))
        s, f = req("A", "/api/flags", tok=pt_a)
        need(f["flags"]["daily"] is True, "... and nothing changed in memory")
        s, jg = req("A", "/api/owner/players/%d/gift" % PLAYER, {"gems": {"turq": 5}, "rid": "e2e-gift-0002"}, tok=ot_a)
        need(s in (503, 500, 404) and not (jg or {}).get("ok"), "Redis down: a gift is refused (%s %s)" % (s, jg))
        subprocess.Popen(["redis-server", "--port", str(REDIS_PORT), "--save", "", "--appendonly", "no", "--bind", "127.0.0.1"], stdout=open("/tmp/redis6391.log", "a"), stderr=subprocess.STDOUT)
        time.sleep(1.5)
        need(rcli("ping") == "PONG", "redis back")
        s, jj = req("A", "/api/owner/liveops/section/flags", dict(values=j["values"]), tok=ot_a)
        need(s in (200, 409), "Redis back: the next save goes through or asks for a refresh (%s %s)" % (s, jj))
        print("  after the redis restart (all data was dropped on purpose): save -> %s" % s)
        txt = open("/tmp/oc1_e2e_B.log").read()
        need("Traceback" not in txt, "no traceback in the B server log")
    finally:
        for s in list(PROCS):
            stop(s)
    print("checks:", N[0])
    if BAD:
        print("OC1 E2E FAILED: %d" % len(BAD))
        return 1
    print("OC1 E2E OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
