#!/usr/bin/env bash
# oc1_test.sh - OC1 SERVER proof (liveops.py + ownerapi.py).  Needs: redis-server, `pip install redis aiohttp`.   Prints `OC1 SERVER OK` at the end.
#   1. oc1_unit.py   OC1_MODE=memory   the in-process store (as the other dev tests)             ~220 checks
#   2. oc1_unit.py   OC1_MODE=redis    a REAL redis-server on 6391: CAS between two processes, <= 30 s ~235 checks
#   3. oc1_e2e.py    the REAL server twice (python -m bluewall) on that redis: owner-only on every route, measured propagation, gifts across
#                    processes, restart, a dead Redis                                              ~95 checks
cd /home/claude/dev || exit 1
FAIL=0
if [ "$(redis-cli -p 6391 ping 2>/dev/null)" != "PONG" ]; then (nohup redis-server --port 6391 --save "" --appendonly no --bind 127.0.0.1 > /tmp/redis6391.log 2>&1 &); sleep 1.5; fi
run(){ local name="$1" want="$2"; shift 2; local out; out=$("$@" 2>&1); echo "$out" | grep -E "^(FAIL|checks:|  )" | head -20; if echo "$out" | tail -1 | grep -q "$want"; then echo "OK   $name"; else echo "FAIL $name"; echo "$out" | tail -8; FAIL=1; fi; }
run "unit (memory store)" "OC1 UNIT memory OK" env OC1_MODE=memory BLUEWALL_STATE=memory python3 oc1_unit.py
run "unit (real redis)" "OC1 UNIT redis OK" env OC1_MODE=redis BLUEBOT_REDIS_URL=redis://127.0.0.1:6391 python3 oc1_unit.py
run "e2e (two real servers, one redis)" "OC1 E2E OK" python3 oc1_e2e.py
[ $FAIL = 0 ] && echo "OC1 SERVER OK" || { echo "OC1 SERVER FAILED"; exit 1; }
