#!/usr/bin/env python3
"""OC1 server tests (liveops.py + ownerapi.py).  Run twice by oc1_test.sh:
     OC1_MODE=memory  BLUEWALL_STATE=memory                         (the in-process store, as the dev tests use)
     OC1_MODE=redis   BLUEBOT_REDIS_URL=redis://127.0.0.1:6391       (a REAL redis-server; also proves two processes see each other's saves)
prints `OC1 UNIT <mode> OK` or a list of FAIL lines.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time
import types

sys.path.insert(0, "/home/claude/dev/stubcfg")
sys.path.insert(0, "/home/claude/bot/bluebot_v2")
MODE = os.environ.get("OC1_MODE", "memory")
if MODE == "memory":
    os.environ["BLUEWALL_STATE"] = "memory"
else:
    os.environ.pop("BLUEWALL_STATE", None)
    os.environ.setdefault("BLUEBOT_REDIS_URL", "redis://127.0.0.1:6391")

from aiohttp import web  # noqa: E402
from aiohttp.test_utils import TestClient, TestServer  # noqa: E402

from bluewall import liveops as LO  # noqa: E402
from bluewall import ownerapi as OW  # noqa: E402
from bluewall.state import STORE  # noqa: E402

BAD: list = []
N = [0]


def need(cond, msg: str) -> None:
    N[0] += 1
    if not cond:
        BAD.append(msg)
        print("FAIL", msg)


async def none_redis():
    return None


async def new_redis():
    import redis.asyncio as aioredis
    return aioredis.from_url(os.environ["BLUEBOT_REDIS_URL"], decode_responses=True)


def demo(lo: LO.LiveOps) -> None:
    lo.register("demo", {"n": 4, "x": 1.5, "on": True, "name": "hi", "top": [{"rank": 1, "gems": 10}, {"rank": 2, "gems": 5}], "tiers": {"a": 1, "b": 2}, "empty": []},
                lambda d: ["n must be even"] if d["n"] % 2 else [],
                limits={"n": (0, 100), "x": (0, 10), "top[].gems": (0, 1000), "top#len": (1, 5), "name#len": (1, 10), "empty#len": (0, 3)}, templates={"empty": {"k": ""}})


async def mk(shared_redis=None) -> LO.LiveOps:
    lo = LO.LiveOps(redis_fn=(lambda: _ret(shared_redis)) if shared_redis is not None else none_redis)
    demo(lo)
    await lo._sync()
    return lo


async def _ret(v):
    return v


# ------------------------------------------------------------------------------------------------------------ 1. the core
async def core(r) -> None:
    A = await mk(r)
    # defaults
    f = A.get("flags")
    need(all(f[k] for k in LO.FLAG_NAMES if k != "clan_war") and f["clan_war"] is False, "flags defaults: all on except clan_war")
    need(A.flag("pass") is True and A.flag("clan_war") is False and A.flag("nope") is False, "flag(): on / off / unknown = False")
    need(A.get("demo")["n"] == 4, "get(demo) = defaults")
    d = A.get("demo")
    d["n"] = 999
    d["top"].append(1)
    need(A.get("demo")["n"] == 4 and len(A.get("demo")["top"]) == 2, "get() returns a fresh copy (mutating it changes nothing)")
    try:
        A.get("zzz")
        need(False, "get(unregistered) raises KeyError")
    except KeyError:
        need(True, "")
    need(A.season() is None, "no season set -> season() is None")

    def full(**kw):
        v = A.get("demo")
        v.update(kw)
        return v

    async def bad(values, frag):
        res = await A.save("demo", values, by=1)
        need(res.get("ok") is False and res.get("why") == "invalid" and any(frag in e for e in res.get("errors", [])), "save refused (%s): %s" % (frag, res))

    rev0 = A.rev()
    v = full()
    v["zz"] = 1
    await bad(v, "unknown key 'zz'")
    v = full()
    v["tiers"]["c"] = 3
    await bad(v, "unknown key 'c'")
    await bad(full(on="yes"), "expected true / false")
    await bad(full(n=True), "expected a number")
    await bad(full(n=float("nan")), "not plain JSON")
    await bad(full(n="5"), "expected a number")
    await bad(full(n=3), "n must be even")
    await bad(full(name=""), "at least 1 characters")
    await bad(full(top=[]), "at least 1 rows")
    await bad(full(top=[{"rank": i, "gems": 1} for i in range(6)]), "at most 5 rows")
    await bad(full(top=[{"rank": 1, "gems": 1, "extra": 2}]), "unknown key 'extra'")
    await bad(full(top="x"), "expected a list")
    await bad(full(empty=[{"k": "a", "bad": 1}]), "unknown key 'bad'")
    await bad(full(empty=[{"k": "a"}] * 4), "at most 3 rows")
    res = await A.save("nope", {}, by=1)
    need(res.get("why") == "section", "save to an unknown section -> why section")
    res = await A.save("demo", {"huge": "x" * 40000}, by=1)
    need(res.get("ok") is False, "an oversized section is refused")
    need(A.rev() == rev0, "refused saves change nothing (rev still %d, is %d)" % (rev0, A.rev()))

    # clamp is applied and reported; only the overrides are stored
    res = await A.save("demo", full(n=1000, x=-5.0, name="a-very-long-name!", top=[{"rank": 1, "gems": 5000}, {"rank": 2, "gems": 5}]), by=1)
    need(res.get("ok") and not res.get("noop"), "clamped save is accepted: %s" % res)
    got = A.get("demo")
    need(got["n"] == 100 and got["x"] == 0.0 and got["name"] == "a-very-lon" and got["top"][0]["gems"] == 1000, "numbers clamped to the registered limits, text clipped: %s" % got)
    need({c["p"] for c in res["clamped"]} >= {"n", "x", "name", "top[0].gems"}, "the clamps are reported: %s" % res["clamped"])
    need(isinstance(got["n"], int) and isinstance(got["x"], float), "int stays int, float stays float")
    ov = A._blob["sec"]["demo"]["d"]
    need(set(ov) == {"n", "x", "name", "top"} and "on" not in ov and "tiers" not in ov, "only the overrides are stored: %s" % list(ov))
    need(A.srev("demo") == 1 and A.rev() == rev0 + 1, "section revision / global revision count up")
    # appended row (template = first row), a row of a list that was empty by default
    res = await A.save("demo", full(top=A.get("demo")["top"] + [{"rank": 3, "gems": 1}], empty=[{"k": "a"}, {"k": "b"}]), by=1)
    need(res.get("ok") and len(A.get("demo")["top"]) == 3 and A.get("demo")["empty"] == [{"k": "a"}, {"k": "b"}], "rows can be added (template from the first row or the registered one)")
    # no change -> no new version
    nv = len(await A.versions())
    res = await A.save("demo", A.get("demo"), by=1)
    need(res.get("ok") and res.get("noop") and len(await A.versions()) == nv, "saving the same values is a no-op (no new version)")
    # dry check
    res = await A.save("demo", full(n=8), by=1, dry=True)
    need(res.get("ok") and res.get("dry") and any(x["p"] == "n" for x in res["diff"]) and A.get("demo")["n"] == 100, "dry check shows the diff and saves nothing")
    # revert-to-default values drop the override
    res = await A.save("demo", dict(A.get("demo"), n=4, x=1.5, name="hi"), by=1)
    need(res.get("ok") and "n" not in A._blob["sec"]["demo"]["d"], "a value back at its default is not stored")

    # stale base revision
    s = A.srev("demo")
    res = await A.save("demo", full(n=10), by=1, base_rev=s - 1)
    need(res.get("ok") is False and res.get("why") == "stale" and res.get("srev") == s, "stale base_rev -> why stale")
    res = await A.save("demo", full(n=10), by=1, base_rev=s)
    need(res.get("ok") and A.get("demo")["n"] == 10, "matching base_rev saves")

    # versions (<= 20), revert one section, revert all, audit
    for i in range(25):
        await A.save("flags", dict(A.get("flags"), friends=bool(i % 2)), by=1, note="n%d" % i)
    vs = await A.versions()
    need(len(vs) == LO.KEEP_VERSIONS and vs[0]["v"] == A.rev() and all("snap" not in x for x in vs), "versions: newest first, at most 20, no snapshot in the list: %d" % len(vs))
    await A.save("demo", full(n=20), by=1)
    target = vs[8]
    flags_now = A.get("flags")
    res = await A.revert(target["v"], by=1, section="demo")
    need(res.get("ok") is True, "revert one section: %s" % res)
    need(A.get("flags") == flags_now, "revert of one section leaves the others alone")
    res = await A.revert(10 ** 6, by=1)
    need(res.get("why") == "gone", "revert to a version that is gone -> why gone")
    oldest = (await A.versions())[-1]
    res = await A.revert(oldest["v"], by=1)
    need(res.get("ok") is True, "revert everything to the oldest kept version: %s" % res)
    au = await A.audit(50)
    need(au and au[0]["act"] == "revert" and au[0]["by"] == 1, "audit: the revert is the newest line")
    need(any(a["act"] == "save" and a["sec"] == "demo" and any(d["p"] == "n" for d in a["diff"]) for a in await A.audit(200)), "audit: a save line carries {p, o, n} diffs")
    a0 = [a for a in await A.audit(200) if a["act"] == "save" and a["sec"] == "flags"][0]
    need({"t", "by", "act", "sec", "v", "diff", "note"} <= set(a0), "audit line has t / by / section / diff: %s" % sorted(a0))

    # export / import
    ex = A.export()
    need(ex["format"] == LO.FMT and set(ex["sections"]) == {"flags", "season", "demo"}, "export: format + every registered section")
    B = await mk(r)
    imp = json.loads(json.dumps(ex))
    imp["sections"]["demo"]["n"] = 30
    imp["sections"]["flags"]["wheel"] = False
    res = await B.import_(imp, by=1, dry=True)
    need(res.get("ok") and res.get("dry") and set(res["sections"]) == {"demo", "flags"} and B.get("demo")["n"] != 30, "import dry run: lists what changes, applies nothing")
    bad_imp = json.loads(json.dumps(imp))
    bad_imp["sections"]["demo"]["n"] = 3
    bad_imp["sections"]["flags"]["wheel"] = False
    rb = B.rev()
    res = await B.import_(bad_imp, by=1)
    need(res.get("ok") is False and any("n must be even" in e for e in res["errors"]) and B.rev() == rb and B.flag("wheel") is True, "import is all-or-nothing: one bad section = nothing applied")
    res = await B.import_({"format": "other", "sections": {}}, by=1)
    need(res.get("why") == "format", "import of a wrong format is refused")
    res = await B.import_({"format": LO.FMT, "sections": {"ghost": {}}}, by=1)
    need(res.get("ok") is False and any("unknown section" in e for e in res["errors"]), "import of an unknown section is refused")
    res = await B.import_(imp, by=1)
    need(res.get("ok") and B.get("demo")["n"] == 30 and B.flag("wheel") is False and len([a for a in await B.audit(5) if a["act"] == "import"]) == 2, "import applies as one revision, one audit line per section")
    need(res["rev"] == rb + 1, "import = ONE revision")

    # mute, names, request ids
    need(B.is_muted(5) == 0, "not muted by default")
    rr = await B.mute(5, 600, by=1, reason="spam")
    need(rr["ok"] and B.is_muted(5) > time.time() + 590, "mute -> is_muted is the end time")
    need((await B.mutes())[0]["id"] == 5 and (await B.mutes())[0]["reason"] == "spam", "mutes() lists it")
    rr = await B.mute(5, 10 ** 9, by=1)
    need(rr["until"] <= time.time() + LO.MAX_MUTE_S + 5, "a mute is capped at 30 days")
    await B.unmute(5, by=1)
    need(B.is_muted(5) == 0 and not await B.mutes(), "unmute")
    await B.note_name(7, "Alice Wonder")
    await B.note_name(8, "bob")
    await B.note_name(9, "ALICIA")
    need([u for u, _n in await B.find_names("ali")] == [9, 7] or {u for u, _n in await B.find_names("ali")} == {7, 9}, "name search is case-insensitive, substring")
    need(await B.find_names("a") == [], "a 1-letter search finds nothing (too wide)")
    need(await B.claim_rid("x1") is True and await B.claim_rid("x1") is False, "request id: first claim wins, the repeat does not")
    await B.release_rid("x1")
    need(await B.claim_rid("x1") is True, "a released request id can be used again")


# ------------------------------------------------------------------------------------------------------------ 2. seasons + checklist
async def seasons() -> None:
    A = await mk(None)
    T = LO.parse_tehran
    need(T("2026-11-01 00:00") - T("2026-10-31 23:59") == 60, "Tehran time parses (minute resolution)")
    need(T("2026-11-01T00:00:30") == T("2026-11-01 00:00:30") and T("garbage") is None and T(5) is None, "Tehran parse: T separator, seconds, garbage -> None")
    need(LO.fmt_tehran(T("2026-11-01 00:00")) == "2026-11-01 00:00", "Tehran format round trip")
    need(T("2026-11-01 00:00") == int(__import__("calendar").timegm((2026, 11, 1, 0, 0, 0))) - 3.5 * 3600, "Tehran = UTC+03:30 (no daylight saving)")
    now = T("2026-10-20 12:00")

    async def put(rows, **kw):
        s = A.get("season")
        s["seasons"] = rows
        s.update(kw)
        return await A.save("season", s, by=1)
    row = lambda i, a, b, **kw: dict({"id": i, "start": a, "end": b, "pass_ready": False, "league_ready": False}, **kw)  # noqa: E731

    for rows, frag in (([row("a", "2026-10-01 00:00", "2026-10-02 00:00"), row("b", "2026-10-01 12:00", "2026-10-05 00:00")], "overlap"),
                       ([row("a", "2026-10-01 00:00", "2026-10-01 05:00")], "1 to 100 days"),
                       ([row("a", "2026-10-01 00:00", "2027-03-01 00:00")], "1 to 100 days"),
                       ([row("a", "nope", "2026-10-05 00:00")], "start / end must look like"),
                       ([row("a", "2026-10-01 00:00", "2026-10-05 00:00"), row("a", "2026-11-01 00:00", "2026-11-05 00:00")], "used twice"),
                       ([row("bad id!", "2026-10-01 00:00", "2026-10-05 00:00")], "id must be")):
        res = await put(rows)
        need(res.get("ok") is False and any(frag in e for e in res["errors"]), "season refused (%s): %s" % (frag, res))
    res = await put([row("2026-10", "2026-10-01 00:00", "2026-11-01 00:00")], warn_days=3)
    need(res.get("ok"), "a good season saves: %s" % res)
    cur = A.season(now)
    need(cur and cur["id"] == "2026-10" and cur["start"] == T("2026-10-01 00:00") and cur["end"] == T("2026-11-01 00:00") and isinstance(cur["start"], int), "season(): id / start / end (epoch ints)")
    need(cur["start_s"] == "2026-10-01 00:00" and cur["end_s"] == "2026-11-01 00:00", "season(): Tehran text too")
    need(A.season(T("2026-11-01 00:00") - 1)["id"] == "2026-10" and A.season(T("2026-11-01 00:00")) is None and A.season(T("2026-09-30 23:59")) is None, "season boundaries: start inclusive, end exclusive")

    cl = A.checklist(T("2026-10-20 12:00"))
    need(cl["current"]["id"] == "2026-10" and abs(cl["days_left"] - 11.5) < 0.01, "checklist: current season + days left")
    lv = {i["id"]: i["level"] for i in cl["items"]}
    need(lv["next"] == "todo" and cl["worst"] == "todo", "checklist: next season missing with 11 days left = a to-do, not an alarm: %s" % lv)
    cl = A.checklist(T("2026-10-29 12:00"))
    lv = {i["id"]: i["level"] for i in cl["items"]}
    need(lv["next"] == "alert" and cl["worst"] == "alert", "checklist: < 3 days left and no next season = ALERT: %s" % lv)
    cl = A.checklist(T("2026-10-29 00:00") - 1)
    need({i["id"]: i["level"] for i in cl["items"]}["next"] == "todo", "checklist: just over 3 days left is still a to-do")
    cl = A.checklist(T("2026-10-29 00:00") + 1)
    need({i["id"]: i["level"] for i in cl["items"]}["next"] == "alert", "checklist: just under 3 days left is an alert")
    cl = A.checklist(T("2026-12-01 00:00"))
    need(cl["current"] is None and {i["id"]: i["level"] for i in cl["items"]}["season"] == "alert", "checklist: no season running, none ahead = alert")

    # next season + prizes (only features that exist in this build are asked about)
    res = await put([row("2026-10", "2026-10-01 00:00", "2026-11-01 00:00"), row("2026-11", "2026-11-01 00:00", "2026-12-01 00:00")])
    need(res.get("ok"), "two seasons save")
    cl = A.checklist(T("2026-10-30 12:00"))
    lv = {i["id"]: i["level"] for i in cl["items"]}
    need(lv["next"] == "ok" and not any(k.startswith("prizes_") for k in lv), "checklist: next season set; no pass / league section yet = nothing to prepare: %s" % lv)
    A.register("pass", {"price": 5, "seasons": {"2026-10": {"a": 1}}}, None)
    A.register("league", {"seasons": {}}, None)
    cl = A.checklist(T("2026-10-30 12:00"))
    lv = {i["id"]: i["level"] for i in cl["items"]}
    need(lv["prizes_pass"] == "alert" and lv["prizes_league"] == "alert", "checklist: next prizes not set + < 3 days left = alert: %s" % lv)
    cl = A.checklist(T("2026-10-10 12:00"))
    need({i["id"]: i["level"] for i in cl["items"]}["prizes_pass"] == "todo", "checklist: prizes not set with time left = to-do")
    s = A.get("season")
    s["seasons"][1]["pass_ready"] = True
    await A.save("season", s, by=1)
    lv = {i["id"]: i["level"] for i in A.checklist(T("2026-10-30 12:00"))["items"]}
    need(lv["prizes_pass"] == "ok" and lv["prizes_league"] == "alert", "checklist: ticked by the owner -> ok (only that one)")
    A.register("pass", {"price": 5, "seasons": {"2026-11": {"a": 1}}}, None)
    A._rebuild_one("pass")
    lv = {i["id"]: i["level"] for i in A.checklist(T("2026-10-30 12:00"))["items"]}
    need(lv["prizes_pass"] == "ok", "checklist: a `seasons` map in the pass config that holds the next id counts as set")
    need("pass_flag" not in lv, "checklist: pass on + a season running = no pass_flag warning")
    lv = {i["id"]: i["level"] for i in A.checklist(T("2027-01-10 00:00"))["items"]}
    need(lv.get("pass_flag") == "warn", "checklist: pass switch on but no season running = warn")
    # flags summary
    f = A.get("flags")
    f["wheel"] = False
    await A.save("flags", f, by=1)
    txt = [i["text"] for i in A.checklist(T("2026-10-30 12:00"))["items"] if i["id"] == "flags"][0]
    need("wheel" in txt and "clan_war" in txt, "checklist: names the switched-off features: %s" % txt)

    # auto chain: a season is made up when the last one is over (same length), and the checklist says so
    B = await mk(None)
    s = B.get("season")
    s["seasons"] = [row("a", "2026-10-01 00:00", "2026-10-31 00:00")]
    s["auto_chain"] = True
    await B.save("season", s, by=1)
    c = B.season(T("2026-11-05 00:00"))
    need(c and c["auto"] is True and c["start"] == T("2026-10-31 00:00") and c["end"] == T("2026-11-30 00:00") and c["id"] == "a+1", "auto_chain: the follow-up has the same length: %s" % c)
    c = B.season(T("2027-01-02 00:00"))
    need(c and c["id"] == "a+3" and c["auto"], "auto_chain: several months later, still contiguous")
    lv = {i["id"]: i["level"] for i in B.checklist(T("2026-11-05 00:00"))["items"]}
    need(lv.get("auto") == "warn", "checklist: an auto-chained season is a warning")
    s["auto_chain"] = False
    await B.save("season", s, by=1)
    need(B.season(T("2026-11-05 00:00")) is None, "auto_chain off: no season after the last one")


# ------------------------------------------------------------------------------------------------------------ 3. <= 30 s between processes
async def propagation(r) -> None:
    A, B = await mk(r), await mk(r)
    need(B.flag("friends") is True, "start: friends on in B")
    f = A.get("flags")
    f["friends"] = False
    res = await A.save("flags", f, by=1)
    need(res.get("ok") and A.flag("friends") is False, "A sees its own save at once")
    need(B.flag("friends") is True, "B has not looked yet")
    need(LO.POLL_S <= 10 and LO.MAX_AGE_S <= 25 and LO.POLL_S + LO.MAX_AGE_S > 0, "poll 10 s, safety net 25 s: both inside the 30 s promise")
    # the background loop (its period shortened for the test)
    LO.POLL_S, old = 0.1, LO.POLL_S
    try:
        B.start()
        t0 = time.monotonic()
        while B.flag("friends") and time.monotonic() - t0 < 5:
            await asyncio.sleep(0.05)
        need(B.flag("friends") is False, "B's poll loop picks the change up (%.2f s with a 0.1 s period)" % (time.monotonic() - t0))
    finally:
        await B.stop()
        LO.POLL_S = old
    # the safety net inside get(): the loop is dead, the last good poll is older than MAX_AGE -> get() refreshes by itself
    C = await mk(r)
    clock = [1000.0]
    C.mono = lambda: clock[0]
    await C.refresh(force=True)
    f = A.get("flags")
    f["daily"] = False
    await A.save("flags", f, by=1)
    need(C.flag("daily") is True, "C is behind")
    clock[0] += LO.MAX_AGE_S - 1
    C.flag("daily")
    await asyncio.sleep(0.05)
    need(C.flag("daily") is True, "inside the age limit nothing is re-read")
    clock[0] += 2
    C.flag("daily")
    for _ in range(40):
        await asyncio.sleep(0.05)
        if not C.flag("daily"):
            break
    need(C.flag("daily") is False, "get() starts a refresh itself when the last good poll is older than %d s" % LO.MAX_AGE_S)
    # a stale second writer cannot lose the first one's change
    X, Y = await mk(r), await mk(r)

    async def save_retry(lo, sec, key, val):
        for _ in range(8):
            v = lo.get(sec)
            v[key] = val
            res = await lo.save(sec, v, by=1)
            if res.get("why") != "busy":
                return res
        return res
    ra, rb = await asyncio.gather(save_retry(X, "flags", "wheel", False), save_retry(Y, "demo", "n", 12))
    need(ra.get("ok") and rb.get("ok"), "two processes saving at once both end up saved (retry on busy): %s / %s" % (ra, rb))
    await X.refresh(force=True)
    await Y.refresh(force=True)
    need(X.flag("wheel") is False and X.get("demo")["n"] == 12 and Y.flag("wheel") is False and Y.get("demo")["n"] == 12, "no lost update: both changes are in both processes")
    need(X.rev() == Y.rev(), "same revision everywhere")
    # a write on a stale revision is refused by the store itself (WATCH), nothing written
    Z = await mk(r)
    blob = Z._next_blob({"demo": {"n": 40}}, 1)
    ver, auds = Z._commit_blob(blob, ["demo"], 1, "save", "", {"demo": []})
    await X.save("demo", dict(X.get("demo"), n=14), by=1)
    res = await Z._write(blob, ver, auds, Z.rev())
    need(res == "conflict", "the store refuses a write based on an old revision (WATCH): %s" % res)
    await Z.refresh(force=True)
    need(Z.get("demo")["n"] == 14, "... and the refused write left the config as the first writer made it")


# ------------------------------------------------------------------------------------------------------------ 4. HTTP layer, owner only
async def http() -> None:
    OWNER, PLAYER = 1, 1001
    lo = LO.L
    demo(lo)
    await lo._sync()

    def uid_of(req):
        h = req.headers.get("X-Uid", "")
        return int(h) if h.isdigit() else None
    gate = {"limited": False}
    app = web.Application(client_max_size=64 * 1024)
    OW.add_routes(app, bearer_uid=uid_of, is_owner=lambda u: u == OWNER, limited=lambda k, mx=0: gate["limited"], nocache=lambda r: r, store=STORE, lo=lo)
    async with TestClient(TestServer(app)) as c:
        async def call(method, path, uid=OWNER, body=None, raw=None):
            h = {"X-Uid": str(uid)} if uid is not None else {}
            kw = {"data": raw, "headers": dict(h, **{"Content-Type": "application/json"})} if raw is not None else {"json": body, "headers": h} if body is not None else {"headers": h}
            async with c.request(method, path, **kw) as r:
                try:
                    j = await r.json()
                except Exception:  # noqa: BLE001
                    j = None
                return r.status, j
        # players to work with
        await STORE.touch(PLAYER, "Alice Wonder")
        await STORE.touch(1002, "Bob Builder")
        await STORE.touch(OWNER, "The Owner")
        # ---- 4a. the owner routes are for the owner and nobody else: every one of them, GET and POST, stranger and no-login
        owner_routes = [(r.method, r.resource.canonical) for r in app.router.routes() if r.resource.canonical.startswith("/api/owner") and r.method in ("GET", "POST")]
        need(len(owner_routes) >= 17, "the owner route table is complete (%d routes)" % len(owner_routes))
        rev, mu = lo.rev(), await lo.mutes()
        for who in (2, PLAYER, None):
            for m, p in owner_routes:
                p2 = p.replace("{name}", "flags").replace("{uid}", str(PLAYER))
                st, j = await call(m, p2, uid=who, body={"values": {}, "version": 1, "doc": {}, "gems": {"turq": 5}, "rid": "abcdefgh12", "minutes": 5} if m == "POST" else None)
                need(st == 403 and j == {"ok": False, "reason": "locked"}, "%s %s as %s -> 403 locked (got %s %s)" % (m, p, who, st, j))
        need(lo.rev() == rev and await lo.mutes() == mu, "a stranger's attempts changed nothing")
        st, j = await call("GET", "/api/flags", uid=PLAYER)
        need(st == 200 and j["flags"]["friends"] is True and "season" in j and "rev" in j, "GET /api/flags is for every signed-in player")
        st, j = await call("GET", "/api/flags", uid=None)
        need(st == 403, "GET /api/flags needs a login")
        gate["limited"] = True
        st, j = await call("GET", "/api/owner/liveops")
        need(st == 429, "the rate limit answers 429")
        st, j = await call("GET", "/api/owner/liveops", uid=2)
        need(st == 403, "a stranger is refused before the rate limit counts")
        gate["limited"] = False
        # ---- 4b. config routes
        st, j = await call("GET", "/api/owner/liveops")
        need(st == 200 and [s["name"] for s in j["sections"]][:2] == ["flags", "season"] and "checklist" in j and j["rev"] == lo.rev(), "overview: sections + checklist")
        st, j = await call("GET", "/api/owner/liveops/section/demo")
        need(st == 200 and j["values"]["n"] == 4 and j["defaults"]["n"] == 4 and j["limits"]["n"] == [0, 100] and j["templates"] == {"empty": {"k": ""}} and isinstance(j["srev"], int), "section: values + defaults + limits + templates")
        sr = j["srev"]
        st, j = await call("GET", "/api/owner/liveops/section/ghost")
        need(st == 404 and j["why"] == "section", "unknown section -> 404")
        vals = (await call("GET", "/api/owner/liveops/section/demo"))[1]["values"]
        st, j = await call("POST", "/api/owner/liveops/section/demo/check", body={"values": dict(vals, n=3)})
        need(st == 400 and j["why"] == "invalid" and "n must be even" in j["errors"][0], "check: errors, nothing saved")
        st, j = await call("POST", "/api/owner/liveops/section/demo/check", body={"values": dict(vals, n=6)})
        need(st == 200 and j["dry"] and j["diff"][0]["p"] == "n" and lo.get("demo")["n"] == 4, "check: the diff, nothing saved")
        st, j = await call("POST", "/api/owner/liveops/section/demo", body={"values": dict(vals, n=6), "base_rev": sr, "note": "six"})
        need(st == 200 and j["values"]["n"] == 6 and j["srev"] == sr + 1 and lo.get("demo")["n"] == 6, "save: ok, new values + revision")
        st, j = await call("POST", "/api/owner/liveops/section/demo", body={"values": dict(vals, n=8), "base_rev": sr})
        need(st == 409 and j["why"] == "stale" and j["values"]["n"] == 6, "save on an old revision -> 409 stale (+ the current values)")
        st, j = await call("POST", "/api/owner/liveops/section/demo", body={"values": dict(vals, n=8), "base_rev": "x"})
        need(st == 400, "a non-integer base_rev -> 400")
        st, j = await call("POST", "/api/owner/liveops/section/demo", body={"values": dict(vals, zz=1)})
        need(st == 400 and "unknown key" in j["errors"][0], "unknown key -> 400")
        st, j = await call("POST", "/api/owner/liveops/section/demo", raw="not json")
        need(st == 400, "not JSON -> 400")
        st, j = await call("POST", "/api/owner/liveops/section/demo", body={"nothing": 1})
        need(st == 400, "no values -> 400")
        st, j = await call("POST", "/api/owner/liveops/section/demo", raw=json.dumps({"values": {"x": "y" * 70000}}))
        need(st in (400, 413), "a body over the app limit is refused (%d)" % st)
        st, j = await call("GET", "/api/owner/liveops/versions")
        need(st == 200 and j["versions"][0]["v"] == lo.rev() and j["versions"][0]["note"] == "six" and "snap" not in j["versions"][0], "versions list")
        vq = j["versions"][0]["v"]
        st, j = await call("POST", "/api/owner/liveops/section/demo", body={"values": dict(vals, n=10)})
        st, j = await call("POST", "/api/owner/liveops/revert", body={"version": vq, "section": "demo"})
        need(st == 200 and lo.get("demo")["n"] == 6 and "demo" in j["sections"], "revert (one button)")
        st, j = await call("POST", "/api/owner/liveops/revert", body={"version": 10 ** 6})
        need(st == 404 and j["why"] == "gone", "revert of a version that is gone -> 404")
        st, j = await call("POST", "/api/owner/liveops/revert", body={"version": "x"})
        need(st == 400, "revert: bad version -> 400")
        st, j = await call("GET", "/api/owner/liveops/audit?limit=5")
        need(st == 200 and j["items"][0]["act"] == "revert" and len(j["items"]) <= 5, "audit: newest first, limit honoured")
        st, j = await call("GET", "/api/owner/liveops/audit?limit=x")
        need(st == 400, "audit: bad limit -> 400")
        st, j = await call("GET", "/api/owner/liveops/export")
        doc = j["doc"]
        need(st == 200 and doc["format"] == LO.FMT and doc["sections"]["demo"]["n"] == 6, "export")
        doc["sections"]["demo"]["n"] = 22
        st, j = await call("POST", "/api/owner/liveops/import", body={"doc": doc, "dry": True})
        need(st == 200 and j["dry"] and lo.get("demo")["n"] == 6, "import dry run")
        st, j = await call("POST", "/api/owner/liveops/import", body={"doc": doc})
        need(st == 200 and lo.get("demo")["n"] == 22, "import applies")
        doc["sections"]["demo"]["n"] = 5
        st, j = await call("POST", "/api/owner/liveops/import", body={"doc": doc})
        need(st == 400 and lo.get("demo")["n"] == 22, "a bad import -> 400, nothing applied")
        st, j = await call("GET", "/api/owner/checklist")
        need(st == 200 and j["checklist"]["worst"] in ("ok", "todo", "warn", "alert"), "checklist route")

        # ---- 4c. players
        st, j = await call("GET", "/api/owner/players?q=1001")
        need(st == 200 and [x["id"] for x in j["items"]] == [PLAYER] and j["items"][0]["n"] == "Alice Wonder" and j["items"][0]["lgn"], "search by code")
        st, j = await call("GET", "/api/owner/players?q=wonder")
        need([x["id"] for x in j["items"]] == [PLAYER], "search by name (substring, any case): %s" % j)
        st, j = await call("GET", "/api/owner/players?q=zzzz")
        need(st == 200 and j["items"] == [], "search: no match")
        st, j = await call("GET", "/api/owner/players?q=9999999")
        need(st == 200 and j["items"] == [], "search by an unknown code finds nobody (no phantom kingdom is created)")
        st, j = await call("GET", "/api/owner/players?q=a")
        need(j["items"] == [], "search: 1 character is too wide")
        st, j = await call("GET", "/api/owner/players/1001")
        p = j["player"]
        need(st == 200 and p["id"] == PLAYER and p["n"] == "Alice Wonder" and {"k", "tro", "lg", "gems", "prem", "created", "seen", "clan", "friends", "mute"} <= set(p), "profile: %s" % sorted(p))
        st, j = await call("GET", "/api/owner/players/424242")
        need(st == 404 and j["why"] == "player", "profile of an unknown code -> 404")
        st, j = await call("GET", "/api/owner/players/-5")
        need(st in (404, 400), "negative code refused")
        g0 = (await STORE.get(PLAYER))["gems"]["turq"]
        rid = "rid-gift-0001"
        st, j = await call("POST", "/api/owner/players/1001/gift", body={"gems": {"turq": 250, "sap": 7}, "rid": rid, "note": "contest prize"})
        need(st == 200 and j["gid"] == "oc1:" + rid and j["gems"] == {"turq": 250, "sap": 7}, "gift: ok, unique id: %s" % j)
        st, j2 = await call("POST", "/api/owner/players/1001/gift", body={"gems": {"turq": 250, "sap": 7}, "rid": rid})
        need(st == 200 and j2.get("dup") is True, "the same request id again = a retried tap: nothing paid twice")
        sv = await STORE.get(PLAYER)
        need(sv["gems"]["turq"] == g0 + 250 and sv["prem"]["sap"] == 7 and sv["gift"] and sv["gift"]["turq"] == 250, "the player gets exactly one gift (wallet + the toast): turq %s -> %s" % (g0, sv["gems"]["turq"]))
        sv = await STORE.get(PLAYER)
        need(sv["gems"]["turq"] == g0 + 250, "... and it is not applied again on the next read")
        for body, why in (({"gems": {"turq": 5001}, "rid": "rid-gift-0002"}, "cap"), ({"gems": {"sap": 1001}, "rid": "rid-gift-0003"}, "cap"), ({"gems": {"gold": 5}, "rid": "rid-gift-0004"}, "gems"),
                          ({"gems": {"turq": -5}, "rid": "rid-gift-0005"}, "cap"), ({"gems": {"turq": 1.5}, "rid": "rid-gift-0006"}, "gems"), ({"gems": {"turq": True}, "rid": "rid-gift-0007"}, "gems"),
                          ({"gems": {"turq": 0}, "rid": "rid-gift-0008"}, "gems"), ({"gems": {}, "rid": "rid-gift-0009"}, "gems"), ({"gems": {"turq": 5}}, "rid"), ({"gems": {"turq": 5}, "rid": "short"}, "rid"),
                          ({"gems": {"turq": 5}, "rid": "bad rid with spaces!"}, "rid")):
            st, j = await call("POST", "/api/owner/players/1001/gift", body=body)
            need(st == 400 and j["why"] == why, "gift refused (%s): %s -> %s %s" % (why, body, st, j))
        st, j = await call("POST", "/api/owner/players/424242/gift", body={"gems": {"turq": 5}, "rid": "rid-gift-0010"})
        need(st == 404 and j["why"] == "player", "gift to an unknown code -> 404 (nothing queued)")
        st, j = await call("POST", "/api/owner/players/0/gift", body={"gems": {"turq": 5}, "rid": "rid-gift-0011"})
        need(st in (400, 404), "gift to code 0 refused")
        sv = await STORE.get(PLAYER)
        need(sv["gems"]["turq"] == g0 + 250 and sv["prem"]["sap"] == 7, "no refused gift reached the player")
        st, j = await call("POST", "/api/owner/players/1001/gift", body={"gems": {"turq": 5000, "emerald": 5000, "ruby": 5000, "sap": 1000, "onyx": 1000}, "rid": "rid-gift-0012"})
        need(st == 200, "the largest allowed gift passes")
        sv = await STORE.get(PLAYER)
        need(sv["prem"]["onyx"] == 1000 and sv["prem"]["sap"] == 1007, "... and is paid in full")
        aud = [a for a in await lo.audit(60) if a["act"] == "gift"]
        need(aud and aud[-1]["uid"] == PLAYER and aud[-1]["gems"] == {"turq": 250, "sap": 7} and aud[-1]["note"] == "contest prize" and aud[-1]["gid"] == "oc1:" + rid, "the gift is in the audit log: %s" % aud[-1:])
        need(len([a for a in aud if a["gid"] == "oc1:" + rid]) == 1, "a retried gift is logged once")

        # mute
        st, j = await call("POST", "/api/owner/players/1001/mute", body={"minutes": 10, "reason": "spam"})
        need(st == 200 and j["chat"] == "absent" and j["until"] > time.time() + 590 and lo.is_muted(PLAYER) == j["until"], "mute: stored (chat module absent until CH1 is merged)")
        st, j = await call("GET", "/api/owner/mutes")
        need(st == 200 and j["items"][0]["id"] == PLAYER and j["items"][0]["reason"] == "spam", "mutes list")
        st, j = await call("GET", "/api/owner/players/1001")
        need(j["player"]["muted"] > 0 and j["player"]["mute"]["reason"] == "spam", "the profile shows the mute")
        calls = []
        ch = types.ModuleType("bluewall.chat")
        ch.mute = lambda u, until, by, reason: calls.append((u, until, by, reason))
        ch.reports = lambda: [{"id": 1, "t": 5, "by": 1002, "target": 1001, "text": "x" * 500}]
        sys.modules["bluewall.chat"] = ch
        st, j = await call("POST", "/api/owner/players/1001/mute", body={"minutes": 60, "reason": "again"})
        need(st == 200 and j["chat"] == "called" and calls and calls[0][0] == PLAYER and calls[0][2] == OWNER and calls[0][3] == "again", "mute: chat.mute(uid, until, by, reason) is called when CH1 is there: %s" % calls)
        st, j = await call("GET", "/api/owner/reports")
        need(st == 200 and j["stub"] is False and j["items"][0]["target"] == 1001 and len(j["items"][0]["text"]) == 300, "reports: CH1's queue is shown (bounded text)")

        async def boom(*a):
            raise RuntimeError("x")
        ch.mute = boom
        st, j = await call("POST", "/api/owner/players/1001/mute", body={"minutes": 5, "reason": "t"})
        need(st == 200 and j["chat"] == "error" and lo.is_muted(PLAYER) > 0, "a failing chat hook never loses the mute")
        del sys.modules["bluewall.chat"]
        st, j = await call("GET", "/api/owner/reports")
        need(st == 200 and j["stub"] is True and j["items"] == [], "reports: a stub (empty) until CH1 / FR1 are merged")
        st, j = await call("GET", "/api/owner/suspicious")
        need(st == 200 and j["stub"] is True and j["items"] == [], "suspicious: a stub until RK1 is merged")
        for bad in ({"minutes": -1}, {"minutes": 10 ** 6}, {"minutes": "5"}, {"minutes": True}, {}):
            st, j = await call("POST", "/api/owner/players/1001/mute", body=bad)
            need(st == 400 and j["why"] == "minutes", "mute refused: %s" % bad)
        st, j = await call("POST", "/api/owner/players/424242/mute", body={"minutes": 5})
        need(st == 404, "mute of an unknown code -> 404")
        st, j = await call("POST", "/api/owner/players/1001/mute", body={"minutes": 0})
        need(st == 200 and j["until"] == 0 and lo.is_muted(PLAYER) == 0, "minutes 0 = unmute")
        # name index
        st, j = await call("POST", "/api/owner/players/reindex", body={})
        need(st == 200 and j["indexed"] >= 3 and j["complete"], "reindex builds the name index from the stored kingdoms: %s" % j)
        st, j = await call("GET", "/api/owner/players?q=builder")
        need([x["id"] for x in j["items"]] == [1002], "search by name after the reindex")


async def main() -> int:
    if MODE == "redis":
        r = await new_redis()
        await r.flushdb()
        await core(r)
        await seasons()
        await r.flushdb()
        await propagation(r)
        await r.flushdb()
        await r.aclose()
        STORE._r = None
        LO.L._checked = -1e9
        LO.L._loaded = False
    else:
        await core(None)
        await seasons()
    if MODE == "redis":
        r2 = await STORE._redis()
        await r2.flushdb()
    LO.L._blob = {"v": 0, "sec": {}}
    await http()
    print("checks:", N[0])
    if BAD:
        print("OC1 UNIT %s FAILED: %d" % (MODE, len(BAD)))
        return 1
    print("OC1 UNIT %s OK" % MODE)
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
