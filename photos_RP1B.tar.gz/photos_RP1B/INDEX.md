# photos_RP1B — proof frames (390 x 844, software GL; all looked at full size)
- reach_before.png / reach_after.png — reach map from the gate (green reachable, red land-but-unreachable, blue water, grey building, brown too steep); reach_*.json the numbers
- bridge, gate_outer, gate_keep, mill, shore — the hero on the main bridge, at the outer gate (drawn closed, she walks through the opening), at the keep gate, at an outer mill, on the lake pier
- wall_climb, wall_climb_side — half-way up a wall (4.1 m of 8.2 m; camera behind her, then turned a little; the climb is the walk cycle + lean, no climb clip exists); wall_top, wall_top_side — on the wall-walk (camera straight behind her, tower ahead), the same turned a little
- swim — swimming in the lake (stand-in pose: no swim clip exists)
- door_barracks, door_barracks_sheet, door_barracks_train — barracks door button, the same T1 sheet at 390 px, Train disabled (Lv 30 housing full: same logic as the strategic view)
- door_farm, door_farm_sheet, door_farm_collected; door_vault_sheet, door_vault_collected (Collect changes the state); door_cottage, door_cottage_sheet, door_cottage_info
- door_closed_walking — sheet closed, walking again, the round door button visible
- governor_stepped — forced slow run: overlay shows `q 4/4 crowd freeze`, `px 0.75`
- views_low_final.json / views_high.json — the calls / triangles table (before vs after, 3 views; high = with shadow pass); walk_tests_42of42.json; swim_tests.json
Note: `progs 261` in a few early frames (gate_outer, mill, shore, swim) is my own top-down dev picture tool rendering into an offscreen target in the same session; a fresh hero has 166, the door frames show 168.
