# shared-file lines changed by RP1C_R2 (vs kit 8256556)

## client/src/main.js
-  const dpr = () => { let b = Math.min(window.devicePixelRatio || 1, Q.dpr); if (cool()) b = Math.min(b, 1); return Math.max(0.75, b * (+settings.resScale || 1) * DYN.s * REACH.dpr * (cool() ? 0.9 : GOVK[GOV.lvl])); };
+  const dpr = () => { let b = Math.min(window.devicePixelRatio || 1, REACH.cap || Q.dpr); if (cool()) b = Math.min(b, 1); return Math.max(REACH.own ? 0.5 : 0.75, b * (+settings.resScale || 1) * (REACH.own ? 1 : DYN.s) * REACH.dpr * (cool() ? 0.9 : (REACH.own ? 1 : GOVK[GOV.lvl]))); };   // RP1C: in hero mode the hero's own governor owns the resolution (REACH.cap / REACH.own)
+    scene.matrixWorldAutoUpdate = !(inHero && !uw && REACH.mtx && REACH.upd > 1 && frames % REACH.upd !== 0);       // RP1C: hero mode: between two world updates only the hero's own nodes get new matrices (cull.js era()); the world's nodes only move inside world.update

## client/src/reach.js
-export const REACH = { k: 1, dpr: 1, fog: 1, upd: 1, sh: 0, norefl: false, nobloom: false };
+//   cap     RP1C-R2: replaces the preset's pixel-ratio cap (Q.dpr) while the hero is on: her back must be sharp, so the hero's target is min(devicePixelRatio, 2); 0 = the preset's own cap   (main.js dpr())
+//   own     RP1C-R2: the hero's own governor is in charge of the resolution: main.js's dynamic resolution (DYN.s) and thermal governor (GOVK) are not multiplied in while it is on          (main.js dpr())
+//   lod     RP1C-R2: the castle's full-model radius in metres while the hero is on (0 = castle_tr2.js's own 80 m; the lo model starts 20 m further out)                                    (castle_tr2.js lodPick)
+//   life    RP1C-R2 Job 1b: villagers and animals farther than this many metres are not packed / animated while the hero is on (0 = off)                                                       (tr2_life.js)
+//   mtx     RP1C-R2 Job 1b: cull.js is running its matrix savings (the nodes that are new since the hero started are updated by it): on the drawn frames between two world updates the scene's own matrix update is skipped   (main.js loop)
+export const REACH = { k: 1, dpr: 1, fog: 1, upd: 1, sh: 0, norefl: false, nobloom: false, cap: 0, own: false, lod: 0, life: 0, mtx: false };

## client/src/castle_tr2.js
+import { REACH } from './reach.js';                                  // RP1C: the hero mode's castle LOD radius (neutral = 0)
-export const lodPick = (d, cur) => (cur === 'lo' ? (d < LOD_NEAR ? 'hi' : 'lo') : (d > LOD_FAR ? 'lo' : 'hi'));
+export const lodPick = (d, cur, n = REACH.lod || LOD_NEAR) => (cur === 'lo' ? (d < n ? 'hi' : 'lo') : (d > n + LOD_FAR - LOD_NEAR ? 'lo' : 'hi'));   // RP1C: hero mode (REACH.lod = 50) shows the full model within 50 m, not 80; REACH.lod 0 = unchanged

## client/src/tr2_life.js
+import { REACH } from './reach.js';                                              // RP1C: hero mode: life beyond REACH.life metres is not packed or animated (neutral = 0 for everyone else)
+    if (REACH.life) maxDist = Math.min(maxDist, REACH.life);       // RP1C: hero mode: only the animals near her are packed
-  o.update = (t, camera, opts) => { for (const k of ks) k.update(t, camera, opts); };
+  const _lo = {};
+  o.update = (t, camera, opts) => { if (REACH.life) { opts = Object.assign(_lo, opts); _lo.maxDist = Math.min(_lo.maxDist || 700, REACH.life); } for (const k of ks) k.update(t, camera, opts); };       // RP1C: hero mode: only the villagers near her are animated
