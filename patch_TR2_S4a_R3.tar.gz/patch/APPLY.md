# TR2_S4a_R3 (TR2_H) — apply on kit 6b0b0ab
1. `git apply TR2_S4a_R3_src.diff`   (modified: b2_homes.js, castle.js, town_build.js, village.js, world.js — world.js has 3 `// TR2:` lines)
2. copy `new/bluewall/client/src/*` (bridges_tr2.js, edge_strip.js, town_ground.js) into bluewall/client/src/
3. copy `assets/tr2/*.glb` over bluewall/web/assets/tr2/ (24 house models, un-slimmed; step 1 cause B)
4. `dev/tr2_h_test.sh` (node only) -> `TR2 H OK`; rebuild the bundle as usual (web/app/wall.js is NOT in this patch).
