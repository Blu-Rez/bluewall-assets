# APPLY_TR2_S5_R2 — how to merge (base kit `0574fdc`; merge this patch LAST of the round)

Content of `patch_TR2_S5_R2.tar.gz`: `patch.diff` (the shared files, against kit `0574fdc`) + the whole files under `bluewall/…` and `workers/…` (so a conflict can be resolved by taking my file and re-adding the others' lines).

## 1. New files (no conflict possible)
`bluewall/client/src/layout_live.js`, `layout_rules.js`, `layout_store.js`, `layout_sync.js`, `layout_ui.js`
`workers/dev/tr2_layout_test.js`, `tr2_layout_test.sh`, `tr2_s5_server_model.js`, `tr2_s5_vectors.js`, `tr2_s5_vectors.sh`, `tr2_s5_drag.py`, `tr2_s5_frames.py`, `tr2_s5_frames2.py`, `tr2_s5_frames3.py`, `tr2_s5_frames4.py`, `tr2_s5_perf.py`, `tr2_s5_perf3.py`, `tr2_s5_perf4.py`
`workers/docs/layout_api.md`, `tr2_s5_geom.json` (NEW planId `p1oqct4l`), `tr2_s5_vectors.json`, `tr2_s5_fuzz.json`, `tr2_s5_ref_rules.py` (unchanged text)

## 2. Shared files (all my lines are marked `// TR2-S5:`; `git apply --check patch.diff` is clean on `0574fdc`)
| file | lines | what |
|---|---|---|
| `main.js` | +12 | live / sync / ui creation, `world.applyLayout`, econ-load hook, tick + update after `world.update`, `window.__bw.layoutUI` |
| `world.js` | +11 / −6 | `buildStores(…, {onMeshes})` + `stores.attach(staticMeshes)` after `B.build(scene)`, `layoutParts`, lot id on picks, `get targets()`, `planLots0` |
| `storeyards.js` (ST1) | +120 / −9 | only inside `buildStoreYards` + the lazy `tr2_s4c` import in `warmYards`; ends with `// TR2-S5: end of the movable-yard part`. **ST1_R2 owns the vault part of this file** — take ST1_R2's vault code, keep my block |
| `stores.js` (ST1) | +16 / −5 | `planStoresDefault()` / `planStores()` / `storesMovable()`; ST1's looks untouched |
| `wslife.js` (AN1) | +17 / −1 | `respawn(siteIds, storeIds)` + drops the walking grids / mesh cache of a moved site |
| `town_plan.js` +20/−6, `town_build.js` +31/−6, `town.js` +1/−1, `b1_layout.js` +2/−2 | small | as in `TR2_S5`, re-applied on the new text (`retargetTown`, `genKeep`, `STORE_FP` footprints for generic houses) |
| `battle.js` | +2 / −0 | `world.layout.enterBattle(target.layout \|\| null)` + `settled()`, `world.layout.leaveBattle()` in the restore |

`bluewall/web/app/wall.js` is the build output: **not** in the patch — rebuild it.

## 3. After applying
1. `bash dev/gate_w.sh` → `GATE_W: ALL OK` (noRoute 647), `bash dev/tr2_layout_test.sh` → `TR2 LAYOUT OK`, `bash dev/tr2_s5_vectors.sh` (writes the four server files), `python3 workers/docs/tr2_s5_ref_rules.py` → `PORT OK` + `FUZZ OK`.
2. **Server:** put the new `tr2_s5_geom.json` (planId `p1oqct4l`) next to `layout.py`; the other three files keep name and format.
3. **BT1_R2:** `world.applyLayout(rec)` (null → nothing; same record → nothing). For a made-up kingdom (no layout) keep `world.layout.enterBattle(target.layout || null)` — it shows the DEFAULT town.
4. **ST1_R2:** if the vaults change radius / place, keep `VAULT_R` in `layout_rules.js` (9.5) ≤ the built part and re-run `tr2_s5_vectors.sh`. If the nine ST1 slots change (`planQuarter()`), `tr2_layout_test.sh` §1 says at once whether the default layout is still valid under the 12 rules.
5. **TR2_H (B7):** after this patch.
