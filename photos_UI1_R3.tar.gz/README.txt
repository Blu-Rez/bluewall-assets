UI1_R3 frames (real game, software GL, Telegram header mocked: Close / ⌄ ⋮, content-safe-top 56 px)
UI1_R3_sheet.png   the numbered sheet (0 = today, 1 left rail, 2 under the badge, 3 right stack = default)
after/comp_<layout>_<WxH>[_side].png   strategic HUD, world captured once per size + HUD layer composited (cells differ only in the HUD); _side = notch case (Telegram side inset 47 px); layout 0 = kit as it was
before/            kit as it was, single real-game shots (hud_ = HUD, hub_ = Assist hub open); the world LOD can differ from after/ (software GL), look at the HUD only
hero/before_hero_844x390.png   hero HUD as it was; hero/after_hero_<WxH>.png  new arc (test only: the contextual «use» button forced visible so all 7 buttons show)
