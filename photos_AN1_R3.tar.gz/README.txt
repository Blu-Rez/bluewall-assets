AN1_R3 photos (software GL, 844x390 landscape, NOT a phone)
lineup_after_*.png / lineup_now_*.png  the numbered lineup sheets (people | animals | cart), after = real sizes, now = the build before AN1_R3. People sheet: hero x1.00 / x1.12 / x1.25 (dev page only).
ingame_pasture_b.png  the real game scene at the stable estate with a 2 m red-white ruler (ingame_pasture_a.png = same place from outside the fence)
night_a.png  hero spawn in front of the castle gate at 23:00 (hero 1.96 m beside the 2 m ruler)
night_b.png  the courtyard forge (buildings.js:49-63) at night: black posts / chimney
night_c.png  the giant dark poles: the legs of a wooden archer tower (buildings.js:102-110), ruler 2 m
night_d.png  the north town gate base (camera too close, kept only because it was looked at)
elev/  front elevations of house doors / gates used for the lineup scale (orthographic, red line every 1 m)
