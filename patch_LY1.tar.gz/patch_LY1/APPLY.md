# patch_LY1 (client) — apply on kit 0e75919
owned/client/src/*.js  -> copy over bluewall/client/src/   (layout_ui, layout_live, layout_sync are rewritten; layout_wire + layout_text are NEW)
shared/client/src/main.js.diff, ui.js.diff   -> cd bluewall && patch -p1 < shared/client/src/main.js.diff   (every changed line is marked LY1)
shared_workers/dev/*.diff  -> cd workers && patch -p1 --directory=dev < shared_workers/dev/gate_w.sh.diff (etc.)   (gate_w.sh +2 lines, tr2_layout_test.js 1 check, tr2_s5_drag.py: lifting on green places)
dev/ly1_*  -> workers/dev/   (ly1_test.sh = node vs the real server, ly1_ui.py = real Chromium, ly1_server.py = the rig, ly1_repro.sh = the owner's bug before / after)
The server half is patch_LY1_server.tar.gz (mother's files).  Test:  bash dev/ly1_test.sh -> LY1 OK;  bash dev/gate_w.sh -> GATE_W: ALL OK.
