"""DR1 - missions: 3 daily (refresh 00:00 Tehran) + 3 weekly (refresh at the start of the Tehran week) missions per player.

* The pool and the numbers come from liveops ("missions" section).  Each entry: id, kind (what is counted), goal, give (a reward in the vocabulary of dr_common), optional `when`.
* Kinds (the server already knows these events; no new client report is trusted):
      collect_n   collect taps worth at least `collect_min_h` hours of the mine's output   (hook: state.collect)
      collect_h   hours of mine output collected                                          (hook: state.collect)
      upgrade     upgrade levels finished                                                  (hook: state._txn, level sum before / after the settle)
      train       soldiers finished training                                               (hook: state._txn, army count before / after the settle)
      attack      attacks with at least one soldier sent                                   (hook: state.battle_end)
      win         attacks with at least one star                                           (hook: state.battle_end)
      stars       stars earned                                                             (hook: state.battle_end)
  Friendly and war attacks (info.mode != "normal") are NOT counted.
* `when`: {"attack": true} = only offered while attacks are open; {"keep_max": N, "upgrade_within_h": H} = offered to a castle <= N, or to a player whose upgrade ends within H hours.
* The set of missions of a day / week is drawn once, from the player's own random salt and the Tehran day / week, so it is the same after a restart; distinct kinds first.
* A finished mission is paid by `claim` (once) through the gift inbox.  An unclaimed one is gone when its day / week ends.
"""
from __future__ import annotations

import json
import random
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import dr_common as C
from . import wheel as W

DEFAULTS: Dict[str, Any] = json.loads((Path(__file__).with_name("missions_defaults.json")).read_text("utf-8"))
KINDS = ("collect_n", "collect_h", "upgrade", "train", "attack", "win", "stars")


def validate(d: Any) -> List[str]:
    if not isinstance(d, dict):
        return ["missions: not an object"]
    err: List[str] = []
    for k, lo, hi in (("daily_count", 1, 6), ("weekly_count", 1, 6)):
        v = d.get(k)
        if isinstance(v, bool) or not isinstance(v, int) or not (lo <= v <= hi):
            err.append("missions.%s: whole number %d..%d" % (k, lo, hi))
    if d.get("week_start") not in C.WEEKDAYS:
        err.append("missions.week_start: one of " + ", ".join(C.WEEKDAYS))
    v = d.get("collect_min_h")
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not (0 <= v <= 12):
        err.append("missions.collect_min_h: 0..12")
    seen = set()
    for sect, cnt in (("daily", "daily_count"), ("weekly", "weekly_count")):
        pool = d.get(sect)
        if not isinstance(pool, list) or not pool:
            err.append("missions.%s: a list of missions" % sect)
            continue
        if isinstance(d.get(cnt), int) and len(pool) < d[cnt]:
            err.append("missions.%s: needs at least %d entries" % (sect, d[cnt]))
        for i, m in enumerate(pool):
            w = "missions.%s[%d]" % (sect, i)
            if not isinstance(m, dict) or not isinstance(m.get("id"), str) or not m["id"] or len(m["id"]) > 24:
                err.append(w + ": need an id (text, up to 24 characters)")
                continue
            if m["id"] in seen:
                err.append(w + ": duplicate id " + m["id"])
            seen.add(m["id"])
            if m.get("kind") not in KINDS:
                err.append(w + ".kind: one of " + ", ".join(KINDS))
            g = m.get("goal")
            if isinstance(g, bool) or not isinstance(g, (int, float)) or not (0 < g <= 100000):
                err.append(w + ".goal: a number above 0")
            err += C.validate_reward(m.get("give"), w + ".give")
            wh = m.get("when")
            if wh is not None:
                if not isinstance(wh, dict) or any(k not in ("attack", "keep_max", "upgrade_within_h") for k in wh):
                    err.append(w + ".when: {attack?, keep_max?, upgrade_within_h?}")
    return err


C.register("missions", DEFAULTS, validate)


def cfg() -> Dict[str, Any]:
    c = C.cfg("missions", DEFAULTS)
    return c if not validate(c) else DEFAULTS


def _entry(c: Dict[str, Any], sect: str, mid: str) -> Optional[Dict[str, Any]]:
    for m in c[sect]:
        if m["id"] == mid:
            return m
    return None


def _eligible(st: Dict[str, Any], m: Dict[str, Any], t: float) -> bool:
    wh = m.get("when")
    if not wh:
        return True
    if wh.get("attack") and not C.attacks_open():
        return False
    if "keep_max" in wh or "upgrade_within_h" in wh:
        from . import progress as PR
        ok = "keep_max" in wh and PR.keep_level(st) <= int(wh["keep_max"])
        if not ok and "upgrade_within_h" in wh:
            lim = t + 3600.0 * float(wh["upgrade_within_h"])
            ok = any(0 < float(i.get("end") or 0) <= lim for i in st.get("q", []))
        return ok
    return True


def _draw(st: Dict[str, Any], c: Dict[str, Any], sect: str, count: int, stamp: int, t: float) -> List[Dict[str, Any]]:
    d = C.ensure(st)
    if not d.get("salt"):
        d["salt"] = random.SystemRandom().randrange(1, 2 ** 31)
    rng = random.Random("%s|%s|%d" % (d["salt"], sect, stamp))
    pool = [m for m in c[sect] if _eligible(st, m, t)]
    rng.shuffle(pool)
    out, kinds = [], set()
    for m in pool:                                          # distinct kinds first ...
        if len(out) < count and m["kind"] not in kinds:
            out.append(m)
            kinds.add(m["kind"])
    for m in pool:                                          # ... then whatever is left
        if len(out) < count and m not in out:
            out.append(m)
    return [{"id": m["id"], "p": 0, "c": 0} for m in out]


def roll(st: Dict[str, Any], t: Optional[float] = None) -> Dict[str, Any]:
    """Draw today's / this week's missions when the Tehran day / week has changed.  Returns the missions part of the state."""
    t = C.now() if t is None else t
    c = cfg()
    m = C.ensure(st)["m"]
    today, week = C.day_of(t), C.week_of(t, c["week_start"])
    if m["day"] != today:
        m["day"], m["dl"] = today, _draw(st, c, "daily", int(c["daily_count"]), today, t)
    if m["week"] != week:
        m["week"], m["wk"] = week, _draw(st, c, "weekly", int(c["weekly_count"]), week, t)
    return m


def bump(st: Dict[str, Any], kind: str, n: float, t: Optional[float] = None) -> None:
    """Count `n` of `kind` for every mission of that kind the player has today / this week (INSIDE the player's transaction)."""
    if n <= 0 or not C.on("missions"):
        return
    t = C.now() if t is None else t
    c = cfg()
    m = roll(st, t)
    for sect, lst in (("daily", m["dl"]), ("weekly", m["wk"])):
        for x in lst:
            e = _entry(c, sect, x["id"])
            if e is None or e["kind"] != kind or x["c"]:
                continue
            x["p"] = round(min(float(e["goal"]), float(x["p"]) + float(n)), 2)


def claimable(st: Dict[str, Any], t: Optional[float] = None) -> int:
    """How many finished, unpaid missions the player has right now (what the badge shows).  Reads only."""
    t = C.now() if t is None else t
    c = cfg()
    m = C.ensure(st)["m"]
    today, week = C.day_of(t), C.week_of(t, c["week_start"])
    n = 0
    for sect, lst, ok in (("daily", m["dl"], m["day"] == today), ("weekly", m["wk"], m["week"] == week)):
        if not ok:
            continue
        for x in lst:
            e = _entry(c, sect, x["id"])
            if e is not None and not x["c"] and float(x["p"]) >= float(e["goal"]):
                n += 1
    return n


def claim(st: Dict[str, Any], key: Any, t: Optional[float] = None) -> Dict[str, Any]:
    """key = "d:<id>" or "w:<id>".  INSIDE the player's transaction (the caller saves when ok)."""
    t = C.now() if t is None else t
    c = cfg()
    key = str(key or "")
    if key[:2] not in ("d:", "w:"):
        return {"ok": False, "why": "bad"}
    sect = "daily" if key[0] == "d" else "weekly"
    mid = key[2:]
    m = roll(st, t)
    x = next((x for x in (m["dl"] if sect == "daily" else m["wk"]) if x["id"] == mid), None)
    e = _entry(c, sect, mid)
    if x is None or e is None:
        return {"ok": False, "why": "gone"}
    if x["c"]:
        return {"ok": False, "why": "claimed"}
    if float(x["p"]) < float(e["goal"]):
        return {"ok": False, "why": "not_done"}
    stamp = m["day"] if sect == "daily" else m["week"]
    pay = C.prepare(st, e["give"], "mission", "%s:%d" % (key, stamp), t)
    x["c"] = 1
    C.outbox_add(st, pay["entries"])
    add = W.grant(st, pay["spins"], "mission", "%s:%d" % (key, stamp), t) if pay["spins"] else 0
    C.emit_xp(st, pay["xp"], "mission", "%s:%d" % (key, stamp))
    return {"ok": True, "key": key, "got": pay["got"], "lost": pay["lost"], "spins": add, "xp": pay["xp"], "t": int(t)}


def view(st: Dict[str, Any], t: Optional[float] = None) -> Dict[str, Any]:
    t = C.now() if t is None else t
    c = cfg()
    m = roll(st, t)

    def rows(sect, lst, pre):
        out = []
        for x in lst:
            e = _entry(c, sect, x["id"])
            if e is None:
                continue
            amt = C.amounts(st, e["give"])
            out.append({"key": pre + x["id"], "id": e["id"], "kind": e["kind"], "goal": e["goal"], "p": x["p"], "done": float(x["p"]) >= float(e["goal"]), "claimed": bool(x["c"]),
                        "give": e["give"], "val": {k: v for k, v in amt.items() if v}})
        return out
    return {"daily": rows("daily", m["dl"], "d:"), "weekly": rows("weekly", m["wk"], "w:"),
            "next_day": C.next_midnight(t), "next_week": C.next_week_start(t, c["week_start"])}
