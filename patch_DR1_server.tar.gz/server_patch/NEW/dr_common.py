"""DR1 - shared helpers of the wheel, the daily login reward and the missions.

* Tehran time.  Every "day" / "week" of DR1 is a day / week of Asia/Tehran (00:00 Tehran = 20:30 UTC).  The clock is injectable (`set_clock`) so the tests can move time forward.
* The reward vocabulary (one dict shape for a wheel segment, a login day and a mission):
      ruby_h / emerald_h / turq_h   hours of the player's OWN mine output of that gem (so a prize stays the same size of help from castle 1 to 50)
      ruby / emerald / turq         an absolute number of gems (tests, owner gifts)
      onyx / sap                    the two special gems (no vault)
      spins                         wheel spins for the spin bank (wheel.grant_spin)
      xp                            Battle Pass XP (handed to the sink BP1 registers; always counted in st.dr.x)
* Gems are NEVER written into the wallet here.  They go through the gift inbox (state.Store.push_inbox -> _drain_inbox), exactly like a prize from the bot:
      1. inside the player's transaction the reward is worked out (`prepare`: hours -> gems at the player's mine level, clamped to the room left in the vault) and its inbox
         entries are written into the player's own state, the OUTBOX (`st.dr.o`) - the state is saved;
      2. `flush` pushes the outbox entries into the inbox (ids are fixed and unique: a repeat is harmless, the drain applies an id once) and applies them at once.
  A crash between 1 and 2 loses nothing: the next call finds the outbox and pushes it again.
* Section switches and numbers come from liveops (OC1): liveops.flag("wheel" | "daily" | "missions"), liveops.get(section).
"""
from __future__ import annotations

import hashlib
import logging
import re
import time
from datetime import date, datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional

from . import progress as PR

try:                                                  # OC1 builds liveops; until it is merged the module runs on its own defaults with every section on
    from . import liveops
except ImportError:                                   # pragma: no cover
    liveops = None

log = logging.getLogger("bluewall.dr")

try:
    from zoneinfo import ZoneInfo
    TZ = ZoneInfo("Asia/Tehran")
except Exception:  # noqa: BLE001  (no tz database on the box: Iran has had no daylight saving since 2022, a fixed +03:30 is right)
    TZ = timezone(timedelta(hours=3, minutes=30))

GEMS = PR.GEMS                                        # ("ruby", "emerald", "turq")
PREM = ("sap", "onyx")
H_KEYS = tuple(g + "_h" for g in GEMS)
REWARD_KEYS = H_KEYS + GEMS + PREM + ("spins", "xp")
CHUNK_GEM = 4000                                      # one inbox entry carries at most this many gems of a mine kind (the drain clamps an entry at state.INBOX_MAX_TURQ = 5000)
CHUNK_PREM = 900                                      # ... and of sap / onyx (state.INBOX_MAX_PREM = 1000)
OUTBOX_MAX = 200
ID_RE = re.compile(r"^[A-Za-z0-9_\-]{8,40}$")         # a spin id the client makes up (one per tap)
WEEKDAYS = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}

# ------------------------------------------------------------------ clock + Tehran days
_clock: Callable[[], float] = time.time


def now() -> float:
    return _clock()


def set_clock(fn: Optional[Callable[[], float]]) -> None:
    """Tests: replace the clock (None = the real one)."""
    global _clock
    _clock = fn or time.time


def day_of(t: float) -> int:
    """The Tehran calendar day of the moment t, as a proleptic ordinal (an integer that grows by 1 at 00:00 Tehran)."""
    return datetime.fromtimestamp(float(t), TZ).date().toordinal()


def day_start(day: int) -> float:
    d = date.fromordinal(int(day))
    return datetime(d.year, d.month, d.day, tzinfo=TZ).timestamp()


def next_midnight(t: float) -> float:
    """The next 00:00 Tehran after t (the moment the free spin / the daily reward / the daily missions come back)."""
    return day_start(day_of(t) + 1)


def week_of(t: float, start: str = "sat") -> int:
    """The id of the Tehran week of t = the day number of the week's first day (the Iranian week starts on Saturday by default)."""
    day = day_of(t)
    wd = date.fromordinal(day).weekday()                  # Monday = 0
    return day - ((wd - WEEKDAYS.get(str(start), 5)) % 7)


def next_week_start(t: float, start: str = "sat") -> float:
    return day_start(week_of(t, start) + 7)


# ------------------------------------------------------------------ liveops handles
def on(flag: str) -> bool:
    if liveops is None:
        return True
    try:
        return bool(liveops.flag(flag))
    except Exception:  # noqa: BLE001
        return False


def register(section: str, defaults: Dict[str, Any], validate: Callable[[Any], List[str]]) -> None:
    """Tell liveops about a section (defaults + validator).  No-op while liveops is not merged."""
    if liveops is not None:
        liveops.register(section, defaults, validate)


def cfg(section: str, defaults: Dict[str, Any]) -> Dict[str, Any]:
    """The live numbers of a section (liveops merges the owner's overrides over the defaults).  Anything unusable falls back to the defaults."""
    if liveops is None:
        return defaults
    try:
        c = liveops.get(section)
        if isinstance(c, dict) and c:
            return c
    except Exception:  # noqa: BLE001
        log.warning("liveops.get(%s) failed - defaults used", section)
    return defaults


# ------------------------------------------------------------------ what the server tells us about itself
STORE: Any = None                                     # the state.Store (set by dr_routes.register)
_attack_open: Callable[[], bool] = lambda: True       # are attacks open to every player?  (kingdoms where they are not never get attack missions)


def bind(store: Any, attack_open: Optional[Callable[[], bool]] = None) -> None:
    global STORE, _attack_open
    STORE = store
    if attack_open is not None:
        _attack_open = attack_open


def attacks_open() -> bool:
    try:
        return bool(_attack_open())
    except Exception:  # noqa: BLE001
        return True


# ------------------------------------------------------------------ state
def ensure(st: Dict[str, Any]) -> Dict[str, Any]:
    """st["dr"] with every key present: w = wheel, d = daily login, m = missions, o = outbox (inbox entries not pushed yet), x = Battle Pass XP issued so far."""
    d = st.get("dr")
    if not isinstance(d, dict):
        d = st["dr"] = {}
    d.setdefault("v", 1)
    w = d.setdefault("w", {})
    for k, v in (("day", 0), ("used", 0), ("earned", 0), ("pity", 0), ("n", 0), ("pday", 0), ("pn", 0)):
        w.setdefault(k, v)
    w.setdefault("ids", [])
    w.setdefault("keys", [])
    g = d.setdefault("d", {})
    for k, v in (("i", 0), ("last", 0), ("s", 0), ("n", 0)):
        g.setdefault(k, v)
    m = d.setdefault("m", {})
    m.setdefault("day", 0)
    m.setdefault("week", 0)
    m.setdefault("dl", [])
    m.setdefault("wk", [])
    d.setdefault("o", [])
    d.setdefault("x", 0)
    return d


def clean_id(v: Any) -> Optional[str]:
    s = str(v or "")
    return s if ID_RE.match(s) else None


def _h(*parts: Any) -> str:
    return "dr" + hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8", "replace")).hexdigest()[:22]


# ------------------------------------------------------------------ rewards
def validate_reward(g: Any, where: str, *, allow_empty: bool = False) -> List[str]:
    """Errors of one reward dict (the same vocabulary everywhere)."""
    if not isinstance(g, dict):
        return [where + ": not an object"]
    err: List[str] = []
    pos = False
    for k, v in g.items():
        if k not in REWARD_KEYS:
            err.append("%s: unknown key %r" % (where, k))
            continue
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v:
            err.append("%s.%s: not a number" % (where, k))
            continue
        lim = {"spins": 20, "xp": 100000, "onyx": 100, "sap": 500}.get(k, 48.0 if k.endswith("_h") else 1000000)
        if not (0 <= v <= lim):
            err.append("%s.%s: %s outside 0..%s" % (where, k, v, lim))
        elif v > 0:
            pos = True
        if k in ("spins", "xp", "onyx", "sap") + GEMS and float(v) != int(v):
            err.append("%s.%s: must be a whole number" % (where, k))
    if not pos and not allow_empty and not err:
        err.append(where + ": pays nothing")
    return err


def rate(st: Dict[str, Any], gem: str) -> float:
    """Gems per hour of the player's mine of that gem."""
    return PR.mine_rate(gem, max(1, PR.level(st, "mine_" + gem)))


def amounts(st: Dict[str, Any], give: Dict[str, Any]) -> Dict[str, int]:
    """The gems a reward is worth to this player right now (before the vault's room is looked at)."""
    out = {}
    for g in GEMS:
        n = int(give.get(g, 0) or 0)
        h = float(give.get(g + "_h", 0) or 0)
        if h > 0:
            n += max(1, int(h * rate(st, g)))
        out[g] = n
    return out


def room(st: Dict[str, Any], gem: str) -> int:
    return max(0, PR.vault_cap(gem, max(1, PR.level(st, "vault_" + gem))) - int(st["gems"].get(gem, 0)))


def _pending(st: Dict[str, Any]) -> Dict[str, int]:
    """Gems already promised to the player and still waiting in the outbox (so two rewards in a row cannot both fit into the same room)."""
    p: Dict[str, int] = {g: 0 for g in GEMS}
    for e in ensure(st)["o"]:
        for g in GEMS:
            p[g] += int(e.get(g, 0) or 0)
    return p


def _chunks(src: str, key: str, gem: str, n: int, size: int, t: float) -> List[Dict[str, Any]]:
    out, i = [], 0
    while n > 0:
        k = min(size, n)
        out.append({"id": _h(src, key, gem, i), "src": src, gem: int(k), "t": int(t)})
        n -= k
        i += 1
    return out


def prepare(st: Dict[str, Any], give: Dict[str, Any], src: str, key: str, t: Optional[float] = None) -> Dict[str, Any]:
    """Work out what `give` pays this player NOW.  Gems that do not fit into the vault are lost (`lost`), never pushed above the cap.
    Returns {"got": {gem: n}, "lost": {gem: n}, "spins": n, "xp": n, "entries": [inbox entries]}.  Changes nothing."""
    t = now() if t is None else t
    amt = amounts(st, give)
    pend = _pending(st)
    got: Dict[str, int] = {}
    lost: Dict[str, int] = {}
    entries: List[Dict[str, Any]] = []
    for g in GEMS:
        n = amt[g]
        if n <= 0:
            continue
        k = max(0, min(n, room(st, g) - pend[g]))
        if k < n:
            lost[g] = n - k
        if k > 0:
            got[g] = k
            entries += _chunks(src, key, g, k, CHUNK_GEM, t)
    for p in PREM:
        n = int(give.get(p, 0) or 0)
        if n > 0:
            got[p] = n
            entries += _chunks(src, key, p, n, CHUNK_PREM, t)
    return {"got": got, "lost": lost, "spins": int(give.get("spins", 0) or 0), "xp": int(give.get("xp", 0) or 0), "entries": entries}


def outbox_add(st: Dict[str, Any], entries: List[Dict[str, Any]]) -> None:
    d = ensure(st)
    d["o"].extend(entries)
    del d["o"][:-OUTBOX_MAX]


async def flush(uid: int, store: Any = None) -> int:
    """Push the outbox of this player into his gift inbox and apply it at once.  Returns how many entries went.  Safe to call any time, as often as you like."""
    store = store or STORE
    async with store._lock(uid):
        st = await store.load(uid)
        todo = [dict(e) for e in ensure(st)["o"]]
    if not todo:
        return 0
    done = []
    for e in todo:
        if await store.push_inbox(uid, e):
            done.append(e["id"])
    async with store._lock(uid):
        st = await store._txn(uid)                                                   # (the drain applies the gifts, each id once)
        d = ensure(st)
        dn = set(done)
        gone = [e for e in d["o"] if e.get("id") in dn]
        d["o"] = [e for e in d["o"] if e.get("id") not in dn]
        gn = st.get("gnew")
        if isinstance(gn, dict):                                                     # (the DR1 sheet shows the prize itself: take OUR part out of the "you got a gift" toast, keep other gifts)
            for e in gone:
                for k in GEMS + PREM:
                    if k in gn:
                        gn[k] = max(0, int(gn.get(k, 0)) - int(e.get(k, 0) or 0))
            if not any(int(gn.get(k, 0)) for k in GEMS + PREM):
                st.pop("gnew", None)
        await store.save(uid, st)
    return len(done)


# ------------------------------------------------------------------ Battle Pass XP
_xp_sink: Optional[Callable[..., Any]] = None


def set_xp_sink(fn: Optional[Callable[..., Any]]) -> None:
    """BP1 registers `fn(st, xp, why, key)`; it is called INSIDE the player's transaction (it changes st, never saves)."""
    global _xp_sink
    _xp_sink = fn


def emit_xp(st: Dict[str, Any], n: int, why: str, key: str) -> None:
    if n <= 0:
        return
    d = ensure(st)
    d["x"] = int(d.get("x", 0)) + int(n)                                              # (total XP DR1 has issued: nothing is lost while no sink is registered)
    if _xp_sink is not None:
        try:
            _xp_sink(st, int(n), why, key)
        except Exception:  # noqa: BLE001
            log.exception("xp sink failed (%s %s)", why, key)


def hours_value(give: Dict[str, Any]) -> float:
    """Gem-hours a reward is worth (the three gems counted equally; spins / xp / onyx / sap not included) - used by the value tools."""
    return sum(float(give.get(k, 0) or 0) for k in H_KEYS)
