"""DR1 - the prize wheel (the server decides everything; the client only draws the answer).

* 8 weighted segments from liveops ("wheel" section).  Each segment pays a reward in the shared vocabulary of dr_common (hours of the player's own mine output, spins, xp ...).
* Spins: `free_per_day` free spins that reset at 00:00 Tehran (not saved up), plus a bank of EARNED spins (`grant` / `add_spin`: Battle Pass, missions, login days, the "spin" segment), capped by `bank_cap`.
  A PAID spin (sapphire / onyx) exists but is OFF by default (`paid.enabled`).
* Pity: after `pity_after` spins in a row without a rare segment, the next one is a rare segment for sure (0 = off).
* One tap = one spin: the client sends a fresh spin id; the same id again returns the stored answer and changes nothing.
* The prize goes through the gift inbox (dr_common.prepare / outbox / flush) and never above the vault.
"""
from __future__ import annotations

import json
import random
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import dr_common as C

DEFAULTS: Dict[str, Any] = json.loads((Path(__file__).with_name("wheel_defaults.json")).read_text("utf-8"))
SEGS = 8
IDS_KEEP = 12                                          # spin ids remembered for replay
KEYS_KEEP = 60                                         # earned-spin keys remembered (add_spin idempotency)
_rng: random.Random = random.SystemRandom()


def set_rng(r: Optional[random.Random]) -> None:
    """Tests: a seeded generator (None = the system one)."""
    global _rng
    _rng = r or random.SystemRandom()


# ------------------------------------------------------------------ config
def validate(d: Any) -> List[str]:
    if not isinstance(d, dict):
        return ["wheel: not an object"]
    err: List[str] = []

    def num(k, lo, hi, whole=True):
        v = d.get(k)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not (lo <= v <= hi) or (whole and v != int(v)):
            err.append("wheel.%s: need %s %s..%s" % (k, "a whole number" if whole else "a number", lo, hi))
    num("free_per_day", 0, 10)
    num("bank_cap", 0, 100)
    num("anim_ms", 1500, 6000)
    num("pity_after", 0, 500)
    p = d.get("paid")
    if not isinstance(p, dict) or not isinstance(p.get("enabled"), bool):
        err.append("wheel.paid: need {enabled, cost, max_per_day}")
    else:
        c = p.get("cost")
        if not isinstance(c, dict) or not c or any(k not in C.PREM or isinstance(v, bool) or not isinstance(v, int) or not (1 <= v <= 1000) for k, v in c.items()):
            err.append("wheel.paid.cost: {sap|onyx: 1..1000}")
        m = p.get("max_per_day")
        if isinstance(m, bool) or not isinstance(m, int) or not (0 <= m <= 50):
            err.append("wheel.paid.max_per_day: 0..50")
    segs = d.get("segments")
    if not isinstance(segs, list) or len(segs) != SEGS:
        return err + ["wheel.segments: exactly %d segments" % SEGS]
    ids, tot, rare = set(), 0.0, 0.0
    for i, s in enumerate(segs):
        w = "wheel.segments[%d]" % i
        if not isinstance(s, dict) or not isinstance(s.get("id"), str) or not s["id"] or len(s["id"]) > 24:
            err.append(w + ": need an id (text, up to 24 characters)")
            continue
        if s["id"] in ids:
            err.append(w + ": duplicate id " + s["id"])
        ids.add(s["id"])
        wt = s.get("w")
        if isinstance(wt, bool) or not isinstance(wt, (int, float)) or not (0 < wt <= 1000):
            err.append(w + ".w: weight 0..1000 (above 0)")
            continue
        tot += wt
        if s.get("rare") is True:
            rare += wt
        elif s.get("rare") not in (None, False):
            err.append(w + ".rare: true or leave out")
        err += C.validate_reward(s.get("give"), w + ".give")
    if int(d.get("pity_after", 0) or 0) > 0 and rare <= 0:
        err.append("wheel.pity_after needs at least one segment with rare: true")
    return err


C.register("wheel", DEFAULTS, validate)


def cfg() -> Dict[str, Any]:
    c = C.cfg("wheel", DEFAULTS)
    return c if not validate(c) else DEFAULTS          # (a broken override never reaches a player)


# ------------------------------------------------------------------ the player's wheel state
def roll_day(st: Dict[str, Any], t: float) -> Dict[str, Any]:
    w = C.ensure(st)["w"]
    today = C.day_of(t)
    if w["day"] != today:
        w["day"], w["used"], w["pday"], w["pn"] = today, 0, today, 0
    return w


def free_left(st: Dict[str, Any], t: float, c: Optional[Dict[str, Any]] = None) -> int:
    c = c or cfg()
    w = C.ensure(st)["w"]
    return max(0, int(c["free_per_day"]) - (int(w["used"]) if w["day"] == C.day_of(t) else 0))


def spins_ready(st: Dict[str, Any], t: float, c: Optional[Dict[str, Any]] = None) -> int:
    """Free + earned spins the player can use now (what the badge shows)."""
    c = c or cfg()
    return free_left(st, t, c) + int(C.ensure(st)["w"]["earned"])


def grant(st: Dict[str, Any], n: int, why: str, key: Optional[str] = None, t: Optional[float] = None) -> int:
    """Add earned spins INSIDE a transaction (the caller saves).  `key` makes it idempotent (a claim id of the caller).  Returns how many spins were really added (the bank has a cap)."""
    n = int(n)
    if n <= 0:
        return 0
    w = C.ensure(st)["w"]
    if key:
        key = str(key)[:48]
        if key in w["keys"]:
            return 0
        w["keys"].append(key)
        del w["keys"][:-KEYS_KEEP]
    c = cfg()
    add = max(0, min(n, int(c["bank_cap"]) - int(w["earned"])))
    w["earned"] = int(w["earned"]) + add
    w["n_earned"] = int(w.get("n_earned", 0)) + add
    return add


async def add_spin(uid: int, n: int, why: str, key: Optional[str] = None) -> int:
    """For Battle Pass / missions / admin code that is NOT inside a player transaction: lock, load, add, save.  Returns the spins added."""
    store = C.STORE
    async with store._lock(uid):
        st = await store._txn(uid)
        add = grant(st, n, why, key)
        await store.save(uid, st)
    return add


# ------------------------------------------------------------------ one spin
def _pick(segs: List[Dict[str, Any]], only_rare: bool) -> int:
    pool = [(i, float(s["w"])) for i, s in enumerate(segs) if (s.get("rare") is True or not only_rare)]
    r = _rng.random() * sum(w for _, w in pool)
    acc = 0.0
    for i, w in pool:
        acc += w
        if r < acc:
            return i
    return pool[-1][0]


def spin(st: Dict[str, Any], sid: Optional[str], paid: bool = False, t: Optional[float] = None) -> Dict[str, Any]:
    """INSIDE the player's transaction (the caller saves when ok).  Returns {"ok": True, ...result} or {"ok": False, "why": ...}."""
    t = C.now() if t is None else t
    sid = C.clean_id(sid)
    if not sid:
        return {"ok": False, "why": "bad"}
    c = cfg()
    w = roll_day(st, t)
    for e in w["ids"]:
        if e.get("i") == sid:
            return {"ok": True, "again": True, **e["r"]}                       # the same tap again: the same answer, nothing changes
    src = None
    if paid:
        p = c["paid"]
        if not p["enabled"]:
            return {"ok": False, "why": "off"}
        if int(w["pn"]) >= int(p["max_per_day"]):
            return {"ok": False, "why": "limit"}
        pm = st.setdefault("prem", {})
        if any(int(pm.get(k, 0) or 0) < int(v) for k, v in p["cost"].items()):
            return {"ok": False, "why": "funds"}
        src = "paid"
    elif free_left(st, t, c) > 0:
        src = "free"
    elif int(w["earned"]) > 0:
        src = "earned"
    else:
        return {"ok": False, "why": "no_spin"}
    segs = c["segments"]
    forced = int(c["pity_after"]) > 0 and int(w["pity"]) >= int(c["pity_after"])
    i = _pick(segs, forced)
    seg = segs[i]
    # --- from here nothing can fail: change the state
    if src == "paid":
        for k, v in c["paid"]["cost"].items():
            st["prem"][k] = int(st["prem"].get(k, 0) or 0) - int(v)
        w["pn"] = int(w["pn"]) + 1
    elif src == "free":
        w["used"] = int(w["used"]) + 1
    else:
        w["earned"] = int(w["earned"]) - 1
    w["n"] = int(w["n"]) + 1
    w["pity"] = 0 if seg.get("rare") is True else int(w["pity"]) + 1
    pay = C.prepare(st, seg["give"], "wheel", sid, t)
    C.outbox_add(st, pay["entries"])
    add = grant(st, pay["spins"], "wheel", "wheel:" + sid, t) if pay["spins"] else 0
    C.emit_xp(st, pay["xp"], "wheel", "wheel:" + sid)
    res = {"id": sid, "i": i, "seg": seg["id"], "src": src, "pity": bool(forced), "got": pay["got"], "lost": pay["lost"], "spins": add, "xp": pay["xp"], "t": int(t)}
    w["ids"].append({"i": sid, "r": res})
    del w["ids"][:-IDS_KEEP]
    return {"ok": True, **res}


# ------------------------------------------------------------------ what the sheet shows
def odds(c: Dict[str, Any]) -> List[float]:
    tot = sum(float(s["w"]) for s in c["segments"])
    return [round(100.0 * float(s["w"]) / tot, 2) for s in c["segments"]]


def rare_rate(c: Dict[str, Any]) -> float:
    """The chance of a rare segment on one spin WITH the pity rule (a run of N non-rare spins is followed by a forced one), in percent."""
    tot = sum(float(s["w"]) for s in c["segments"])
    p = sum(float(s["w"]) for s in c["segments"] if s.get("rare") is True) / tot
    n = int(c["pity_after"])
    if p <= 0:
        return 0.0
    if n <= 0:
        return round(100.0 * p, 2)
    mean_gap = (1.0 - (1.0 - p) ** (n + 1)) / p        # spins between two rares: a geometric wait cut at n + 1
    return round(100.0 / mean_gap, 2)


def view(st: Dict[str, Any], t: Optional[float] = None) -> Dict[str, Any]:
    t = C.now() if t is None else t
    c = cfg()
    w = C.ensure(st)["w"]
    today = C.day_of(t)
    used = int(w["used"]) if w["day"] == today else 0
    pn = int(w["pn"]) if w["day"] == today else 0
    od = odds(c)
    segs = []
    for i, s in enumerate(c["segments"]):
        amt = C.amounts(st, s["give"])
        segs.append({"i": i, "id": s["id"], "give": s["give"], "val": {g: n for g, n in amt.items() if n}, "pct": od[i], "rare": s.get("rare") is True})
    p = c["paid"]
    return {"segs": segs, "free": max(0, int(c["free_per_day"]) - used), "free_max": int(c["free_per_day"]), "earned": int(w["earned"]), "bank_cap": int(c["bank_cap"]),
            "next": C.next_midnight(t), "anim_ms": int(c["anim_ms"]),
            "pity": {"after": int(c["pity_after"]), "n": int(w["pity"]), "rare_pct": rare_rate(c)},
            "paid": ({"cost": p["cost"], "left": max(0, int(p["max_per_day"]) - pn)} if p["enabled"] else None),
            "room": {g: C.room(st, g) for g in C.GEMS}, "n": int(w["n"])}
