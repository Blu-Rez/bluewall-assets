"""DR1 - HTTP routes (see ROUTES.md).  All need the session Bearer token; every answer is {"ok": bool, ...}.

    GET  /api/dr                  the whole sheet: wheel + login + missions (+ which sections are on)
    POST /api/wheel/spin          {id, paid?}      one spin (id = a fresh id per tap; the same id again returns the same answer)
    POST /api/daily/claim         {}               today's login reward
    POST /api/missions/claim      {key}            "d:<id>" or "w:<id>"
"""
from __future__ import annotations

import logging
import time
from typing import Any, Callable, Dict, Optional

from aiohttp import web

from . import dr_common as C
from . import daily as D
from . import missions as M
from . import wheel as W

log = logging.getLogger("bluewall.dr")

_bearer: Callable[[web.Request], Optional[int]]
_limited: Callable[..., bool]
_nocache: Callable[[web.StreamResponse], web.StreamResponse]
_unavail: tuple = ()


def _json(d: Dict[str, Any], status: int = 200) -> web.Response:
    return _nocache(web.json_response(d, status=status))


def _guard(req: web.Request, per: int, key: str = "dr"):
    uid = _bearer(req)
    if uid is None:
        return None, _json({"ok": False, "reason": "locked"}, 403)
    if _limited(key + ":" + str(uid), per):
        return None, _json({"ok": False, "reason": "slow"}, 429)
    return uid, None


def _flags() -> Dict[str, bool]:
    return {"wheel": C.on("wheel"), "daily": C.on("daily"), "missions": C.on("missions")}


async def _body(req: web.Request) -> Dict[str, Any]:
    try:
        b = await req.json()
        return b if isinstance(b, dict) else {}
    except Exception:  # noqa: BLE001
        return {}


async def _sheet(uid: int) -> Dict[str, Any]:
    """Everything the sheet shows, from one transaction (also pays out a prize that a crash left in the outbox)."""
    store = C.STORE
    fl = _flags()
    async with store._lock(uid):
        st = await store._txn(uid)
        t = C.now()
        out: Dict[str, Any] = {"ok": True, "now": t, "on": fl}
        if fl["wheel"]:
            out["wheel"] = W.view(st, t)
        if fl["daily"]:
            out["daily"] = D.view(st, t)
        if fl["missions"]:
            out["missions"] = M.view(st, t)
        out["gems"] = {g: int(st["gems"].get(g, 0)) for g in C.GEMS}
        out["prem"] = {k: int((st.get("prem") or {}).get(k, 0) or 0) for k in C.PREM}
        todo = bool(C.ensure(st)["o"])
        await store.save(uid, st)
    if todo:
        await C.flush(uid)
        async with store._lock(uid):
            st = await store.load(uid)
            out["gems"] = {g: int(st["gems"].get(g, 0)) for g in C.GEMS}
            out["prem"] = {k: int((st.get("prem") or {}).get(k, 0) or 0) for k in C.PREM}
    return out


async def h_dr(req: web.Request) -> web.Response:
    uid, bad = _guard(req, 40, "drg")
    if bad is not None:
        return bad
    try:
        return _json(await _sheet(uid))
    except _unavail:
        return _json({"ok": False, "reason": "busy"}, 503)


async def _act(req: web.Request, flag: str, fn: Callable[[Dict[str, Any], Dict[str, Any], float], Dict[str, Any]], per: int) -> web.Response:
    uid, bad = _guard(req, per, "dr" + flag[0])
    if bad is not None:
        return bad
    if not C.on(flag):
        return _json({"ok": False, "why": "off"})
    body = await _body(req)
    store = C.STORE
    try:
        async with store._lock(uid):
            st = await store._txn(uid)
            t = C.now()
            res = fn(st, body, t)
            if res.get("ok"):
                await store.save(uid, st)
            else:
                await store.save(uid, st)                              # (the transaction may have settled upgrades / rolled the day: keep that)
        if res.get("ok") and C.ensure(st)["o"]:
            await C.flush(uid)
        out = await _sheet(uid)
        out.update({"res": res, "ok": bool(res.get("ok")), "why": res.get("why")})
        log.info("dr %s uid=%s ok=%s got=%s", flag, uid, res.get("ok"), res.get("got"))
        return _json(out)
    except _unavail:
        return _json({"ok": False, "reason": "busy"}, 503)


async def h_spin(req: web.Request) -> web.Response:
    return await _act(req, "wheel", lambda st, b, t: W.spin(st, b.get("id"), bool(b.get("paid")), t), 30)


async def h_daily(req: web.Request) -> web.Response:
    return await _act(req, "daily", lambda st, b, t: D.claim(st, t), 20)


async def h_mission(req: web.Request) -> web.Response:
    return await _act(req, "missions", lambda st, b, t: M.claim(st, b.get("key"), t), 30)


def _attack_public() -> bool:
    from . import state as S                                           # (lazy: state.py imports dr_hooks, so this module must not import state at load time)
    return bool(S.ATTACK_PUBLIC)


def register(app: web.Application, *, bearer_uid: Callable, limited: Callable, nocache: Callable, store: Any, unavailable: Optional[tuple] = None,
             attack_open: Optional[Callable[[], bool]] = None) -> None:
    """Called once from server.make_app()."""
    global _bearer, _limited, _nocache, _unavail
    if unavailable is None:
        from .state import StateUnavailable                            # (the exception the store raises when a kingdom cannot be read)
        unavailable = (StateUnavailable,)
    _bearer, _limited, _nocache, _unavail = bearer_uid, limited, nocache, tuple(unavailable)
    C.bind(store, attack_open or _attack_public)
    app.router.add_get("/api/dr", h_dr)
    app.router.add_post("/api/wheel/spin", h_spin)
    app.router.add_post("/api/daily/claim", h_daily)
    app.router.add_post("/api/missions/claim", h_mission)
