"""DR1 - the few places where the game server tells DR1 what happened.  Every function is wrapped: a bug here is logged and NEVER breaks collecting, upgrading, training or a battle.

state.py calls (each one marked `# DR1:`):
    DR.snap(st)                  before PR.settle in Store._txn            -> (level sum, army count)
    DR.on_settle(st, snap)       after MI.settle in Store._txn             -> counts finished upgrades / trained soldiers
    DR.on_collect(st, mine, got) in Store.collect                          -> counts collect taps / hours
    DR.on_battle(st, info, spec) in Store.battle_end (why == "ok")         -> counts attacks / wins / stars   (only mode "normal")
    DR.badge(st)                 in Store.view                             -> {"n": total, "w": spins, "d": 0|1, "m": missions to claim}
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Tuple

from . import dr_common as C
from . import daily as D
from . import missions as M
from . import wheel as W

log = logging.getLogger("bluewall.dr")


def snap(st: Dict[str, Any]) -> Optional[Tuple[int, int]]:
    try:
        return (sum(int(v) for v in (st.get("b") or {}).values()), sum(int(n) for n in (st.get("army") or {}).values()))
    except Exception:  # noqa: BLE001
        log.exception("DR1 snap")
        return None


def on_settle(st: Dict[str, Any], s0: Optional[Tuple[int, int]]) -> None:
    if s0 is None:
        return
    try:
        s1 = snap(st)
        if s1 is None:
            return
        if s1[0] > s0[0]:
            M.bump(st, "upgrade", s1[0] - s0[0])
        if s1[1] > s0[1]:
            M.bump(st, "train", s1[1] - s0[1])
    except Exception:  # noqa: BLE001
        log.exception("DR1 on_settle")


def on_collect(st: Dict[str, Any], mine: str, got: int) -> None:
    try:
        if got <= 0 or mine not in C.GEMS:
            return
        h = float(got) / max(1e-9, C.rate(st, mine))
        if h >= float(M.cfg()["collect_min_h"]):
            M.bump(st, "collect_n", 1)
        M.bump(st, "collect_h", h)
    except Exception:  # noqa: BLE001
        log.exception("DR1 on_collect")


def on_battle(st: Dict[str, Any], info: Dict[str, Any], spec: Optional[Dict[str, Any]]) -> None:
    try:
        mode = str((info or {}).get("mode") or (spec or {}).get("mode") or "normal")
        if mode != "normal":                                              # friendly / war battles count for nothing here
            return
        rep = (info or {}).get("report") or {}
        if not any(int(n or 0) > 0 for n in (rep.get("sent") or {}).values()):
            return                                                        # (a report with nobody sent is not an attack)
        stars = max(0, int((info or {}).get("stars") or 0))
        M.bump(st, "attack", 1)
        if stars >= 1:
            M.bump(st, "win", 1)
            M.bump(st, "stars", stars)
    except Exception:  # noqa: BLE001
        log.exception("DR1 on_battle")


def badge(st: Dict[str, Any]) -> Dict[str, int]:
    """What the hub icon shows: free + earned spins, today's login reward, finished missions.  A section that liveops switched off counts for 0."""
    try:
        t = C.now()
        w = W.spins_ready(st, t) if C.on("wheel") else 0
        d = 1 if (C.on("daily") and D.claimable(st, t)) else 0
        m = M.claimable(st, t) if C.on("missions") else 0
        return {"n": w + d + m, "w": w, "d": d, "m": m}
    except Exception:  # noqa: BLE001
        log.exception("DR1 badge")
        return {"n": 0, "w": 0, "d": 0, "m": 0}
