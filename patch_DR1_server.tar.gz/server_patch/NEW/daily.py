"""DR1 - the daily login reward: a 7-day cycle, one claim per Tehran day.

* The table comes from liveops ("daily" section): 7 rewards in the shared vocabulary of dr_common.
* Missing a day: `on_miss` = "pause" (the cycle waits where it was) or "reset" (back to day 1).
* One claim per Tehran day (the day changes at 00:00 Tehran); a second claim the same day pays nothing.
* The prize goes through the gift inbox (dr_common.prepare / outbox / flush) and never above the vault.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import dr_common as C
from . import wheel as W

DEFAULTS: Dict[str, Any] = json.loads((Path(__file__).with_name("daily_defaults.json")).read_text("utf-8"))
DAYS = 7


def validate(d: Any) -> List[str]:
    if not isinstance(d, dict):
        return ["daily: not an object"]
    err: List[str] = []
    if d.get("on_miss") not in ("pause", "reset"):
        err.append('daily.on_miss: "pause" or "reset"')
    days = d.get("days")
    if not isinstance(days, list) or len(days) != DAYS:
        return err + ["daily.days: exactly %d rewards" % DAYS]
    for i, g in enumerate(days):
        err += C.validate_reward(g, "daily.days[%d]" % i)
    return err


C.register("daily", DEFAULTS, validate)


def cfg() -> Dict[str, Any]:
    c = C.cfg("daily", DEFAULTS)
    return c if not validate(c) else DEFAULTS


def _where(st: Dict[str, Any], t: float, c: Dict[str, Any]) -> Dict[str, Any]:
    """Which day of the cycle is next, and in what state is the player today."""
    g = C.ensure(st)["d"]
    today = C.day_of(t)
    last = int(g["last"])
    claimed = last == today
    missed = last > 0 and today - last > 1
    idx = int(g["i"]) % DAYS
    if missed and c["on_miss"] == "reset":
        idx = 0
    return {"idx": idx, "claimed": claimed, "missed": missed, "today": today}


def claimable(st: Dict[str, Any], t: Optional[float] = None) -> bool:
    t = C.now() if t is None else t
    return not _where(st, t, cfg())["claimed"]


def claim(st: Dict[str, Any], t: Optional[float] = None) -> Dict[str, Any]:
    """INSIDE the player's transaction (the caller saves when ok)."""
    t = C.now() if t is None else t
    c = cfg()
    p = _where(st, t, c)
    if p["claimed"]:
        return {"ok": False, "why": "claimed"}
    g = C.ensure(st)["d"]
    idx = p["idx"]
    give = c["days"][idx]
    pay = C.prepare(st, give, "daily", "%d:%d" % (p["today"], idx), t)
    C.outbox_add(st, pay["entries"])
    add = W.grant(st, pay["spins"], "daily", "daily:%d" % p["today"], t) if pay["spins"] else 0
    C.emit_xp(st, pay["xp"], "daily", "daily:%d" % p["today"])
    g["last"] = p["today"]
    g["i"] = (idx + 1) % DAYS
    g["n"] = int(g["n"]) + 1
    return {"ok": True, "day": idx, "got": pay["got"], "lost": pay["lost"], "spins": add, "xp": pay["xp"], "t": int(t)}


def view(st: Dict[str, Any], t: Optional[float] = None) -> Dict[str, Any]:
    t = C.now() if t is None else t
    c = cfg()
    p = _where(st, t, c)
    days = []
    for i, give in enumerate(c["days"]):
        amt = C.amounts(st, give)
        days.append({"n": i + 1, "give": give, "val": {k: v for k, v in amt.items() if v}})
    return {"days": days, "idx": p["idx"], "claimed": p["claimed"], "missed": p["missed"], "on_miss": c["on_miss"], "next": C.next_midnight(t),
            "total": int(C.ensure(st)["d"]["n"])}
