# DR1 — server patch (wheel · daily login reward · missions)

**Apply** (inside `bluewall/`, on the kit): copy `NEW/*` next to `state.py`, then `patch -p1 < state.py.diff` and `patch -p1 < server.py.diff`.
Tested: `bash dev/dr1_tree.sh` builds the scratch tree exactly like this, `python3 dev/dr1_test.py` → `DR1 OK`.
Marked lines: `state.py` **6** (`# DR1:`), `server.py` **2**. Everything else lives in `NEW/`.

Merge order (ROUND8_COMMON §6): …OC1 → … → **DR1** → BP1. DR1 runs without `liveops` (own defaults, every section on) but is built for OC1's contract:
`liveops.get("wheel"|"daily"|"missions")`, `liveops.flag("wheel"|"daily"|"missions")`, `liveops.register(section, defaults, validate)` — called at import by `wheel.py`, `daily.py`, `missions.py`.

## Routes (all need `Authorization: Bearer <session>`; answers `{"ok": bool, ...}`; `403 {"reason":"locked"}` without a session, `429 {"reason":"slow"}` when limited)
| method + path | body | answer | limit (per player / min) |
|---|---|---|---|
| `GET /api/dr` | – | the whole sheet: `{ok, now, on:{wheel,daily,missions}, wheel?, daily?, missions?, gems:{ruby,emerald,turq}, prem:{sap,onyx}}` — a section that liveops switched off is missing. Also pays a prize that a crash left in the outbox. | 40 |
| `POST /api/wheel/spin` | `{id, paid?}` — `id` = fresh text 8–40 chars `[A-Za-z0-9_-]` per tap | the sheet (as above) + `res`: `{ok, id, i, seg, src:"free"\|"earned"\|"paid", pity:bool, got:{gem:n}, lost:{gem:n}, spins, xp, t, again?}`; `ok:false` + `why`: `bad` (id) `no_spin` `off` `limit` `funds` | 30 |
| `POST /api/daily/claim` | `{}` | the sheet + `res: {ok, day, got, lost, spins, xp}`; `why:"claimed"` the second time the same Tehran day | 20 |
| `POST /api/missions/claim` | `{key}` — `"d:<id>"` / `"w:<id>"` | the sheet + `res: {ok, key, got, lost, spins, xp}`; `why`: `bad` `gone` `claimed` `not_done` | 30 |
Every action answer also has top-level `ok` / `why` copied from `res`, and `why:"off"` when liveops switched the section off.

`GET /api/state` (existing) gets one more key: `dr: {n, w, d, m}` = hub badge (`w` free + earned spins, `d` 1 when today's login reward is waiting, `m` finished unpaid missions; a section that is off counts 0, `n` = sum).

## Server rules
- **Server decides**: the segment, the pity, the day. The client only sends a fresh id per tap; the same id returns the stored answer and changes nothing (last 12 ids kept in `st.dr.w.ids`, saved in the same write as the spin).
- **Tehran time**: day and week change at 00:00 `Asia/Tehran` (= 20:30 UTC; fixed +03:30 fallback when the tz database is missing). Free spin, login reward, daily missions: new each day. Weekly missions: new at the start of the Tehran week (`week_start`, default Saturday).
- **Prizes through the gift inbox**: the reward is worked out in the player's transaction (hours of the player's own mine output → gems at his mine level), cut to the room that is left in each vault (what does not fit is *lost* and reported in `lost`), written to `st.dr.o` (outbox) and saved; then pushed into the inbox with fixed ids (`dr…` sha1 of source+key+gem) and applied at once. A crash anywhere between the two loses nothing and pays nothing twice (the drain remembers ids). The "you got a gift" toast is not shown for DR1 prizes (the sheet shows them).
- **Hooks** (all wrapped in try/except: a bug in DR1 can never break collecting, upgrading, training or a battle): `Store._txn` counts finished upgrades (sum of structure levels before/after `settle`) and trained soldiers (army count before/after `settle`); `Store.collect` counts collect taps (≥ `collect_min_h` hours of output) and hours; `Store.battle_end` (why == ok) counts attacks (≥ 1 soldier sent), wins (≥ 1 star), stars — **only `info.mode`/`spec.mode` == "normal"** (friendly / war: nothing).
- **For other chats**: `wheel.add_spin(uid, n, why, key=None)` (async, own lock+save) or `wheel.grant(st, n, why, key)` (sync, inside a transaction) → earned spins (bank cap `bank_cap`; `key` makes it idempotent). `dr_common.set_xp_sink(fn)`: BP1 registers `fn(st, xp, why, key)` (called inside the transaction, must not save); until then XP is only counted in `st.dr.x`.
- **State**: `st["dr"] = {v, w:{day,used,earned,pity,n,pday,pn,ids,keys}, d:{i,last,n}, m:{day,week,dl,wk,salt?}, o:[outbox], x:xp issued}` — about 1 KB per player.

## liveops sections (`NEW/*_defaults.json`; `validate` rejects a broken override, the defaults stay)
- `wheel`: `free_per_day`, `bank_cap`, `anim_ms`, `pity_after` (0 = off), `paid:{enabled(false), cost:{sap|onyx:n}, max_per_day}`, `segments[8]: {id, w, rare?, give}`.
- `daily`: `on_miss` ("pause" | "reset"), `days[7]: give`.
- `missions`: `daily_count`, `weekly_count`, `week_start`, `collect_min_h`, `daily[]`, `weekly[]`: `{id, kind, goal, give, when?}`.
- `give` (one vocabulary): `ruby_h|emerald_h|turq_h` hours of the player's mine output · `ruby|emerald|turq` gems · `sap|onyx` · `spins` · `xp`.

## Not wired by DR1 (by design)
Battle Pass XP (BP1 registers the sink), friendly/war `mode` (AT1/CW1: DR1 only reads `mode`, "normal" when absent).
