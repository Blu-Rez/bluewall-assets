#!/bin/bash
# DR1: build a scratch copy of the server (kit python files + the DR1 server_patch applied with `patch -p1`) for the tests.   usage: dr1_tree.sh [OUT_DIR] [KIT_DIR] [PATCH_DIR]
set -e
OUT=${1:-/home/claude/dr1/tree}
KIT=${2:-/home/claude/bot/bluebot_v2/bluewall}
PATCH=${3:-/home/claude/dr1/server_patch}
rm -rf "$OUT"; mkdir -p "$OUT/bluewall"
cp "$KIT"/*.py "$KIT"/layout_geom.json "$OUT/bluewall/"
cp "$PATCH"/NEW/*.py "$PATCH"/NEW/*.json "$OUT/bluewall/"
cd "$OUT/bluewall"
for f in state server; do patch -s -p1 < "$PATCH/$f.py.diff"; done
find . -name '*.orig' -delete
python3 -m py_compile *.py
echo "DR1 tree ready: $OUT  ($(grep -c '# DR1:' state.py) marked lines in state.py, $(grep -c '# DR1:' server.py) in server.py)"
