"""DR1 server test: wheel + daily login reward + missions on the REAL state.py / server.py (memory store), with the DR1 patch applied.
Ends with `DR1 OK`.  usage: bash dev/dr1_tree.sh && python3 dev/dr1_test.py   (DR1_TREE=<dir> to test another tree; DR1_SPINS=100000 for the distribution)."""
import asyncio, copy, json, math, os, random, sys, time
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

os.environ["BLUEWALL_STATE"] = "memory"
TREE = os.environ.get("DR1_TREE", "/home/claude/dr1/tree")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, "/home/claude/dev/stubcfg"); sys.path.insert(0, TREE); sys.path.insert(0, HERE)
import bluewall                                                          # noqa: E402
import dr1_liveops_stub as LS                                            # noqa: E402
LS.install()
from bluewall import state as S, dr_common as C, wheel as W, daily as D, missions as M, dr_hooks as H, dr_routes as R, server as SRV, auth as A, progress as PR, military as MI   # noqa: E402

TEH = ZoneInfo("Asia/Tehran")
STORE = S.STORE
N = {"checks": 0}


def ok(cond, msg=""):
    N["checks"] += 1
    if not cond:
        raise AssertionError(msg or "check failed")


def teh(y, m, d, hh=0, mm=0, ss=0):
    return datetime(y, m, d, hh, mm, ss, tzinfo=TEH).timestamp()


class Clock:
    t = teh(2026, 10, 18, 10, 0, 0)

    def __call__(self):
        return self.t


CK = Clock()
C.set_clock(CK)
C.bind(STORE, lambda: True)
_uid = [5000]


def new_uid():
    _uid[0] += 1
    return _uid[0]


def reset_cfg():
    LS.reset()
    W.set_rng(random.Random(7))


async def txn(uid, fn):
    async with STORE._lock(uid):
        st = await STORE._txn(uid)
        r = fn(st)
        await STORE.save(uid, st)
    return r


async def load(uid):
    async with STORE._lock(uid):
        return await STORE.load(uid)


async def wallet(uid):
    st = await load(uid)
    return {g: int(st["gems"][g]) for g in C.GEMS}, {k: int((st.get("prem") or {}).get(k, 0)) for k in C.PREM}


async def spin(uid, sid, paid=False):
    r = await txn(uid, lambda st: W.spin(st, sid, paid, CK()))
    if r.get("ok") and not r.get("again"):
        await C.flush(uid)
    return r


def sid(n):
    return "spin%08d" % n


class FixedRng(random.Random):
    """random() always returns v (0.0 = the first segment, 0.9999 = the last)."""
    def __init__(self, v):
        super().__init__(0)
        self.v = v

    def random(self):
        return self.v


# ============================================================ 1. Tehran time
def t_tehran():
    d = C.day_of
    ok(d(teh(2026, 10, 17, 23, 59, 59)) + 1 == d(teh(2026, 10, 18, 0, 0, 0)), "Tehran midnight")
    u = lambda *a: datetime(*a, tzinfo=timezone.utc).timestamp()                      # noqa: E731
    ok(d(u(2026, 10, 17, 20, 29, 59)) + 1 == d(u(2026, 10, 17, 20, 30, 0)), "00:00 Tehran = 20:30 UTC")
    ok(C.next_midnight(teh(2026, 10, 17, 12)) == teh(2026, 10, 18), "next midnight")
    ok(C.next_midnight(teh(2026, 10, 17, 23, 59, 59)) - teh(2026, 10, 17, 23, 59, 59) == 1, "1 s before midnight")
    ok(C.day_start(d(teh(2026, 10, 18, 5))) == teh(2026, 10, 18), "day start")
    # the Iranian week starts on Saturday (17 Oct 2026 is a Saturday)
    ok(C.week_of(teh(2026, 10, 17, 0, 0, 1)) == d(teh(2026, 10, 17)), "Saturday starts the week")
    ok(C.week_of(teh(2026, 10, 16, 23, 59, 59)) == d(teh(2026, 10, 10)), "Friday night is still last week")
    ok(C.week_of(teh(2026, 10, 23, 23, 59, 59)) == d(teh(2026, 10, 17)), "Friday 23:59:59 is the last second of the week")
    ok(C.next_week_start(teh(2026, 10, 20, 9)) == teh(2026, 10, 24), "next week start")
    ok(C.week_of(teh(2026, 10, 19), "mon") == d(teh(2026, 10, 19)), "other week start")
    # a leap of years / months does not break the day number
    ok(d(teh(2027, 1, 1)) - d(teh(2026, 12, 31)) == 1, "year change")


# ============================================================ 2. config validation
def t_validate():
    reset_cfg()
    ok(W.validate(W.DEFAULTS) == [] and D.validate(D.DEFAULTS) == [] and M.validate(M.DEFAULTS) == [], "defaults valid")
    b = copy.deepcopy(W.DEFAULTS); b["segments"].pop()
    ok(W.validate(b), "7 segments rejected")
    b = copy.deepcopy(W.DEFAULTS); b["segments"][0]["w"] = 0
    ok(W.validate(b), "weight 0 rejected")
    b = copy.deepcopy(W.DEFAULTS); b["segments"][1]["give"] = {"ruby_h": 1, "gold": 3}
    ok(any("unknown key" in e for e in W.validate(b)), "unknown reward key rejected")
    b = copy.deepcopy(W.DEFAULTS); b["segments"][1]["give"] = {}
    ok(any("pays nothing" in e for e in W.validate(b)), "empty reward rejected")
    b = copy.deepcopy(W.DEFAULTS); b["segments"][7].pop("rare")
    ok(any("rare" in e for e in W.validate(b)), "pity without a rare segment rejected")
    b = copy.deepcopy(W.DEFAULTS); b["pity_after"] = 0
    ok(W.validate(b) == [], "pity off needs no rare segment")
    b = copy.deepcopy(W.DEFAULTS); b["paid"]["cost"] = {"ruby": 3}
    ok(W.validate(b), "paid cost must be sap / onyx")
    b = copy.deepcopy(D.DEFAULTS); b["days"].pop()
    ok(D.validate(b), "6 login days rejected")
    b = copy.deepcopy(D.DEFAULTS); b["on_miss"] = "forgive"
    ok(D.validate(b), "bad on_miss rejected")
    b = copy.deepcopy(M.DEFAULTS); b["daily"][0]["kind"] = "dance"
    ok(M.validate(b), "unknown mission kind rejected")
    b = copy.deepcopy(M.DEFAULTS); b["daily"][1]["id"] = b["daily"][0]["id"]
    ok(M.validate(b), "duplicate mission id rejected")
    b = copy.deepcopy(M.DEFAULTS); b["week_start"] = "someday"
    ok(M.validate(b), "bad week_start rejected")
    # liveops: a broken override never reaches a player (the stub, like OC1, falls back to the defaults)
    LS.OVR["wheel"] = {"segments": []}
    ok(W.cfg()["segments"] == W.DEFAULTS["segments"], "broken override -> defaults")
    LS.reset()
    # nothing a player reads may contain the words bot / ربات
    for f in ("wheel_defaults.json", "daily_defaults.json", "missions_defaults.json"):
        txt = open(os.path.join(TREE, "bluewall", f), encoding="utf-8").read().lower()
        ok("bot" not in txt and "ربات" not in txt, f + " mentions bot")


# ============================================================ 3. wheel
async def t_wheel_basic():
    reset_cfg()
    uid = new_uid()
    w0, p0 = await wallet(uid)
    v = W.view(await load(uid), CK())
    ok(v["free"] == 1 and v["earned"] == 0 and len(v["segs"]) == 8, "fresh wheel")
    ok(abs(sum(s["pct"] for s in v["segs"]) - 100) < 0.05, "odds sum to 100")
    r = await spin(uid, sid(1))
    ok(r["ok"] and r["src"] == "free" and not r.get("again"), "first spin")
    w1, _ = await wallet(uid)
    gain = {g: w1[g] - w0[g] for g in C.GEMS}
    ok({g: n for g, n in gain.items() if n} == r["got"] or r["seg"] in ("spin", "xp"), "wallet got exactly what the spin said: %s vs %s" % (gain, r["got"]))
    # the same tap again (same id) = the same answer, nothing more
    r2 = await spin(uid, sid(1))
    ok(r2["ok"] and r2["again"] and r2["i"] == r["i"] and r2["got"] == r["got"], "same id -> same answer")
    await C.flush(uid)
    w2, _ = await wallet(uid)
    ok(w2 == w1, "double tap paid once")
    ok(not (await txn(uid, lambda st: W.spin(st, "x", False, CK())))["ok"], "bad id rejected")
    ok((await spin(uid, sid(2)))["why"] == "no_spin", "no second free spin the same day")
    st = await load(uid)
    ok(st["dr"]["w"]["used"] == 1 and st["dr"]["w"]["n"] == 1, "counters")
    ok(not st["dr"]["o"], "outbox empty after the flush")
    # the hub badge in the normal state view
    v = await STORE.get(uid)
    ok(v["dr"]["w"] == 0 and v["dr"]["d"] == 1, "badge: no spin left, login reward waiting: %s" % v["dr"])


async def t_wheel_midnight():
    reset_cfg()
    uid = new_uid()
    CK.t = teh(2026, 10, 18, 23, 59, 58)
    ok((await spin(uid, sid(10)))["src"] == "free", "free spin before midnight")
    CK.t = teh(2026, 10, 18, 23, 59, 59)
    ok((await spin(uid, sid(11)))["why"] == "no_spin", "still the same Tehran day at 23:59:59")
    ok(W.view(await load(uid), CK())["free"] == 0, "view: none left")
    CK.t = teh(2026, 10, 19, 0, 0, 0)
    ok(W.view(await load(uid), CK())["free"] == 1, "view: free spin is back at 00:00:00")
    r = await spin(uid, sid(12))
    ok(r["ok"] and r["src"] == "free", "free spin again at 00:00:00")
    ok((await spin(uid, sid(13)))["why"] == "no_spin", "only one a day")
    v = W.view(await load(uid), CK())
    ok(v["next"] == teh(2026, 10, 20), "countdown target is the next Tehran midnight")
    # 20:29:59 UTC / 20:30:00 UTC is the same boundary
    CK.t = datetime(2026, 10, 19, 20, 29, 59, tzinfo=timezone.utc).timestamp()
    ok(W.view(await load(uid), CK())["free"] == 0, "20:29:59 UTC still the same day")
    CK.t += 1
    ok(W.view(await load(uid), CK())["free"] == 1, "20:30:00 UTC new day")
    # unused free spins are not saved up
    CK.t = teh(2026, 10, 25, 8)
    ok(W.view(await load(uid), CK())["free"] == 1 and W.spins_ready(await load(uid), CK.t) == 1, "no stacking of free spins")
    CK.t = teh(2026, 10, 18, 10)


async def t_wheel_earned():
    reset_cfg()
    uid = new_uid()
    async def add(n, key=None):
        async with STORE._lock(uid):
            st = await STORE._txn(uid)
            r = W.grant(st, n, "test", key, CK())
            await STORE.save(uid, st)
        return r
    ok(await add(3, "bp:1") == 3, "3 earned")
    ok(await add(3, "bp:1") == 0, "same key twice = once")
    ok(await W.add_spin(uid, 2, "test", "bp:2") == 2, "async add_spin (STORE bound by register)")
    ok(await W.add_spin(uid, 2, "test", "bp:2") == 0, "add_spin idempotent")
    ok(W.view(await load(uid), CK())["earned"] == 5, "5 in the bank")
    LS.OVR["wheel"] = {"bank_cap": 6}
    ok(await add(10) == 1, "bank cap clips")
    ok(await add(1) == 0, "bank full")
    LS.OVR.clear()
    # order: free first, then earned
    srcs = [(await spin(uid, sid(20 + i)))["src"] for i in range(3)]
    ok(srcs == ["free", "earned", "earned"], srcs)
    ok(W.view(await load(uid), CK())["earned"] == 4, "bank counted down")
    # the 'spin' segment pays a spin back (into the bank)
    W.set_rng(FixedRng(0.0)); LS.OVR["wheel"] = {"segments": copy.deepcopy(W.DEFAULTS["segments"])}
    LS.OVR["wheel"]["segments"][0] = {"id": "again", "w": 22, "give": {"spins": 1}}
    b4 = W.view(await load(uid), CK())["earned"]
    r = await spin(uid, sid(30))
    ok(r["seg"] == "again" and r["spins"] == 1, "spin segment")
    ok(W.view(await load(uid), CK())["earned"] == b4, "spin paid back: one used, one returned")
    reset_cfg()


async def t_wheel_pity():
    reset_cfg()
    uid = new_uid()
    LS.OVR["wheel"] = {"pity_after": 5, "bank_cap": 100}
    await txn(uid, lambda st: W.grant(st, 60, "test", None, CK()))
    W.set_rng(FixedRng(0.0))                                    # always the first (common) segment, if it is not forced
    seq = []
    for i in range(14):
        r = await spin(uid, sid(100 + i))
        seq.append((r["seg"], r["pity"]))
    # 5 commons, then a forced rare, again 5 commons, forced rare ...
    ok([s for s, _ in seq[:6]] == ["ruby_s"] * 5 + ["jackpot"] and seq[5][1] is True, seq)
    ok([s for s, _ in seq[6:12]] == ["ruby_s"] * 5 + ["jackpot"], seq)
    ok(not any(p for _, p in seq[:5]), "not forced before N")
    # a natural rare resets the counter too
    W.set_rng(FixedRng(0.99999))                                # the last segment = the rare one, naturally
    r = await spin(uid, sid(200))
    ok(r["seg"] == "jackpot" and r["pity"] is False, "natural rare")
    st = await load(uid)
    ok(st["dr"]["w"]["pity"] == 0, "counter reset by a natural rare")
    W.set_rng(FixedRng(0.0))
    seg = [(await spin(uid, sid(210 + i)))["seg"] for i in range(6)]
    ok(seg == ["ruby_s"] * 5 + ["jackpot"], seg)
    # pity off
    LS.OVR["wheel"] = {"pity_after": 0, "bank_cap": 100}
    await txn(uid, lambda st: W.grant(st, 60, "test", None, CK()))
    seg = [(await spin(uid, sid(300 + i)))["seg"] for i in range(30)]
    ok("jackpot" not in seg, "no pity when off")
    reset_cfg()


async def t_wheel_paid():
    reset_cfg()
    uid = new_uid()
    ok((await spin(uid, sid(400), paid=True))["why"] == "off", "paid spins are OFF by default")
    ok(W.view(await load(uid), CK())["paid"] is None, "view hides the paid spin when off")
    LS.OVR["wheel"] = {"paid": {"enabled": True, "cost": {"sap": 3}, "max_per_day": 2}}
    ok((await spin(uid, sid(401), paid=True))["why"] == "funds", "no sapphire")
    await txn(uid, lambda st: st["prem"].__setitem__("sap", 7))
    r = await spin(uid, sid(402), paid=True)
    ok(r["ok"] and r["src"] == "paid", "paid spin")
    ok((await wallet(uid))[1]["sap"] == 4, "3 sapphire taken")
    ok((await spin(uid, sid(402), paid=True))["again"], "paid replay costs nothing")
    ok((await wallet(uid))[1]["sap"] == 4, "replay did not charge")
    ok((await spin(uid, sid(403), paid=True))["ok"], "second paid")
    ok((await spin(uid, sid(404), paid=True))["why"] == "limit", "daily paid limit")
    ok((await wallet(uid))[1]["sap"] == 1, "6 sapphire in total")
    ok(W.view(await load(uid), CK())["paid"] == {"cost": {"sap": 3}, "left": 0}, "view of the paid spin")
    CK.t += 86400
    ok(W.view(await load(uid), CK())["paid"]["left"] == 2, "paid counter resets at midnight")
    CK.t -= 86400
    reset_cfg()


async def t_wheel_vault():
    reset_cfg()
    uid = new_uid()
    W.set_rng(FixedRng(0.0))                                    # ruby_s: 0.25 h of ruby
    st = await load(uid)
    cap = PR.vault_cap("ruby", max(1, PR.level(st, "vault_ruby")))
    prize = C.amounts(st, {"ruby_h": 0.25})["ruby"]
    ok(prize > 5, "prize size %s" % prize)
    async def setr(n):
        def f(st):
            st["gems"]["ruby"] = n
        await txn(uid, f)
    await setr(cap)                                             # vault full: the prize is lost, nothing goes above the cap
    r = await spin(uid, sid(500))
    ok(r["got"] == {} and r["lost"] == {"ruby": prize}, r)
    ok((await wallet(uid))[0]["ruby"] == cap, "wallet not above the vault")
    ok(not (await load(uid))["dr"]["o"], "nothing left in the outbox")
    await setr(cap - 3)                                         # 3 free places: only 3 come
    LS.OVR["wheel"] = {"free_per_day": 5}
    r = await spin(uid, sid(501))
    ok(r["got"] == {"ruby": 3} and r["lost"] == {"ruby": prize - 3}, r)
    ok((await wallet(uid))[0]["ruby"] == cap, "exactly full")
    # two prizes in a row BEFORE the flush share the same room
    await setr(cap - prize - 2)
    ra = await txn(uid, lambda st: W.spin(st, sid(502), False, CK()))
    rb = await txn(uid, lambda st: W.spin(st, sid(503), False, CK()))
    ok(ra["got"] == {"ruby": prize} and rb["got"] == {"ruby": 2} and rb["lost"] == {"ruby": prize - 2}, (ra, rb))
    await C.flush(uid)
    ok((await wallet(uid))[0]["ruby"] == cap, "two prizes in the outbox never exceed the vault")
    reset_cfg()


async def t_wheel_outbox():
    """A crash between 'spin saved' and 'gift delivered' loses nothing and pays nothing twice."""
    reset_cfg()
    uid = new_uid()
    W.set_rng(FixedRng(0.0))
    w0, _ = await wallet(uid)
    r = await txn(uid, lambda st: W.spin(st, sid(600), False, CK()))                    # saved, NOT flushed (crash)
    st = await load(uid)
    ok(st["dr"]["o"] and (await wallet(uid))[0] == w0, "prize waits in the outbox")
    out = await R._sheet(uid)                                                           # the next sheet / request pays it
    got = (await wallet(uid))[0]["ruby"] - w0["ruby"]
    ok(got == r["got"]["ruby"] and not (await load(uid))["dr"]["o"], "paid by the next call")
    out = await R._sheet(uid)
    ok((await wallet(uid))[0]["ruby"] - w0["ruby"] == got, "and only once")
    ok(out["gems"]["ruby"] == w0["ruby"] + got, "sheet shows the new balance")
    # a crash AFTER the push but before the outbox was cleaned: the inbox entry is used, the second push is a no-op
    LS.OVR["wheel"] = {"free_per_day": 3}
    r = await txn(uid, lambda st: W.spin(st, sid(601), False, CK()))
    ent = [dict(e) for e in (await load(uid))["dr"]["o"]]
    for e in ent:
        await STORE.push_inbox(uid, e)
    await STORE.get(uid)                                                                # a normal request drains the gift
    before = (await wallet(uid))[0]["ruby"]
    await C.flush(uid)                                                                  # the outbox still has it: pushed again
    ok((await wallet(uid))[0]["ruby"] == before, "same ids -> not applied twice")
    ok(not (await load(uid))["dr"]["o"], "outbox cleaned")
    # no second 'you got a gift' toast for the prize the sheet already showed
    r = await spin(uid, sid(602))
    ok((await load(uid)).get("gnew") is None, "no gift toast left behind")
    reset_cfg()


async def t_concurrent():
    reset_cfg()
    uid = new_uid()
    rs = await asyncio.gather(*[spin(uid, sid(700)) for _ in range(6)])
    ok(sum(1 for r in rs if r["ok"] and not r.get("again")) == 1 and all(r["ok"] for r in rs), "same id x6 at once = one spin")
    ok((await load(uid))["dr"]["w"]["n"] == 1, "one spin counted")
    uid = new_uid()
    rs = await asyncio.gather(*[spin(uid, sid(710 + i)) for i in range(6)])
    ok(sum(1 for r in rs if r["ok"]) == 1, "6 different taps, one free spin: one wins")


async def t_wheel_distribution():
    reset_cfg()
    n = int(os.environ.get("DR1_SPINS", "100000"))
    segs = W.DEFAULTS["segments"]
    wt = [s["w"] for s in segs]
    tot = sum(wt)
    # (a) pity OFF: the draw follows the weights
    LS.OVR["wheel"] = {"pity_after": 0, "bank_cap": 100}
    W.set_rng(random.Random(20261018))
    st = S.STORE._fresh(1)
    cnt = [0] * 8
    t0 = time.time()
    for k in range(n):
        st["dr"] = st.get("dr") or {}
        w = C.ensure(st)["w"]; w["earned"] = 1; w["used"] = 1; w["day"] = C.day_of(CK())
        r = W.spin(st, "dist%016d" % k, False, CK())
        cnt[r["i"]] += 1
        st["dr"]["o"] = []
        st["gems"] = {g: 0 for g in C.GEMS}
    dt = time.time() - t0
    zs = []
    for i in range(8):
        p = wt[i] / tot
        z = (cnt[i] - n * p) / math.sqrt(n * p * (1 - p))
        zs.append(round(z, 2))
        ok(abs(z) < 4.5, "segment %s: %d of %d, expected %.0f (z=%.2f)" % (segs[i]["id"], cnt[i], n, n * p, z))
    print("   distribution (pity off) %d spins in %.1fs: %s  z=%s" % (n, dt, [round(100.0 * c / n, 2) for c in cnt], zs))
    # (b) pity ON (40): the rare rate follows the Markov value, the common segments keep their relative weights
    LS.OVR["wheel"] = {"pity_after": 40, "bank_cap": 100}
    W.set_rng(random.Random(20261019))
    st = S.STORE._fresh(2)
    cnt = [0] * 8; forced = 0; worst = 0; run = 0
    for k in range(n):
        w = C.ensure(st)["w"]; w["earned"] = 1; w["used"] = 1; w["day"] = C.day_of(CK())
        r = W.spin(st, "pity%016d" % k, False, CK())
        cnt[r["i"]] += 1
        forced += 1 if r["pity"] else 0
        run = 0 if segs[r["i"]].get("rare") else run + 1
        worst = max(worst, run)
        st["dr"]["o"] = []
        st["gems"] = {g: 0 for g in C.GEMS}
    c = W.cfg()
    exp = W.rare_rate(c) / 100.0
    z = (cnt[7] - n * exp) / math.sqrt(n * exp * (1 - exp))
    ok(abs(z) < 5.0, "rare with pity: %d of %d, expected %.0f (z=%.2f)" % (cnt[7], n, n * exp, z))
    ok(worst <= 40, "never more than 40 spins without a rare: %d" % worst)
    nr = sum(cnt[:7]); wr = sum(wt[:7])
    for i in range(7):
        p = wt[i] / wr
        zi = (cnt[i] - nr * p) / math.sqrt(nr * p * (1 - p))
        ok(abs(zi) < 4.5, "common %s share z=%.2f" % (segs[i]["id"], zi))
    print("   with pity 40: rare %.2f%% (analytic %.2f%%), forced %d, longest dry run %d" % (100.0 * cnt[7] / n, 100 * exp, forced, worst))
    reset_cfg()


# ============================================================ 4. daily login reward
async def claim_daily(uid):
    r = await txn(uid, lambda st: D.claim(st, CK()))
    if r.get("ok"):
        await C.flush(uid)
    return r


async def t_daily():
    reset_cfg()
    uid = new_uid()
    CK.t = teh(2026, 10, 18, 9)
    v = D.view(await load(uid), CK())
    ok(v["idx"] == 0 and not v["claimed"] and len(v["days"]) == 7, "fresh login view")
    w0, _ = await wallet(uid)
    r = await claim_daily(uid)
    ok(r["ok"] and r["day"] == 0 and "ruby" in r["got"], r)
    ok((await wallet(uid))[0]["ruby"] - w0["ruby"] == r["got"]["ruby"], "day 1 paid")
    r2 = await claim_daily(uid)
    ok(not r2["ok"] and r2["why"] == "claimed", "second claim the same day")
    ok((await wallet(uid))[0]["ruby"] - w0["ruby"] == r["got"]["ruby"], "and nothing more paid")
    ok(D.view(await load(uid), CK())["claimed"], "view: claimed")
    # Tehran midnight
    CK.t = teh(2026, 10, 18, 23, 59, 59)
    ok(not (await claim_daily(uid))["ok"], "23:59:59 still today")
    CK.t = teh(2026, 10, 19, 0, 0, 0)
    ok(D.claimable(await load(uid), CK()), "00:00:00 claimable again")
    r = await claim_daily(uid)
    ok(r["ok"] and r["day"] == 1 and "emerald" in r["got"], "day 2 = emerald")
    CK.t = teh(2026, 10, 20, 12)
    r = await claim_daily(uid)
    ok(r["ok"] and r["day"] == 2 and r["spins"] == 1, "day 3 pays a spin: %s" % r)
    ok(W.view(await load(uid), CK())["earned"] == 1, "spin is in the bank")
    # miss two days: 'pause' continues where it was
    CK.t = teh(2026, 10, 23, 12)
    v = D.view(await load(uid), CK())
    ok(v["missed"] and v["idx"] == 3, "pause: day 4 waits for the player: %s" % v)
    r = await claim_daily(uid)
    ok(r["ok"] and r["day"] == 3 and r["xp"] == 30, "day 4 after the gap: %s" % r)
    ok((await load(uid))["dr"]["x"] == 30, "xp counted for BP1")
    # a full week, then the cycle starts again
    days = []
    for i in range(1, 5):
        CK.t = teh(2026, 10, 23 + i, 12)
        days.append((await claim_daily(uid))["day"])
    ok(days == [4, 5, 6, 0], days)
    ok(D.view(await load(uid), CK())["total"] == 8, "8 claims")
    # 'reset': a missed day sends the player back to day 1
    LS.OVR["daily"] = {"on_miss": "reset"}
    CK.t = teh(2026, 10, 29, 12)
    v = D.view(await load(uid), CK())
    ok(v["missed"] and v["idx"] == 0, "reset: back to day 1: %s" % v)
    r = await claim_daily(uid)
    ok(r["day"] == 0, "claimed day 1 after the reset")
    CK.t = teh(2026, 10, 30, 12)
    ok((await claim_daily(uid))["day"] == 1, "and the cycle goes on")
    CK.t = teh(2026, 10, 18, 10)
    reset_cfg()


async def t_daily_vault():
    reset_cfg()
    uid = new_uid()
    def full(st):
        for g in C.GEMS:
            st["gems"][g] = C.room(st, g) + int(st["gems"][g])
    await txn(uid, full)
    r = await claim_daily(uid)
    ok(r["ok"] and r["got"] == {} and r["lost"].get("ruby", 0) > 0, "vault full: the reward is reported lost, not pushed above the cap: %s" % r)
    w, _ = await wallet(uid)
    st = await load(uid)
    ok(all(w[g] <= PR.vault_cap(g, max(1, PR.level(st, "vault_" + g))) for g in C.GEMS), "within the vaults")
    reset_cfg()


# ============================================================ 5. missions
SMALL = {"daily_count": 3, "weekly_count": 3, "collect_min_h": 0.5,
         "daily": [{"id": "t_collect_n", "kind": "collect_n", "goal": 1, "give": {"emerald_h": 0.25, "xp": 10}},
                   {"id": "t_collect_h", "kind": "collect_h", "goal": 2, "give": {"ruby_h": 0.25}},
                   {"id": "t_train", "kind": "train", "goal": 3, "give": {"spins": 1, "xp": 10}}],
         "weekly": [{"id": "t_w_collect", "kind": "collect_n", "goal": 2, "give": {"turq_h": 1}},
                    {"id": "t_w_upgrade", "kind": "upgrade", "goal": 1, "give": {"spins": 2}},
                    {"id": "t_w_win", "kind": "win", "goal": 1, "give": {"ruby_h": 1}}]}


def small():
    LS.OVR["missions"] = copy.deepcopy(SMALL)
    # the stub merges dicts but a LIST replaces: the pools are exactly the three test missions each


def find(m, key):
    return next(x for x in m["daily"] + m["weekly"] if x["key"] == key)


async def t_missions_roll():
    reset_cfg()
    C.bind(STORE, lambda: True)
    uid = new_uid()
    CK.t = teh(2026, 10, 18, 9)
    m = M.view(await save_view(uid), CK())
    ok(len(m["daily"]) == 3 and len(m["weekly"]) == 3, "3 + 3")
    ok(len({x["kind"] for x in m["daily"]}) == 3 and len({x["kind"] for x in m["weekly"]}) == 3, "distinct kinds: %s" % [x["kind"] for x in m["daily"]])
    keys = [x["key"] for x in m["daily"]]
    # the same after a restart / reload (state is saved), different next day / next week
    ok([x["key"] for x in M.view(await save_view(uid), CK())["daily"]] == keys, "stable within the day")
    sets = set()
    for dday in range(19, 29):
        CK.t = teh(2026, 10, dday, 9)
        sets.add(tuple(sorted(x["key"] for x in M.view(await save_view(uid), CK())["daily"])))
    ok(len(sets) > 2, "the daily set changes from day to day (%d different sets in 10 days)" % len(sets))
    # a different player gets his own draw
    other = set()
    for _ in range(12):
        u2 = new_uid()
        CK.t = teh(2026, 10, 18, 9)
        other.add(tuple(sorted(x["key"] for x in M.view(await save_view(u2), CK())["daily"])))
    ok(len(other) > 2, "players get different sets (%d)" % len(other))
    # attacks closed: no attack / win / stars mission is offered
    C.bind(STORE, lambda: False)
    bad = 0
    for _ in range(25):
        u2 = new_uid()
        m2 = M.view(await save_view(u2), CK())
        bad += sum(1 for x in m2["daily"] + m2["weekly"] if x["kind"] in ("attack", "win", "stars"))
    ok(bad == 0, "no attack missions while attacks are closed")
    C.bind(STORE, lambda: True)
    # an upgrade mission only for a castle that can finish one
    st = await load(uid)
    st["b"]["keep"] = 20
    mm = M.cfg()["daily"][2]
    ok(mm["id"] == "d_upgrade" and not M._eligible(st, mm, CK()), "castle 20, nothing finishing today: no 'finish an upgrade' mission")
    st["q"] = [{"e": "wall", "to": 5, "s": CK() - 100, "end": CK() + 3600, "d": 100}]
    ok(M._eligible(st, mm, CK()), "an upgrade ends within 24 h: offered")
    st["q"] = []; st["b"]["keep"] = 5
    ok(M._eligible(st, mm, CK()), "castle 5: offered")
    CK.t = teh(2026, 10, 18, 10)


async def save_view(uid):
    """load + save (the view rolls the day) and return the state"""
    async with STORE._lock(uid):
        st = await STORE._txn(uid)
        M.roll(st, CK())
        await STORE.save(uid, st)
    return st


async def t_missions_week():
    reset_cfg()
    uid = new_uid()
    CK.t = teh(2026, 10, 23, 23, 59, 59)                      # Friday night, last second of the week
    a = M.view(await save_view(uid), CK())
    CK.t = teh(2026, 10, 23, 23, 59, 59)
    ok(a["next_week"] == teh(2026, 10, 24) and a["next_day"] == teh(2026, 10, 24), "week and day end together on Friday")
    CK.t = teh(2026, 10, 24, 0, 0, 0)
    b = M.view(await save_view(uid), CK())
    st = await load(uid)
    ok(st["dr"]["m"]["week"] == C.day_of(teh(2026, 10, 24)), "new week id at Saturday 00:00")
    CK.t = teh(2026, 10, 25, 12)
    c = M.view(await save_view(uid), CK())
    ok([x["key"] for x in b["weekly"]] == [x["key"] for x in c["weekly"]], "the weekly set holds all week")
    CK.t = teh(2026, 10, 30, 23, 59, 59)
    d = M.view(await save_view(uid), CK())
    ok([x["key"] for x in d["weekly"]] == [x["key"] for x in b["weekly"]], "... until Friday 23:59:59")
    CK.t = teh(2026, 10, 18, 10)


async def t_missions_count():
    reset_cfg()
    small()
    uid = new_uid()
    CK.t = teh(2026, 10, 18, 9)
    m = M.view(await save_view(uid), CK())
    ok({x["id"] for x in m["daily"]} == {"t_collect_n", "t_collect_h", "t_train"} and {x["id"] for x in m["weekly"]} == {"t_w_collect", "t_w_upgrade", "t_w_win"}, "test pool")
    ok((await txn(uid, lambda st: M.claim(st, "d:t_collect_n", CK())))["why"] == "not_done", "claim before it is done")
    ok((await txn(uid, lambda st: M.claim(st, "x:what", CK())))["why"] == "bad", "bad key")
    ok((await txn(uid, lambda st: M.claim(st, "d:zzz", CK())))["why"] == "gone", "unknown mission")
    # a real collect through Store.collect (fresh mines are half full = 6 h of output)
    res = await STORE.collect(uid, "ruby")
    ok(res["got"]["n"] > 0, "collected")
    m = M.view(await load(uid), CK())
    a, h = find(m, "d:t_collect_n"), find(m, "d:t_collect_h")
    ok(a["p"] == 1 and a["done"], "collect_n counted through the real collect: %s" % a)
    ok(h["p"] == h["goal"] and h["done"], "collect_h counted (6 h of output >= goal 2): %s" % h)
    w = find(m, "w:t_w_collect")
    ok(w["p"] == 1 and not w["done"], "weekly collect 1/2")
    # an empty / tiny collect does not count
    res = await STORE.collect(uid, "ruby")
    m = M.view(await load(uid), CK())
    ok(find(m, "d:t_collect_n")["p"] == 1 and find(m, "w:t_w_collect")["p"] == 1, "a second collect right away counts for nothing")
    res = await STORE.collect(uid, "emerald")
    ok(find(M.view(await load(uid), CK()), "w:t_w_collect")["done"], "second real collect completes the weekly")
    # claim: paid once
    w0, _ = await wallet(uid)
    r = await txn(uid, lambda st: M.claim(st, "d:t_collect_n", CK()))
    await C.flush(uid)
    ok(r["ok"] and r["xp"] == 10 and r["got"]["emerald"] > 0, r)
    ok((await wallet(uid))[0]["emerald"] - w0["emerald"] == r["got"]["emerald"], "mission reward arrived")
    r2 = await txn(uid, lambda st: M.claim(st, "d:t_collect_n", CK()))
    await C.flush(uid)
    ok(r2["why"] == "claimed" and (await wallet(uid))[0]["emerald"] - w0["emerald"] == r["got"]["emerald"], "second claim pays nothing")
    ok(find(M.view(await load(uid), CK()), "d:t_collect_n")["claimed"], "view: claimed")
    ok(M.claimable(await load(uid), CK()) == 2, "badge counts the two other finished missions (collect_h, weekly collect)")
    # the spin reward goes into the bank
    r = await txn(uid, lambda st: M.claim(st, "w:t_w_collect", CK()))
    ok(r["ok"], r)
    # soldiers: finished training is seen as an army delta in _txn
    def train3(st):
        s0 = H.snap(st)
        st["army"]["spear"] = int(st["army"].get("spear", 0)) + 3
        H.on_settle(st, s0)
    await txn(uid, train3)
    t = find(M.view(await load(uid), CK()), "d:t_train")
    ok(t["p"] == 3 and t["done"], "3 trained soldiers: %s" % t)
    r = await txn(uid, lambda st: M.claim(st, "d:t_train", CK()))
    ok(r["ok"] and r["spins"] == 1, "train mission pays a spin")
    ok(W.view(await load(uid), CK())["earned"] == 1, "in the bank")
    # a finished upgrade: a queue item whose time is up is settled by the next _txn and counted
    def queue_done(st):
        lv = PR.level(st, "wall")
        st["q"].append({"e": "wall", "to": lv + 1, "s": time.time() - 100, "end": time.time() - 1, "d": 99})
    await txn(uid, queue_done)
    await STORE.get(uid)                                                                # a normal request settles it
    u = find(M.view(await load(uid), CK()), "w:t_w_upgrade")
    ok(u["p"] == 1 and u["done"], "upgrade finished through Store._txn: %s" % u)
    await STORE.get(uid)
    ok(find(M.view(await load(uid), CK()), "w:t_w_upgrade")["p"] == 1, "counted once")
    # the day changes: a new set, nothing carried over; the unclaimed weekly stays
    CK.t = teh(2026, 10, 19, 0, 0, 1)
    m = M.view(await save_view(uid), CK())
    ok(all(x["p"] == 0 and not x["claimed"] for x in m["daily"]), "new day, new counters")
    ok(find(m, "w:t_w_upgrade")["done"], "the weekly survives midnight")
    ok(M.claimable(await load(uid), CK()) == 1, "badge: only the unclaimed weekly")
    CK.t = teh(2026, 10, 24, 0, 0, 1)
    m = M.view(await save_view(uid), CK())
    ok(all(x["p"] == 0 for x in m["weekly"]), "new week, new counters")
    CK.t = teh(2026, 10, 18, 10)
    reset_cfg()


async def t_missions_battle():
    reset_cfg()
    small()
    uid = new_uid()
    CK.t = teh(2026, 10, 18, 9)
    await save_view(uid)
    rep = {"sent": {"spear": 5}, "lost": {"spear": 1}, "stars": 2}
    def hit(info, spec=None):
        def f(st):
            H.on_battle(st, info, spec)
        return f
    await txn(uid, hit({"stars": 2, "report": rep}, {"kind": "bot"}))
    w = find(M.view(await load(uid), CK()), "w:t_w_win")
    ok(w["p"] == 1 and w["done"], "a normal 2-star attack is a win")
    # friendly and war battles are never counted
    uid2 = new_uid()
    await save_view(uid2)
    await txn(uid2, hit({"stars": 3, "mode": "friendly", "report": rep}))
    await txn(uid2, hit({"stars": 3, "report": rep}, {"mode": "war"}))
    await txn(uid2, hit({"stars": 3, "mode": "war", "report": rep}))
    ok(find(M.view(await load(uid2), CK()), "w:t_w_win")["p"] == 0, "friendly / war battles do not count")
    # nobody sent = not an attack
    await txn(uid2, hit({"stars": 1, "report": {"sent": {}, "stars": 1}}))
    ok(find(M.view(await load(uid2), CK()), "w:t_w_win")["p"] == 0, "an empty report is not an attack")
    # the real battle_end
    LS.OVR["missions"] = copy.deepcopy(SMALL)
    LS.OVR["missions"]["weekly"] = [{"id": "t_w_win", "kind": "win", "goal": 2, "give": {"ruby_h": 1}}, {"id": "t_w_stars", "kind": "stars", "goal": 5, "give": {"ruby_h": 1}}, {"id": "t_w_att", "kind": "attack", "goal": 3, "give": {"ruby_h": 1}}]
    uid3 = new_uid()
    await save_view(uid3)
    async def battle(tid, stars, destruction):
        def setup(st):
            st["atk"] = {"id": tid, "t": time.time(), "started": time.time(), "spec": {"power": 10, "loot": {"ruby": 0, "emerald": 0, "turq": 0}, "kind": "bot", "name": "Test"}}
        await txn(uid3, setup)
        st = await load(uid3)
        n = int(st["army"].get("spear", 0))
        return await STORE.battle_end(uid3, tid, {"sent": {"spear": min(n, 2)}, "lost": {}, "destruction": destruction, "stars": stars, "loot": {}})
    ok(int((await load(uid3))["army"].get("spear", 0)) >= 2, "test player has spearmen")
    b1 = await battle("t1", 2, 70)
    b2 = await battle("t2", 0, 10)
    b3 = await battle("t3", 3, 100)
    ok(b1["ok"] and b2["ok"] and b3["ok"], (b1.get("why"), b2.get("why"), b3.get("why")))
    mm = M.view(await load(uid3), CK())
    ok(find(mm, "w:t_w_win")["p"] == 2 and find(mm, "w:t_w_stars")["p"] == b1["info"]["stars"] + b2["info"]["stars"] + b3["info"]["stars"] and find(mm, "w:t_w_att")["p"] == 3,
       "attack 3, win 2, stars %s: %s" % (b1["info"]["stars"] + b2["info"]["stars"] + b3["info"]["stars"], [(x["id"], x["p"]) for x in mm["weekly"]]))
    reset_cfg()


async def t_missions_flag():
    reset_cfg()
    small()
    uid = new_uid()
    await save_view(uid)
    LS.FLAGS["missions"] = False
    await STORE.collect(uid, "ruby")
    ok(find(M.view(await load(uid), CK()), "d:t_collect_n")["p"] == 0, "missions off: nothing counted")
    ok(STORE.view(await load(uid), None, uid)["dr"]["m"] == 0, "missions off: no badge")
    reset_cfg()


# ============================================================ 6. flags, badge, HTTP
async def t_flags_badge():
    reset_cfg()
    uid = new_uid()
    v = await STORE.get(uid)
    ok(v["dr"] == {"n": 2, "w": 1, "d": 1, "m": 0}, "fresh: 1 free spin + 1 login reward: %s" % v["dr"])
    LS.FLAGS["wheel"] = False
    ok((await STORE.get(uid))["dr"] == {"n": 1, "w": 0, "d": 1, "m": 0}, "wheel off: no spin badge")
    LS.FLAGS["daily"] = False
    ok((await STORE.get(uid))["dr"]["n"] == 0, "daily off")
    r = await txn(uid, lambda st: W.spin(st, sid(900), False, CK()))
    ok(r["ok"], "the module itself does not look at the flag; the ROUTE does")
    reset_cfg()


def hdr(uid):
    return {"Authorization": "Bearer " + A.make_session(uid, "123456:TESTTOKENabcdefghijk")}


async def t_http():
    from aiohttp.test_utils import TestClient, TestServer
    reset_cfg()
    W.set_rng(random.Random(3))
    app = SRV.make_app()
    async with TestClient(TestServer(app)) as cl:
        uid = 777                                                       # the owner may always enter
        async with cl.get("/api/dr") as r:
            ok(r.status == 403, "no token")
        async with cl.get("/api/dr", headers=hdr(uid)) as r:
            d = await r.json()
            ok(r.status == 200 and d["ok"] and set(d["on"]) == {"wheel", "daily", "missions"}, d.keys())
            ok(len(d["wheel"]["segs"]) == 8 and len(d["daily"]["days"]) == 7 and len(d["missions"]["daily"]) == 3, "sheet content")
            ok(d["wheel"]["pity"]["after"] == 40 and d["wheel"]["pity"]["rare_pct"] == 4.92, "odds + pity shown")
        # free spin through HTTP, twice with the same id
        async with cl.post("/api/wheel/spin", json={"id": "http00000001"}, headers=hdr(uid)) as r:
            a = await r.json()
        async with cl.post("/api/wheel/spin", json={"id": "http00000001"}, headers=hdr(uid)) as r:
            b = await r.json()
        ok(a["ok"] and b["ok"] and a["res"]["i"] == b["res"]["i"] and b["res"].get("again") and a["wheel"]["free"] == 0, (a.get("why"), b.get("why")))
        ok(a["gems"] == b["gems"], "no second payout")
        async with cl.post("/api/wheel/spin", json={"id": "http00000002"}, headers=hdr(uid)) as r:
            c = await r.json()
        ok(not c["ok"] and c["why"] == "no_spin", "no spin left")
        async with cl.post("/api/wheel/spin", json={}, headers=hdr(uid)) as r:
            ok((await r.json())["why"] == "bad", "no id")
        async with cl.post("/api/daily/claim", json={}, headers=hdr(uid)) as r:
            a = await r.json()
        async with cl.post("/api/daily/claim", json={}, headers=hdr(uid)) as r:
            b = await r.json()
        ok(a["ok"] and not b["ok"] and b["why"] == "claimed" and a["daily"]["claimed"], "daily claim over HTTP")
        async with cl.post("/api/missions/claim", json={"key": "d:nothing"}, headers=hdr(uid)) as r:
            ok((await r.json())["why"] == "gone", "mission claim of something that is not there")
        # the state view carries the badge
        async with cl.get("/api/state", headers=hdr(uid)) as r:
            s = await r.json()
            ok(s["dr"]["w"] == 0 and s["dr"]["d"] == 0, "badge after the claims: %s" % s["dr"])
        # liveops switches: a section that is off answers 'off' and is missing from the sheet
        LS.FLAGS["wheel"] = False
        async with cl.post("/api/wheel/spin", json={"id": "http00000003"}, headers=hdr(uid)) as r:
            ok((await r.json())["why"] == "off", "wheel off")
        async with cl.get("/api/dr", headers=hdr(uid)) as r:
            d = await r.json()
            ok("wheel" not in d and d["on"]["wheel"] is False and "daily" in d, "sheet without the wheel")
        LS.reset()
        # rate limit
        codes = []
        for i in range(60):
            async with cl.get("/api/dr", headers=hdr(uid)) as r:
                codes.append(r.status)
        ok(429 in codes and codes[0] == 200, "rate limit on /api/dr: %s" % sorted(set(codes)))
        codes = []
        for i in range(45):
            async with cl.post("/api/wheel/spin", json={"id": "rl%010d" % i}, headers=hdr(uid)) as r:
                codes.append(r.status)
        ok(429 in codes, "rate limit on the spin")


async def main():
    t0 = time.time()
    t_tehran(); t_validate()
    for name, fn in [("wheel basic", t_wheel_basic), ("wheel midnight", t_wheel_midnight), ("wheel earned", t_wheel_earned), ("wheel pity", t_wheel_pity), ("wheel paid", t_wheel_paid),
                     ("wheel vault", t_wheel_vault), ("wheel outbox", t_wheel_outbox), ("concurrent", t_concurrent), ("wheel distribution", t_wheel_distribution),
                     ("daily", t_daily), ("daily vault", t_daily_vault), ("missions roll", t_missions_roll), ("missions week", t_missions_week), ("missions count", t_missions_count),
                     ("missions battle", t_missions_battle), ("missions flag", t_missions_flag), ("flags + badge", t_flags_badge), ("http", t_http)]:
        CK.t = teh(2026, 10, 18, 10)
        try:
            await fn()
        except Exception:
            print("FAIL in", name)
            raise
        print("ok  ", name)
    print("DR1 checks: %d in %.0fs" % (N["checks"], time.time() - t0))
    print("DR1 OK")


asyncio.run(main())
