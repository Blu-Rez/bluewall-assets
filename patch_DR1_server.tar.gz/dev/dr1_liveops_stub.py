"""DR1 tests: a stand-in for OC1's `liveops` (the contract: get / flag / register / season).  Overrides are merged over the registered defaults and used only when the section's own validator accepts the result."""
import copy, sys, types

REG = {}            # section -> (defaults, validate)
OVR = {}            # section -> {key: value}  (deep-merged over the defaults)
FLAGS = {k: True for k in ("friends", "chat_global", "chat_dm", "chat_clan", "friendly", "clan_war", "pass", "wheel", "missions", "daily", "season")}


def _merge(a, b):
    out = copy.deepcopy(a)
    for k, v in (b or {}).items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else copy.deepcopy(v)
    return out


def register(section, defaults, validate):
    REG[section] = (defaults, validate)


def get(section):
    d, val = REG[section]
    m = _merge(d, OVR.get(section))
    return m if not val(m) else copy.deepcopy(d)


def flag(name):
    return bool(FLAGS.get(name, False))


def season():
    return None


def install():
    import bluewall
    m = types.ModuleType("bluewall.liveops")
    m.get, m.flag, m.register, m.season = get, flag, register, season
    sys.modules["bluewall.liveops"] = m
    bluewall.liveops = m
    return m


def reset():
    OVR.clear()
    for k in FLAGS:
        FLAGS[k] = True
