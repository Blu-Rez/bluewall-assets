render noise (same pose, two frames): mad 0.0, changed>16 0.0 %
Z zoom: one camera step = mad 16.80..41.81 (median 34.22);  ALL cells full vs ALL cells lo at one pose = mad 1.93..7.13 (max 7.13), changed>16 up to 18.92 %
A arc: one camera step = mad 12.50..26.41 (median 18.55);  ALL cells full vs ALL cells lo at one pose = mad 2.47..3.32 (max 3.32), changed>16 up to 8.89 %
flips (natural passes):
  z/zf step 3->4: tWN->hi;  error vs all-full 5.309 -> 3.678 (jump 1.631 mad, 4.687 % px)
  z/zf step 8->9: core->lo;  error vs all-full 3.127 -> 4.198 (jump 1.071 mad, 4.528 % px)
  z/zb step 7->6: core->hi;  error vs all-full 3.709 -> 0.505 (jump 3.204 mad, 9.33 % px)
  a/af step 1->2: tEN->hi;  error vs all-full 0.028 -> 0.0 (jump 0.028 mad, 0.078 % px)
  a/af step 6->7: tWN->lo;  error vs all-full 0.086 -> 0.063 (jump 0.023 mad, 0.07 % px)
