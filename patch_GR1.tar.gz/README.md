patch_GR1 — apply on the kit tree (p53 + landscape):
  git apply GR1_shared_edits.diff            # roads.js (owned), terrain.js (owned), world.js (3 lines marked // GR1:)
  cp -r new/bluewall .  ;  cp new/dev/gr1_test.* /home/claude/dev/  (or workers/dev/)
  bash dev/gr1_test.sh  -> GR1 OK ;  bash dev/gate_w.sh -> GATE_W: ALL OK (noRoute 612)
Not included: web/app/wall.js (build output). No new image files.
Shared-file lines: world.js only, 3 lines (see report_GR1.md section 3). Everything else is owned (terrain.js, roads.js, ground_near.js).
