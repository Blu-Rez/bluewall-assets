# CN1 — clan server patch (roles, edit, requests, search, feed, cool-downs)

Apply on `kit`:  copy `NEW/clan_ext.py` and `NEW/clan_defaults.json` into `bluewall/`, then `git apply clan.py.diff server.py.diff` (run from the repo root).
`state.py` is **not** touched: `clan.py` ends with `from .clan_ext import ClansX as Clans`, so `STORE.clans` is the extended class (subclass of the old `Clans`).
Import clan.py first (state.py does); importing clan_ext.py alone first is a circular import.
Tests: `bash dev/cn1_test.sh` → `CN1 SERVER OK` (old clan/social tests + 4-account route test on memory state + the same on a real Redis).

All routes: `Authorization: Bearer <session>`; not logged in → `403 {"ok":false,"reason":"locked"}`; over the limit → `429 {"ok":false,"reason":"slow"}`.
A refusal is `200 {"ok":false,"reason":"no","why":"<code>", + need / wait / max}`; a malformed id / op / query → `400 {"ok":false,"reason":"bad"}`.

| route | limit / min / player | answer |
|---|---|---|
| `GET /api/clan` | 30 (shared with POST) | the view: `{ok, mine, top, max, min_keep, desc_max, min_cups_max, types, my_req, wait, now, flags}` |
| `POST /api/clan {op,…}` | 30 | success = `{ok:true, …the same view}`; ops below |
| `GET /api/clan/find?q=&min=&type=` | 40 | `{ok, list:[card], q, max, wait, low, min_keep}` |
| `GET /api/clan/requests` | 30 | `{ok, requests:[{id,n,e,tro,lg,k,t,ok}], min}` — only for who may accept (else `why: perm`, no clan → `none`) |
| `GET /api/clan/feed` | 30 | `{ok, feed:[{t,k,a?,an?,b?,bn?,x?}]}` newest first, members only |

**view.mine** (null without a clan): `id,name,tag,n,max,tro,r,badge,type,min,desc, owner,me_owner,role, req_n (only if you may accept), can{edit,requests,kick,promote,transfer}, members[{id,n,e,tro,lg,k,owner,role,seen,me,acts[]}]` (members sorted by cups; `acts` ⊂ promote|demote|kick|transfer = what YOU may do to that member, computed by the server).
**view.top / find.list card**: `id,name,tag,n,max,tro,r,badge,type,min,desc,act`. `act` (for a player without a clan) = `join | request | pending | cups | full | closed | banned`; null when he is in a clan. `view.my_req` = the card of the clan he asked (null when none / rejected / expired / gone). `view.wait` = seconds left of the 12 h after leaving (also in `find`). `view.flags` = `{chat_clan, clan_war}` from `liveops.flag` (the UI shows Chat / War only when true).
**find**: `q` = prefix of the name or the tag (case-blind, `#` ignored, ≤ 16 chars); no `q` = the best clans by cups. `min` = the cups the player has: only clans whose entry requirement ≤ `min`. `type` = open|request|closed. At most `find_max` (20). A prefix search returns the first 40 matches by name, then sorts them by cups.

## POST /api/clan ops (`id` is a clan id for join/request, a player id for kick/promote/demote/transfer/accept/reject)
| op | body | who | refusals (`why`) |
|---|---|---|---|
| create | `name` (3–16), `tag` (2–4 A-Z0-9), optional `desc` (≤ `desc_max`), `badge` (crest id), `type` (default open), `min` (default 0) | castle ≥ `min_keep`, no clan, no wait | name tag desc badge type mincups(max) in_clan low(need) wait(wait) taken |
| join | `id` | open clan only | in_clan low wait banned(wait) gone closed request cups(need) full |
| request | `id` | request clan only; one pending request at a time | in_clan low wait banned gone closed open cups(need) full pending busy |
| cancel | – | the applicant | none |
| accept / reject | `id` = applicant | role ≥ `perms.requests` (default elder) | none perm gone in_clan wait cups full |
| leave | – | anyone; the **leader only as the last member** (clan is deleted) | none leader (hand over first) |
| kick | `id` | role ≥ `perms.kick` (default co-leader) AND target strictly lower | none perm rank gone |
| promote / demote | `id` | role ≥ `perms.promote` (co-leader); one step; target strictly lower; the new role strictly below yours (so nobody makes a peer, nobody becomes leader) | none perm rank gone self floor |
| transfer | `id` | leader only → target becomes leader, the old leader becomes co-leader | none perm self gone |
| edit | any of `desc badge type min` | role ≥ `perms.edit` (co-leader) | none perm desc badge type mincups |
Ranks: member 0 < elder 1 < co-leader 2 < leader 3. Leaving → `cwait` = 12 h (`leave_wait_s`), no create/join/request/accept in that time. Kicked → 24 h (`kick_ban_s`) before coming back to THAT clan (other clans are fine).
Feed kinds (`k`): `create join leave kick promote demote transfer edit`; `x` = new role (promote/demote) · changed fields CSV (edit) · `req` (join through a request); names (`an`,`bn`) are snapshots; last `feed_max` (50) kept.

## Settings (liveops section `clan`; `clan_defaults.json` = defaults; `clan_ext.validate(d) -> [errors]` is the validator; works without liveops too)
`max_members 30 · min_keep 2 · desc_max 120 · min_cups_max 5000 · leave_wait_s 43200 · kick_ban_s 86400 · feed_max 50 · requests_max 30 · request_ttl_s 259200 (3 days) · find_max 20 · perms{edit,requests,kick,promote}` (values elder|co-leader|leader). A bad liveops value is ignored (defaults used), never raises. Flags read: `chat_clan`, `clan_war`.

## Storage added
Clan JSON: `desc badge type min roles{uid:role} req{uid:t} feed[]` (old clans get defaults on read: open, min 0). Player state: `creq` (his one pending request), `cwait`, `cban{clanId:until}`. Redis: `bluewall:clan:lex` (ZSET, prefix index `n:<name>:<id>` / `t:<tag>:<id>`, built lazily from `bluewall:clan:names` for clans that existed before — flag key `bluewall:clan:lexv`). Clan totals are now one `ZSCORE` of `bluewall:clb` (was a HASH read per clan).
Lock order: player lock → clan lock (never the other way); accept takes the applicant's lock first.

## For the other chats
`await STORE.clans.clan_of(uid) -> int` (0 = none) · `await STORE.clans.members(cid) -> [uid]` · `clan_ext.flag(name)` · `clan_ext.cfg()` · `clan_ext.role_of(clanrecord, uid)`.
Client: `clanui.js` shows **Chat** / **War** only when `view.flags` says so and fires `window` event `bw-clan-action` with `detail {act:"chat"|"war", clan:id}` — CH1 / CW1 listen to it.
