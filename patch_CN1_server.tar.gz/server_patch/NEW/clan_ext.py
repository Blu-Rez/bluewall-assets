"""CN1 - clans, part 2: roles, edit, join requests, search, activity feed, cool-downs.

clan.py wires this in with two lines at its end (`Clans` there becomes `ClansX`, a subclass), so state.py / server.py keep using `STORE.clans`.
Everything here is server-side truth: the client only draws what `view()` / `find()` / `requests()` / `feed()` return.

A clan record (the old fields stay): {id, name, tag, owner, members:[uid], t,
    desc (<= cfg desc_max chars), badge (a crest id from emblems.js / military.EMBLEMS), type "open"|"request"|"closed", min (cups needed to enter),
    roles {"<uid>": "elder"|"co-leader"} (the leader is `owner`; everybody else without an entry is a "member"),
    req {"<uid>": unix time} (pending join requests of a `request` clan), feed [{t, k, a?, an?, b?, bn?, x?}] (newest last, cfg feed_max)}
A player's own kingdom stores, besides `clan`:  `creq` (the clan id of his one pending request), `cwait` (no clan until this time: after leaving),
    `cban` {"<clan id>": until} (kicked: cannot come back to THAT clan until then).
Lock order is always  player lock -> clan lock  (the same as clan.py); a clan lock is never held while a player lock is taken.
Settings: liveops section `clan` (clan_defaults.json holds the defaults, `validate` the checks); without liveops the defaults are used.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import unicodedata
from typing import Any, Dict, List, Optional

from . import military as MI
from . import progress as PR
from . import social as SO
from .clan import Clans as _Base, K_LB, K_NAMES, K_SEQ, TAG_RE, clean_name

log = logging.getLogger("bluewall.clan_ext")

K_LEX = "bluewall:clan:lex"       # ZSET (every score 0): "n:<lower name>:<id>" and "t:<lower tag>:<id>"  -> prefix search with ZRANGEBYLEX
K_LEXV = "bluewall:clan:lexv"     # set once the index has been built from the clans that existed before CN1
ROLES = ("member", "elder", "co-leader", "leader")
RANK = {r: i for i, r in enumerate(ROLES)}
TYPES = ("open", "request", "closed")

# ---------------------------------------------------------------------------------------------- settings (liveops section "clan")
_NUM = {                                  # key: (lowest, highest) allowed value
    "max_members": (2, 100), "min_keep": (1, 50), "desc_max": (1, 300), "min_cups_max": (0, 100000),
    "leave_wait_s": (0, 30 * 86400), "kick_ban_s": (0, 30 * 86400), "feed_max": (10, 200),
    "requests_max": (1, 100), "request_ttl_s": (60, 30 * 86400), "find_max": (5, 50),
}
_PERM_KEYS = ("edit", "requests", "kick", "promote")
_PERM_VALUES = ("elder", "co-leader", "leader")
_FALLBACK = {
    "max_members": 30, "min_keep": 2, "desc_max": 120, "min_cups_max": 5000,
    "leave_wait_s": 43200, "kick_ban_s": 86400, "feed_max": 50, "requests_max": 30, "request_ttl_s": 259200, "find_max": 20,
    "perms": {"edit": "co-leader", "requests": "elder", "kick": "co-leader", "promote": "co-leader"},
}


def validate(d: Any) -> List[str]:
    """liveops validator for the `clan` section: a list of error texts (empty = fine)"""
    if not isinstance(d, dict):
        return ["clan: must be an object"]
    errs: List[str] = []
    for k, (lo, hi) in _NUM.items():
        if k in d and (isinstance(d[k], bool) or not isinstance(d[k], int) or not lo <= d[k] <= hi):
            errs.append("clan.%s must be a whole number from %d to %d" % (k, lo, hi))
    p = d.get("perms")
    if p is not None:
        if not isinstance(p, dict):
            errs.append("clan.perms must be an object")
        else:
            for k, v in p.items():
                if k not in _PERM_KEYS:
                    errs.append("clan.perms.%s is not a known permission (%s)" % (k, ", ".join(_PERM_KEYS)))
                elif v not in _PERM_VALUES:
                    errs.append("clan.perms.%s must be one of %s" % (k, ", ".join(_PERM_VALUES)))
    return errs


def _load_defaults() -> Dict[str, Any]:
    d = json.loads(json.dumps(_FALLBACK))
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "clan_defaults.json"), encoding="utf-8") as f:
            j = json.load(f)
        if not validate(j):
            for k, v in j.items():
                if k == "perms":
                    d["perms"].update(v)
                else:
                    d[k] = v
        else:
            log.warning("clan_defaults.json is not valid (%s): built-in defaults used", validate(j))
    except Exception as e:  # noqa: BLE001
        log.warning("clan_defaults.json not read (%s): built-in defaults used", e)
    return d


DEFAULTS = _load_defaults()
_REG: Dict[str, Any] = {"mod": None}


def _lo():
    """the liveops module if the kit has it (registers the `clan` section the first time it is seen)"""
    if _REG["mod"] is None and time.monotonic() - float(_REG.get("miss", -99)) < 5:
        return None
    try:
        from . import liveops as m  # noqa: WPS433
    except Exception:  # noqa: BLE001
        _REG["miss"] = time.monotonic()
        return None
    if _REG["mod"] is not m:
        _REG["mod"] = m
        try:
            m.register("clan", json.loads(json.dumps(DEFAULTS)), validate)
        except Exception as e:  # noqa: BLE001
            log.warning("liveops.register('clan') failed: %s", e)
    return m


def cfg() -> Dict[str, Any]:
    """the clan settings now: the defaults, over them whatever liveops holds (a bad value is ignored, never raised)"""
    out = dict(DEFAULTS, perms=dict(DEFAULTS["perms"]))
    m = _lo()
    if m is not None:
        try:
            d = m.get("clan")
        except Exception as e:  # noqa: BLE001
            d = None
            log.warning("liveops.get('clan') failed: %s", e)
        if isinstance(d, dict):
            for k, v in d.items():
                if k == "perms" and isinstance(v, dict):
                    out["perms"].update({a: b for a, b in v.items() if a in _PERM_KEYS and b in _PERM_VALUES})
                elif k in _NUM and isinstance(v, int) and not isinstance(v, bool) and _NUM[k][0] <= v <= _NUM[k][1]:
                    out[k] = v
    return out


def flag(name: str) -> bool:
    m = _lo()
    try:
        return bool(m.flag(name)) if m is not None else False
    except Exception:  # noqa: BLE001
        return False


# ---------------------------------------------------------------------------------------------- small helpers
def clean_text(s: Any) -> str:
    t = "".join(ch for ch in str(s or "") if unicodedata.category(ch) not in ("Cc", "Cf", "Cs", "Co", "Cn", "Zl", "Zp"))
    return " ".join(t.split())


def _ids(c: Dict[str, Any]) -> List[int]:
    return [int(x) for x in c["members"]]


def _norm(c: Dict[str, Any]) -> Dict[str, Any]:
    c.setdefault("desc", "")
    c.setdefault("type", "open")
    c.setdefault("min", 0)
    c.setdefault("roles", {})
    c.setdefault("req", {})
    c.setdefault("feed", [])
    return c


def role_of(c: Dict[str, Any], uid: int) -> Optional[str]:
    """leader / co-leader / elder / member, or None when `uid` is not in the clan"""
    uid = int(uid)
    if uid not in _ids(c):
        return None
    if int(c["owner"]) == uid:
        return "leader"
    r = (c.get("roles") or {}).get(str(uid))
    return r if r in ("elder", "co-leader") else "member"


def can(c: Dict[str, Any], uid: int, what: str, cf: Optional[Dict[str, Any]] = None) -> bool:
    r = role_of(c, uid)
    if r is None:
        return False
    need = (cf or cfg())["perms"].get(what, "co-leader")
    return RANK[r] >= RANK[need]


def why_act(c: Dict[str, Any], actor: int, target: int, kind: str, cf: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """why `actor` may not do `kind` (promote / demote / kick) to `target`; None = allowed"""
    ra, rt = role_of(c, actor), role_of(c, target)
    if ra is None:
        return "none"
    if rt is None:
        return "gone"
    if int(actor) == int(target):
        return "self"
    cf = cf or cfg()
    if RANK[ra] < RANK[cf["perms"]["kick" if kind == "kick" else "promote"]]:
        return "perm"
    if RANK[rt] >= RANK[ra]:                                  # only people BELOW you
        return "rank"
    if kind == "promote":
        new = RANK[rt] + 1
        if new >= RANK[ra] or new > RANK["co-leader"]:        # never up to your own rank; leadership moves only with `transfer`
            return "rank"
    elif kind == "demote" and rt == "member":
        return "floor"
    return None


def _next_prefix(s: str) -> str:
    return s[:-1] + chr(min(0x10FFFF, ord(s[-1]) + 1))


def _live_req(c: Dict[str, Any], now: float, cf: Dict[str, Any]) -> Dict[str, float]:
    return {u: t for u, t in (c.get("req") or {}).items() if now - float(t) < cf["request_ttl_s"]}


def _nm(st: Dict[str, Any]) -> str:
    return str(st.get("name") or "Kingdom")[:24]


class ClansX(_Base):
    OPS = ("create", "join", "leave", "kick", "edit", "promote", "demote", "transfer", "request", "cancel", "accept", "reject")

    def __init__(self, store: Any) -> None:
        super().__init__(store)
        self._topc: Optional[tuple] = None          # (time, cards) 10 s cache of the best clans (the Find list without a query)
        self._lex_ok = False
        _lo()                                       # the `clan` settings section shows up in liveops as soon as the server starts

    # ------------------------------------------------------------------ storage (the old methods, now with the new fields)
    async def _get(self, cid: int) -> Optional[Dict[str, Any]]:
        c = await super()._get(cid)
        return _norm(c) if c else None

    async def _put(self, c: Dict[str, Any]) -> None:
        await super()._put(c)
        self._topc = None

    async def _del(self, c: Dict[str, Any]) -> None:
        await super()._del(c)
        self._topc = None
        r = await self.s._redis()
        if r is not None:
            try:
                await asyncio.wait_for(r.zrem(K_LEX, "n:%s:%d" % (c["name"].lower(), int(c["id"])), "t:%s:%d" % (str(c.get("tag", "")).lower(), int(c["id"]))), 2.0)
            except Exception as e:  # noqa: BLE001
                log.warning("clan index delete failed: %s", e)

    async def _lex_add(self, c: Dict[str, Any]) -> None:
        r = await self.s._redis()
        if r is None:
            return
        try:
            await asyncio.wait_for(r.zadd(K_LEX, {"n:%s:%d" % (c["name"].lower(), int(c["id"])): 0, "t:%s:%d" % (c["tag"].lower(), int(c["id"])): 0}), 2.0)
        except Exception as e:  # noqa: BLE001
            log.warning("clan index write failed: %s", e)

    async def _lex_ensure(self, r: Any) -> None:
        """the first search after CN1 is installed: index the clans that were created before it (names HASH has every clan id)"""
        if self._lex_ok:
            return
        if not await asyncio.wait_for(r.exists(K_LEXV), 2.0):
            raw = await asyncio.wait_for(r.hgetall(K_NAMES), 5.0)
            for v in raw.values():
                c = await self._get(int(v))
                if c:
                    await self._lex_add(c)
            await asyncio.wait_for(r.set(K_LEXV, 1), 2.0)
        self._lex_ok = True

    async def _total(self, cid: int) -> int:
        r = await self.s._redis()
        if r is not None:
            try:
                sc = await asyncio.wait_for(r.zscore(K_LB, str(cid)), 2.0)               # (the sorted set IS the clan total: one O(log n) read, not a HASH read per clan)
                if sc is not None:
                    return int(sc)
            except Exception:  # noqa: BLE001
                pass
        return sum((await self._trophies(cid)).values())

    async def _card(self, c: Dict[str, Any], rank: Optional[int] = None) -> Dict[str, Any]:
        out = await super()._card(c, rank)
        out.update(max=cfg()["max_members"], badge=c.get("badge") or MI.default_emblem(int(c["id"])), type=c["type"], min=int(c["min"]), desc=c["desc"])
        return out

    async def _members(self, c: Dict[str, Any]) -> List[Dict[str, Any]]:
        cid = int(c["id"]); now = time.time()
        key = (_ids(c), json.dumps(c["roles"], sort_keys=True), int(c["owner"]))
        hit = self._vc.get(cid)
        if hit and now - hit[0] < 30 and hit[2] == key:
            return hit[1]
        tro = await self._trophies(cid)
        rows = []
        for u in _ids(c):
            try:
                st = await self.s.load(u)
            except Exception:  # noqa: BLE001
                st = {}
            t = int(tro.get(u, st.get("tro", 0)) or 0)
            rows.append({"id": u, "n": _nm(st), "e": MI.emblem_of(st, u) if st else None, "tro": t, "lg": SO.league_index(t),
                         "k": PR.keep_level(st) if st else 1, "owner": u == int(c["owner"]), "role": role_of(c, u), "seen": int(st.get("seen") or 0)})
        rows.sort(key=lambda x: (-x["tro"], x["id"]))
        self._vc[cid] = (now, rows, key)
        return rows

    async def _top_ids(self, n: int) -> List[int]:
        r = await self.s._redis()
        if r is None:
            return sorted(self._mem, key=lambda i: (-sum(self._tro.get(i, {}).values()), i))[:n]
        try:
            ids = [int(i) for i in await asyncio.wait_for(r.zrevrange(K_LB, 0, n - 1), 2.0)]
            if len(ids) < n:                                                             # (a clan with no cups yet is not in the sorted set: the newest ones too)
                seq = int((await asyncio.wait_for(r.get(K_SEQ), 2.0)) or 0)
                for i in range(seq, max(0, seq - 40), -1):
                    if len(ids) >= n:
                        break
                    if i not in ids:
                        ids.append(i)
            return ids
        except Exception as e:  # noqa: BLE001
            log.warning("clan list failed: %s", e)
            return []

    async def _by_prefix(self, q: str, limit: int) -> List[int]:
        ql = q.lower()
        r = await self.s._redis()
        if r is None:
            return [i for i, c in sorted(self._mem.items()) if c["name"].lower().startswith(ql) or c["tag"].lower().startswith(ql)][:limit]
        ids: List[int] = []
        try:
            await self._lex_ensure(r)
            for kind in ("n", "t"):
                rows = await asyncio.wait_for(r.zrangebylex(K_LEX, "[%s:%s" % (kind, ql), "(%s:%s" % (kind, _next_prefix(ql)), 0, limit), 2.0)
                for m in rows:
                    i = int(m.rsplit(":", 1)[1])
                    if i not in ids:
                        ids.append(i)
        except Exception as e:  # noqa: BLE001
            log.warning("clan search failed: %s", e)
        return ids

    # ------------------------------------------------------------------ small shared pieces
    async def _pending(self, st: Dict[str, Any], uid: int) -> int:
        """the clan id of the player's pending request - only if that clan still holds it (a rejected / expired / vanished one counts as none)"""
        cid = int(st.get("creq") or 0)
        if not cid:
            return 0
        c = await self._get(cid)
        if c and str(uid) in _live_req(c, time.time(), cfg()):
            return cid
        return 0

    async def _in_clan(self, st: Dict[str, Any], uid: int) -> int:
        """the clan the player really is in (a stale `clan` pointing at a vanished clan / one he is not in is dropped from `st`)"""
        cid = int(st.get("clan") or 0)
        if cid:
            c = await self._get(cid)
            if c and uid in _ids(c):
                return cid
            st.pop("clan", None)
        return 0

    @staticmethod
    def _gate(st: Dict[str, Any], cf: Dict[str, Any], now: float, cid: int = 0) -> Optional[Dict[str, Any]]:
        """rules that hold for every way in (create / join / request / accept): castle level, the 12 h after leaving, the 24 h after a kick from THIS clan"""
        if PR.keep_level(st) < cf["min_keep"]:
            return {"ok": False, "why": "low", "need": cf["min_keep"]}
        w = float(st.get("cwait") or 0) - now
        if w > 0:
            return {"ok": False, "why": "wait", "wait": int(w + 0.999)}
        if cid:
            b = float((st.get("cban") or {}).get(str(cid)) or 0) - now
            if b > 0:
                return {"ok": False, "why": "banned", "wait": int(b + 0.999)}
        return None

    @staticmethod
    def _log(c: Dict[str, Any], cf: Dict[str, Any], kind: str, now: float, a: Optional[int] = None, an: str = "", b: Optional[int] = None, bn: str = "", x: str = "") -> None:
        e: Dict[str, Any] = {"t": int(now), "k": kind}
        if a is not None:
            e["a"], e["an"] = int(a), an
        if b is not None:
            e["b"], e["bn"] = int(b), bn
        if x:
            e["x"] = x
        c["feed"].append(e)
        del c["feed"][:-cf["feed_max"]]

    async def _name(self, uid: int) -> str:
        try:
            return _nm(await self.s.load(int(uid)))
        except Exception:  # noqa: BLE001
            return "Kingdom"

    def _acts(self, c: Dict[str, Any], actor: int, target: int, cf: Dict[str, Any]) -> List[str]:
        if int(actor) == int(target):
            return []
        out = [k for k in ("promote", "demote", "kick") if why_act(c, actor, target, k, cf) is None]
        if role_of(c, actor) == "leader":
            out.append("transfer")
        return out

    def _act_for(self, card: Dict[str, Any], st: Dict[str, Any], now: float, pend: int) -> Optional[str]:
        """what the button of a clan card should be for a player without a clan: join / request / pending / cups / full / closed / banned"""
        b = float((st.get("cban") or {}).get(str(card["id"])) or 0) - now
        if b > 0:
            return "banned"
        if card["type"] == "closed":
            return "closed"
        if card["n"] >= card["max"]:
            return "full"
        if int(st.get("tro", 0)) < card["min"]:
            return "cups"
        if card["type"] == "open":
            return "join"
        return "pending" if pend == card["id"] else "request"

    # ------------------------------------------------------------------ views
    async def view(self, uid: int, top_n: int = 20) -> Dict[str, Any]:
        cf = cfg(); now = time.time()
        st = await self.s.load(uid)
        cid = int(st.get("clan") or 0)
        mine = None
        if cid:
            c = await self._get(cid)
            if c and uid in _ids(c):
                mem = [dict(m, me=(m["id"] == uid), acts=self._acts(c, uid, m["id"], cf)) for m in await self._members(c)]
                me_role = role_of(c, uid)
                mine = dict(await self._card(c), owner=int(c["owner"]), members=mem, me_owner=int(c["owner"]) == uid, role=me_role,
                            req_n=len(_live_req(c, now, cf)) if can(c, uid, "requests", cf) else 0,
                            can={"edit": can(c, uid, "edit", cf), "requests": can(c, uid, "requests", cf), "kick": can(c, uid, "kick", cf),
                                 "promote": can(c, uid, "promote", cf), "transfer": me_role == "leader"})
        pend = 0 if mine else await self._pending(st, uid)
        top = []
        for k, i in enumerate((await self._top_ids(top_n))[:top_n]):
            c = await self._get(i)
            if c:
                top.append(await self._card(c, k + 1))
        top.sort(key=lambda x: (-x["tro"], x["id"]))
        for k, t in enumerate(top):
            t["r"] = k + 1
            if not mine:
                t["act"] = self._act_for(t, st, now, pend)
        my_req = None
        if pend:
            c = await self._get(pend)
            if c:
                my_req = await self._card(c)
        return {"mine": mine, "top": top, "max": cf["max_members"], "min_keep": cf["min_keep"], "desc_max": cf["desc_max"], "min_cups_max": cf["min_cups_max"],
                "types": list(TYPES), "my_req": my_req, "wait": max(0, int(float(st.get("cwait") or 0) - now + 0.999)), "now": int(now),
                "flags": {"chat_clan": flag("chat_clan"), "clan_war": flag("clan_war")}}

    async def find(self, uid: int, q: str = "", min_cups: Optional[int] = None, ctype: str = "") -> Dict[str, Any]:
        """search: by name / tag prefix, or the best clans when `q` is empty.  `min_cups` = the cups the player has: only clans he can enter by cups; `ctype` = open | request"""
        cf = cfg(); now = time.time()
        q = clean_name(q).lstrip("#").strip()
        ctype = ctype if ctype in TYPES else ""
        st = await self.s.load(uid)
        mine = bool(await self._in_clan(dict(st), uid))
        pend = 0 if mine else await self._pending(st, uid)
        if q:
            cards = []
            for i in await self._by_prefix(q, 40):
                c = await self._get(i)
                if c:
                    cards.append(await self._card(c))
        else:
            hit = self._topc
            if hit and now - hit[0] < 10:
                cards = [dict(x) for x in hit[1]]
            else:
                cards = []
                for i in await self._top_ids(60):
                    c = await self._get(i)
                    if c:
                        cards.append(await self._card(c))
                self._topc = (now, [dict(x) for x in cards])
        cards.sort(key=lambda x: (-x["tro"], x["id"]))
        out = []
        for card in cards:
            if ctype and card["type"] != ctype:
                continue
            if min_cups is not None and card["min"] > min_cups:
                continue
            card["r"] = len(out) + 1 if not q else None
            card["act"] = None if mine else self._act_for(card, st, now, pend)
            out.append(card)
            if len(out) >= cf["find_max"]:
                break
        return {"list": out, "q": q, "max": cf["max_members"], "wait": max(0, int(float(st.get("cwait") or 0) - now + 0.999)),
                "low": PR.keep_level(st) < cf["min_keep"], "min_keep": cf["min_keep"]}

    async def requests(self, uid: int) -> Dict[str, Any]:
        """the pending join requests (for the people who may accept them)"""
        cf = cfg(); now = time.time()
        st = await self.s.load(uid)
        cid = int(st.get("clan") or 0)
        c = await self._get(cid) if cid else None
        if not c or uid not in _ids(c):
            return {"ok": False, "why": "none"}
        if not can(c, uid, "requests", cf):
            return {"ok": False, "why": "perm"}
        rows, stale = [], []
        for u, t in sorted(_live_req(c, now, cf).items(), key=lambda kv: -kv[1]):
            try:
                a = await self.s.load(int(u))
            except Exception:  # noqa: BLE001
                continue
            if int(a.get("clan") or 0) or int(a.get("creq") or 0) != cid:                 # joined another clan / asked somewhere else since: not a request any more
                stale.append(u)
                continue
            tro = int(a.get("tro", 0))
            rows.append({"id": int(u), "n": _nm(a), "e": MI.emblem_of(a, int(u)), "tro": tro, "lg": SO.league_index(tro), "k": PR.keep_level(a), "t": int(t),
                         "ok": tro >= int(c["min"])})
        gone = [u for u in c["req"] if u not in _live_req(c, now, cf)] + stale
        if gone:
            async with self._lock(cid):
                c2 = await self._get(cid)
                if c2:
                    for u in gone:
                        c2["req"].pop(u, None)
                    await self._put(c2)
        return {"ok": True, "requests": rows, "min": int(c["min"])}

    async def feed(self, uid: int) -> Dict[str, Any]:
        st = await self.s.load(uid)
        cid = int(st.get("clan") or 0)
        c = await self._get(cid) if cid else None
        if not c or uid not in _ids(c):
            return {"ok": False, "why": "none"}
        return {"ok": True, "feed": list(reversed(c["feed"]))}

    # ------------------------------------------------------------------ for the other chats (CH1 / CW1 / AT1)
    async def clan_of(self, uid: int) -> int:
        """the clan id of `uid`, 0 when he has none"""
        st = await self.s.load(int(uid))
        return await self._in_clan(st, int(uid))

    async def members(self, cid: int) -> List[int]:
        """the member ids of clan `cid` ([] when it does not exist)"""
        c = await self._get(int(cid))
        return _ids(c) if c else []

    # ------------------------------------------------------------------ commands (each: {ok, why?, ...})
    async def command(self, uid: int, op: str, body: Dict[str, Any]) -> Dict[str, Any]:
        """one entry for POST /api/clan: any op, old or new.  A malformed id raises ValueError / TypeError (the route answers 400)."""
        if op == "create":
            return await self.create(uid, str(body.get("name") or ""), str(body.get("tag") or ""), desc=body.get("desc"), badge=body.get("badge"),
                                     ctype=body.get("type"), min_cups=body.get("min"))
        if op == "join":
            return await self.join(uid, int(body.get("id")))
        if op == "leave":
            return await self.leave(uid)
        if op == "kick":
            return await self.kick(uid, int(body.get("id")))
        if op == "edit":
            return await self.edit(uid, body)
        if op in ("promote", "demote"):
            return await self.set_role(uid, int(body.get("id")), op)
        if op == "transfer":
            return await self.transfer(uid, int(body.get("id")))
        if op == "request":
            return await self.request(uid, int(body.get("id")))
        if op == "cancel":
            return await self.cancel(uid)
        if op in ("accept", "reject"):
            return await self.answer(uid, int(body.get("id")), op == "accept")
        return {"ok": False, "why": "bad_op"}

    @staticmethod
    def _fields(cf: Dict[str, Any], body: Dict[str, Any]) -> Dict[str, Any]:
        """validate the editable fields that are present in `body` -> {field: value} or {"why": code}"""
        out: Dict[str, Any] = {}
        if body.get("desc") is not None:
            d = clean_text(body.get("desc") or "")
            if len(d) > cf["desc_max"]:
                return {"why": "desc"}
            out["desc"] = d
        if body.get("badge") is not None:
            b = MI.norm_emblem(body.get("badge"))
            if b is None:
                return {"why": "badge"}
            out["badge"] = b
        if body.get("type") is not None:
            if body.get("type") not in TYPES:
                return {"why": "type"}
            out["type"] = body["type"]
        if body.get("min") is not None:
            m = body.get("min")
            if isinstance(m, bool) or not isinstance(m, int) or not 0 <= m <= cf["min_cups_max"]:
                return {"why": "mincups", "max": cf["min_cups_max"]}
            out["min"] = m
        return out

    async def create(self, uid: int, name: str, tag: str, desc: Any = None, badge: Any = None, ctype: Any = None, min_cups: Any = None) -> Dict[str, Any]:
        cf = cfg(); now = time.time()
        nm, tg = clean_name(name), str(tag or "").strip().upper()
        if len(nm) < 3:
            return {"ok": False, "why": "name"}
        if not TAG_RE.match(tg):
            return {"ok": False, "why": "tag"}
        f = self._fields(cf, {"desc": desc, "badge": badge, "type": ctype, "min": min_cups})
        if "why" in f:
            return {"ok": False, **f}
        an = ""
        async with self.s._lock(uid):
            st = await self.s._txn(uid)
            if await self._in_clan(st, uid):
                return {"ok": False, "why": "in_clan"}
            bad = self._gate(st, cf, now)
            if bad:
                return bad
            an = _nm(st)
            async with self._glock:
                cid = await self._next_id()
                if not await self._claim_name(nm, cid):
                    return {"ok": False, "why": "taken"}
                c = _norm({"id": cid, "name": nm, "tag": tg, "owner": uid, "members": [uid], "t": now})
                c["desc"], c["type"], c["min"] = f.get("desc", ""), f.get("type", "open"), f.get("min", 0)
                c["badge"] = f.get("badge") or MI.default_emblem(cid)
                self._log(c, cf, "create", now, uid, an)
                await self._put(c)
                await self._lex_add(c)
            st["clan"] = cid
            st.pop("creq", None)
            await self.s.save(uid, st)
        await self.member_cups(uid, st)
        return {"ok": True, "id": cid}

    async def join(self, uid: int, cid: int) -> Dict[str, Any]:
        cf = cfg(); now = time.time()
        async with self.s._lock(uid):
            st = await self.s._txn(uid)
            if await self._in_clan(st, uid):
                return {"ok": False, "why": "in_clan"}
            bad = self._gate(st, cf, now, cid)
            if bad:
                return bad
            an = _nm(st)
            async with self._lock(cid):
                c = await self._get(cid)
                if not c:
                    return {"ok": False, "why": "gone"}
                if c["type"] == "closed":
                    return {"ok": False, "why": "closed"}
                if c["type"] == "request":
                    return {"ok": False, "why": "request"}
                if int(st.get("tro", 0)) < int(c["min"]):
                    return {"ok": False, "why": "cups", "need": int(c["min"])}
                if len(c["members"]) >= cf["max_members"]:
                    return {"ok": False, "why": "full"}
                if uid not in _ids(c):
                    c["members"].append(uid)
                    c["req"].pop(str(uid), None)
                    self._log(c, cf, "join", now, uid, an)
                    await self._put(c)
            st["clan"] = cid
            st.pop("creq", None)
            await self.s.save(uid, st)
        await self.member_cups(uid, st)
        self._vc.pop(cid, None)
        return {"ok": True, "id": cid}

    async def _drop(self, c: Dict[str, Any], uid: int) -> None:
        """take `uid` out of clan `c` (clan lock held by the caller).  A leader leaves only as the last one (the clan is then deleted);
        should one ever be taken out otherwise (an admin tool) the strongest member takes over, as before"""
        mem = [x for x in _ids(c) if x != uid]
        await self._set_tro(int(c["id"]), uid, None)
        if not mem:
            await self._del(c)
            return
        c["members"] = mem
        c["roles"].pop(str(uid), None)
        c["req"].pop(str(uid), None)
        if int(c["owner"]) == uid:
            tro = await self._trophies(int(c["id"]))
            c["owner"] = max(mem, key=lambda u: (tro.get(u, 0), -u))
            c["roles"].pop(str(c["owner"]), None)
        await self._put(c)

    async def leave(self, uid: int) -> Dict[str, Any]:
        cf = cfg(); now = time.time()
        async with self.s._lock(uid):
            st = await self.s._txn(uid)
            cid = int(st.get("clan") or 0)
            if not cid:
                return {"ok": False, "why": "none"}
            an = _nm(st)
            async with self._lock(cid):
                c = await self._get(cid)
                if c and uid in _ids(c):
                    if int(c["owner"]) == uid and len(c["members"]) > 1:
                        return {"ok": False, "why": "leader"}                                  # the leader hands the clan over first (transfer)
                    self._log(c, cf, "leave", now, uid, an)
                    await self._drop(c, uid)
            st.pop("clan", None)
            st.pop("creq", None)
            if cf["leave_wait_s"] > 0:
                st["cwait"] = now + cf["leave_wait_s"]
            await self.s.save(uid, st)
        self._vc.pop(cid, None)
        return {"ok": True, "wait": cf["leave_wait_s"]}

    async def kick(self, uid: int, target: int) -> Dict[str, Any]:
        cf = cfg(); now = time.time()
        st = await self.s.load(uid)
        cid = int(st.get("clan") or 0)
        if not cid or target == uid:
            return {"ok": False, "why": "none"}
        an, bn = await self._name(uid), await self._name(target)
        async with self._lock(cid):
            c = await self._get(cid)
            if not c or uid not in _ids(c):
                return {"ok": False, "why": "none"}
            w = why_act(c, uid, target, "kick", cf)
            if w:
                return {"ok": False, "why": w}
            self._log(c, cf, "kick", now, uid, an, target, bn)
            await self._drop(c, target)
        async with self.s._lock(target):
            t = await self.s.load(target)
            if int(t.get("clan") or 0) == cid:
                t.pop("clan", None)
            if cf["kick_ban_s"] > 0:
                ban = {k: v for k, v in (t.get("cban") or {}).items() if float(v) > now}
                ban[str(cid)] = now + cf["kick_ban_s"]
                t["cban"] = ban
            await self.s.save(target, t)
        self._vc.pop(cid, None)
        return {"ok": True}

    async def set_role(self, uid: int, target: int, kind: str) -> Dict[str, Any]:
        cf = cfg(); now = time.time()
        st = await self.s.load(uid)
        cid = int(st.get("clan") or 0)
        if not cid:
            return {"ok": False, "why": "none"}
        an, bn = await self._name(uid), await self._name(target)
        async with self._lock(cid):
            c = await self._get(cid)
            if not c or uid not in _ids(c):
                return {"ok": False, "why": "none"}
            w = why_act(c, uid, target, kind, cf)
            if w:
                return {"ok": False, "why": w}
            new = ROLES[RANK[role_of(c, target)] + (1 if kind == "promote" else -1)]
            if new == "member":
                c["roles"].pop(str(target), None)
            else:
                c["roles"][str(target)] = new
            self._log(c, cf, kind, now, uid, an, target, bn, new)
            await self._put(c)
        self._vc.pop(cid, None)
        return {"ok": True, "role": new}

    async def transfer(self, uid: int, target: int) -> Dict[str, Any]:
        cf = cfg(); now = time.time()
        st = await self.s.load(uid)
        cid = int(st.get("clan") or 0)
        if not cid:
            return {"ok": False, "why": "none"}
        an, bn = await self._name(uid), await self._name(target)
        async with self._lock(cid):
            c = await self._get(cid)
            if not c or uid not in _ids(c):
                return {"ok": False, "why": "none"}
            if int(c["owner"]) != uid:
                return {"ok": False, "why": "perm"}
            if target == uid:
                return {"ok": False, "why": "self"}
            if target not in _ids(c):
                return {"ok": False, "why": "gone"}
            c["owner"] = target
            c["roles"].pop(str(target), None)
            c["roles"][str(uid)] = "co-leader"                                               # the old leader stays on as co-leader
            self._log(c, cf, "transfer", now, uid, an, target, bn)
            await self._put(c)
        self._vc.pop(cid, None)
        return {"ok": True}

    async def edit(self, uid: int, body: Dict[str, Any]) -> Dict[str, Any]:
        cf = cfg(); now = time.time()
        f = self._fields(cf, body)
        if "why" in f:
            return {"ok": False, **f}
        if not f:
            return {"ok": False, "why": "none"}
        st = await self.s.load(uid)
        cid = int(st.get("clan") or 0)
        if not cid:
            return {"ok": False, "why": "none"}
        an = await self._name(uid)
        async with self._lock(cid):
            c = await self._get(cid)
            if not c or uid not in _ids(c):
                return {"ok": False, "why": "none"}
            if not can(c, uid, "edit", cf):
                return {"ok": False, "why": "perm"}
            changed = [k for k, v in f.items() if (c.get(k) if k != "badge" else (c.get("badge") or MI.default_emblem(cid))) != v]
            if changed:
                for k in changed:
                    c[k] = f[k]
                self._log(c, cf, "edit", now, uid, an, x=",".join(changed))
                await self._put(c)
        self._vc.pop(cid, None)
        return {"ok": True, "changed": changed}

    async def request(self, uid: int, cid: int) -> Dict[str, Any]:
        cf = cfg(); now = time.time()
        async with self.s._lock(uid):
            st = await self.s._txn(uid)
            if await self._in_clan(st, uid):
                return {"ok": False, "why": "in_clan"}
            bad = self._gate(st, cf, now, cid)
            if bad:
                return bad
            pend = await self._pending(st, uid)
            async with self._lock(cid):
                c = await self._get(cid)
                if not c:
                    return {"ok": False, "why": "gone"}
                if c["type"] == "closed":
                    return {"ok": False, "why": "closed"}
                if c["type"] == "open":
                    return {"ok": False, "why": "open"}                                      # (just join)
                live = _live_req(c, now, cf)
                if str(uid) not in live:
                    if pend and pend != cid:
                        return {"ok": False, "why": "pending"}                                # one request at a time: cancel the other first
                    if int(st.get("tro", 0)) < int(c["min"]):
                        return {"ok": False, "why": "cups", "need": int(c["min"])}
                    if len(c["members"]) >= cf["max_members"]:
                        return {"ok": False, "why": "full"}
                    if len(live) >= cf["requests_max"]:
                        return {"ok": False, "why": "busy"}
                    c["req"] = dict(live, **{str(uid): int(now)})
                    await self._put(c)
            st["creq"] = cid
            await self.s.save(uid, st)
        return {"ok": True, "id": cid}

    async def cancel(self, uid: int) -> Dict[str, Any]:
        async with self.s._lock(uid):
            st = await self.s._txn(uid)
            cid = int(st.get("creq") or 0)
            if not cid:
                return {"ok": False, "why": "none"}
            async with self._lock(cid):
                c = await self._get(cid)
                if c and str(uid) in c["req"]:
                    c["req"].pop(str(uid), None)
                    await self._put(c)
            st.pop("creq", None)
            await self.s.save(uid, st)
        return {"ok": True}

    async def answer(self, uid: int, target: int, accept: bool) -> Dict[str, Any]:
        """accept / reject the join request of `target` (needs the `requests` permission)"""
        cf = cfg(); now = time.time()
        me = await self.s.load(uid)
        cid = int(me.get("clan") or 0)
        if not cid or target == uid:
            return {"ok": False, "why": "none"}
        if not accept:
            async with self._lock(cid):
                c = await self._get(cid)
                if not c or uid not in _ids(c):
                    return {"ok": False, "why": "none"}
                if not can(c, uid, "requests", cf):
                    return {"ok": False, "why": "perm"}
                if c["req"].pop(str(target), None) is None:
                    return {"ok": False, "why": "gone"}
                await self._put(c)
            return {"ok": True}                                                              # (his `creq` is dropped lazily: _pending() asks the clan)
        an, bn = await self._name(uid), await self._name(target)
        async with self.s._lock(target):                                                     # (player lock first, then the clan lock)
            t = await self.s.load(target)
            async with self._lock(cid):
                c = await self._get(cid)
                if not c or uid not in _ids(c):
                    return {"ok": False, "why": "none"}
                if not can(c, uid, "requests", cf):
                    return {"ok": False, "why": "perm"}
                if str(target) not in _live_req(c, now, cf):
                    if c["req"].pop(str(target), None) is not None:                          # (an expired one is swept now)
                        await self._put(c)
                    return {"ok": False, "why": "gone"}
                if await self._in_clan(t, target):
                    c["req"].pop(str(target), None)
                    await self._put(c)
                    return {"ok": False, "why": "in_clan"}
                bad = self._gate(t, cf, now, cid)
                if bad:
                    return bad
                if int(t.get("tro", 0)) < int(c["min"]):
                    return {"ok": False, "why": "cups", "need": int(c["min"])}
                if len(c["members"]) >= cf["max_members"]:
                    return {"ok": False, "why": "full"}
                c["members"].append(target)
                c["req"].pop(str(target), None)
                self._log(c, cf, "join", now, target, bn, x="req")
                await self._put(c)
            t["clan"] = cid
            t.pop("creq", None)
            await self.s.save(target, t)
        await self.member_cups(target, t)
        self._vc.pop(cid, None)
        return {"ok": True}


# ---------------------------------------------------------------------------------------------- routes
def add_routes(app: Any, get_store: Any, bearer_uid: Any, limited: Any, nocache: Any) -> None:
    """GET /api/clan/find  /api/clan/requests  /api/clan/feed  (the same guard as the other social routes: bearer login, rate limit per player)"""
    from aiohttp import web

    def _guard(req: Any, key: str, per: int):
        uid = bearer_uid(req)
        if uid is None:
            return None, nocache(web.json_response({"ok": False, "reason": "locked"}, status=403))
        if limited(key + ":" + str(uid), per):
            return None, nocache(web.json_response({"ok": False, "reason": "slow"}, status=429))
        return uid, None

    async def h_find(req: Any):
        uid, bad = _guard(req, "cf", 40)
        if bad is not None:
            return bad
        try:
            m = req.query.get("min")
            mn = None if m in (None, "") else max(0, min(10 ** 6, int(m)))
        except (ValueError, TypeError):
            return nocache(web.json_response({"ok": False, "reason": "bad"}, status=400))
        t = str(req.query.get("type") or "")
        if t not in ("",) + TYPES:
            return nocache(web.json_response({"ok": False, "reason": "bad"}, status=400))
        return nocache(web.json_response({"ok": True, **(await get_store().clans.find(uid, str(req.query.get("q") or "")[:40], mn, t))}))

    async def h_requests(req: Any):
        uid, bad = _guard(req, "cq", 30)
        if bad is not None:
            return bad
        r = await get_store().clans.requests(uid)
        return nocache(web.json_response(r if r.get("ok") else {"ok": False, "reason": "no", "why": r.get("why")}))

    async def h_feed(req: Any):
        uid, bad = _guard(req, "cd", 30)
        if bad is not None:
            return bad
        r = await get_store().clans.feed(uid)
        return nocache(web.json_response(r if r.get("ok") else {"ok": False, "reason": "no", "why": r.get("why")}))

    app.router.add_get("/api/clan/find", h_find)
    app.router.add_get("/api/clan/requests", h_requests)
    app.router.add_get("/api/clan/feed", h_feed)
