# APPLY — TR2_S4c (nature, lamps, props from the Tripo library)
Base: kit **p47** (includes TR2-S2). Nothing else merged on top.

1. Copy the files of this archive over the kit, same paths:
   - `bluewall/client/src/tr2_s4c.js` (NEW, mine) · `trees.js` · `sc_rocks.js` · `sc_bush.js` (my files, full copies)
   - `bluewall/web/assets/tr2/*.glb` (13 packs, 1.8 MB; `swap.json` is S2's, unchanged)
   - `tools/tr2_slim_pack.mjs` (UV-aware slimming used to make the packs; not needed at run time)
   - `workers/dev/tr2_s4c_*` (test + frame tools; not needed at run time)
2. `world.js` is SHARED: apply `patch.diff` (11 lines marked `// TR2-S4c`, listed in `report_TR2_S4c.md` §4). A full copy is in the archive too (`bluewall/client/src/world.js`) in case world.js was not touched by another worker.
3. `bash dev/rb.sh` (build) — `web/app/wall.js` is NOT in this archive on purpose; rebuild it.
4. Check: `bash dev/gate_w.sh` → `GATE_W: ALL OK` (noRoute 667). Frames: `bash dev/tr2_s4c_test.sh 30`.
5. Dev switch: `?s4c=0` in the URL = the old models (A/B).
