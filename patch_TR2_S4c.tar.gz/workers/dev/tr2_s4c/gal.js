// TR2-S4c dev: every tree species of S4C.treeSet in a row (real meshes, the game's tint), seen from the game camera angle and from above
import * as THREE from '/home/claude/bot/bluebot_v2/bluewall/client/node_modules/three/build/three.module.js';
import { S4C } from '/home/claude/bot/bluebot_v2/bluewall/client/src/tr2_s4c.js';
import tr2 from '/home/claude/bot/bluebot_v2/bluewall/client/src/tr2lib.js';
const q = new URLSearchParams(location.search);
window.BW_ASSETS = '/assets/';
(async () => {
  const W = 1500, H = 760;
  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true }); renderer.setSize(W, H); document.body.appendChild(renderer.domElement);
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.outputColorSpace = THREE.SRGBColorSpace;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x8a9aa8);
  scene.add(new THREE.HemisphereLight(0xcfe0ff, 0x4a5a30, 1.4)); const sun = new THREE.DirectionalLight(0xfff0d8, 2.4); sun.position.set(-150, 230, 150); scene.add(sun);
  const g = new THREE.Mesh(new THREE.PlaneGeometry(900, 900), new THREE.MeshStandardMaterial({ color: 0x6b7a3a, roughness: 1 })); g.rotation.x = -Math.PI / 2; scene.add(g);
  await S4C.load();
  const season = q.get('s') != null ? { s: +q.get('s'), p: 0.6 } : null;
  const specs = (q.get('specs') || 'trees_conifer/spruce:20,trees_conifer/pine:23,trees_conifer/cedar:15,trees_conifer/cypress:15,trees_broadleaf/oak:12,trees_broadleaf/plane:13').split(',');
  const T = S4C.treeSet(season); const tintKey = { spruce: 'tr_spruce', pine: 'tr_pine', cedar: 'tr_cedar', cypress: 'tr_cypress', oak: 'tr_oak', plane: 'tr_plane', walnut: 'tr_walnut', poplar: 'tr_poplar', birch: 'tr_birch', maple_autumn: 'tr_maple', dead_tree: 'tr_dead', fir_snow: 'tr_fir_snow' };
  const lab = []; const sp = 20, x0 = -(specs.length - 1) * sp / 2;
  specs.forEach((sx, i) => {
    const [spec, h] = sx.split(':'); const ps = tr2.parts(spec, { h: +h }); const name = spec.split('/')[1]; const tk = tintKey[name];
    ps.forEach((p) => { const m = new THREE.Mesh(p.geometry, p.material.clone()); if (tk && T.tint) m.material.color = T.tint(tk, 3); m.position.set(x0 + i * sp, 0, 0); scene.add(m); });
    lab.push(spec + ' h' + h);
  });
  const cam = new THREE.PerspectiveCamera(30, W / H, 1, 3000);
  const mode = q.get('cam') || 'side';
  if (mode === 'top') { cam.position.set(0, 190, 40); cam.lookAt(0, 0, 0); } else { cam.position.set(0, 22, 110); cam.lookAt(0, 9, 0); }
  renderer.render(scene, cam);
  window.__done = { keys: lab };
})();
