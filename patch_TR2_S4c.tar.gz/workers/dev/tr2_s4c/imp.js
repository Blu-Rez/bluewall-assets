// TR2-S4c dev: the far-forest impostors + real trees of trees.js on a flat ground, and the impostor atlas itself (what the bake produced)
import * as THREE from '/home/claude/bot/bluebot_v2/bluewall/client/node_modules/three/build/three.module.js';
import { buildTrees } from '/home/claude/bot/bluebot_v2/bluewall/client/src/trees.js';
import { S4C } from '/home/claude/bot/bluebot_v2/bluewall/client/src/tr2_s4c.js';
const q = new URLSearchParams(location.search);
window.BW_ASSETS = '/assets/';
(async () => {
  const W = 1100, H = 640;
  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true }); renderer.setSize(W, H); document.body.appendChild(renderer.domElement);
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.outputColorSpace = THREE.SRGBColorSpace;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x8a9aa8);
  scene.add(new THREE.HemisphereLight(0xcfe0ff, 0x4a5a30, 1.4)); const sun = new THREE.DirectionalLight(0xfff0d8, 2.4); sun.position.set(-150, 230, 150); scene.add(sun);
  const g = new THREE.Mesh(new THREE.PlaneGeometry(900, 900), new THREE.MeshStandardMaterial({ color: 0x6b7a3a, roughness: 1 })); g.rotation.x = -Math.PI / 2; scene.add(g);
  const ok = await S4C.load(); document.title = 'S4C ' + ok;
  const season = q.get('s') != null ? { s: +q.get('s'), p: 0.6 } : null;
  const far = [], near = []; let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 160; i++) { const x = -150 + (i % 16) * 20 + rnd() * 6, z = -90 + Math.floor(i / 16) * 22 + rnd() * 6; far.push({ m: new THREE.Matrix4().compose(new THREE.Vector3(x, 0, z), new THREE.Quaternion(), new THREE.Vector3(1, 1, 1)), d: 300, group: i % 5 === 0 ? 'broad' : undefined }); }
  for (let i = 0; i < 8; i++) near.push({ m: new THREE.Matrix4().makeTranslation(-60 + i * 16, 0, 120), d: 1, group: i % 2 ? 'pine' : 'broad' });
  const R = buildTrees(renderer, scene, { models: {} }, near, far, { level: 'medium', shadows: false, trees: 'high' }, rnd, season);
  const cam = new THREE.PerspectiveCamera(40, W / H, 1, 3000); cam.position.set(0, 190, 330); cam.lookAt(0, 0, 20);
  if (q.get('cam') === 'near') { cam.position.set(0, 45, 60); cam.lookAt(0, 6, -30); }
  renderer.render(scene, cam);
  // atlas
  const sc2 = new THREE.Scene(); sc2.background = new THREE.Color(0x303a44); const maps = [];
  scene.traverse((o) => { if (o.isInstancedMesh && o.material.map && o.material.map.isRenderTargetTexture && !maps.includes(o.material.map)) maps.push(o.material.map); });
  maps.slice(0, 12).forEach((t, i) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(3, 4), new THREE.MeshBasicMaterial({ map: t, transparent: true, alphaTest: 0.1 })); m.position.set((i % 6) * 3.2 - 8, 1.2 - Math.floor(i / 6) * 4.2, 0); sc2.add(m); });
  const c2 = new THREE.OrthographicCamera(-9.5, 9.5, 5, -4.5, 0.1, 10); c2.position.z = 5; window.__atlas = () => { renderer.render(sc2, c2); return maps.length; };
  window.__main = () => renderer.render(scene, cam);
  window.__done = { count: R && R.count, maps: maps.length, calls: renderer.info.render.calls, tris: renderer.info.render.triangles };
})();
