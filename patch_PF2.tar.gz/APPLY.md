# APPLY — patch_PF2.tar.gz (for the mother)
Base: branch `kit` (the commit named in the last line of workers/KIT_VERSION when PF2 started; PF1 merged). Extract at the repo root: `bluewall/client/src/{main.js,perf.js,pf_probe.js}`, `workers/dev/pf2_*`, `workers/dev/pf2/*`, `workers/dev/pf1/page.py` (updated: its bench checks read the v2 result), `patch.diff` (the same change as a diff).
main.js is the only shared file: 13 lines marked `// PF2` (listed in report_PF2.md §7; limit 30). `web/app/wall.js` is NOT in the patch: rebuild with `client/build.sh`.
Nothing else outside perf.js / pf_probe.js changed (no world.js / dragon*.js / weather.js / battle.js / assets.js / shaderwarm.js / perfhud.js line).
Check: `bash dev/pf2_test.sh` -> PF2 OK (PF1=1 also runs pf1_test.sh -> PF1 OK); `bash dev/gate_w.sh` -> GATE_W: ALL OK.
Switches: `?nres=0.7` (night path at 0.7 x resolution, A/B for BW_bench on a phone; default 1 = unchanged). `window.pf_overdraw(view)` (owner / ?pf=1 pages): pixels x blended layers.
