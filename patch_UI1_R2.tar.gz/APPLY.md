cd <repo root> (kit 8ce26f5 or newer)
git apply UI1_R2.diff            # or copy files/ over the tree (same paths)
bash dev/ui1r2_test.sh           # -> UI1_R2 OK
