RP4 Round 2 frames (all full size, software GL)
block_strip / block_0..3     dev arena, from behind (host behind-camera D 3.6, fov 50): guard up · enemy telegraph · BLOCKED (sparks, blue digit 13 = 52.5 x 0.25) · +0.12 s still guarding
break_strip                  guard break: stamina 14, brute hit -> red flash + vignette, digit 120, staggered
game_block_390x844           the REAL game (kit a314960 + R2 + 1-line hook), hero mode -> underworld, 390x844: a blocked hit (digit 34 = 135 x 0.25), sparks at the guard, shield button lit, red edge arrow
fx_ranged_strip, fx_ranged_0 test kit "bow healer": bolt hit, heal (+150 and +25/s), root snare (green enemies)
fx_spear_strip               test kit "spear controller": ice beads (fan of 3), slowed enemy, freezing nova (ice-blue enemies, ring)
fx_hammer_strip              test kit "hammer tank": 100-degree quake cone (3 hits), stone shield on the hero
fx_daggers_strip             test kit "dagger scout": burning enemy (orange flicker, small digits), gust + buff
fx_staff_strip               test kit "staff healer": water bolt, healing rain over time
skills_strip                 Elina (the real kit_elina.js): Flame Wave crescent + Ember Burst ring, through the new generic effect code
The fx_* kits are TEST FIXTURES (dev/rp4_kit_fixtures.js), not game content.
