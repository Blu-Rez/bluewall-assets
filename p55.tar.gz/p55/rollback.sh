#!/usr/bin/env bash
set -euo pipefail
APP=/root/bluebot_v2; BK="$APP/_backups/p55"
[ -d "$BK/files" ] || { echo "no backup at $BK"; exit 1; }
cp -r "$BK/files/." "$APP/"
while read -r f; do [ -n "$f" ] && rm -f "$APP/$f"; done < "$BK/added.txt"
systemctl restart bluebot-wall && echo "✅ rolled back to the previous version"
