#!/usr/bin/env bash
# Blue Wall — p55: day-dominant day/night cycle + blue rotate card (+ everything in p54)
set -Eeuo pipefail
NAME=p55
APP=/root/bluebot_v2
PKG="$(cd "$(dirname "$0")" && pwd)"
BK="$APP/_backups/$NAME"
fail(){ trap - ERR; echo "❌ $1 — rolling back"; bash "$PKG/rollback.sh" || true; exit 1; }
[ -d "$APP/bluewall" ] || { echo "❌ $APP/bluewall not found"; exit 1; }

echo "== 0/4 verify package"
( cd "$PKG" && sha256sum -c --quiet SHA256SUMS ) || { echo "❌ package damaged — download it again"; exit 1; }

echo "== 1/4 backup -> $BK"
if [ -d "$BK/files" ]; then
  echo "   (already there — re-run, keeping the original backup)"
else
  mkdir -p "$BK/files"; : > "$BK/added.txt"
  ( cd "$PKG/files" && find . -type f | sed 's#^\./##' ) | while read -r f; do
    if [ -e "$APP/$f" ]; then mkdir -p "$BK/files/$(dirname "$f")"; cp -p "$APP/$f" "$BK/files/$f"; else echo "$f" >> "$BK/added.txt"; fi
  done
fi
trap 'fail "unexpected error (line $LINENO)"' ERR

echo "== 2/4 copy files ($(cd "$PKG/files" && find . -type f | wc -l) files)"
cp -r "$PKG/files/." "$APP/"

echo "== 3/4 python check"
PY=python3; for c in "$APP/venv/bin/python" "$APP/.venv/bin/python"; do [ -x "$c" ] && PY="$c" && break; done
( cd "$APP" && "$PY" -m bluewall.names --export ) >/dev/null 2>&1 || true      # kingdom names from the bot's game section (read-only; harmless when not found)
( cd "$APP" && "$PY" -m py_compile bluewall/*.py ) || fail "python check failed"

echo "== 4/4 restart bluebot-wall"
systemctl restart bluebot-wall || fail "restart failed"
for i in $(seq 1 25); do curl -fs http://127.0.0.1:8590/healthz >/dev/null 2>&1 && break; sleep 1; done
curl -fs http://127.0.0.1:8590/healthz >/dev/null 2>&1 || { journalctl -u bluebot-wall -n 15 --no-pager || true; fail "bluebot-wall is down"; }
B=$(curl -fs "http://127.0.0.1:8590/healthz?deep=1" 2>/dev/null | "$PY" -c 'import sys,json;print(json.load(sys.stdin).get("build",""))' 2>/dev/null || true)
[ "$B" = "$NAME" ] || fail "the running server is '$B' (expected $NAME)"
S=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8590/api/state || true)
[ "$S" = 403 ] || fail "state API answered $S"
I=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8590/ || true)
[ "$I" = 200 ] || fail "game page answered $I"
trap - ERR
echo "✅ bluebot-wall up (build $B) — gems/mines API ok"
echo "Done ✅  حالا ربات رو باز کن ← بخش بازی ← 🏰 Blue Wall"
echo "Rollback: bash $PKG/rollback.sh"
