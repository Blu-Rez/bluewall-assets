LY1 frames (844x390, real Chromium + real local server, final bundle on kit 0e75919)
ly1_drag_green.png  - mid-drag, green spot, pill "Fits here - let go to place it"
ly1_drag_red.png    - mid-drag, red spot, pill "Too close to the moat . Another building is in the way"   (frame of the earlier identical run: complete world; the final run's red frame has the terrain on the left still streaming - kept beside it)
ly1_drag_red_final_run_world_still_loading.png - same scene in the last run (all checks passed; GL is software ~1 fps so terrain tiles were still revealing)
ly1_placed.png      - placed on lifting, Undo/Reset enabled
ly1_swap.png        - dropped on another building: "Let go to trade places with the merchant house"
ly1_reload.png      - after a page reload the moved house stands where it was left
*.log               - final test outputs (ly1_ui: 37 OK + LY1 UI OK; ly1_test: LY1 OK (35 checks); layout_server_test: LAYOUT SERVER OK; tr2_layout_test: TR2 LAYOUT OK)
