// hero view census: what the main pass and the shadow pass draw (replicates three's projectObject + frustum test), grouped by the scene's top-level child; compared with renderer.info of a real frame
const b = __bw, r = b.renderer, sc = b.scene, cam = b.camera, T = b.THREE;
window.__nd.on = true;
const sleep = (ms) => new Promise((x) => setTimeout(x, ms)); const poke = () => window.dispatchEvent(new Event('pointermove'));
const ip = setInterval(poke, 500);
await __rpLoad('?v=' + Date.now()); await __rp.start('elina'); await sleep(2500);
const res = { views: [] };
const tri = (o) => { const g = o.geometry; if (!g) return 0; let n = g.index ? g.index.count : (g.attributes.position ? g.attributes.position.count : 0); n = Math.max(0, Math.min(n, g.drawRange.count === Infinity ? n : g.drawRange.count)); const inst = o.isInstancedMesh ? o.count : (g.isInstancedBufferGeometry ? g.instanceCount : 1); return (o.isPoints || o.isLine) ? 0 : (n / 3) * inst; };
const top = (o) => { let a = o; while (a.parent && a.parent !== sc) a = a.parent; return (a.name || a.type) + (a.isGroup ? '' : ''); };
const census = (camera, layersCam, shadowOnly) => {
  const fr = new T.Frustum(); fr.setFromProjectionMatrix(new T.Matrix4().multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse));
  const by = new Map(), items = []; let calls = 0, tris = 0;
  const walk = (o) => {
    if (!o.visible) return;
    if (o.layers.test(layersCam.layers) && (o.isMesh || o.isLine || o.isPoints || o.isSprite)) {
      if (!(shadowOnly && !o.castShadow)) {
        let ok = true; if (o.frustumCulled) { try { ok = o.isSprite ? fr.intersectsSprite(o) : fr.intersectsObject(o); } catch (e) { ok = true; } }
        if (ok) { const t = tri(o), n = Array.isArray(o.material) ? Math.max(1, (o.geometry.groups || []).length) : 1; calls += n; tris += t; const k = top(o); const e = by.get(k) || { calls: 0, tris: 0, n: 0 }; e.calls += n; e.tris += t; e.n++; by.set(k, e); items.push([o.name || o.type, o.isInstancedMesh ? 'I' : (o.isSkinnedMesh ? 'S' : ''), Math.round(t), k]); }
      }
    }
    for (const c of o.children) walk(c);
  };
  walk(sc);
  items.sort((a, b) => b[2] - a[2]);
  return { calls, tris: Math.round(tris), groups: [...by.entries()].sort((a, b) => b[1].tris - a[1].tris).slice(0, 22).map(([k, e]) => k + ' calls ' + e.calls + ' tris ' + Math.round(e.tris / 1000) + 'k n' + e.n), topItems: items.slice(0, 14).map((x) => x.join(' ')) };
};
const sun = (() => { let l = null; sc.traverse((o) => { if (o.isDirectionalLight && o.castShadow) l = o; }); return l; })();
const yaws = [0, 1.57, 3.14, 4.71];
for (const yaw of yaws) {
  __rp.setPos(40.95, -2.17, 0); __rp.setLook(yaw, 0.25); await sleep(1800);
  cam.updateMatrixWorld(); cam.updateProjectionMatrix();
  const main = census(cam, cam, false);
  let sh = null; if (sun && sun.shadow && sun.shadow.camera) { sun.shadow.camera.updateMatrixWorld(); sh = census(sun.shadow.camera, cam, true); }
  r.info.autoReset = true; r.info.reset(); r.shadowMap.needsUpdate = true; r.render(sc, cam);
  res.views.push({ yaw, main, shadow: sh && { calls: sh.calls, tris: sh.tris, groups: sh.groups.slice(0, 8) }, info: { calls: r.info.render.calls, tris: r.info.render.triangles } });
}
clearInterval(ip);
return res;
