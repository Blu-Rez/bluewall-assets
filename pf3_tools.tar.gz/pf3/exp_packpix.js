// pixel proof: the packed tufts draw exactly what the full slot list drew (same page, same time, game paused, only window.__gnPack toggled)
const b = __bw, r = b.renderer, sc = b.scene, cam = b.camera, gl = r.getContext(), G = b.world.ground;
const sleep = (ms) => new Promise((x) => setTimeout(x, ms)); const poke = () => window.dispatchEvent(new Event('pointermove')); const ip = setInterval(poke, 500);
await __rpLoad('?v=' + Date.now()); await __rp.start('elina'); await sleep(2500);
window.__nd.on = false;
const W = r.domElement.width, H = r.domElement.height; const px = new Uint8Array(W * H * 4);
const out = { W, H, views: [] };
for (const [name, x, z, yaw] of [['gate', 40.95, 0, 0], ['town', 80, 60, 3.14], ['field', -60, 40, 4.71]]) {
  __rp.setPos(x, -2.17, z); __rp.setLook(yaw, 0.25); await sleep(2000);
  b.pause(true); await sleep(400);
  let tm = null; sc.traverse((o) => { if (o.name === 'gr1-tuft') tm = o; });
  const shot = (pack) => { window.__gnPack = pack; G.styleTufts(); G.update(cam, 0, b.t); r.info.autoReset = false; r.info.reset(); r.setRenderTarget(null); r.render(sc, cam); const info = { calls: r.info.render.calls, tris: r.info.render.triangles, n: tm.count }; gl.readPixels(0, 0, W, H, gl.RGBA, gl.UNSIGNED_BYTE, px); return { px: px.slice(), info }; };
  const a = shot(true), c = shot(false), a2 = shot(true);
  let diff = 0, diff0 = 0, maxd = 0; for (let i = 0; i < a.px.length; i += 4) { const d = Math.abs(a.px[i] - c.px[i]) + Math.abs(a.px[i + 1] - c.px[i + 1]) + Math.abs(a.px[i + 2] - c.px[i + 2]); if (d > 0) diff++; if (d > maxd) maxd = d; const e = Math.abs(a.px[i] - a2.px[i]) + Math.abs(a.px[i + 1] - a2.px[i + 1]) + Math.abs(a.px[i + 2] - a2.px[i + 2]); if (e > 0) diff0++; }
  out.views.push({ name, packed: a.info, full: c.info, packedVsFull_diffPx: diff, maxChannelSumDiff: maxd, selfDiff_diffPx: diff0 });
  b.pause(false);
}
window.__gnPack = true; clearInterval(ip);
return out;
