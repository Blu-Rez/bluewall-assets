const b = __bw, r = b.renderer, sc = b.scene, sw = b.sw;
const chain = (o) => { const c = []; for (let a = o; a && c.length < 5; a = a.parent) c.push((a.name || a.type).slice(0, 18) + (a.visible ? '' : '(h)')); return c.join('<'); };
const rows = [];
sc.traverse((o) => { if (o.isMesh && o.castShadow && /tripo_node_9723|tripo_node_e468|tripo_node_9306|Wolf_1/.test(o.name)) rows.push({ n: o.name.slice(0, 24), sig: sw.shadowSig(o), seen: sw.shadowSeen.has(sw.shadowSig(o)), chain: chain(o), side: o.material.side, vc: o.material.vertexColors }); });
const sigs = new Map(); sc.traverse((o) => { if (o.isMesh && o.castShadow) { const k = sw.shadowSig(o); if (!sigs.has(k)) sigs.set(k, []); sigs.get(k).push(o); } });
const same = rows.map((x) => ({ n: x.n, sig: x.sig, others: (sigs.get(x.sig) || []).slice(0, 5).map((o) => o.name.slice(0, 20) + ' ' + chain(o)) }));
return { rows, same };
