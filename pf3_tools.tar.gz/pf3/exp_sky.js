// who renders the sky with no lights / no fog at night, and when
const b = __bw, r = b.renderer, sc = b.scene, cam = b.camera;
const calls = []; const rr = r.render.bind(r);
const progs = () => r.info.programs.length;
r.render = function (s, c) { const n0 = progs(); const rt = r.getRenderTarget(); const out = rr(s, c); const d = progs() - n0; if (d) calls.push({ n: d, scene: s.type + (s === sc ? '(main)' : '(' + (s.name || '?') + ')'), layers: c.layers.mask, isMain: c === cam, rt: !!rt, rtw: rt && rt.width, fog: !!s.fog, bg: !!s.background }); return out; };
// move the clock to night and let it run
window.__bw.ctl && 0;
const url = new URLSearchParams(location.search); 
const sleep = (ms) => new Promise((x) => setTimeout(x, ms));
const before = progs();
if (b.world && b.world.setHour) b.world.setHour(23); else if (window.__bwHour) window.__bwHour(23);
await sleep(8000);
r.render = rr;
return { before, after: progs(), calls, hasSetHour: !!(b.world && b.world.setHour) };
