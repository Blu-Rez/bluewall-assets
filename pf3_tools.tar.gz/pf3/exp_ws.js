const b = __bw, r = b.renderer, sw = b.sw;
window.__nd.on = true;
const progs = () => r.info.programs.length;
const out = {};
sw.forgetShadow();
const n0 = progs(), ev0 = window.__t3.length;
try { out.made = await sw.warmShadow({ k0: 24, target: 400, rt: () => (b.useComposer() && b.composer() ? b.composer().readBuffer : null) }); } catch (e) { out.err = String(e && e.stack || e).slice(0, 800); }
out.new = progs() - n0;
out.ev = window.__t3.slice(ev0).map((e) => e.who.slice(0, 70));
// now the full real shadow pass on all casters: anything new?
const sc = b.scene; const saved = []; sc.traverse((o) => { if (o.isMesh && o.castShadow) saved.push([o, o.frustumCulled]); });
const hid = []; for (const [o] of saved) { o.frustumCulled = false; for (let a = o; a; a = a.parent) if (!a.visible && !hid.includes(a)) hid.push(a); }
for (const a of hid) a.visible = true;
const n1 = progs(), ev1 = window.__t3.length; r.shadowMap.needsUpdate = true; r.render(sc, b.camera);
out.realNew = progs() - n1; out.realEv = window.__t3.slice(ev1).map((e) => e.who.slice(0, 80));
for (const a of hid) a.visible = false; for (const [o, f] of saved) o.frustumCulled = f;
return out;
