const b = __bw, sc = b.scene, cam = b.camera;
const sleep = (ms) => new Promise((x) => setTimeout(x, ms)); const poke = () => window.dispatchEvent(new Event('pointermove')); const ip = setInterval(poke, 500);
await __rpLoad('?v=' + Date.now()); await __rp.start('elina'); await sleep(2000);
let terr = null; sc.traverse((o) => { if (o.name === 'terrain') terr = o; });
const g = terr.geometry, P = g.attributes.position, I = g.index;
const out = { fog: sc.fog && { type: sc.fog.constructor.name, density: sc.fog.density, near: sc.fog.near, far: sc.fog.far }, tris: I.count / 3, verts: P.count, far: cam.far, drawRange: [g.drawRange.start, g.drawRange.count] };
// grid size
const n = Math.round(Math.sqrt(P.count)); out.n = n;
const zs = []; for (let j = 0; j < n; j++) zs.push(+P.getZ(j * n).toFixed(1)); out.zs = [zs[0], zs[1], zs[2], zs[(n / 2) | 0], zs[n - 3], zs[n - 2], zs[n - 1]];
const xs = []; for (let i = 0; i < n; i++) xs.push(+P.getX(i).toFixed(1)); out.xs = [xs[0], xs[1], xs[2], xs[(n / 2) | 0], xs[n - 2], xs[n - 1]];
// index layout: is triangle t in row-major order? check first triangles' vertex rows
const rowOf = (v) => (v / n) | 0; out.rows = [0, 6, 600, 6000, 100000, I.count - 3].map((k) => [k, rowOf(I.getX(k)), rowOf(I.getX(k + 1)), rowOf(I.getX(k + 2))]);
// hero position
out.hero = { x: __rp.S ? __rp.S.x : null, z: __rp.S ? __rp.S.z : null, cam: [cam.position.x, cam.position.y, cam.position.z] };
// fraction of tris within distance R of cam in xz
const cx = cam.position.x, cz = cam.position.z; const cnt = {}; for (const R of [150, 250, 400, 500, 650, 800]) cnt[R] = 0;
for (let t = 0; t < I.count; t += 3) { const a = I.getX(t); const x = P.getX(a), z = P.getZ(a); const d = Math.hypot(x - cx, z - cz); for (const R of [150, 250, 400, 500, 650, 800]) if (d < R) cnt[R]++; }
out.within = cnt;
clearInterval(ip);
return out;
