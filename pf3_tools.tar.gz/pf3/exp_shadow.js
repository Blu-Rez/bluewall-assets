// prototype of sw.warmShadow(): a shadow-pass REHEARSAL of one representative per caster variant, on a private layer (31), 1 px scissor — then the real shadow pass over every caster must create nothing
const b = __bw, r = b.renderer, sc = b.scene, cam = b.camera, T = b.THREE;
const progs = () => r.info.programs.length;
window.__nd.on = true;
const out = { p0: progs() };
const chainVisible = (o) => { for (let a = o; a; a = a.parent) if (!a.visible) return false; return true; };
const keyOf = (o) => { const m = Array.isArray(o.material) ? o.material[0] : o.material; return [o.isSkinnedMesh ? 's' : '', o.isInstancedMesh ? 'i' : '', o.instanceColor ? 'c' : '', (o.morphTargetInfluences && o.morphTargetInfluences.length) ? 'm' : '', o.receiveShadow ? 'r' : '', m ? m.side : '', m && m.alphaTest > 0 ? 'a' + (m.map ? 'M' : '') + (m.alphaMap ? 'A' : '') : '', m && m.displacementMap ? 'd' : '', o.customDepthMaterial ? 'U' + o.customDepthMaterial.id : ''].join(''); };
const t0 = performance.now();
// representatives
const reps = new Map(); let casters = 0;
sc.traverse((o) => { if (o.isMesh && o.castShadow) { casters++; const k = keyOf(o); if (!reps.has(k)) reps.set(k, o); } });
// lights that the real camera counts (decided BEFORE anything is made visible)
const lights = []; sc.traverse((l) => { if (l.isLight && chainVisible(l) && l.layers.test(cam.layers)) lights.push(l); });
const saved = [];
const c31 = cam.clone(); c31.layers.set(31); c31.updateMatrixWorld(true);
const sci = { t: r.getScissorTest(), s: r.getScissor(new T.Vector4()), v: r.getViewport(new T.Vector4()) };
const n0 = progs(), ev0 = window.__t3.length;
try {
  for (const l of lights) { saved.push([l, l.layers.mask]); l.layers.enable(31); }
  const vis = [];
  for (const o of reps.values()) { saved.push([o, o.layers.mask]); o.layers.enable(31); vis.push([o, o.frustumCulled]); o.frustumCulled = false; for (let a = o.parent; a; a = a.parent) if (!a.visible) { vis.push([a, null, true]); } o.visible; }
  const hid = []; for (const o of reps.values()) for (let a = o; a; a = a.parent) if (!a.visible && !hid.includes(a)) hid.push(a);
  for (const a of hid) a.visible = true;
  const off = []; sc.traverse((l) => { if (l.isLight && !lights.includes(l) && l.visible) { l.visible = false; off.push(l); } }); window.__off = off;
  r.setScissorTest(true); r.setScissor(0, 0, 1, 1);
  // (the casters outside the reps must not draw: only layer 31 casters are walked by the shadow pass because the camera's layers are 31)
  r.shadowMap.needsUpdate = true; r.render(sc, c31);
  for (const a of hid) a.visible = false; for (const l of window.__off) l.visible = true;
  for (const [o, fc] of vis) if (fc != null) o.frustumCulled = fc;
} finally { for (const [o, m] of saved) o.layers.mask = m; r.setScissorTest(sci.t); r.setScissor(sci.s.x, sci.s.y, sci.s.z, sci.s.w); r.shadowMap.needsUpdate = true; }
out.rehearsal = { reps: reps.size, casters, newPrograms: progs() - n0, ms: Math.round(performance.now() - t0), who: window.__t3.slice(ev0).map((e) => e.who.slice(0, 90)) };
// the real shadow pass over every caster (visible, culling off) must create nothing new
const saved2 = []; sc.traverse((o) => { if (o.isMesh && o.castShadow) { saved2.push([o, o.frustumCulled]); o.frustumCulled = false; } });
const hid2 = []; for (const [o] of saved2) for (let a = o; a; a = a.parent) if (!a.visible && !hid2.includes(a)) hid2.push(a);
for (const a of hid2) a.visible = true;
const off2 = []; sc.traverse((l) => { if (l.isLight && !lights.includes(l) && l.visible) { l.visible = false; off2.push(l); } });
const n1 = progs(), ev1 = window.__t3.length; r.shadowMap.needsUpdate = true; r.render(sc, cam);
out.realPassNew = progs() - n1; out.realWho = window.__t3.slice(ev1).map((e) => e.who.slice(0, 110));
for (const a of hid2) a.visible = false; for (const l of off2) l.visible = true; for (const [o, fc] of saved2) o.frustumCulled = fc;

const dk = r.info.programs.filter((p) => /^depth/.test(p.cacheKey) || p.name === 'depth').map((p) => p.cacheKey);
out.depthKeys = dk.length; out.lastDepth = dk.slice(-3);
// what is special about the wolf
let wolf = null; sc.traverse((o) => { if (!wolf && o.isSkinnedMesh && /Wolf/.test(o.name)) wolf = o; });
if (wolf) { const m = wolf.material; out.wolf = { mat: m.type, side: m.side, alphaTest: m.alphaTest, map: !!m.map, alphaMap: !!m.alphaMap, attrs: Object.keys(wolf.geometry.attributes), morph: wolf.morphTargetInfluences && wolf.morphTargetInfluences.length, rs: wolf.receiveShadow, cd: !!wolf.customDepthMaterial, shadowSide: m.shadowSide, bones: wolf.skeleton && wolf.skeleton.bones.length, vc: m.vertexColors }; }
let trip = null; sc.traverse((o) => { if (!trip && o.isSkinnedMesh && /tripo_node_e468/.test(o.name)) trip = o; });
if (trip) { const m = trip.material; out.trip = { mat: m.type, side: m.side, alphaTest: m.alphaTest, map: !!m.map, alphaMap: !!m.alphaMap, attrs: Object.keys(trip.geometry.attributes), morph: trip.morphTargetInfluences && trip.morphTargetInfluences.length, rs: trip.receiveShadow, bones: trip.skeleton && trip.skeleton.bones.length, vc: m.vertexColors }; }
return out;
