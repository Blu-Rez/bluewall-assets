const b = __bw, r = b.renderer, sc = b.scene, cam = b.camera, T = b.THREE;
window.__nd.on = true;
const sleep = (ms) => new Promise((x) => setTimeout(x, ms)); const poke = () => window.dispatchEvent(new Event('pointermove')); const ip = setInterval(poke, 500);
await __rpLoad('?v=' + Date.now()); await __rp.start('elina'); await sleep(2500);
const tri = (o) => { const g = o.geometry; if (!g) return 0; let n = g.index ? g.index.count : (g.attributes.position ? g.attributes.position.count : 0); n = Math.max(0, Math.min(n, g.drawRange.count === Infinity ? n : g.drawRange.count)); const inst = o.isInstancedMesh ? o.count : 1; return (o.isPoints || o.isLine) ? 0 : (n / 3) * inst; };
const chain = (o) => { const c = []; for (let a = o; a && a !== sc && c.length < 5; a = a.parent) c.push((a.name || a.type).slice(0, 16)); return c.join('<'); };
const out = {};
for (const yaw of [0, 1.57]) {
  __rp.setPos(40.95, -2.17, 0); __rp.setLook(yaw, 0.25); await sleep(1800);
  cam.updateMatrixWorld(); cam.updateProjectionMatrix();
  const fr = new T.Frustum(); fr.setFromProjectionMatrix(new T.Matrix4().multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
  const items = [];
  const walk = (o) => { if (!o.visible) return; if (o.layers.test(cam.layers) && (o.isMesh || o.isSprite || o.isPoints || o.isLine)) { let ok = true; if (o.frustumCulled) { try { ok = o.isSprite ? fr.intersectsSprite(o) : fr.intersectsObject(o); } catch (e) { ok = true; } } if (ok) items.push({ n: (o.name || o.type).slice(0, 24), I: o.isInstancedMesh ? o.count : 0, S: o.isSkinnedMesh ? 1 : 0, t: Math.round(tri(o)), chain: chain(o), mat: (Array.isArray(o.material) ? o.material[0] : o.material).type, cast: o.castShadow ? 1 : 0 }); } for (const c of o.children) walk(c); };
  walk(sc);
  items.sort((a, b) => b.t - a.t);
  const byChain = {}; for (const it of items) { const k = it.chain.split('<').slice(-2).join('<'); const e = byChain[k] || (byChain[k] = { calls: 0, t: 0 }); e.calls++; e.t += it.t; }
  out['yaw' + yaw] = { total: items.length, top: items.slice(0, 22), small: items.filter((x) => x.t < 1500).length, smallTris: items.filter((x) => x.t < 1500).reduce((s, x) => s + x.t, 0), by: Object.entries(byChain).sort((a, b) => b[1].t - a[1].t).slice(0, 14).map(([k, v]) => k + ' ' + v.calls + 'c ' + Math.round(v.t / 1000) + 'k') };
}
clearInterval(ip);
return out;
