// the owner's bench started AFTER the idle build is done (EAGER owner build): programs added by the bench itself + any draw-time creation
const b = __bw, r = b.renderer; const sleep = (ms) => new Promise((x) => setTimeout(x, ms));
const t0 = performance.now(); let last = r.info.programs.length, stable = 0, steps = [];
while (stable < 25 && performance.now() - t0 < 420000) { await sleep(1000); const n = r.info.programs.length; if (n === last) stable++; else { stable = 0; last = n; } }
const settled = r.info.programs.length, tSettle = Math.round((performance.now() - t0) / 1000), ev0 = window.__t3.length;
const res = await BW_bench.run({ secs: 4 });
const ev = window.__t3.slice(ev0), draws = ev.filter((e) => /renderBufferDirect/.test((e.st || []).join(' ')));
return { settledAt: settled, secondsToSettle: tSettle, afterBench: r.info.programs.length, addedByBench: r.info.programs.length - settled, drawTime: draws.length, who: ev.map((e) => (e.who || '').slice(0, 80)).slice(0, 12), phases: Object.fromEntries(Object.entries(res.ph || {}).map(([k, v]) => [k, (v || {}).prog])) };
