#!/usr/bin/env python3
# pf3/trace.py <tag> — PF3: WHO adds every shader program AFTER the start, in the owner's own sequence (window.BW_bench.run: map day -> map night (builds the night path) -> hero night -> hero day).
# Hooks renderer.info.programs.push (WebGLPrograms.acquireProgram: the one place a program is created, whoever asks: renderer.compile, a draw, a shadow pass) and records for each new program:
#   time, game hour, night, path (screen / render target), hero active, light counts, the JS stack (function names), material / object names, the decoded cache key (numPointLights, toneMapping ...).
# Software GL, draw calls swallowed (CPU side only): program COUNTS and their causes are real, milliseconds are not the phone's.   Page: dev/pf2_<tag>.html (bash dev/pf2_rig_build.sh <tag>).
# env: PF3_SECS (bench seconds per phase, default 4) · PF3_PAGE (page file) · PF3_QS (extra query string) · PF3_NOBENCH=1 (no bench: only boot + idle) · PF3_OUT (json path)
import asyncio, json, os, sys, time, subprocess, socket
from playwright.async_api import async_playwright
D = '/home/claude/dev/'; TAG = sys.argv[1] if len(sys.argv) > 1 else 'before'; PORT = int(os.environ.get('PF3_PORT', 8796)); SECS = float(os.environ.get('PF3_SECS', 4))
PAGE = os.environ.get('PF3_PAGE') or ('pf2_%s.html' % TAG); QS = os.environ.get('PF3_QS', ''); OUT = os.environ.get('PF3_OUT') or ('/home/claude/work/pf3/trace_%s.json' % TAG)
os.makedirs(os.path.dirname(OUT), exist_ok=True)
ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-precise-memory-info']
INIT = open(D + 'pf2/page.py').read().split('INIT = "')[1].split('"\n')[0].replace('\\"', '"')
HOOK = """(()=>{ Error.stackTraceLimit = 40; const b = window.__bw, r = b.renderer, arr = r.info.programs, push = arr.push.bind(arr); window.__t3 = []; const T0 = performance.now();
  const lights = () => { let all = 0, vis = 0; b.scene.traverse((o) => { if (o.isPointLight) { all++; let v = true; for (let a = o; a; a = a.parent) if (!a.visible) { v = false; break; } if (v) vis++; } }); return [all, vis]; };
  arr.push = function (p) { const n = push(p); try {
    const st = (new Error().stack || '').split('\\n').slice(2, 12).map((l) => { const m = /at (?:async )?([^ (]+)/.exec(l); return m ? m[1] : l.trim().slice(0, 30); });
    let P = null; try { P = b.P(); } catch (e) {}
    const L = lights(); const rt = r.getRenderTarget();
    window.__t3.push({ i: n - 1, t: Math.round(performance.now() - T0), name: p.name, key: p.cacheKey, hour: P ? +(+P.hour).toFixed(2) : null, night: P ? +(+P.night).toFixed(2) : null, rt: rt ? 1 : 0,
      hero: (window.__heroOn ? 1 : 0), la: L[0], lv: L[1], seen: (() => { try { return window.__inDraw && window.__cur && b.sw.shadowSeen ? b.sw.shadowSeen(window.__cur.obj) : null; } catch (e) { return null; } })(), dk: (() => { try { if (!(window.__inDraw && /depth/.test(p.cacheKey.slice(0, 6)))) return null; const mk = (c) => c.split(',').slice(-3, -2)[0]; return r.info.programs.filter((q) => /^depth,/.test(q.cacheKey) && p !== q && mk(q.cacheKey) === mk(p.cacheKey)).map((q) => q.cacheKey); } catch (e) { return String(e); } })(), up: (() => { try { const o = window.__cur && window.__cur.obj; if (!o) return null; const c = []; for (let a = o; a; a = a.parent) c.push(a.visible ? 1 : 0); return c.join(''); } catch (e) { return null; } })(), st, rs: (window.__rs || []).join(' > '),
      who: (() => { const nm = (a) => { const c = []; for (let x = a; x && c.length < 4; x = x.parent) c.push(x.name || x.type); return c.join('<'); };
        if (window.__cur && window.__inDraw) { const c = window.__cur; return 'draw|' + (c.mat && (c.mat.type + ':' + (c.mat.name || ''))) + '|' + (c.obj && (c.obj.type + (c.obj.isSkinnedMesh ? '(S)' : '') + (c.obj.isInstancedMesh ? '(I)' : '') + ':' + nm(c.obj) + '|geo=' + (c.obj.geometry && c.obj.geometry.type) + '|tr=' + (c.mat && c.mat.transparent ? 1 : 0) + '|bl=' + (c.mat && c.mat.blending) + '|ud=' + JSON.stringify(c.obj.userData || {}).slice(0, 60))); }
        const o = window.__cmp; return o ? 'compile|' + (o.material && (Array.isArray(o.material) ? o.material[0] : o.material).type) + '|' + o.type + (o.isSkinnedMesh ? '(S)' : '') + (o.isInstancedMesh ? '(I)' : '') + ':' + nm(o) : 'other'; })() });
  } catch (e) { window.__t3.push({ err: String(e) }); } return n; };
  const rbd = r.renderBufferDirect.bind(r); window.__cur = null;
  r.renderBufferDirect = function (cam, scene, geo, mat, obj, grp) { window.__cur = { mat, obj }; window.__inDraw = true; try { return rbd(cam, scene, geo, mat, obj, grp); } finally { window.__inDraw = false; } };
  window.__rs = []; const rnd = r.render.bind(r); r.render = function (s, c) { window.__rs.push((s === b.scene ? 'main' : (s.name || s.type)) + '/' + (c === b.camera ? 'cam' : 'L' + c.layers.mask) + (r.getRenderTarget() ? '/rt' : '/scr')); try { return rnd(s, c); } finally { window.__rs.pop(); } };
  const cmp = r.compile.bind(r); r.compile = function (o, cam, sc) { window.__cmp = o; try { return cmp(o, cam, sc); } finally { window.__cmp = null; } };
  Object.defineProperty(window, '__heroOn', { get() { try { return !!(window.__rp && window.__rp.S && window.__rp.S.hero); } catch (e) { return false; } }, configurable: true });
  window.__t3.t0 = T0; })()"""
def up():
    s = socket.socket(); s.settimeout(0.5)
    try: s.connect(('127.0.0.1', PORT)); return True
    except Exception: return False
    finally: s.close()
def log(*a): print(time.strftime('%H:%M:%S'), *a, flush=True)
async def main():
    R = {'tag': TAG, 'errors': []}; srv = None
    if not up():
        srv = subprocess.Popen(['python3', '-m', 'http.server', str(PORT), '--bind', '127.0.0.1'], cwd=D, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(1.5)
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(args=ARGS)
            ctx = await b.new_context(viewport={'width': 844, 'height': 390}, device_scale_factor=1, is_mobile=True, has_touch=True)
            await ctx.add_init_script(INIT); pg = await ctx.new_page(); pg.on('pageerror', lambda e: R['errors'].append(str(e)[:200]))
            t0 = time.time()
            await pg.goto('http://127.0.0.1:%d/%s?pf=1&q=high&w=clear&h=%s&wa=0.1%s' % (PORT, PAGE, os.environ.get('PF3_H', '14'), QS))
            for i in range(3000):
                await asyncio.sleep(0.4)
                st = await pg.evaluate('({b: !!window.__bw})')
                if st['b']: break
            await pg.evaluate(HOOK)
            for i in range(3000):
                await asyncio.sleep(0.4)
                st = await pg.evaluate('({ready: !!window.__ready, late: !!(window.__bw && __bw.lateReady)})')
                if st['ready'] and st['late']: break
            R['boot_s'] = round(time.time() - t0, 1)
            R['boot_progs'] = await pg.evaluate('__bw.renderer.info.programs.length'); R['boot_events'] = await pg.evaluate('window.__t3.length')
            log('boot ready: programs', R['boot_progs'], 'events', R['boot_events'])
            await pg.evaluate('__bw.ctl._skipIntro && __bw.ctl._skipIntro()'); await asyncio.sleep(2)
            R['mark_after_boot'] = await pg.evaluate('window.__t3.length'); R['progs_at_bench_start'] = await pg.evaluate('__bw.renderer.info.programs.length')
            log('at bench start: programs', R['progs_at_bench_start'])
            if os.environ.get('PF3_NOBENCH'):
                for _ in range(40): await pg.evaluate("window.dispatchEvent(new Event('pointermove'))"); await asyncio.sleep(0.5)
            else:
                R['bench'] = await pg.evaluate('BW_bench.run({secs:%s})' % SECS)
                R['card'] = await pg.evaluate("[...document.querySelectorAll('div')].filter(d=>/^BENCH/.test(d.textContent||'')&&d.children.length==0).map(d=>d.textContent)")
            R['progs_end'] = await pg.evaluate('__bw.renderer.info.programs.length')
            R['t3'] = await pg.evaluate('window.__t3.slice()')
            log('end: programs', R['progs_end'], 'events after boot', len(R['t3']) - R['boot_events'])
            json.dump(R, open(OUT, 'w'))
            await b.close()
    finally:
        if srv: srv.terminate()
asyncio.run(main())
