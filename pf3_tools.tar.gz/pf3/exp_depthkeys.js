const r = __bw.renderer;
const deco = (m) => { const o = []; for (let i = 0; i < 25; i++) if (m & (1 << i)) o.push(i); return o; };
const rows = r.info.programs.filter((p) => /^depth|MeshDepth/.test(p.name) || /^depth,/.test(p.cacheKey)).map((p) => { const t = p.cacheKey.split(','); const n = t.length; return { name: p.name, i: p.id, mapUv: t[t.findIndex((x) => x === 'highp') + 3], m2: deco(+t[n - 4]), m3: deco(+t[n - 3]), pack: t[n - 5], tail: t.slice(-3).join('|').slice(0, 60) }; });
return { n: rows.length, rows };
