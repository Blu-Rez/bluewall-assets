const b = __bw, sc = b.scene;
const sleep = (ms) => new Promise((x) => setTimeout(x, ms)); const poke = () => window.dispatchEvent(new Event('pointermove')); const ip = setInterval(poke, 500);
await __rpLoad('?v=' + Date.now()); await __rp.start('elina'); await sleep(2500);
const out = {};
for (const [name, x, z] of [['gate', 40.95, 0], ['town', 80, 60], ['field', -60, 40]]) {
  __rp.setPos(x, -2.17, z); await sleep(1500);
  let tm = null; sc.traverse((o) => { if (o.name === 'gr1-tuft') tm = o; });
  if (!tm) { out[name] = 'none'; continue; }
  const M = tm.instanceMatrix.array, n = tm.count; let valid = 0, tiny = 0;
  for (let i = 0; i < n; i++) { const j = i * 16, s = Math.abs(M[j]) + Math.abs(M[j + 2]) + Math.abs(M[j + 5]); if (s > 1e-4) valid++; else tiny++; }
  out[name] = { n, valid, pct: +(100 * valid / n).toFixed(1), vis: tm.visible };
}
clearInterval(ip);
return out;
