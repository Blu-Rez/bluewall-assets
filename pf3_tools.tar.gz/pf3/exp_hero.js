// hero walk: start the hero (day), walk, switch to night, walk, back to day, exit; programs created are recorded by the hook (window.__t3)
const b = __bw, r = b.renderer; window.__nd.on = true;
const sleep = (ms) => new Promise((x) => setTimeout(x, ms));
const poke = () => window.dispatchEvent(new Event('pointermove'));
const n0 = window.__t3.length, out = { steps: [] };
const mark = (name) => { out.steps.push({ name, progs: r.info.programs.length, ev: window.__t3.length - n0, hero: window.__heroOn, t: Math.round(performance.now() - window.__t3.t0) }); };
mark('start');
await __rpLoad('?v=' + Date.now()); mark('loaded');
const ip = setInterval(poke, 600);
await __rp.start('elina'); mark('started'); await sleep(3000); mark('+3s');
__rp.setPos(40.95, -2.17, 0); await sleep(1500); mark('at gate');
let yaw = 0; const walk = async (sec) => { const t0 = performance.now(); while (performance.now() - t0 < sec * 1000) { yaw += 0.04; __rp.setLook(yaw, 0.25); __rp.setInput(0, 0.8); __rp.sprint(((performance.now() - t0) / 1000 | 0) % 4 === 3); await sleep(50); } __rp.setInput(0, 0); };
await walk(10); mark('walk day');
__bw.ov = { night: 1 }; window.__bwPath = undefined; await sleep(3000); mark('night +3s'); await walk(10); mark('walk night');
__bw.ov = { night: 0 }; await sleep(3000); await walk(6); mark('day again');
clearInterval(ip);
out.created = window.__t3.slice(n0).filter((e) => !/^compile/.test(e.who || '')).map((e) => [e.t, e.rt, e.hero, (e.who || '').slice(0, 220), e.st.slice(0, 4).join('<')].join(' ; '));
return out;
