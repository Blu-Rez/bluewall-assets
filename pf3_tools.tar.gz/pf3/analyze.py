#!/usr/bin/env python3
# pf3/analyze.py <trace.json> [--all] — reads the output of pf3/trace.py: programs added after the boot, grouped by phase and by cause; the draw-time ones (= a compile inside a frame = a hitch) one by one.
import json, re, sys, collections
SRC = open('/home/claude/bot/bluebot_v2/bluewall/client/node_modules/three/src/renderers/webgl/WebGLPrograms.js').read()
blk = SRC[SRC.index('function getProgramCacheKeyParameters'):SRC.index('function getProgramCacheKeyBooleans')]
FIELDS = re.findall(r'array\.push\( parameters\.(\w+) \)', blk)
def decode(key):
    t = key.split(',')
    try: i = next(j for j, x in enumerate(t) if x in ('highp', 'mediump', 'lowp') and j >= 1)
    except StopIteration: return {}
    return {f: t[i + k] for k, f in enumerate(FIELDS) if i + k < len(t)}
R = json.load(open(sys.argv[1])); n0 = R['boot_events']; T = R['t3'][n0:]
print('boot programs', R['boot_progs'], '| at bench start', R['progs_at_bench_start'], '| end', R['progs_end'], '| added after boot', len(T))
if R.get('bench'): print('per phase programs:', {k: (v or {}).get('prog') for k, v in R['bench']['ph'].items()}, 'night path:', R['bench'].get('night'))
def kind(e): return 'DRAW' if re.search('renderBufferDirect', ' '.join(e['st'])) else 'compile'
c = collections.Counter();
for e in T:
    d = decode(e['key']); c[(kind(e), 'rt' if e['rt'] else 'screen', 'hero' if e['hero'] else '-', 'L%s' % d.get('numPointLights', '?'))] += 1
print('\nkind / path / hero / pointLights:'); [print('  %4d  %s' % (n, k)) for k, n in sorted(c.items(), key=lambda x: -x[1])]
print('\nDRAW-time creations (a synchronous compile inside a frame):')
for e in T:
    if kind(e) == 'DRAW':
        d = decode(e['key']); print('  t=%6d h=%s rt=%d hero=%d L=%s tm=%s sk=%s inst=%s shadowMap=%s | %s' % (e['t'], e['hour'], e['rt'], e['hero'], d.get('numPointLights'), d.get('toneMapping'), d.get('skinning'), d.get('instancing'), d.get('shadowMapEnabled'), e.get('who')))
if '--all' in sys.argv:
    print('\nall:')
    for e in T: print('  %6d %s rt=%d %s' % (e['t'], kind(e), e['rt'], e.get('who')))
w = collections.Counter(e.get('who', '').split('|')[0] + '|' + (e.get('who', '').split('|')[1] if '|' in e.get('who', '') else '') for e in T if kind(e) == 'compile')
print('\ncompile units by material type:'); [print('  %4d %s' % (n, k)) for k, n in w.most_common(12)]
