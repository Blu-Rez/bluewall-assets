// after the hero start: which skinned casters exist, are they covered by warmShadow, what creates the depth programs later
const b = __bw, r = b.renderer, sc = b.scene, cam = b.camera, sw = b.sw;
window.__nd.on = true;
const sleep = (ms) => new Promise((x) => setTimeout(x, ms)); const poke = () => window.dispatchEvent(new Event('pointermove'));
const ip = setInterval(poke, 500);
const out = { events: [] };
const progs = () => r.info.programs.length;
const n00 = progs(), ev00 = window.__t3.length;
const t0 = performance.now();
await __rpLoad('?v=' + Date.now()); await __rp.start('elina');
out.startMs = Math.round(performance.now() - t0); out.progsAtStart = progs() - n00;
const desc = (o) => { const m = Array.isArray(o.material) ? o.material[0] : o.material; const g = o.geometry; let vis = true; for (let a = o; a; a = a.parent) if (!a.visible) { vis = false; break; } return { n: (o.name || o.type).slice(0, 40), cast: o.castShadow, vis, fc: o.frustumCulled, layers: o.layers.mask, side: m && m.side, ss: m && m.shadowSide, map: !!(m && m.map), at: m && m.alphaTest, vc: m && m.vertexColors, attrs: Object.keys(g.attributes).join(','), cd: !!o.customDepthMaterial, rs: o.receiveShadow, parent: o.parent && (o.parent.name || o.parent.type), inScene: (() => { for (let a = o; a; a = a.parent) if (a === sc) return true; return false; })() }; };
const list = () => { const a = []; sc.traverse((o) => { if (o.isSkinnedMesh) a.push(desc(o)); }); return a; };
out.skinnedAtStart = list();
await sleep(2500);
out.skinnedLater = list();
out.evAfterStart = window.__t3.slice(ev00).map((e) => ({ t: e.t, rt: e.rt, who: e.who.slice(0, 80), draw: /renderBufferDirect/.test(e.st.join(' ')) }));
// warmShadow now: does it make anything? then a real full shadow pass
const n1 = progs(); const made = await sw.warmShadow({ k0: 24, target: 400 }); out.warmShadowMade = made; out.warmShadowNew = progs() - n1;
clearInterval(ip);
return out;
