// experiment: can the depth (shadow) programs be made by renderer.compile with a swapped-in MeshDepthMaterial — same cache keys as the real shadow pass?
const b = __bw, r = b.renderer, sc = b.scene, cam = b.camera, T = b.THREE;
const progs = () => r.info.programs.length;
const out = { p0: progs() };
// 1) the casters, grouped by the features that decide a depth program
const keyOf = (o) => [o.isSkinnedMesh ? 's' : '', o.isInstancedMesh ? 'i' : '', o.instanceColor ? 'c' : '', (o.morphTargetInfluences && o.morphTargetInfluences.length) ? 'm' : '', o.receiveShadow ? 'r' : '',
  o.material && (Array.isArray(o.material) ? o.material[0] : o.material).side, (() => { const m = Array.isArray(o.material) ? o.material[0] : o.material; return m && (m.alphaTest > 0 ? 'a' + (m.map ? 'M' : '') + (m.alphaMap ? 'A' : '') : '') + (m.displacementMap ? 'd' : ''); })()].join('');
const reps = new Map(); let nCast = 0, nHidden = 0;
sc.traverse((o) => { if (o.isMesh && o.castShadow) { nCast++; let vis = true; for (let a = o; a; a = a.parent) if (!a.visible) { vis = false; break; } if (!vis) nHidden++; const k = keyOf(o); if (!reps.has(k)) reps.set(k, o); } });
out.casters = nCast; out.hiddenCasters = nHidden; out.variants = [...reps.keys()];
// 2) compile each representative with a depth material
const shadowSide = { 0: 1, 1: 0, 2: 2 };
const before = new Set(r.info.programs.map((p) => p.cacheKey));
const dm = new T.MeshDepthMaterial();
for (const [k, o] of reps) {
  const m0 = o.material, mm = Array.isArray(m0) ? m0[0] : m0;
  const d = dm.clone(); d.side = mm.shadowSide != null ? mm.shadowSide : shadowSide[mm.side]; d.alphaMap = mm.alphaMap; d.alphaTest = mm.alphaTest; d.map = mm.map; d.displacementMap = mm.displacementMap; d.displacementScale = mm.displacementScale; d.displacementBias = mm.displacementBias;
  o.material = d; try { r.compile(o, cam, sc); } finally { o.material = m0; }
}
out.afterCompile = progs() - out.p0;
const mid = new Set(r.info.programs.map((p) => p.cacheKey));
// 3) the real shadow pass over every caster (visible, culling off) must create nothing new
const saved = []; sc.traverse((o) => { if (o.isMesh && o.castShadow) { saved.push([o, o.visible, o.frustumCulled]); o.frustumCulled = false; } });
for (const [o] of saved) for (let a = o; a; a = a.parent) a.visible = true;
const n1 = progs(); window.__nd.on = true; r.shadowMap.needsUpdate = true; r.render(sc, cam);
out.realShadowPassNew = progs() - n1;
out.newKeys = r.info.programs.filter((p) => !mid.has(p.cacheKey)).map((p) => p.cacheKey.slice(0, 160));
out.log = window.__t3.slice(-6).map((e) => e.who);
return out;
