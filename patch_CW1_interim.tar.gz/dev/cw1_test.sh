#!/bin/bash
# CW1: the clan-war server proof (whole cycle, restarts, draws, leaving, matchmaker, redis path, HTTP routes).  -> "CW1 OK (N checks)"
cd "$(dirname "$0")/../bot/bluebot_v2" 2>/dev/null || cd /home/claude/bot/bluebot_v2
python3 "${CW1_TEST:-/home/claude/dev/cw1_test.py}" 2>&1 | grep -v "^Traceback\|^  File\|^    \|RuntimeError: crash\|^$" | tail -20
