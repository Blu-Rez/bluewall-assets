#!/usr/bin/env python3
"""CW1: UI fixtures made by the REAL server code (clanwar.py on an in-memory STORE, 10 v 10, advancing clock).   python3 dev/cw1_fixtures_gen.py  ->  dev/cw1_fixtures/*.json"""
import asyncio, json, os, sys, time
os.environ["BLUEWALL_STATE"] = "memory"
sys.path.insert(0, "/home/claude/dev/stubcfg"); sys.path.insert(0, "/home/claude/bot/bluebot_v2")
src = open("/home/claude/dev/cw1_test.py").read().split("async def main")[0]
exec(compile(src, "cw1_test_head", "exec"))                      # (the same harness: clock, liveops stub, world(), attack() ...)
from bluewall import layout as LY

OUT = "/home/claude/dev/cw1_fixtures"
NAMES = ["Ana", "Reza", "Mina", "Kaveh", "Dara", "Shirin", "Omid", "Leila", "Babak", "Nadia", "Farid", "Sara", "Arman", "Roya", "Kian", "Yasna", "Pouya", "Tara", "Nima", "Hana"]
T0 = 1_760_000_000.0


def dump(name, obj):
    with open("%s/%s.json" % (OUT, name), "w") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1, sort_keys=False)


async def named(st, A, B):
    for i, u in enumerate(A + B):
        async with st._lock(u):
            s = await st._txn(u); s["name"] = NAMES[i % len(NAMES)] + ("" if i < len(NAMES) else "2"); s["b"]["keep"] = 3 + (u * 5) % 6; await st.save(u, s)


async def scenario(base, extra=3):
    CLOCK[0] = T0
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, base, 10, 10, tro_a=[1400 - 55 * i for i in range(10 + extra)], tro_b=[1380 - 55 * i for i in range(10)], extra_a=extra)
    await named(st, A, B)
    G = LY.geom()
    for u in A[:10] + B:
        k = (u * 7) % 40
        async with st._lock(u):
            s = await st._txn(u)
            t = [x for x in G["things"] if x["kind"] == "cottage"][k % 6]
            s["layout"] = {"v": 1, "g": G["planId"], "m": {t["id"]: [round(t["x"] + 1.5, 2), round(t["z"] - 1.0, 2), t["ry"]]}}
            await st.save(u, s)
    return st, cw, cidA, A[:10], cidB, B, A


def ok_(v):
    return dict(v, ok=True)


async def main():
    # --- none / nolead / off / search
    st, cw, cidA, A, cidB, B, allA = await scenario(100)
    dump("none", ok_(await cw.view(A[0])))
    dump("nolead", ok_(await cw.view(A[1])))
    dump("noclan", ok_(await cw.view(99999)))
    dump("off", {"ok": True, "on": False})
    ok((await cw.search(A[0], 10, A))["ok"])
    adv(7 * 60)
    dump("search", ok_(await cw.view(A[0])))
    dump("search_member", ok_(await cw.view(A[1])))
    ok((await cw.cancel(A[0]))["ok"])
    dump("none_after_cancel", ok_(await cw.view(A[0])))
    # --- prep (+ a spectator outside the roster)
    await cw.search(A[0], 10, A); await cw.search(B[0], 10, B)
    adv(3 * 3600 + 120)
    dump("prep", ok_(await cw.view(A[2])))
    dump("prep_lead", ok_(await cw.view(A[0])))
    dump("prep_spectator", ok_(await cw.view(allA[11])))
    dump("base_prep", ok_(await cw.base(A[2], B[0])))
    dump("err_not_battle", await cw.scout(A[2], B[0]))
    # --- battle: a mixed bag of results
    adv(9 * 3600)
    await cw.tick()
    plan_a = [(0, 0, 3, 100.0), (1, 1, 2, 78.4), (2, 2, 1, 52.3), (3, 5, 2, 66.0), (5, 3, 1, 33.5), (7, 8, 3, 100.0)]
    plan_b = [(0, 0, 2, 66.5), (1, 1, 1, 41.0), (3, 3, 3, 100.0), (4, 2, 0, 12.0), (6, 9, 2, 71.2)]
    for i, j, s_, p_ in plan_a:
        adv(300); await attack(st, A[i], B[j], s_, p_)
    for i, j, s_, p_ in plan_b:
        adv(300); await attack(st, B[i], A[j], s_, p_)
    adv(900)
    dump("battle", ok_(await cw.view(A[2])))                       # (1 attack used, 1 left)
    dump("battle_fresh", ok_(await cw.view(A[9])))                 # (no attack yet)
    dump("battle_lead", ok_(await cw.view(A[0])))
    # a second attack, and an error of each kind
    adv(300)
    j, e, rep = await attack(st, A[2], B[5], 2, 61.0)
    dump("scout_ok", j); dump("end_ok", e)
    dump("err_maxed", await cw.scout(A[8], B[0]))
    adv(100)
    dump("err_no_attacks", await cw.scout(A[2], B[6]))
    adv(25)
    dump("err_not_foe", await cw.scout(A[8], A[0]))
    jp = await cw.scout(A[4], B[4]); ok(jp["ok"])
    dump("err_pending", await cw.scout(A[4], B[7]))
    dump("battle_pending", ok_(await cw.view(A[4])))
    dump("base_battle", ok_(await cw.base(A[4], B[4])))
    dump("battle_spectator", ok_(await cw.view(allA[10])))
    # finish the pending one, more attacks, then the clock ends it: A wins
    s = await st.load(A[4])
    await st.battle_end(A[4], jp["target"]["id"], {"sent": dict(MI.attack_army(s)), "lost": {}, "destruction": 47.0, "stars": 1, "loot": {}, "spells": {}})
    for i, j, s_, p_ in [(6, 6, 2, 75.0), (8, 7, 1, 44.0), (9, 9, 2, 70.5), (4, 2, 2, 60.0)]:
        adv(300); await attack(st, A[i], B[j], s_, p_)
    war = await cw._load(1)
    CLOCK[0] = war["te"] + 5
    await cw.tick()
    dump("ended_win", ok_(await cw.view(A[0])))
    dump("ended_win_member", ok_(await cw.view(A[7])))
    dump("ended_lose", ok_(await cw.view(B[0])))
    dump("ended_lose_noprize", ok_(await cw.view(B[8])))
    # --- a draw, a three-star sweep with an early end
    CLOCK[0] = T0
    st, cw, cidA, A, cidB, B, allA = await scenario(300, extra=0)
    await cw.search(A[0], 10, A); await cw.search(B[0], 10, B); adv(12 * 3600 + 5); await cw.tick()
    for i in range(3):
        adv(300); await attack(st, A[i], B[i], 2, 70.0)
    CLOCK[0] += 0
    for i in range(3):
        await attack(st, B[i], A[i], 2, 70.0)
    war = await cw._load(1)
    # same second for the last results: set both finish times equal by rewriting the stored times (the clock differs by a few seconds otherwise)
    for a in war["atk"]:
        a["t"] = 1760100000.0
    await cw._save(war)
    CLOCK[0] = war["te"] + 5
    await cw.tick()
    dump("ended_draw", ok_(await cw.view(A[0])))
    dump("ended_draw_noprize", ok_(await cw.view(A[7])))
    print("fixtures:", len(os.listdir(OUT)))

asyncio.run(main())
