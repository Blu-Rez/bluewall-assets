#!/usr/bin/env python3
"""CW1 clan war: the whole cycle on an in-memory STORE with a clock that is moved forward by the test.
   2 clans x 5 members: search -> match -> prepare (frozen snapshot) -> battle (reserve / report / reissue / lost) -> early end / time end -> prizes -> free again;
   a restart (a new ClanWar object over the same store) in the middle of EVERY phase, a crash while the prizes are being paid, a crash while a war is being made,
   draw / time / star tie-breaks, leaving the clan (forfeit / keep / remove), the matchmaker window, search timeout / cancel / roster change, flag off,
   the config validator, and the real HTTP routes (server.make_app) with the real /api/scout + /api/battle/end.        python3 dev/cw1_test.py   ->  CW1 OK
"""
import asyncio, json, os, sys, time
os.environ["BLUEWALL_STATE"] = "memory"
sys.path.insert(0, "/home/claude/dev/stubcfg"); sys.path.insert(0, "/home/claude/bot/bluebot_v2")
from bluewall import state as S, military as MI, progress as PR, clanwar as CW

CLOCK = [1_760_000_000.0]
time.time = lambda: CLOCK[0]                       # (every module reads time.time(): one clock for the server, the rules and the test)
CHECKS = [0]


def adv(sec):
    CLOCK[0] += sec


def ok(cond, msg=""):
    CHECKS[0] += 1
    if not cond:
        raise AssertionError(msg or "check failed")


class LO:                                          # the 3-line stub of the liveops contract (OC1 builds the real one)
    flags, sec, reg = {"clan_war": True}, {}, {}
    get = staticmethod(lambda s: dict(LO.sec.get(s, {})))
    flag = staticmethod(lambda n: LO.flags.get(n, False))
    register = staticmethod(lambda s, d, v: LO.reg.__setitem__(s, (d, v)))


def new_store(cfg=None):
    LO.flags["clan_war"] = True
    LO.sec["war"] = dict(cfg or {})
    st = S.Store()
    st.clanwar.set_liveops(LO)
    return st


def restart(st):
    """a server restart: all volatile objects (locks, caches, the clock task) are gone, the data stays"""
    st.clanwar = CW.ClanWar(st)
    st.clanwar.set_liveops(LO)
    return st.clanwar


async def setk(st, uid, **kw):
    async with st._lock(uid):
        s = await st._txn(uid)
        for k, v in kw.items():
            if k == "keep": s["b"]["keep"] = v
            else: s[k] = v
        await st.save(uid, s)
    if "tro" in kw:
        await st._lb_set(uid, await st.load(uid))


async def world(st, base, n_a, n_b, tro_a=None, tro_b=None, extra_a=0, extra_b=0):
    """two clans; clan A = uids base+1.., clan B = base+101..; the owner of each clan is the first member.  extra_* = members that are in the clan but not in the roster"""
    A = [base + 1 + i for i in range(n_a + extra_a)]
    B = [base + 101 + i for i in range(n_b + extra_b)]
    tro_a = tro_a or [900 - 40 * i for i in range(len(A))]
    tro_b = tro_b or [880 - 40 * i for i in range(len(B))]
    out = []
    for us, tros, nm, tag in ((A, tro_a, "Blue%d" % base, "BL"), (B, tro_b, "Iron%d" % base, "IR")):
        for u, t in zip(us, tros):
            await st.touch(u, "P%d" % u)
            await setk(st, u, keep=2, tro=t)
        r = await st.clans.create(us[0], nm, tag); ok(r["ok"], r)
        for u in us[1:]:
            ok((await st.clans.join(u, r["id"]))["ok"])
        out += [r["id"], us]
    return out[0], out[1], out[2], out[3]


async def attack(st, uid, base, stars=2, pct=75.0, tid_check=None):
    j = await st.clanwar.scout(uid, base)
    ok(j.get("ok"), j)
    s = await st.load(uid)
    rep = {"sent": dict(MI.attack_army(s)), "lost": {}, "destruction": pct, "stars": stars, "loot": {}, "spells": {}}
    e = await st.battle_end(uid, j["target"]["id"], rep)
    ok(e.get("ok"), e)
    return j, e, rep


def inbox_of(st, uid):
    return [json.loads(x) if isinstance(x, str) else x for x in st._inbox.get(uid, [])]


async def go_battle(st):
    adv(12 * 3600 + 5)
    await st.clanwar.tick()


# ------------------------------------------------------------------ 0. config
async def t_config():
    ok(CW.validate(CW.DEFAULTS) == [], CW.validate(CW.DEFAULTS))
    bad = json.loads(json.dumps(CW.DEFAULTS))
    bad["sizes"] = [5, 5]; bad["leave"] = "x"; bad["prizes"]["win"]["turq"] = 5001; bad["prizes"]["win"]["sap"] = 1001; bad["prizes"]["lose"]["gold"] = 1
    bad["attacks_each"] = 4; bad["early_end"] = "yes"; bad["match"]["max_gap_pct"] = 1
    errs = CW.validate(bad)
    ok(len(errs) >= 7, errs)
    ok(CW.validate({"sizes": "x"}) != [] and CW.validate([]) == ["war: not an object"])
    st = new_store(); st.clanwar.cfg(); ok("war" in LO.reg and LO.reg["war"][1] is CW.validate and LO.reg["war"][0] == CW.DEFAULTS, LO.reg.keys())
    ok(st.clanwar.cfg()["attacks_each"] == 2 and st.clanwar.cfg()["prep_hours"] == 12)
    LO.sec["war"] = {"attacks_each": 3, "prizes": {"win": {"turq": 5}}}
    c = st.clanwar.cfg(); ok(c["attacks_each"] == 3 and c["prizes"]["win"] == {"turq": 5} and c["prizes"]["lose"] == {"turq": 500}, c)   # (a section is merged over the defaults)


# ------------------------------------------------------------------ pure rules
async def t_rules():
    sc = lambda a, b: [{"st": a[0], "pc": a[1], "t": a[2]}, {"st": b[0], "pc": b[1], "t": b[2]}]
    ok(CW.decide(sc((5, 100, 9), (4, 999, 1))) == (0, "stars"))
    ok(CW.decide(sc((4, 100.0, 9), (4, 100.5, 1))) == (1, "pct"))
    ok(CW.decide(sc((4, 100, 9), (4, 100, 1))) == (1, "time"))
    ok(CW.decide(sc((4, 100, 5), (4, 100, 5))) == (None, "draw"))
    ok(CW.decide(sc((0, 0, 0), (0, 0, 0))) == (None, "draw"))
    war = {"atk": [{"id": "a", "by": 1, "base": 9, "side": 0, "t": 10, "st": 1, "pc": 60}, {"id": "b", "by": 2, "base": 9, "side": 0, "t": 20, "st": 2, "pc": 70},
                   {"id": "c", "by": 3, "base": 9, "side": 0, "t": 30, "st": 2, "pc": 70}, {"id": "d", "by": 4, "base": 8, "side": 1, "t": 5, "st": 0, "pc": 10, "lost": True},
                   {"id": "e", "by": 4, "base": 7, "side": 1, "t": 6, "st": 3, "pc": 100}]}
    s, best = CW.score(war)
    ok(best[9]["id"] == "b", best)                                              # (stars, then %, then the EARLIER one)
    ok(s[0] == {"st": 2, "pc": 70.0, "t": 20.0} and s[1] == {"st": 3, "pc": 100.0, "t": 6.0}, s)
    s2, _ = CW.score(war, {2})                                                  # (attacker 2 removed: the next best result of base 9 counts)
    ok(s2[0]["st"] == 2 and s2[0]["t"] == 30.0, s2)
    s3, _ = CW.score(war, {9})
    ok(s3[0]["st"] == 0)


# ------------------------------------------------------------------ 1. the whole cycle
async def t_cycle():
    st = new_store(); cw = st.clanwar
    lay = {"v": 1, "g": "x", "m": {"cottage_00": [1.0, 2.0, 3.0]}}
    A_, B_ = 1000, 1000
    cidA, A, cidB, B = await world(st, 1000, 5, 5, extra_a=2)
    await setk(st, B[1], layout=lay)
    roster = A[:5]
    # --- rules of the search
    ok((await cw.search(A[1], 5, roster))["why"] == "not_leader")
    ok((await cw.search(A[0], 7, roster))["why"] == "size")
    ok((await cw.search(A[0], 5, roster[:4]))["why"] == "roster")
    ok((await cw.search(A[0], 5, roster[:4] + [B[0]]))["why"] == "roster")
    ok((await cw.search(A[0], 5, roster[:4] + [roster[0]]))["why"] == "roster")
    ok((await cw.search(9999, 5, roster))["why"] == "no_clan")
    LO.flags["clan_war"] = False
    ok((await cw.search(A[0], 5, roster))["why"] == "off" and await cw.view(A[0]) == {"on": False})
    LO.flags["clan_war"] = True
    v = await cw.view(A[0])
    ok(v["on"] and v["state"] == "none" and v["free"] and v["clan"]["lead"] and v["war"] is None and v["note"] is None, v)
    ok([c["id"] for c in v["cands"]] == A and v["cands"][0]["tro"] == 900, v["cands"])                      # (strongest first)
    ok((await cw.view(A[1]))["cands"] is None and not (await cw.view(A[1]))["clan"]["lead"])
    ok((await cw.view(555))["clan"] is None and (await cw.view(555))["state"] == "none")
    # --- queue and match
    ok((await cw.search(A[0], 5, roster))["ok"])
    v = await cw.view(A[1]); ok(v["state"] == "search" and v["search"]["size"] == 5 and v["search"]["until"] == v["search"]["t0"] + 1800 and not v["free"], v)
    ok((await cw.search(A[0], 5, roster))["why"] == "busy")
    ok((await cw.base(A[0], B[0]))["why"] == "no_war")
    ok((await cw.search(B[0], 5, B))["ok"])                                                                 # (an opponent was waiting: matched at once)
    va, vb = await cw.view(A[0]), await cw.view(B[0])
    ok(va["state"] == "prep" and vb["state"] == "prep" and va["war"]["id"] == vb["war"]["id"] == 1, (va["state"], vb["state"]))
    w = va["war"]
    ok(w["phase"] == "prep" and w["size"] == 5 and w["tb"] - w["t0"] == 12 * 3600 and w["te"] - w["tb"] == 24 * 3600, w)
    ok(w["me"]["in"] and w["me"]["rank"] == 1 and w["me"]["left"] == 2 and w["me"]["max"] == 2 and w["me"]["used"] == 0 and w["me"]["pending"] is None and not w["me"]["gone"])
    ok([r["id"] for r in w["us"]["roster"]] == A[:5] and [r["id"] for r in w["them"]["roster"]] == B[:5])
    ok(w["us"]["clan"]["tag"] == "BL" and w["them"]["clan"]["tag"] == "IR" and w["us"]["stars"] == 0 and w["us"]["max"] == 10)
    ok(w["log"] == [{"t": w["t0"], "k": "found"}], w["log"])
    ok(not (await cw.view(A[6]))["war"]["me"]["in"] and (await cw.view(A[6]))["state"] == "prep")          # (a clan member outside the roster watches)
    ok((await cw.cancel(A[0]))["why"] == "in_war" and (await cw.search(A[0], 5, roster))["why"] == "busy")
    r = await cw.search(A[1], 5, roster); ok(r["why"] == "not_leader")
    # --- the snapshot is FROZEN at the match
    b0 = (await cw.base(A[0], B[1]))["base"]
    ok(b0["n"] == "P%d" % B[1] and b0["layout"] == lay and b0["lv"]["keep"] == 2 and b0["power"] > 0 and "guard" in b0, b0)
    ok((await cw.base(A[0], A[1]))["why"] == "not_foe" and (await cw.base(A[0], 4242))["why"] == "not_foe")
    ok((await cw.base(A[6], B[0]))["ok"] and (await cw.base(555, B[0]))["why"] == "no_war")
    await setk(st, B[1], keep=9, layout={"v": 1, "g": "x", "m": {}})
    b1 = (await cw.base(A[0], B[1]))["base"]
    ok(b1 == b0, "the base changed after the snapshot")
    # --- prepare phase: no attacks yet
    j = await cw.scout(A[0], B[0]); ok(j["why"] == "not_battle" and j["t"] == w["tb"], j)
    ok((await cw.scout(A[6], B[0]))["why"] == "no_war")
    ok((await cw.scout(B[3], A[0]))["why"] == "not_battle")
    await go_battle(st)
    va = await cw.view(A[0]); ok(va["state"] == "battle" and va["war"]["phase"] == "battle" and va["war"]["log"][-1]["k"] == "phase", va["war"]["log"])
    ok((await cw.scout(A[0], A[1]))["why"] == "not_foe")
    # --- attack 1: reserved, spends nothing, books into the war
    me0 = await st.load(A[0]); vic0 = await st.load(B[0])
    j, e, rep = await attack(st, A[0], B[0], 2, 70.0)
    ok(j["target"]["mode"] == "war" and j["target"]["war"] == {"id": 1, "base": B[0], "left": 1} and j["target"]["name"] == "P%d" % B[0], j["target"])
    ok(j["target"]["loot"] == {"ruby": 0, "emerald": 0, "turq": 0} and "_war" not in j["target"] and "kind" not in j["target"], j["target"])
    me1 = await st.load(A[0]); vic1 = await st.load(B[0])
    ok(me1["army"] == me0["army"] and me1["gems"] == me0["gems"] and me1.get("tro") == me0.get("tro") and len(me1.get("rep", [])) == len(me0.get("rep", [])), "the attacker paid something")
    ok(vic1["gems"] == vic0["gems"] and vic1.get("tro") == vic0.get("tro") and not vic1.get("shield") and not vic1.get("hits"), "the defender was touched")
    ok(me1["atk"]["mode"] == "war" and me1["atk"]["done"] and me1["atk"]["war"] == 1, me1["atk"])
    ok(e["info"]["mode"] == "war" and e["info"]["loot"] == {} and e["info"]["stars"] == 2 and e["info"]["report"]["lost"] == {} and "tro" not in e["info"], e["info"])
    ok(e["war"]["st"] == 2 and e["war"]["pc"] == 70.0 and e["war"]["best"] and e["war"]["us"] == {"st": 2, "pc": 70.0} and e["war"]["left"] == 1, e["war"])
    tid = j["target"]["id"]
    e2 = await st.battle_end(A[0], tid, rep)                                                                  # (the same end sent again)
    ok(e2["ok"] and e2["war"]["st"] == 2 and e2["war"]["us"] == {"st": 2, "pc": 70.0}, e2)
    war = await cw._load(1); ok(len(war["atk"]) == 1 and not war["pend"], war["atk"])
    ok((await st.battle_end(A[0], "nope", rep))["why"] in ("no_target",))
    va = await cw.view(A[0])
    ok(va["war"]["me"]["used"] == 1 and va["war"]["me"]["left"] == 1 and len(va["war"]["my"]) == 1 and va["war"]["my"][0]["bn"] == "P%d" % B[0], va["war"]["me"])
    row = next(r for r in va["war"]["them"]["roster"] if r["id"] == B[0])
    ok(row["best"]["st"] == 2 and row["best"]["bn"] == "P%d" % A[0] and va["war"]["us"]["stars"] == 2 and va["war"]["them"]["stars"] == 0, row)
    ok(next(r for r in va["war"]["us"]["roster"] if r["id"] == A[0])["used"] == 1)
    ok(va["war"]["log"][-1]["k"] == "atk" and va["war"]["log"][-1]["side"] == "us" and va["war"]["log"][-1]["best"], va["war"]["log"][-1])
    vb = await cw.view(B[0]); ok(vb["war"]["log"][-1]["side"] == "them" and vb["war"]["us"]["stars"] == 0 and vb["war"]["them"]["stars"] == 2, vb["war"]["log"][-1])
    # --- the cooldown of the normal scout also applies; a second attack of the same player later
    j = await cw.scout(A[0], B[1]); ok(j["why"] == "slow" and j["wait"] > 0, j)
    adv(25)
    # --- pending: the same base again = the same attack; another base = refused; after a restart still the same
    j1 = await cw.scout(A[0], B[1]); ok(j1["ok"] and j1["target"]["war"]["left"] == 0, j1)
    j1b = await cw.scout(A[0], B[1]); ok(j1b["ok"] and j1b["target"]["id"] == j1["target"]["id"], "reissue must be the same token")
    ok((await cw.scout(A[0], B[2]))["why"] == "pending" and (await cw.scout(A[0], B[2]))["base"] == B[1])
    cw = restart(st)
    j1c = await cw.scout(A[0], B[1]); ok(j1c["ok"] and j1c["target"]["id"] == j1["target"]["id"])
    ok((await cw.scout(A[0], B[1]))["why"] == "pending")                                                      # (MAX_REISSUE used up: finish it)
    va = await cw.view(A[0]); ok(va["war"]["me"]["pending"]["base"] == B[1] and va["war"]["me"]["used"] == 2 and va["war"]["me"]["left"] == 0)
    s = await st.load(A[0])
    e = await st.battle_end(A[0], j1["target"]["id"], {"sent": dict(MI.attack_army(s)), "lost": {}, "destruction": 55.0, "stars": 1, "loot": {}, "spells": {}})
    ok(e["ok"] and e["war"]["st"] == 1 and e["war"]["best"] and e["war"]["left"] == 0, e)
    ok((await cw.scout(A[0], B[2]))["why"] == "no_attacks")
    ok((await st.battle_end(A[0], j1["target"]["id"], rep))["ok"] and len((await cw._load(1))["atk"]) == 2)   # (again: same answer)
    # --- the others: A attacks B_i 2 stars; the second attack on B_{i+1} 1 star (best per base counts); B attacks A 1 star 50 %
    for u in A[1:5]:
        i = A.index(u)
        await attack(st, u, B[i], 2, 70.0)
    for u in A[1:5]:
        adv(25)
        i = A.index(u)
        await attack(st, u, B[(i + 1) % 5], 1, 55.0)
    for u in B[:5]:
        adv(25)
        await attack(st, u, A[B.index(u)], 1, 50.0)
    adv(25)
    war = await cw._load(1)
    ok(war["ph"] == "battle", "the war must not end while B still has attacks")
    # a 3-starred base cannot be attacked again, and a base whose best is 3 stars is `maxed`
    # --- B's second round: all at once ends the war early
    for u in B[:5]:
        i = B.index(u)
        await attack(st, u, A[(i + 1) % 5], 1, 50.0)
        adv(25)
    # the last attack ended it; prizes are in the inbox once
    war = await cw._load(1)
    ok(war["ph"] == "ended" and war["done"] and war["res"]["early"] and war["res"]["w"] == 0 and war["res"]["why"] == "stars", war["res"])
    ok(war["res"]["sc"][0]["st"] == 10 and war["res"]["sc"][1]["st"] == 5, war["res"]["sc"])
    for u in A[:5]:
        g = inbox_of(st, u); ok(len(g) == 1 and g[0]["id"] == "war:1:%d" % u and g[0]["src"] == "war" and g[0]["turq"] == 2000 and g[0]["sap"] == 10, g)
    for u in B[:5]:
        g = inbox_of(st, u); ok(len(g) == 1 and g[0]["turq"] == 500 and "sap" not in g[0], g)
    ok(inbox_of(st, A[6]) == [])                                                                              # (not in the roster: nothing)
    pre = (await st.load(A[0]))
    async with st._lock(A[0]):
        s = await st._txn(A[0]); await st.save(A[0], s)
    s = await st.load(A[0]); ok(s["prem"]["sap"] == pre["prem"]["sap"] + 10 and s["gems"]["turq"] == pre["gems"]["turq"] + 2000, "prize not applied")
    async with st._lock(A[0]):
        s = await st._txn(A[0]); await st.save(A[0], s)
    s2 = await st.load(A[0]); ok(s2["prem"]["sap"] == s["prem"]["sap"] and s2["gems"]["turq"] == s["gems"]["turq"], "prize applied twice")
    await cw.tick(); await cw.tick(); ok(all(len(inbox_of(st, u)) <= 1 for u in A + B))
    # --- afterwards: the result stays on the screen, the clan is free again
    va, vb = await cw.view(A[0]), await cw.view(B[0])
    ok(va["state"] == "ended" and va["free"] and va["cands"] and va["war"]["res"]["winner"] == "us" and vb["war"]["res"]["winner"] == "them", (va["state"], va["free"]))
    ok(va["war"]["res"]["us"] == {"st": 10, "pc": 700.0 - 0.0} or va["war"]["res"]["us"]["st"] == 10, va["war"]["res"])
    ok(va["war"]["res"]["prize"] == {"turq": 2000, "sap": 10} and va["war"]["res"]["sent"] and vb["war"]["res"]["prize"] == {"turq": 500} and va["war"]["phase"] == "ended")
    ok(va["last"][0]["won"] == "win" and vb["last"][0]["won"] == "lose" and va["last"][0]["st"] == [10, 5] and va["last"][0]["vs"]["tag"] == "IR", va["last"])
    ok((await cw.view(A[6]))["war"]["res"]["prize"] is None and (await cw.view(A[6]))["war"]["me"]["in"] is False)
    ok(await cw.kv.get(CW.K_PTR % cidA) is None and await cw.kv.get(CW.K_UW % A[0]) is None and await cw.kv.sall(CW.K_ACTIVE) == [])
    ok(await cw.kv.get(CW.K_BASE % (1, B[0])) is None)                                                        # (the frozen bases are deleted after the war)
    ok((await cw.scout(A[0], B[0]))["why"] == "no_war")
    ok((await cw.search(A[0], 5, roster))["ok"] and (await cw.cancel(A[0]))["ok"])
    v = await cw.view(A[0]); ok(v["note"]["why"] == "cancelled" and v["free"] and v["state"] == "ended", v["note"])
    ok((await cw.cancel(A[0]))["why"] == "no_search")
    ok((await cw.search(A[0], 5, roster))["ok"] and (await cw.view(A[0]))["note"] is None and (await cw.view(A[0]))["state"] == "search")


# ------------------------------------------------------------------ 2. a restart in the middle of every phase; crash while paying; crash while making a war
async def t_restart():
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 2000, 5, 5)
    ok((await cw.search(A[0], 5, A))["ok"])
    cw = restart(st)                                                                           # restart while searching
    ok((await cw.view(A[0]))["state"] == "search")
    # crash while the war is being made: the war record is written, the links are not
    real = cw._link
    async def boom(war): raise RuntimeError("crash")
    cw._link = boom
    ok((await cw.search(B[0], 5, B))["ok"])                                                    # (match() logs the failure and leaves both in the queue)
    ok(await cw.kv.sall(CW.K_ACTIVE) == ["1"] and (await cw.kv.get(CW.K_PTR % cidA))["k"] == "search")
    cw = restart(st)                                                                           # the restart repairs the links, the clans leave the queue
    await cw.tick()
    ok((await cw.kv.get(CW.K_PTR % cidA)) == {"k": "war", "id": 1} and (await cw.kv.get(CW.K_PTR % cidB)) == {"k": "war", "id": 1} and await cw.kv.hall(CW.K_Q) == {})
    ok(await cw.kv.incr(CW.K_SEQ) == 2, "a second war must not have been made")
    ok((await cw.view(B[0]))["state"] == "prep")
    cw = restart(st)                                                                           # restart in the prepare phase
    adv(6 * 3600); await cw.tick(); ok((await cw.view(A[0]))["state"] == "prep")
    cw = restart(st)
    adv(6 * 3600 + 10); ok((await cw.view(A[0]))["state"] == "battle")                          # (a view alone moves the phase too)
    j, e, _ = await attack(st, A[0], B[0], 2, 66.0)
    adv(25)
    j2 = await cw.scout(A[1], B[1]); ok(j2["ok"])                                                # a pending attack ...
    cw = restart(st)                                                                           # ... survives a restart in the battle phase
    ok((await cw.view(A[1]))["war"]["me"]["pending"]["base"] == B[1])
    s = await st.load(A[1])
    ok((await st.battle_end(A[1], j2["target"]["id"], {"sent": dict(MI.attack_army(s)), "lost": {}, "destruction": 60.0, "stars": 1, "loot": {}, "spells": {}}))["ok"])
    # the battle runs out at the end time: A made 2 attacks, B none -> A wins; paying breaks half way (the inbox refuses after 2 gifts)
    adv(24 * 3600)
    real_push = st.push_inbox; calls = [0]
    async def flaky(uid, e):
        calls[0] += 1
        return False if calls[0] > 1 else await real_push(uid, e)
    st.push_inbox = flaky
    await cw.tick()
    war = await cw._load(1); ok(war["ph"] == "ended" and not war["done"] and sum(war["res"]["pay"].values()) == 1, (war["ph"], war["done"], war["res"]["pay"]))
    ok(await cw.kv.sall(CW.K_ACTIVE) == ["1"] and (await cw.kv.get(CW.K_PTR % cidA)) == {"k": "war", "id": 1})
    v = await cw.view(A[0]); ok(v["war"]["phase"] == "ended" and v["war"]["res"]["winner"] == "us")
    ok(sum(len(inbox_of(st, u)) for u in A + B) == 1)
    cw = restart(st)                                                                           # restart in the middle of the payout
    st.push_inbox = real_push
    await asyncio.gather(*(cw.tick() for _ in range(6)))                                       # (six clocks at once: still one gift per member)
    war = await cw._load(1); ok(war["done"] and all(war["res"]["pay"].values()))
    paid = [u for u in A + B if inbox_of(st, u)]
    ok(len(paid) == len(war["res"]["pz"]) and all(len(inbox_of(st, u)) == 1 for u in paid), [(u, len(inbox_of(st, u))) for u in A + B])
    ok(sorted(g[0]["id"] for g in (inbox_of(st, u) for u in paid)) == sorted("war:1:%d" % u for u in paid))
    cw = restart(st); await cw.tick(); await cw.tick()
    ok(sum(len(inbox_of(st, u)) for u in A + B) == len(paid), "paid again after a restart")
    ok(war["res"]["w"] == 0 and war["res"]["why"] == "stars" and not war["res"]["early"])
    ok(all(g not in [x for u in B for x in inbox_of(st, u)] for g in []))
    # B did not attack: no prize (prize_min_attacks = 1); A's members who did not attack either
    ok(set(war["res"]["pz"]) == {str(A[0]), str(A[1])}, war["res"]["pz"])


# ------------------------------------------------------------------ 3. draw / time / nothing
async def t_draws():
    # nobody attacks: a draw at the end time, nobody is paid (prize_min_attacks 1)
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 3000, 5, 5)
    await cw.search(A[0], 5, A); await cw.search(B[0], 5, B)
    adv(36 * 3600 + 1); await cw.tick()
    war = await cw._load(1); ok(war["done"] and war["res"]["w"] is None and war["res"]["why"] == "draw" and war["res"]["pz"] == {}, war["res"])
    v = await cw.view(A[0]); ok(v["war"]["res"]["winner"] == "draw" and v["war"]["res"]["prize"] is None and v["last"][0]["won"] == "draw")
    ok(all(inbox_of(st, u) == [] for u in A + B))
    # prize_min_attacks 0: the draw prize goes to everybody
    st = new_store({"prize_min_attacks": 0}); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 3100, 5, 5)
    await cw.search(A[0], 5, A); await cw.search(B[0], 5, B)
    adv(40 * 3600); await cw.tick()
    ok(all(len(inbox_of(st, u)) == 1 and inbox_of(st, u)[0]["turq"] == 1000 and inbox_of(st, u)[0]["sap"] == 5 for u in A + B))
    # a real draw: the same stars, the same % and the SAME second (a frozen clock)
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 3200, 5, 5)
    await cw.search(A[0], 5, A); await cw.search(B[0], 5, B); await go_battle(st)
    ja = await cw.scout(A[0], B[0]); jb = await cw.scout(B[0], A[0]); ok(ja["ok"] and jb["ok"])
    for u, j in ((A[0], ja), (B[0], jb)):
        s = await st.load(u)
        ok((await st.battle_end(u, j["target"]["id"], {"sent": dict(MI.attack_army(s)), "lost": {}, "destruction": 60.0, "stars": 1, "loot": {}, "spells": {}}))["ok"])
    adv(24 * 3600); await cw.tick()
    war = await cw._load(1); ok(war["res"]["w"] is None and war["res"]["why"] == "draw" and war["res"]["sc"][0]["st"] == 1, war["res"])
    ok(len(inbox_of(st, A[0])) == 1 and inbox_of(st, A[0])[0]["turq"] == 1000 and inbox_of(st, A[1]) == [])      # (draw prize to the two who attacked)
    # the time tie-break: the same result, A earlier
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 3300, 5, 5)
    await cw.search(A[0], 5, A); await cw.search(B[0], 5, B); await go_battle(st)
    await attack(st, A[0], B[0], 1, 60.0); adv(30); await attack(st, B[0], A[0], 1, 60.0)
    adv(24 * 3600); await cw.tick()
    war = await cw._load(1); ok(war["res"]["w"] == 0 and war["res"]["why"] == "time", war["res"])
    ok((await cw.view(B[0]))["war"]["res"]["winner"] == "them")
    # the percentage tie-break
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 3400, 5, 5)
    await cw.search(A[0], 5, A); await cw.search(B[0], 5, B); await go_battle(st)
    await attack(st, B[0], A[0], 2, 80.0); await attack(st, A[0], B[0], 2, 75.0)
    adv(24 * 3600); await cw.tick()
    war = await cw._load(1); ok(war["res"]["w"] == 1 and war["res"]["why"] == "pct", war["res"])


# ------------------------------------------------------------------ 4. leaving the clan in the middle of a war
async def t_leave():
    for rule in ("forfeit", "keep", "remove"):
        st = new_store({"leave": rule}); cw = st.clanwar
        cidA, A, cidB, B = await world(st, 4000 + 100 * ("forfeit keep remove".split().index(rule)), 5, 5)
        await cw.search(A[0], 5, A); await cw.search(B[0], 5, B); await go_battle(st)
        await attack(st, A[2], B[2], 3, 100.0)                                                    # A's member 3 makes a 3-star hit, then leaves
        adv(25)
        await attack(st, B[0], A[2], 2, 70.0)                                                     # B hits the base of the leaver
        ok((await st.clans.leave(A[2]))["ok"])
        v = await cw.view(A[2])
        ok(v["clan"] is None and v["state"] == "battle" and v["war"]["me"]["gone"] and v["war"]["me"]["in"], (rule, v["clan"], v["state"], v["war"] and v["war"]["me"]))
        va = await cw.view(A[0])
        row = next(r for r in va["war"]["us"]["roster"] if r["id"] == A[2]); ok(row["left"], row)
        adv(25)
        j = await cw.scout(A[2], B[3])
        if rule == "keep":
            ok(j["ok"], j)
            s = await st.load(A[2])
            ok((await st.battle_end(A[2], j["target"]["id"], {"sent": dict(MI.attack_army(s)), "lost": {}, "destruction": 60.0, "stars": 1, "loot": {}, "spells": {}}))["ok"])
        else:
            ok(j["why"] == "left_clan", j)
        adv(24 * 3600); await cw.tick()
        war = await cw._load(1); sc = war["res"]["sc"]
        if rule == "remove":
            ok(sc[0]["st"] == 0 and sc[1]["st"] == 0 and war["res"]["w"] is None and war["res"]["removed"] == [A[2]], (sc, war["res"]))     # (his 3 stars and the hit on his base both void)
        elif rule == "keep":
            ok(sc[0]["st"] == 4 and sc[1]["st"] == 2 and war["res"]["w"] == 0, sc)
        else:
            ok(sc[0]["st"] == 3 and sc[1]["st"] == 2 and war["res"]["w"] == 0, sc)
        ok((str(A[2]) in war["res"]["pz"]) == (rule == "keep"), (rule, war["res"]["pz"]))              # (the leaver is paid only when the rule is `keep`)
    # kicked = left;  and a clan with everybody gone still ends
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 4500, 5, 5)
    await cw.search(A[0], 5, A); await cw.search(B[0], 5, B); await go_battle(st)
    ok((await st.clans.kick(A[0], A[3]))["ok"] and (await cw.scout(A[3], B[0]))["why"] == "left_clan")
    for u in A[1:]:
        await st.clans.leave(u)
    await st.clans.leave(A[0])
    adv(24 * 3600); await cw.tick()
    war = await cw._load(1); ok(war["done"] and war["res"]["w"] is None)


# ------------------------------------------------------------------ 5. matchmaker
async def t_match():
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 5000, 5, 5, tro_a=[300] * 5, tro_b=[360] * 5)                 # 1500 vs 1800: gap 300 of avg 1650 = 18 %
    await cw.search(A[0], 5, A); await cw.search(B[0], 5, B)
    ok((await cw.view(A[0]))["state"] == "search", "18 % apart must not match at 10 %")
    adv(5 * 60); await cw.tick(); ok((await cw.view(A[0]))["state"] == "search")           # (15 % window)
    adv(3 * 60); await cw.tick(); ok((await cw.view(A[0]))["state"] == "search")           # (18 % < 18.18 %)
    adv(2 * 60); await cw.tick(); ok((await cw.view(A[0]))["state"] == "prep", "the window must widen while they wait")
    # far apart never match; after search_minutes the search ends without a penalty
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 5100, 5, 5, tro_a=[100] * 5, tro_b=[900] * 5)
    await cw.search(A[0], 5, A); await cw.search(B[0], 5, B)
    adv(29 * 60); await cw.tick(); ok((await cw.view(A[0]))["state"] == "search")
    adv(2 * 60); await cw.tick()
    va = await cw.view(A[0]); ok(va["state"] == "none" and va["free"] and va["note"]["why"] == "no_match" and va["war"] is None, va)
    ok(await cw.kv.get(CW.K_PTR % cidA) is None and await cw.kv.hall(CW.K_Q) == {})
    ok((await cw.search(A[0], 5, A))["ok"])                                                           # (free to search again, no penalty)
    # different sizes never match
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 5200, 10, 5)
    await cw.search(A[0], 10, A[:10]); await cw.search(B[0], 5, B)
    ok((await cw.view(A[0]))["state"] == "search" and (await cw.view(B[0]))["state"] == "search")
    adv(31 * 60); await cw.tick(); ok((await cw.view(B[0]))["note"]["why"] == "no_match")
    # three clans: A (1000) searches, B (1150) searches (too far for A), C (1050) searches -> A and C are paired, B keeps waiting
    st = new_store(); cw = st.clanwar
    async def mk(uids, tro, nm, tag):
        for u in uids:
            await st.touch(u, "P%d" % u); await setk(st, u, keep=2, tro=tro)
        r = await st.clans.create(uids[0], nm, tag); ok(r["ok"], r)
        for u in uids[1:]:
            ok((await st.clans.join(u, r["id"]))["ok"])
        return r["id"]
    UA, UB, UC = [5301, 5302, 5303, 5304, 5305], [5311, 5312, 5313, 5314, 5315], [5321, 5322, 5323, 5324, 5325]
    await mk(UA, 200, "AlphaX", "AX"); await mk(UB, 230, "BravoX", "BX"); await mk(UC, 210, "CharlieX", "CX")
    await cw.search(UA[0], 5, UA); await cw.search(UB[0], 5, UB)
    ok((await cw.view(UA[0]))["state"] == "search" and (await cw.view(UB[0]))["state"] == "search")
    await cw.search(UC[0], 5, UC)
    ok((await cw.view(UA[0]))["state"] == "prep" and (await cw.view(UC[0]))["state"] == "prep" and (await cw.view(UB[0]))["state"] == "search")
    ok((await cw.view(UA[0]))["war"]["them"]["clan"]["tag"] == "CX")
    # a roster member leaves while the clan searches: the clan is dropped at the match, the opponent stays
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 5500, 5, 5)
    await cw.search(A[0], 5, A)
    await st.clans.leave(A[4])
    await cw.search(B[0], 5, B)
    va, vb = await cw.view(A[0]), await cw.view(B[0])
    ok(va["state"] == "none" and va["note"]["why"] == "roster" and vb["state"] == "search", (va["state"], vb["state"]))
    # flag off: the queue is kept, nothing is matched, nothing is lost; with the flag back on the match is made
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 5600, 5, 5, tro_a=[300] * 5, tro_b=[355] * 5)                 # (1500 vs 1775: needs ~9 min of waiting)
    await cw.search(A[0], 5, A); await cw.search(B[0], 5, B)
    LO.flags["clan_war"] = False
    ok((await cw.search(B[0], 5, B))["why"] == "off")
    adv(10 * 60); await cw.tick()
    ok(sorted((await cw.kv.hall(CW.K_Q))) == [str(cidA), str(cidB)] and await cw.kv.sall(CW.K_ACTIVE) == [], "the matchmaker must stay quiet while the feature is off")
    LO.flags["clan_war"] = True; await cw.tick()
    ok((await cw.view(A[0]))["state"] == "prep" and (await cw.view(B[0]))["state"] == "prep")


# ------------------------------------------------------------------ 6. attack rules
async def t_attack_rules():
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 6000, 5, 5, extra_a=1)
    await cw.search(A[0], 5, A[:5]); await cw.search(B[0], 5, B); await go_battle(st)
    ok((await cw.scout(A[5], B[0]))["why"] == "no_war")                                                # (in the clan, not in the roster)
    ok((await cw.scout(A[0], "x"))["why"] == "not_foe" and (await cw.scout(A[0], None))["why"] == "not_foe")
    # no army
    s = await st.load(A[1]); s["army"] = {}; await st.save(A[1], s)
    ok((await cw.scout(A[1], B[0]))["why"] == "no_army" and (await cw.view(A[1]))["war"]["me"]["used"] == 0)
    # closed attacks
    old = S.ATTACK_PUBLIC; S.ATTACK_PUBLIC = False
    ok((await cw.scout(A[0], B[0]))["why"] == "closed"); S.ATTACK_PUBLIC = old
    # an implausible report is refused and the attack stays open (the token is not used up)
    j = await cw.scout(A[0], B[0]); ok(j["ok"])
    e = await st.battle_end(A[0], j["target"]["id"], {"sent": {"dragon": 99}, "lost": {}, "destruction": 90.0, "stars": 2, "loot": {}, "spells": {}})
    ok(not e["ok"] and e["why"] == "bad_units", e)
    s = await st.load(A[0])
    e = await st.battle_end(A[0], j["target"]["id"], {"sent": dict(MI.attack_army(s)), "lost": {}, "destruction": 100.0, "stars": 3, "loot": {}, "spells": {}})
    ok(e["ok"] and e["war"]["st"] == 3 and e["info"]["stars"] == 3)
    # the base is 3-starred: `maxed` for everybody (nothing is reserved)
    adv(25)
    ok((await cw.scout(A[2], B[0]))["why"] == "maxed" and (await cw.view(A[2]))["war"]["me"]["used"] == 0 and (await cw.view(A[2]))["war"]["me"]["pending"] is None)
    ok((await cw.scout(A[0], B[1]))["ok"])                                                              # A[0]'s second attack (left 0 afterwards)
    # a started attack that never reports back is used up (0 stars) after the token's lifetime
    j = await cw.scout(A[3], B[2]); ok(j["ok"])
    adv(MI.BATTLE_TIMEOUT + 60); await cw.tick()
    v = await cw.view(A[3]); ok(v["war"]["me"]["used"] == 1 and v["war"]["me"]["pending"] is None and v["war"]["my"][0]["lost"] and v["war"]["log"][-1]["k"] == "lost", v["war"]["me"])
    s = await st.load(A[3])
    e = await st.battle_end(A[3], j["target"]["id"], {"sent": dict(MI.attack_army(s)), "lost": {}, "destruction": 100.0, "stars": 3, "loot": {}, "spells": {}})
    ok(not e["ok"] and e["why"] == "expired", e)                                                       # (too late: the war has booked it as lost)
    # a pending attack at the end time delays the end until it is booked (or has run out)
    CLOCK[0] = (await cw._load(1))["te"] - 60
    await cw.tick()
    j = await cw.scout(A[4], B[3]); ok(j["ok"])
    adv(120); await cw.tick()
    ok((await cw._load(1))["ph"] == "battle", "must wait for the attack in progress")
    ok((await cw.view(A[4]))["war"]["phase"] == "battle")
    s = await st.load(A[4])
    ok((await st.battle_end(A[4], j["target"]["id"], {"sent": dict(MI.attack_army(s)), "lost": {}, "destruction": 60.0, "stars": 1, "loot": {}, "spells": {}}))["ok"])
    war = await cw._load(1); ok(war["ph"] == "ended" and war["done"], war["ph"])
    ok((await cw.scout(A[4], B[3]))["why"] == "no_war")


# ------------------------------------------------------------------ 7. the owner's dev tool; flag off in the middle of a war
async def t_dev_flag():
    st = new_store(); cw = st.clanwar
    cidA, A, cidB, B = await world(st, 7000, 5, 5)
    await cw.search(A[0], 5, A); await cw.search(B[0], 5, B)
    ok((await cw.dev(A[0], {"shift": 12 * 3600 + 1}))["ok"] and (await cw.view(A[0]))["state"] == "battle")
    ok((await cw.dev(555, {"shift": 5}))["why"] == "no_war" and (await cw.dev(A[0], {"shift": "x"}))["why"] == "bad")
    await attack(st, A[0], B[0], 2, 70.0)
    LO.flags["clan_war"] = False
    ok(await cw.view(A[0]) == {"on": False} and (await cw.scout(A[1], B[0]))["why"] == "off" and (await cw.base(A[1], B[0]))["why"] == "off" and (await cw.cancel(A[0]))["why"] == "off")
    adv(30 * 3600); await cw.tick()                                                                       # (the clock settles a war even while the feature is hidden)
    war = await cw._load(1); ok(war["done"] and war["res"]["w"] == 0 and len(inbox_of(st, A[0])) == 1)
    LO.flags["clan_war"] = True
    ok((await cw.view(A[0]))["state"] == "ended")


# ------------------------------------------------------------------ 8. the real HTTP routes (server.make_app): GET|POST /api/clan/war, /api/scout {mode:war}, /api/battle/end
async def t_http():
    from aiohttp import web
    from aiohttp.test_utils import TestClient, TestServer
    from bluewall import server as SV
    st = SV.STORE
    st.clanwar.set_liveops(LO); LO.flags["clan_war"] = True; LO.sec["war"] = {}
    SV._bearer_uid = lambda req: int(req.headers["X-Uid"]) if req.headers.get("X-Uid") else None
    SV._is_owner = lambda uid: uid == 8999
    SV._limited = lambda key, mx=0: False
    cidA, A, cidB, B = await world(st, 8000, 5, 5)
    app = SV.make_app()
    async with TestClient(TestServer(app)) as c:
        async def get(uid, path="/api/clan/war"):
            r = await c.get(path, headers={"X-Uid": str(uid)}); return r.status, await r.json()
        async def post(uid, path, body):
            r = await c.post(path, json=body, headers={"X-Uid": str(uid)}); return r.status, await r.json()
        r = await c.get("/api/clan/war"); ok(r.status == 403 and (await r.json())["reason"] == "locked")
        s, j = await get(A[0]); ok(s == 200 and j["ok"] and j["state"] == "none" and j["cfg"]["sizes"] == [5, 10, 15, 20] and j["cfg"]["prizes"]["win"] == {"turq": 2000, "sap": 10}, j)
        s, j = await post(A[0], "/api/clan/war", {"op": "search", "size": 5, "roster": A}); ok(s == 200 and j["ok"] and j["state"] == "search" and j["search"]["roster"] == A, j)
        s, j = await post(A[0], "/api/clan/war", {"op": "search", "size": 5, "roster": A}); ok(s == 200 and not j["ok"] and j["why"] == "busy", j)
        s, j = await post(A[0], "/api/clan/war", {"op": "nope"}); ok(s == 400)
        s, j = await post(B[1], "/api/clan/war", {"op": "search", "size": 5, "roster": B}); ok(j["why"] == "not_leader")
        s, j = await post(B[0], "/api/clan/war", {"op": "search", "size": 5, "roster": B}); ok(j["ok"] and j["state"] == "prep" and j["war"]["id"] == 1, j)
        s, j = await post(A[0], "/api/clan/war", {"op": "base", "id": B[0]}); ok(j["ok"] and j["base"]["n"] == "P%d" % B[0], j)
        s, j = await post(A[0], "/api/clan/war", {"op": "dev", "shift": 1}); ok(s == 403)
        s, j = await post(8999, "/api/clan/war", {"op": "dev", "shift": 1}); ok(s == 200 and j["why"] == "no_war", (s, j))
        adv(12 * 3600 + 5); await st.clanwar.tick()
        s, j = await post(A[0], "/api/scout", {"mode": "war", "base": B[0]}); ok(s == 200 and j["ok"] and j["target"]["mode"] == "war" and j["target"]["war"]["left"] == 1 and "gems" in j, j)
        tid = j["target"]["id"]
        sa = await st.load(A[0])
        rep = {"sent": dict(MI.attack_army(sa)), "lost": {}, "destruction": 80.0, "stars": 2, "loot": {}, "spells": {}}
        s, j = await post(A[0], "/api/battle/end", {"id": tid, "rep": rep}); ok(s == 200 and j["ok"] and j["info"]["mode"] == "war" and j["war"]["st"] == 2 and "gems" in j, j)
        s, j = await get(B[2]); ok(j["war"]["them"]["stars"] == 2 and j["war"]["log"][-1]["side"] == "them", j["war"]["log"][-1])
        s, j = await post(A[0], "/api/scout", {"mode": "war", "base": B[1]}); ok(not j["ok"] and j["why"] == "slow", j)                     # (the usual scout cooldown)
        s, j = await post(A[0], "/api/scout", {"bots_only": True}); ok(s == 200)                                                      # (the normal scout is untouched; it may be slow too)
        s, j = await post(A[1], "/api/scout", {"mode": "war"}); ok(not j["ok"] and j["why"] == "not_foe", j)
    # normal attacks still work next to a war (a bot target, normal settlement: loot / cups)
    st2 = S.Store(); LO.flags["clan_war"] = True
    await st2.touch(9001, "Solo")
    j = await st2.scout(9001, True); ok(j["ok"] and "mode" not in (j["target"] or {}), j.get("why"))

# ------------------------------------------------------------------ 9. the Redis path of the storage layer (a fake with the semantics of redis.asyncio, decode_responses=True)
class FakeRedis:
    def __init__(self): self.d, self.ex, self.calls = {}, {}, 0
    async def get(self, k): self.calls += 1; return self.d.get(k)
    async def set(self, k, v, ex=None):
        self.calls += 1; self.d[k] = v
        if ex: self.ex[k] = ex
        return True
    async def delete(self, k): self.calls += 1; return 1 if self.d.pop(k, None) is not None else 0
    async def incr(self, k): self.calls += 1; self.d[k] = str(int(self.d.get(k, 0)) + 1); return int(self.d[k])
    async def hgetall(self, k): self.calls += 1; return dict(self.d.get(k) or {})
    async def hset(self, k, f, v): self.calls += 1; self.d.setdefault(k, {})[f] = v; return 1
    async def hdel(self, k, f): self.calls += 1; return 1 if (self.d.get(k) or {}).pop(f, None) is not None else 0
    async def smembers(self, k): self.calls += 1; return set(self.d.get(k) or ())
    async def sadd(self, k, v): self.calls += 1; self.d.setdefault(k, set()).add(v); return 1
    async def srem(self, k, v): self.calls += 1; (self.d.get(k) or set()).discard(v); return 1


async def t_redis_kv():
    class Fake:
        def __init__(self, r): self.r = r
        async def _redis(self): return self.r
    r = FakeRedis(); kv = CW._Kv(Fake(r))
    ok(await kv.get("a") is None)
    await kv.put("a", {"x": [1, 2], "s": "é"}); ok(await kv.get("a") == {"x": [1, 2], "s": "é"})
    await kv.put("b", 7, ex=60); ok(r.ex["b"] == 60 and await kv.get("b") == 7)
    await kv.delete("a"); ok(await kv.get("a") is None)
    ok(await kv.incr("n") == 1 and await kv.incr("n") == 2)
    ok(await kv.hall("h") == {})
    await kv.hput("h", "1", {"q": 1}); await kv.hput("h", "2", {"q": 2}); ok(await kv.hall("h") == {"1": {"q": 1}, "2": {"q": 2}})
    await kv.hdel("h", "1"); await kv.hdel("h", "nope"); ok(await kv.hall("h") == {"2": {"q": 2}})
    ok(await kv.sall("s") == []); await kv.sadd("s", "5"); await kv.sadd("s", "5"); await kv.sadd("s", "12"); ok(await kv.sall("s") == ["12", "5"])
    await kv.srem("s", "5"); await kv.srem("s", "zz"); ok(await kv.sall("s") == ["12"])
    # an outage is a StateUnavailable (the routes answer 503 busy), never a half-written war
    class Dead(FakeRedis):
        async def get(self, k): raise ConnectionError("down")
    try:
        await CW._Kv(Fake(Dead())).get("a"); ok(False, "no error")
    except S.StateUnavailable:
        ok(True)
    class Slow(FakeRedis):
        async def get(self, k): await asyncio.sleep(5)
    t0 = time.perf_counter()
    try:
        await CW._Kv(Fake(Slow())).get("a"); ok(False, "no timeout")
    except S.StateUnavailable:
        ok(True)


async def main():
    for t in (t_config, t_rules, t_cycle, t_restart, t_draws, t_leave, t_match, t_attack_rules, t_dev_flag, t_redis_kv, t_http):
        t0 = CHECKS[0]
        try:
            await t()
        except Exception:
            print("FAIL in", t.__name__, "after", CHECKS[0] - t0, "checks"); raise
        print("ok  %-16s %3d checks" % (t.__name__, CHECKS[0] - t0))
    print("CW1 OK (%d checks)" % CHECKS[0])

asyncio.run(main())
