# CW1 — Clan War: routes and shapes (server `clanwar.py`, client `warui.js`)

All calls: `Authorization: Bearer <token>`, JSON, `Cache-Control: no-store`. Locked → `403 {"ok":false,"reason":"locked"}`; rate → `429 {"ok":false,"reason":"slow"}`; store hiccup → `503 {"ok":false,"reason":"busy"}`.
Everything is **server-authoritative**: the client only draws what it is told, and sends intentions.

## 0. Flag and config
* Feature = `liveops.flag('clan_war')`. Off → `GET /api/clan/war` answers `{"ok":true,"on":false}` and **every other call answers `{"ok":false,"why":"off"}`**. The client hides every entry point while `on` is false (no «soon» button).
* Numbers live in the liveops section `war` (defaults: `bluewall/war_defaults.json`, validated by `clanwar.validate`). The client gets the public part in `cfg` (below) — never hard-code them.

## 1. `GET /api/clan/war` → the whole screen
```jsonc
{
 "ok": true, "on": true,
 "now": 1760750000.0,                // server clock (s). The client keeps  skew = now - Date.now()/1000  and counts down with it.
 "cfg": { "sizes":[5,10,15,20], "prep_h":12, "battle_h":24, "attacks":2, "search_min":30, "leave":"forfeit"|"keep"|"remove",
          "prize_min":1, "prizes": {"win":{"turq":2000,"sap":10},"draw":{...},"lose":{...}} },
 "clan": null | {"id":7,"name":"Blue Fleet","tag":"BF","n":12,"lead":true},   // lead = owner / co-leader: may start / cancel a search
 "state": "none" | "search" | "prep" | "battle" | "ended",
 "free": true,                       // the clan has no live search and no live war → the Start tab may be used (state "none" or "ended"); a leader can start a new search from "ended" too
 "cands": null | [ {"id":101,"n":"Ana","e":"crest_3","tro":820,"k":14,"lg":2}, ... ],   // only state "none" AND clan.lead: the members to pick the roster from, strongest first
 "search": null | {"size":10,"t0":..., "until":...,"roster":[101,...],"score":8120},     // state "search": until = t0 + search_min*60
 "note": null | {"t":...,"why":"no_match"|"cancelled"|"roster"},      // how the last search ended (no penalty ever); shown once, cleared by the next search
 "war": null | WAR,                  // states prep / battle / ended
 "last": [ {"id":12,"t":...,"won":"win"|"lose"|"draw","vs":{"name":"Iron Owls","tag":"IO"},"st":[21,17],"pc":[1450.5,1302.0],"size":10} ]   // finished wars of my clan, newest first, <= 5
}
```
### WAR (always from the viewer's side: `us` = the viewer's clan, `them` = the other)
```jsonc
{
 "id": 12, "size": 10,
 "phase": "prep" | "battle" | "ended",
 "t0": ..., "tb": ..., "te": ..., "ended_at": null | ...,            // found, battle starts, battle ends (planned); ended_at = real end (early end possible)
 "me": { "id":101, "side":"us", "in": true,                        // in = in the roster (may attack). A clan member outside the roster only watches.
         "rank": 3, "used": 1, "left": 1, "max": 2,                // attacks made (incl. one in progress) / attacks still available / per member
         "pending": null | {"base":205,"t":...},                   // a started, unfinished attack (the client continues it by asking for the same base again)
         "gone": false },                                          // true = no longer in the clan (policy decides what that means)
 "us":   { "clan":{"id":7,"name":"Blue Fleet","tag":"BF"}, "stars":14, "pct":812.5, "used":9, "max":20, "roster":[ROW,...] },
 "them": { "clan":{...}, "stars":11, "pct":700.0, "used":8, "max":20, "roster":[ROW,...] },
 "my":   [ {"base":205,"bn":"Cy","st":2,"pc":71.5,"t":...,"lost":false} ],      // my finished attacks, oldest first
 "log":  [ {"t":...,"k":"found"} , {"t":...,"k":"phase","ph":"battle"}, {"t":...,"k":"atk","by":101,"bn":"Ana","side":"us","base":205,"tn":"Cy","st":2,"pc":71.5,"best":true},
           {"t":...,"k":"lost","by":102,"bn":"Bob","side":"us"} , {"t":...,"k":"end"} ],     // newest LAST, <= 60 entries; `lost` = an attack that never reported back
 "res": null | { "winner":"us"|"them"|"draw", "why":"stars"|"pct"|"time"|"draw", "early":false,
                 "us":{"st":14,"pc":812.5}, "them":{"st":11,"pc":700.0},
                 "prize": null | {"turq":2000,"sap":10},              // MY prize (null = I get none, e.g. no attack made)
                 "sent": true }                                      // false until the gift is in the inbox (a few seconds; the clock retries)
}
```
### ROW (one base — `roster` is ordered by rank 1..N = strongest cups first at the moment of the snapshot)
```jsonc
{ "id":205, "n":"Cy", "e":"crest_5", "rank":1, "k":16, "tro":900,
  "lv":{"keep":16,"wall":15,"towers":14}, "power":5400, "tesla":1,
  "used":2,                       // attacks this PLAYER has made (as attacker) — useful on the `us` roster
  "left":false,                   // left the clan after the snapshot
  "best": null | {"st":3,"pc":100.0,"by":101,"bn":"Ana","t":...}    // the best result of the OTHER side against this base
}
```
Stars of a side = sum over the OTHER side's bases of the best result (stars first, then % of destruction, then earlier). `pct` = sum of those best percentages.

## 2. `POST /api/clan/war`   body `{ "op": ... }` → `{"ok":true, ...same body as GET}` or `{"ok":false,"why":...}`
| op | body | who | why-codes |
|---|---|---|---|
| `search` | `{size, roster:[uid,...]}` | owner / co-leader | `off` `size` (not in cfg.sizes) `no_clan` `not_leader` `roster` (not `size` distinct members of the clan) `busy` (clan already searching / at war) |
| `cancel` | `{}` | owner / co-leader | `no_search` `in_war` `not_leader` — a search can be cancelled at any time, no penalty |
| `base` | `{id}` | any member of a clan in the war | `no_war` `not_foe` → `{"ok":true,"base":{id,n,e,k,lv,power,tesla,guard:{unit:n},"layout":null|record}}` the frozen snapshot of an enemy base (visible from the start of the prepare phase) |
| `dev` | `{shift:seconds}` | **game owner only** | moves the war's clock forward (test phases without waiting) |

* `search` closes the roster: it cannot be edited; a member who leaves before the match removes the clan from the queue (`note.why:"roster"`).
* No opponent within `cfg.search_min` minutes → the search ends by itself, `note.why:"no_match"`, nothing is lost.
* One war per clan at a time; one war per player (a player is in one clan).

## 3. An attack = the normal attack flow with `mode:"war"`
`POST /api/scout   {"mode":"war","base":205}` → same shape as a normal scout:
```jsonc
{ "ok":true, ...the usual kingdom view..., "target": { "id":"<token>", "name":"Cy", "emblem":"crest_5", "ratio":1, "levels":{...}, "seed":123, "power":5400,
        "loot":{"ruby":0,"emerald":0,"turq":0}, "tesla":1, "guard":{...}, "layout": {...snapshot record...}|absent,
        "mode":"war", "war":{"id":12,"base":205,"left":1} } }           // left = attacks still available AFTER this one
```
or `{"ok":false,"why":...}` with: `off` `no_war` `not_in_war` `not_battle` (+`"t"` = when the battle starts) `not_foe` `no_attacks` `maxed` (that base is already 3-starred: save the attack) `pending` (+`"base"`: finish that one first) `left_clan` `no_army` `slow` (+`"wait"` seconds: the usual scout cooldown — `findOpponent` already handles it) `closed`.
* **The attack is reserved when the token is issued.** Asking again for the same base while it is unfinished gives the same attack again (no second one is used); an attack that never reports back is counted as used with 0 stars after the token's lifetime.
* `findOpponent(econ, { opts: { mode:'war', base: 205 } })` (search.js) already forwards `opts` to this call; the battle then starts with `target` as usual (`target.layout` = the defender's snapshot layout).

`POST /api/battle/end  {"id":"<token>","rep":{...}}` — unchanged call. For a war token the server: validates exactly like a normal battle, but **no loot, no cups, no shield, no soldier or spell is spent, no XP / mission / pass event**; books the result into the war. Answer: the usual `{ok, ...kingdom view, info:{mode:"war", report:{...,"mode":"war","loot":{},"lost":{}}, loot:{}, stars}}` plus
`"war":{"id":12,"base":205,"st":2,"pc":71.5,"best":true,"us":{"st":14,"pc":812.5},"them":{"st":11,"pc":700.0},"left":1}`  (`best` = this is now the best result against that base). Re-sending the same end is safe (same answer).

## 4. Phases (all times server clock)
`search` → (match) → **prepare** `prep_h` (12 h; all enemy bases visible, the snapshot is frozen at the match) → **battle** `battle_h` (24 h; `attacks` per member) → **ended**. The battle ends at `te`, or earlier when every member has used every attack (`cfg early_end`) — never while an attack is in progress.
Winner = more stars; tie → more total destruction %; tie → the side that finished its result earlier; nothing at all → draw. Prizes (`cfg.prizes`) are paid to the members who made at least `prize_min` attacks, through the gift inbox (id `war:<war>:<uid>`, safe to repeat).
