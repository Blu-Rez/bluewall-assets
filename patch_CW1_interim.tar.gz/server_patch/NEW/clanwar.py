"""CW1 — clan war: two clans fight a timed war of snapshot bases.  (new module; the rest of the server only calls into it, see server_patch/)

Flow
    leader / co-leader  ->  search(size, roster)      the roster (5 / 10 / 15 / 20 members) is closed here; the clan joins the queue
    matchmaker          ->  two searches of the same size whose roster cups are close (the window widens while they wait)
                            no opponent after `search_minutes`  ->  the search ends by itself, nothing is lost
    PREPARE  (12 h)     the snapshot of every roster member's base (levels, guardians, Tesla, layout) is FROZEN at the match; all enemy bases can be looked at
    BATTLE   (24 h)     every member attacks the enemy bases `attacks_each` (2) times: the normal attack flow with mode "war" (no loot, no cups, no shield,
                        no soldier / spell spent, no XP / mission / pass event).  An attack is reserved when its token is issued (no free retries).
    ENDED               at the end time, or earlier when every member has used every attack; winner = more stars, then more destruction %, then who finished earlier
                        (the best result against each base counts); prizes go to members with >= `prize_min_attacks` attacks, through the gift inbox.

Everything runs from timestamps stored in the war record, and every step is idempotent: a restart in the middle of any phase finds the work again (`_repair`, `tick`)
and nothing is paid twice (the gift id is war:<war>:<uid>; the war records who was paid).

Storage (Redis, or memory when BLUEWALL_STATE=memory; a new ClanWar object over the same store = a restart):
    bluewall:war:<id>          JSON the war record            bluewall:war:<id>:b:<uid>   JSON the frozen spec of one base (attack target, layout)
    bluewall:war:seq           counter                        bluewall:war:active         SET of war ids not settled yet (the work list)
    bluewall:war:q             HASH clan id -> search entry   bluewall:clan:<id>:war      JSON {"k":"search",..} | {"k":"war","id":..}  (one war per clan)
    bluewall:war:u:<uid>       war id of a running war        bluewall:war:lu:<uid> / bluewall:clan:<id>:wlast  last finished war (3 days, for the result screen)
    bluewall:clan:<id>:wh      HASH war id -> summary         bluewall:clan:<id>:wnote    how the last search ended (6 h)
Numbers come from the liveops section "war" (war_defaults.json); a war keeps the rules it was made with.
"""
from __future__ import annotations

import asyncio
import hashlib
import importlib
import json
import logging
import os
import random
import time
from typing import Any, Dict, List, Optional, Set, Tuple

from . import military as MI
from . import progress as PR

log = logging.getLogger("bluewall.clanwar")

with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "war_defaults.json"), encoding="utf-8") as _f:
    DEFAULTS: Dict[str, Any] = json.load(_f)

SECTION, FLAG = "war", "clan_war"
K_WAR, K_BASE, K_SEQ, K_ACTIVE, K_Q = "bluewall:war:%d", "bluewall:war:%d:b:%d", "bluewall:war:seq", "bluewall:war:active", "bluewall:war:q"
K_PTR, K_UW, K_LASTW, K_CLAST = "bluewall:clan:%d:war", "bluewall:war:u:%d", "bluewall:war:lu:%d", "bluewall:clan:%d:wlast"
K_HIST, K_NOTE = "bluewall:clan:%d:wh", "bluewall:clan:%d:wnote"
RETAIN = 14 * 86400                 # a finished war record stays this long (Redis)
LAST_SEEN = 3 * 86400               # ... and is offered on the result screen this long
TIMEOUT = MI.BATTLE_TIMEOUT         # an attack token lives this long (seconds); an attack that never reports back is then booked as lost
MAX_REISSUE = 2                     # a started attack can be asked for again (crash / lost connection) this many times
LEAVE = ("keep", "forfeit", "remove")
PRIZE_CAP = {"turq": 5000, "emerald": 5000, "ruby": 5000, "sap": 1000, "onyx": 1000}     # = state.INBOX_MAX_TURQ / INBOX_MAX_PREM: a bigger gift would be cut by the inbox
LEAD_ROLES = ("co", "coleader", "co-leader", "co_leader", "leader")                       # CN1 roles that may start a war (the owner always may)


# ------------------------------------------------------------------ config
def validate(d: Dict[str, Any]) -> List[str]:
    """liveops validator for the section "war": a list of error strings (empty = fine)."""
    e: List[str] = []
    if not isinstance(d, dict):
        return ["war: not an object"]

    def num(src: Dict[str, Any], k: str, lo: float, hi: float, whole: bool = False, where: str = "") -> None:
        v = src.get(k)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v or not (lo <= v <= hi) or (whole and int(v) != v):
            e.append("%s%s: %s in %s..%s" % (where, k, "a whole number" if whole else "a number", lo, hi))

    s = d.get("sizes")
    if not isinstance(s, list) or not s or len(set(s)) != len(s) or any(isinstance(x, bool) or not isinstance(x, int) or not 2 <= x <= 30 for x in s):
        e.append("sizes: a list of distinct whole numbers 2..30 (a clan has at most 30 members)")
    num(d, "prep_hours", 0.01, 168)
    num(d, "battle_hours", 0.01, 168)
    num(d, "attacks_each", 1, 3, True)
    num(d, "search_minutes", 0.1, 1440)
    num(d, "prize_min_attacks", 0, 3, True)
    num(d, "tick_seconds", 5, 600)
    num(d, "log_keep", 20, 500, True)
    if d.get("leave") not in LEAVE:
        e.append("leave: one of %s" % ", ".join(LEAVE))
    if not isinstance(d.get("early_end"), bool):
        e.append("early_end: true or false")
    m = d.get("match")
    if not isinstance(m, dict):
        e.append("match: an object")
    else:
        num(m, "base_gap_pct", 0, 100, where="match.")
        num(m, "min_gap", 0, 100000, where="match.")
        num(m, "widen_pct_per_min", 0, 100, where="match.")
        num(m, "max_gap_pct", 0, 1000, where="match.")
        if not e and m["max_gap_pct"] < m["base_gap_pct"]:
            e.append("match.max_gap_pct must be >= base_gap_pct")
    p = d.get("prizes")
    if not isinstance(p, dict) or set(p) != {"win", "draw", "lose"}:
        e.append("prizes: an object with win, draw, lose")
    else:
        for o, g in p.items():
            if not isinstance(g, dict):
                e.append("prizes.%s: an object of gem -> amount" % o)
                continue
            for k, v in g.items():
                if k not in PRIZE_CAP:
                    e.append("prizes.%s.%s: unknown currency (turq, emerald, ruby, sap, onyx)" % (o, k))
                elif isinstance(v, bool) or not isinstance(v, int) or not 0 <= v <= PRIZE_CAP[k]:
                    e.append("prizes.%s.%s: a whole number 0..%d (the gift inbox cuts anything bigger)" % (o, k, PRIZE_CAP[k]))
    return e


def _merge(base: Dict[str, Any], over: Any) -> Dict[str, Any]:
    out = json.loads(json.dumps(base))
    if isinstance(over, dict):
        for k, v in over.items():
            if isinstance(v, dict) and isinstance(out.get(k), dict):
                out[k].update(v)
            else:
                out[k] = v
    return out


# ------------------------------------------------------------------ storage (Redis or memory)
class _Kv:
    """The few storage calls the war needs.  Memory mode keeps its data on the Store object, so a fresh ClanWar over the same Store is exactly a restart."""

    def __init__(self, store: Any) -> None:
        self.s = store
        self.m: Dict[str, Any] = store.__dict__.setdefault("_cw_mem", {})

    async def _r(self):
        return await self.s._redis()

    @staticmethod
    async def _io(coro):
        try:
            return await asyncio.wait_for(coro, 2.0)
        except Exception as e:  # noqa: BLE001
            from .state import StateUnavailable
            raise StateUnavailable("war storage: %s" % e) from e

    async def get(self, key: str) -> Any:
        r = await self._r()
        if r is None:
            v = self.m.get(key)
            return json.loads(v) if isinstance(v, str) else None
        raw = await self._io(r.get(key))
        return json.loads(raw) if raw else None

    async def put(self, key: str, obj: Any, ex: Optional[int] = None) -> None:
        raw = json.dumps(obj, separators=(",", ":"))
        r = await self._r()
        if r is None:
            self.m[key] = raw
            return
        await self._io(r.set(key, raw, ex=ex) if ex else r.set(key, raw))

    async def delete(self, key: str) -> None:
        r = await self._r()
        if r is None:
            self.m.pop(key, None)
            return
        await self._io(r.delete(key))

    async def incr(self, key: str) -> int:
        r = await self._r()
        if r is None:
            self.m[key] = int(self.m.get(key, 0)) + 1
            return int(self.m[key])
        return int(await self._io(r.incr(key)))

    async def hall(self, key: str) -> Dict[str, Any]:
        r = await self._r()
        raw = dict(self.m.get(key) or {}) if r is None else await self._io(r.hgetall(key))
        return {str(f): json.loads(v) for f, v in raw.items()}

    async def hput(self, key: str, f: str, obj: Any) -> None:
        raw = json.dumps(obj, separators=(",", ":"))
        r = await self._r()
        if r is None:
            self.m.setdefault(key, {})[f] = raw
            return
        await self._io(r.hset(key, f, raw))

    async def hdel(self, key: str, f: str) -> None:
        r = await self._r()
        if r is None:
            (self.m.get(key) or {}).pop(f, None)
            return
        await self._io(r.hdel(key, f))

    async def sall(self, key: str) -> List[str]:
        r = await self._r()
        if r is None:
            return sorted(self.m.get(key) or ())
        return sorted(str(x) for x in await self._io(r.smembers(key)))

    async def sadd(self, key: str, v: str) -> None:
        r = await self._r()
        if r is None:
            self.m.setdefault(key, set()).add(v)
            return
        await self._io(r.sadd(key, v))

    async def srem(self, key: str, v: str) -> None:
        r = await self._r()
        if r is None:
            (self.m.get(key) or set()).discard(v)
            return
        await self._io(r.srem(key, v))


# ------------------------------------------------------------------ pure rules
def base_spec(st: Dict[str, Any], uid: int, wid: int) -> Dict[str, Any]:
    """The frozen attack target of one member's base (what an enemy fights).  Fields as in military.player_target, but no loot and no fairness check; the seed is fixed per base."""
    lv = {e: PR.level(st, e) for e in ("keep", "wall", "towers")}
    tesla = max(0, min(4, int((st.get("own") or {}).get("tesla", 0) or 0)))
    power = MI.defence_power(lv, MI.army_power(st)) * (1.0 + 0.08 * tesla)
    seed = int(hashlib.sha256(("war:%d:%d" % (wid, uid)).encode()).hexdigest()[:8], 16) % (2 ** 31 - 2) + 1
    spec = {"kind": "war", "name": (str(st.get("name") or "").strip() or "Kingdom")[:24], "emblem": MI.emblem_of(st, uid), "ratio": 1.0, "levels": lv, "seed": seed,
            "power": int(power), "loot": {g: 0 for g in MI.GEMS}, "tesla": tesla, "guard": MI.victim_guard(st), "_war": wid, "_base": uid}
    lay = st.get("layout")
    if isinstance(lay, dict) and lay.get("m"):
        spec["layout"] = lay
    return spec


def _key(a: Dict[str, Any]) -> Tuple[int, float, float]:
    """the order of two results against the same base: more stars, then more destruction, then the earlier one"""
    return (int(a["st"]), round(float(a["pc"]), 2), -float(a["t"]))


def score(war: Dict[str, Any], removed: Set[int] = frozenset()) -> Tuple[List[Dict[str, Any]], Dict[int, Dict[str, Any]]]:
    """-> ([side 0 result, side 1 result], best attack per base).  Side i's result = what side i's attackers took from the OTHER side's bases (best result per base)."""
    best: Dict[int, Dict[str, Any]] = {}
    for a in war["atk"]:
        if a.get("lost") or a["by"] in removed or a["base"] in removed:
            continue
        cur = best.get(a["base"])
        if cur is None or _key(a) > _key(cur):
            best[a["base"]] = a
    sc = [{"st": 0, "pc": 0.0, "t": 0.0}, {"st": 0, "pc": 0.0, "t": 0.0}]
    for a in best.values():
        s = sc[a["side"]]
        s["st"] += int(a["st"])
        s["pc"] = round(s["pc"] + float(a["pc"]), 2)
        s["t"] = max(s["t"], float(a["t"]))
    return sc, best


def decide(sc: List[Dict[str, Any]]) -> Tuple[Optional[int], str]:
    """winner side (0 / 1 / None = draw) and the reason: stars, then total destruction %, then the side that finished earlier"""
    a, b = sc
    if a["st"] != b["st"]:
        return (0 if a["st"] > b["st"] else 1), "stars"
    if round(a["pc"], 2) != round(b["pc"], 2):
        return (0 if a["pc"] > b["pc"] else 1), "pct"
    if a["st"] == 0 and a["pc"] == 0:
        return None, "draw"
    if a["t"] != b["t"]:
        return (0 if a["t"] < b["t"] else 1), "time"
    return None, "draw"


def _members(c: Optional[Dict[str, Any]]) -> List[int]:
    return [int(x) for x in (c or {}).get("members", [])]


def _is_lead(c: Dict[str, Any], uid: int) -> bool:
    """owner, or a co-leader.  (CN1 decides how roles are stored: this is the ONE place to adapt.  Today: the owner; a `co` list or a `roles` map {uid: role} when present.)"""
    if int(c.get("owner", 0) or 0) == uid:
        return True
    if uid in [int(x) for x in (c.get("co") or [])]:
        return True
    return str((c.get("roles") or {}).get(str(uid), "")).lower() in LEAD_ROLES


# ------------------------------------------------------------------ the war service
class ClanWar:
    def __init__(self, store: Any, lo: Any = None) -> None:
        self.s = store
        self.kv = _Kv(store)
        self._lo = lo                                         # liveops module (or a stub); None = look it up; False = none
        self._wl: Dict[int, asyncio.Lock] = {}
        self._gl = asyncio.Lock()                             # matchmaking / search / cancel
        self._bl = asyncio.Lock()
        self._booted = False
        self._task: Optional[asyncio.Task] = None

    # ---- config
    def set_liveops(self, lo: Any) -> None:
        self._lo = lo
        if lo:
            try:
                lo.register(SECTION, DEFAULTS, validate)          # (the same registration as the normal lookup does)
            except Exception as e:  # noqa: BLE001
                log.warning("liveops.register(war) failed: %s", e)

    def _lo_obj(self) -> Any:
        if self._lo is None:
            try:
                lo = importlib.import_module((__package__ or "bluewall") + ".liveops")
                try:
                    lo.register(SECTION, DEFAULTS, validate)
                except Exception as e:  # noqa: BLE001
                    log.warning("liveops.register(war) failed: %s", e)
                self._lo = lo
            except Exception:  # noqa: BLE001
                self._lo = False
        return self._lo or None

    def cfg(self) -> Dict[str, Any]:
        lo, d = self._lo_obj(), None
        if lo:
            try:
                d = lo.get(SECTION)
            except Exception as e:  # noqa: BLE001
                log.warning("liveops.get(war) failed: %s", e)
        return _merge(DEFAULTS, d)

    def flag(self) -> bool:
        lo = self._lo_obj()
        if not lo:
            return False
        try:
            return bool(lo.flag(FLAG))
        except Exception:  # noqa: BLE001
            return False

    # ---- small helpers
    def _wlock(self, wid: int) -> asyncio.Lock:
        if len(self._wl) > 500:
            for k in [k for k, v in self._wl.items() if not v.locked() and not getattr(v, "_waiters", None)]:
                del self._wl[k]
        return self._wl.setdefault(int(wid), asyncio.Lock())

    async def _clan(self, cid: int) -> Optional[Dict[str, Any]]:
        if not cid:
            return None
        cl = self.s.clans
        return await (getattr(cl, "get", None) or cl._get)(int(cid))

    async def _my_clan(self, uid: int) -> Tuple[int, Optional[Dict[str, Any]]]:
        st = await self.s.load(uid)
        cid = int(st.get("clan") or 0)
        c = await self._clan(cid)
        if c and uid not in _members(c):
            c = None
        return (cid if c else 0), c

    async def _load(self, wid: int) -> Optional[Dict[str, Any]]:
        return await self.kv.get(K_WAR % int(wid))

    async def _save(self, war: Dict[str, Any]) -> None:
        await self.kv.put(K_WAR % int(war["id"]), war, ex=RETAIN if war.get("done") else None)

    @staticmethod
    def _side_of(war: Dict[str, Any], uid: int) -> Optional[int]:
        for i in (0, 1):
            if str(uid) in war["s"][i]["b"]:
                return i
        return None

    async def _left_all(self, war: Dict[str, Any]) -> Set[int]:
        """roster members that are no longer in their clan (left, kicked, clan gone)"""
        out: Set[int] = set()
        for i in (0, 1):
            mem = set(_members(await self._clan(war["s"][i]["cid"])))
            out.update(u for u in war["s"][i]["roster"] if u not in mem)
        return out

    @staticmethod
    def _used(war: Dict[str, Any], uid: int) -> int:
        return sum(1 for a in war["atk"] if a["by"] == uid) + (1 if str(uid) in war["pend"] else 0)

    @staticmethod
    def _name(war: Dict[str, Any], uid: int) -> str:
        for i in (0, 1):
            b = war["s"][i]["b"].get(str(uid))
            if b:
                return b["n"]
        return "?"

    @staticmethod
    def _logev(war: Dict[str, Any], ev: Dict[str, Any]) -> None:
        war["log"].append(ev)
        del war["log"][:-int(war["cfg"].get("log_keep", 120))]

    # ---- boot / repair (restart safety)
    async def _boot(self) -> None:
        if self._booted:
            return
        async with self._bl:
            if not self._booted:
                await self._repair()
                self._booted = True

    async def _repair(self) -> None:
        """after a restart, or a crash while a war was being made: every unsettled war has its links again, and a clan that is in a war is not in the queue"""
        for w in await self.kv.sall(K_ACTIVE):
            war = await self._load(int(w))
            if not war:
                await self.kv.srem(K_ACTIVE, w)
            elif not war.get("done"):
                await self._link(war)

    async def _link(self, war: Dict[str, Any]) -> None:
        for i in (0, 1):
            cid = int(war["s"][i]["cid"])
            await self.kv.hdel(K_Q, str(cid))
            p = await self.kv.get(K_PTR % cid)
            if not p or p.get("id") != war["id"]:
                await self.kv.put(K_PTR % cid, {"k": "war", "id": war["id"]})
            for u in war["s"][i]["roster"]:
                await self.kv.put(K_UW % int(u), war["id"])

    async def _release(self, war: Dict[str, Any]) -> None:
        """the war is over and paid: free the clans (a new war may start), remember it for the result screen and the history"""
        res = war["res"]
        sc = res["sc"]
        for i in (0, 1):
            s, o = war["s"][i], war["s"][1 - i]
            cid = int(s["cid"])
            p = await self.kv.get(K_PTR % cid)
            if p and p.get("k") == "war" and p.get("id") == war["id"]:
                await self.kv.delete(K_PTR % cid)
            await self.kv.put(K_CLAST % cid, war["id"], ex=LAST_SEEN)
            for u in s["roster"]:
                if await self.kv.get(K_UW % int(u)) == war["id"]:
                    await self.kv.delete(K_UW % int(u))
                await self.kv.put(K_LASTW % int(u), war["id"], ex=LAST_SEEN)
            won = "draw" if res["w"] is None else ("win" if res["w"] == i else "lose")
            await self.kv.hput(K_HIST % cid, str(war["id"]), {"id": war["id"], "t": res["t"], "won": won, "vs": {"name": o["name"], "tag": o["tag"]},
                                                              "st": [sc[i]["st"], sc[1 - i]["st"]], "pc": [sc[i]["pc"], sc[1 - i]["pc"]], "size": war["size"]})
            hist = await self.kv.hall(K_HIST % cid)
            for f in sorted(hist, key=lambda k: -float(hist[k]["t"]))[10:]:
                await self.kv.hdel(K_HIST % cid, f)
            for u in s["roster"]:
                await self.kv.delete(K_BASE % (war["id"], int(u)))

    # ---- search / cancel
    async def _leader(self, uid: int) -> Tuple[Optional[Dict[str, Any]], int, Optional[str]]:
        cid, c = await self._my_clan(uid)
        if not c:
            return None, 0, "no_clan"
        if not _is_lead(c, uid):
            return c, cid, "not_leader"
        return c, cid, None

    async def search(self, uid: int, size: Any, roster: Any) -> Dict[str, Any]:
        if not self.flag():
            return {"ok": False, "why": "off"}
        await self._boot()
        cfg = self.cfg()
        try:
            size = int(size)
            ids = [int(x) for x in roster]
        except (TypeError, ValueError):
            return {"ok": False, "why": "roster"}
        if size not in cfg["sizes"]:
            return {"ok": False, "why": "size"}
        c, cid, why = await self._leader(uid)
        if why:
            return {"ok": False, "why": why}
        if await self.kv.get(K_PTR % cid):                                 # (the clan is already searching / at war: say that first)
            return {"ok": False, "why": "busy"}
        mem = set(_members(c))
        if len(ids) != size or len(set(ids)) != size or any(u not in mem for u in ids):
            return {"ok": False, "why": "roster"}
        for u in ids:
            if await self.kv.get(K_UW % u):                                # (a member that is still in a war of its old clan cannot be in two)
                return {"ok": False, "why": "roster"}
        rows = {r["id"]: r for r in await self.s.clans._members(c)}
        total = sum(int((rows.get(u) or {}).get("tro", 0)) for u in ids)
        now = time.time()
        async with self._gl:
            if await self.kv.get(K_PTR % cid):
                return {"ok": False, "why": "busy"}
            e = {"cid": cid, "size": size, "roster": ids, "score": total, "t0": now, "by": uid}
            await self.kv.hput(K_Q, str(cid), e)
            await self.kv.put(K_PTR % cid, dict(e, k="search"))
            await self.kv.delete(K_NOTE % cid)
        await self.match(now)                                              # (an opponent may be waiting already)
        return {"ok": True}

    async def cancel(self, uid: int) -> Dict[str, Any]:
        if not self.flag():
            return {"ok": False, "why": "off"}
        await self._boot()
        c, cid, why = await self._leader(uid)
        if why:
            return {"ok": False, "why": why}
        async with self._gl:
            p = await self.kv.get(K_PTR % cid)
            if not p:
                return {"ok": False, "why": "no_search"}
            if p.get("k") == "war":
                return {"ok": False, "why": "in_war"}
            await self._drop_search(cid, "cancelled")
        return {"ok": True}

    async def _drop_search(self, cid: int, why: str) -> None:
        await self.kv.hdel(K_Q, str(cid))
        p = await self.kv.get(K_PTR % cid)
        if p and p.get("k") == "search":
            await self.kv.delete(K_PTR % cid)
        await self.kv.put(K_NOTE % cid, {"t": time.time(), "why": why}, ex=6 * 3600)

    # ---- matchmaking
    @staticmethod
    def _gap_ok(e: Dict[str, Any], f: Dict[str, Any], now: float, m: Dict[str, Any]) -> bool:
        avg = (e["score"] + f["score"]) / 2.0
        waited = max(now - e["t0"], now - f["t0"]) / 60.0
        pct = min(float(m["max_gap_pct"]), float(m["base_gap_pct"]) + float(m["widen_pct_per_min"]) * waited)
        return abs(e["score"] - f["score"]) <= max(float(m["min_gap"]), avg * pct / 100.0)

    async def match(self, now: Optional[float] = None) -> int:
        """end the searches that waited too long, pair the others; returns how many wars were made"""
        now = time.time() if now is None else now
        cfg = self.cfg()
        made = 0
        async with self._gl:
            q = sorted((await self.kv.hall(K_Q)).values(), key=lambda x: (x["t0"], x["cid"]))
            live: List[Dict[str, Any]] = []
            for e in q:
                if now - e["t0"] > cfg["search_minutes"] * 60:
                    await self._drop_search(int(e["cid"]), "no_match")
                else:
                    live.append(e)
            if not self.flag():
                return 0
            used: Set[int] = set()
            for e in live:
                if e["cid"] in used:
                    continue
                best, bgap = None, 0.0
                for f in live:
                    if f["cid"] == e["cid"] or f["cid"] in used or f["size"] != e["size"] or not self._gap_ok(e, f, now, cfg["match"]):
                        continue
                    gap = abs(e["score"] - f["score"])
                    if best is None or gap < bgap or (gap == bgap and f["t0"] < best["t0"]):
                        best, bgap = f, gap
                if best is not None:
                    try:
                        if await self._make_war(e, best, now, cfg):
                            made += 1
                            used.update((e["cid"], best["cid"]))
                    except Exception:  # noqa: BLE001
                        used.update((e["cid"], best["cid"]))                # (never a second try in the same pass: the war record may already exist; _repair links it at the next boot / tick)
                        log.exception("clan war: could not make a war for clans %s / %s (they stay in the queue)", e["cid"], best["cid"])
        return made

    async def _make_war(self, e: Dict[str, Any], f: Dict[str, Any], now: float, cfg: Dict[str, Any]) -> bool:
        """(called with the matchmaking lock) snapshot both rosters and open the war.  False = one of the two searches was no longer valid (it is dropped)."""
        clans = []
        for x in (e, f):
            c = await self._clan(int(x["cid"]))
            mem = set(_members(c))
            busy = False
            for u in x["roster"]:
                if await self.kv.get(K_UW % int(u)):
                    busy = True
            if not c or busy or any(int(u) not in mem for u in x["roster"]):
                await self._drop_search(int(x["cid"]), "roster")
                return False
            clans.append(c)
        wid = await self.kv.incr(K_SEQ)
        sides, specs = [], []
        for x, c in zip((e, f), clans):
            rows = []
            for u in x["roster"]:
                async with self.s._lock(int(u)):
                    st = await self.s.load(int(u))
                PR.settle(st, now)
                MI.settle(st, now)
                rows.append((int(st.get("tro", 0) or 0), int(u), st))
            rows.sort(key=lambda r: (-r[0], r[1]))
            b = {}
            for tro, u, st in rows:
                spec = base_spec(st, u, wid)
                specs.append((u, spec))
                b[str(u)] = {"n": spec["name"], "e": spec["emblem"], "k": PR.keep_level(st), "tro": tro, "lv": spec["levels"], "power": spec["power"], "tesla": spec["tesla"]}
            sides.append({"cid": int(c["id"]), "name": c["name"], "tag": c["tag"], "roster": [u for _t, u, _s in rows], "b": b,
                          "score": sum(r[0] for r in rows)})
        for u, spec in specs:                                              # (bases first, then the war record = the commit point; links are repaired by _link / _repair)
            await self.kv.put(K_BASE % (wid, u), spec, ex=int((cfg["prep_hours"] + cfg["battle_hours"]) * 3600) + 4 * 86400)
        pz = {k: {g: int(n) for g, n in v.items() if int(n) > 0} for k, v in cfg["prizes"].items()}
        war = {"v": 1, "id": wid, "size": int(e["size"]), "t0": now, "tb": now + cfg["prep_hours"] * 3600.0, "te": now + (cfg["prep_hours"] + cfg["battle_hours"]) * 3600.0,
               "ph": "prep", "s": sides, "atk": [], "pend": {}, "res": None, "done": False,
               "log": [{"t": now, "k": "found"}],
               "cfg": {"attacks": int(cfg["attacks_each"]), "leave": cfg["leave"], "early": bool(cfg["early_end"]), "pmin": int(cfg["prize_min_attacks"]),
                       "prizes": pz, "log_keep": int(cfg["log_keep"]), "prep_h": cfg["prep_hours"], "battle_h": cfg["battle_hours"]}}
        await self.kv.put(K_WAR % wid, war)
        await self.kv.sadd(K_ACTIVE, str(wid))
        await self._link(war)
        log.info("clan war %d: %s [%s] vs %s [%s], %d a side", wid, sides[0]["name"], sides[0]["tag"], sides[1]["name"], sides[1]["tag"], war["size"])
        return True

    # ---- phases / settlement (idempotent)
    async def advance(self, wid: int, now: Optional[float] = None) -> Optional[Dict[str, Any]]:
        return await self._advance(int(wid), time.time() if now is None else now)

    async def _advance(self, wid: int, now: float) -> Optional[Dict[str, Any]]:
        async with self._wlock(wid):
            war = await self._load(wid)
            if war is None:
                await self.kv.srem(K_ACTIVE, str(wid))
                return None
            dirty = False
            for u, p in list(war["pend"].items()):                          # an attack that never reported back: used, 0 stars
                if now - p["t"] > TIMEOUT + 30:
                    self._book_lost(war, int(u), p, now)
                    dirty = True
            if war["ph"] == "prep" and now >= war["tb"]:
                war["ph"] = "battle"
                self._logev(war, {"t": war["tb"], "k": "phase", "ph": "battle"})
                dirty = True
            if war["ph"] == "battle" and not war["pend"]:
                end = now >= war["te"]
                if not end and war["cfg"]["early"] and war["atk"]:
                    end = await self._all_done(war)
                if end:
                    await self._decide(war, now)
                    dirty = True
            if war["ph"] == "ended" and not war["done"]:
                if dirty:
                    await self._save(war)                                   # (the result is on disk before anything is paid)
                    dirty = False
                if await self._pay(war):
                    await self._save(war)
                    await self._release(war)
                    war["done"] = True
                    await self._save(war)
                    await self.kv.srem(K_ACTIVE, str(wid))
                    dirty = False
                else:
                    dirty = True
            if dirty:
                await self._save(war)
            return war

    async def _all_done(self, war: Dict[str, Any]) -> bool:
        """every member has used every attack (a member that left the clan cannot attack any more unless the rule is `keep`)"""
        att = war["cfg"]["attacks"]
        rest = [u for i in (0, 1) for u in war["s"][i]["roster"] if self._used(war, u) < att]
        if not rest:
            return True
        if war["cfg"]["leave"] == "keep":
            return False
        left = await self._left_all(war)
        return all(u in left for u in rest)

    async def _decide(self, war: Dict[str, Any], now: float) -> None:
        left = await self._left_all(war)
        removed = left if war["cfg"]["leave"] == "remove" else set()
        sc, _best = score(war, removed)
        w, why = decide(sc)
        pz: Dict[str, Dict[str, int]] = {}
        for i in (0, 1):
            outcome = "draw" if w is None else ("win" if w == i else "lose")
            prize = war["cfg"]["prizes"].get(outcome) or {}
            for u in war["s"][i]["roster"]:
                made = sum(1 for a in war["atk"] if a["by"] == u and not a.get("lost"))
                if prize and made >= war["cfg"]["pmin"] and (u not in left or war["cfg"]["leave"] == "keep"):
                    pz[str(u)] = dict(prize)
        war["res"] = {"w": w, "why": why, "early": now < war["te"] - 1, "sc": sc, "pz": pz, "pay": {u: 0 for u in pz}, "t": min(now, war["te"]),
                      "removed": sorted(removed)}
        war["ph"] = "ended"
        self._logev(war, {"t": war["res"]["t"], "k": "end"})
        log.info("clan war %d ended: winner side %s (%s) stars %s / %s", war["id"], w, why, sc[0]["st"], sc[1]["st"])

    async def _pay(self, war: Dict[str, Any]) -> bool:
        pay, pz = war["res"]["pay"], war["res"]["pz"]
        for u, ok in list(pay.items()):
            if not ok and await self.s.push_inbox(int(u), dict(pz[u], id="war:%d:%s" % (war["id"], u), src="war", t=int(time.time()))):
                pay[u] = 1
        return all(pay.values())

    @staticmethod
    def _book_lost(war: Dict[str, Any], uid: int, p: Dict[str, Any], now: float) -> None:
        side = ClanWar._side_of(war, uid)
        war["atk"].append({"i": len(war["atk"]), "id": p["id"], "by": uid, "base": int(p["base"]), "side": side, "t": now, "st": 0, "pc": 0.0, "lost": True})
        war["pend"].pop(str(uid), None)
        ClanWar._logev(war, {"t": now, "k": "lost", "by": uid, "bn": ClanWar._name(war, uid), "side": side})

    async def tick(self, now: Optional[float] = None) -> None:
        """one round of the clock: searches, matches, phases, prizes.  Safe to call as often as you like, from any number of places."""
        now = time.time() if now is None else now
        await self._boot()
        try:
            await self.match(now)
        except Exception:  # noqa: BLE001
            log.exception("clan war: match pass failed")
        for w in await self.kv.sall(K_ACTIVE):
            try:
                await self._advance(int(w), now)
            except Exception:  # noqa: BLE001
                log.exception("clan war %s: advance failed (retried next round)", w)

    async def _loop(self) -> None:
        while True:
            try:
                await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception("clan war clock")
            await asyncio.sleep(max(5.0, float(self.cfg().get("tick_seconds", 30))))

    def start(self) -> None:
        if self._task is None or self._task.done():
            self._task = asyncio.get_event_loop().create_task(self._loop())

    async def stop(self) -> None:
        t, self._task = self._task, None
        if t:
            t.cancel()
            try:
                await t
            except BaseException:  # noqa: BLE001
                pass

    # ---- attacks
    async def scout(self, uid: int, base: Any) -> Dict[str, Any]:
        """POST /api/scout {mode:"war", base}: reserve an attack on an enemy base and return the target (same shape as a normal scout)."""
        from . import state as ST
        if not self.flag():
            return {"ok": False, "why": "off"}
        if not MI.attack_allowed(uid, ST._owner_ids(), ST.ATTACK_PUBLIC):
            return {"ok": False, "why": "closed"}
        await self._boot()
        try:
            buid = int(base)
        except (TypeError, ValueError):
            return {"ok": False, "why": "not_foe"}
        wid = await self.kv.get(K_UW % uid)
        if not wid:
            return {"ok": False, "why": "no_war"}
        if await self._advance(int(wid), time.time()) is None:
            return {"ok": False, "why": "no_war"}
        async with self.s._lock(uid):
            st = await self.s._txn(uid)
            now = time.time()
            async with self._wlock(int(wid)):
                war = await self._load(int(wid))
                if not war or war["ph"] == "ended":
                    return {"ok": False, "why": "no_war"}
                side = self._side_of(war, uid)
                if side is None:
                    return {"ok": False, "why": "not_in_war"}
                if now < war["tb"]:
                    return {"ok": False, "why": "not_battle", "t": war["tb"]}
                if now >= war["te"]:
                    return {"ok": False, "why": "no_war"}
                if str(buid) not in war["s"][1 - side]["b"]:
                    return {"ok": False, "why": "not_foe"}
                if war["cfg"]["leave"] != "keep" and uid not in _members(await self._clan(war["s"][side]["cid"])):
                    return {"ok": False, "why": "left_clan"}
                spec = await self.kv.get(K_BASE % (int(wid), buid))
                if spec is None:
                    return {"ok": False, "why": "no_war"}
                p = war["pend"].get(str(uid))
                if p and now - p["t"] > TIMEOUT:                           # (the old unfinished attack ran out: it is used, 0 stars)
                    self._book_lost(war, uid, p, now)
                    await self._save(war)
                    p = None
                if p:
                    if int(p["base"]) != buid or int(p.get("n", 0)) >= MAX_REISSUE:
                        return {"ok": False, "why": "pending", "base": int(p["base"])}
                    tid = p["id"]
                    p["t"], p["n"] = now, int(p.get("n", 0)) + 1           # (asking again for the same base = the same attack, not a second one)
                else:
                    made = sum(1 for a in war["atk"] if a["by"] == uid)
                    if made >= war["cfg"]["attacks"]:
                        return {"ok": False, "why": "no_attacks"}
                    cur = score(war)[1].get(buid)
                    if cur is not None and int(cur["st"]) >= 3:
                        return {"ok": False, "why": "maxed"}
                    if MI.space_of(MI.attack_army(st)) <= 0:
                        return {"ok": False, "why": "no_army"}
                    wait = MI.scout_wait(st, now, 2.0 if uid in ST._owner_ids() else None)
                    if wait > 0:
                        return {"ok": False, "why": "slow", "wait": round(wait, 1)}
                    tid = "%x%x" % (int(now * 1000), random.randrange(1 << 20))
                    war["pend"][str(uid)] = {"id": tid, "base": buid, "t": now, "n": 0}
                left_after = max(0, war["cfg"]["attacks"] - self._used(war, uid))
                await self._save(war)
            st["atk"] = {"id": tid, "spec": spec, "t": now, "done": False, "mode": "war", "war": int(wid), "base": buid}
            await self.s.save(uid, st)
            out = self.s.view(st, None, uid)
            tgt = {k: v for k, v in spec.items() if not k.startswith("_") and k != "kind"}
            out.update({"ok": True, "why": None, "target": dict(tgt, id=tid, mode="war", war={"id": int(wid), "base": buid, "left": left_after})})
            return out

    async def is_war_token(self, uid: int, tid: str) -> bool:
        a = (await self.s.load(uid)).get("atk") or {}
        return a.get("id") == tid and a.get("mode") == "war"

    async def battle_end(self, uid: int, tid: str, rep: Dict[str, Any]) -> Dict[str, Any]:
        """POST /api/battle/end for a war token: validate like any battle (military.settle_battle, the CW1 block), spend nothing, book the result into the war."""
        from . import state as ST
        if not MI.attack_allowed(uid, ST._owner_ids(), ST.ATTACK_PUBLIC):
            return {"ok": False, "why": "closed"}
        await self._boot()
        async with self.s._lock(uid):
            st = await self.s._txn(uid)
            now = time.time()
            a = st.get("atk") or {}
            wid, buid = int(a.get("war") or 0), int(a.get("base") or 0)
            prev = await self._booked(wid, tid) if a.get("id") == tid and a.get("done") else None
            if prev is not None:                                           # (the same end sent again: the same answer, nothing is booked twice)
                att, rec = prev
                info = {"mode": "war", "report": {"t": att["t"], "target": self._name_of_base(rec, buid), "kind": "war", "mode": "war", "stars": att["st"], "destruction": att["pc"],
                                                  "loot": {}, "lost": {}, "sent": {}, "spells": {}}, "loot": {}, "stars": att["st"]}
            else:
                why, info = MI.settle_battle(st, tid, rep, now)
                if why != "ok":
                    return {"ok": False, "why": why}
                att, rec = await self._book(wid, uid, buid, tid, int(info["stars"]), float(info["report"]["destruction"]), now)
                if att is None:
                    return {"ok": False, "why": rec}                      # (nothing was saved: the token is untouched)
                await self.s.save(uid, st)
            await self._advance(wid, time.time())                          # (the last attack may end the war now)
            out = self.s.view(st, None, uid)
            out.update({"ok": True, "why": None, "info": info, "war": rec})
            return out

    @staticmethod
    def _name_of_base(rec: Dict[str, Any], buid: int) -> str:
        return str(rec.get("bn", "")) if isinstance(rec, dict) else ""

    async def _booked(self, wid: int, tid: str) -> Optional[Tuple[Dict[str, Any], Dict[str, Any]]]:
        war = await self._load(wid)
        for a in (war or {}).get("atk", []):
            if a["id"] == tid:
                return a, self._rec(war, a)
        return None

    def _rec(self, war: Dict[str, Any], att: Dict[str, Any]) -> Dict[str, Any]:
        sc, best = score(war)
        side = int(att["side"])
        cur = best.get(att["base"])
        return {"id": war["id"], "base": att["base"], "bn": self._name(war, att["base"]), "st": att["st"], "pc": att["pc"], "best": bool(cur and cur["id"] == att["id"]),
                "us": {"st": sc[side]["st"], "pc": sc[side]["pc"]}, "them": {"st": sc[1 - side]["st"], "pc": sc[1 - side]["pc"]},
                "left": max(0, war["cfg"]["attacks"] - self._used(war, att["by"]))}

    async def _book(self, wid: int, uid: int, buid: int, tid: str, stars: int, pct: float, now: float) -> Tuple[Optional[Dict[str, Any]], Any]:
        async with self._wlock(wid):
            war = await self._load(wid)
            if not war:
                return None, "no_war"
            for a in war["atk"]:
                if a["id"] == tid:
                    return a, self._rec(war, a)
            p = war["pend"].get(str(uid))
            if not p or p["id"] != tid or int(p["base"]) != buid:
                return None, ("war_over" if war["ph"] == "ended" else "no_target")
            side = self._side_of(war, uid)
            cur = score(war)[1].get(buid)
            att = {"i": len(war["atk"]), "id": tid, "by": uid, "base": buid, "side": side, "t": now, "st": int(stars), "pc": round(float(pct), 2)}
            war["atk"].append(att)
            del war["pend"][str(uid)]
            self._logev(war, {"t": now, "k": "atk", "by": uid, "bn": self._name(war, uid), "side": side, "base": buid, "tn": self._name(war, buid), "st": att["st"], "pc": att["pc"],
                              "best": cur is None or _key(att) > _key(cur)})
            await self._save(war)
            return att, self._rec(war, att)

    # ---- views
    @staticmethod
    def _pubcfg(cfg: Dict[str, Any]) -> Dict[str, Any]:
        return {"sizes": cfg["sizes"], "prep_h": cfg["prep_hours"], "battle_h": cfg["battle_hours"], "attacks": cfg["attacks_each"], "search_min": cfg["search_minutes"],
                "leave": cfg["leave"], "prize_min": cfg["prize_min_attacks"], "prizes": cfg["prizes"]}

    async def view(self, uid: int) -> Dict[str, Any]:
        """GET /api/clan/war — everything the war screens draw (shapes: server_patch/ROUTES.md)"""
        if not self.flag():
            return {"on": False}
        await self._boot()
        cfg, now = self.cfg(), time.time()
        cid, c = await self._my_clan(uid)
        out: Dict[str, Any] = {"on": True, "now": now, "cfg": self._pubcfg(cfg), "clan": None, "state": "none", "free": False, "cands": None, "search": None, "note": None,
                               "war": None, "last": []}
        ptr = await self.kv.get(K_PTR % cid) if c else None
        wid = await self.kv.get(K_UW % uid) or (ptr.get("id") if ptr and ptr.get("k") == "war" else None)
        if c:
            out["clan"] = {"id": cid, "name": c["name"], "tag": c["tag"], "n": len(_members(c)), "lead": _is_lead(c, uid)}
            out["last"] = sorted((await self.kv.hall(K_HIST % cid)).values(), key=lambda x: -float(x["t"]))[:5]
        if not wid:
            wid = await self.kv.get(K_LASTW % uid) or (await self.kv.get(K_CLAST % cid) if c else None)
        war = await self._advance(int(wid), now) if wid else None
        if war is not None and self._side_of(war, uid) is None and not (c and cid in (war["s"][0]["cid"], war["s"][1]["cid"])):
            war = None
        if war is not None:
            out["war"] = await self._war_view(war, uid, cid)
            out["state"] = out["war"]["phase"]
            out["cfg"] = dict(out["cfg"], attacks=war["cfg"]["attacks"], leave=war["cfg"]["leave"], prizes=war["cfg"]["prizes"], prize_min=war["cfg"]["pmin"])
        if c:
            live = ptr is not None or (war is not None and not war["done"])
            if ptr and ptr.get("k") == "search":
                out["state"], out["war"] = "search", None
                out["search"] = {"size": ptr["size"], "t0": ptr["t0"], "until": ptr["t0"] + cfg["search_minutes"] * 60, "roster": ptr["roster"], "score": ptr["score"]}
            out["free"] = not live
            note = await self.kv.get(K_NOTE % cid)
            if note and not live:
                out["note"] = note
            if out["free"] and out["clan"]["lead"]:
                out["cands"] = [{"id": r["id"], "n": r["n"], "e": r["e"], "tro": r["tro"], "k": r["k"], "lg": r["lg"]} for r in await self.s.clans._members(c)]
        return out

    async def _war_view(self, war: Dict[str, Any], uid: int, cid: int) -> Optional[Dict[str, Any]]:
        mine = self._side_of(war, uid)
        inr = mine is not None
        if mine is None:
            mine = 0 if war["s"][0]["cid"] == cid else 1
        left = await self._left_all(war)
        res = war["res"]
        removed = set(res["removed"]) if res else (left if war["cfg"]["leave"] == "remove" else set())
        sc, best = score(war, removed)
        if res:
            sc = res["sc"]
        att = war["cfg"]["attacks"]
        rel = lambda i: "us" if i == mine else "them"            # noqa: E731

        def side_view(i: int) -> Dict[str, Any]:
            s = war["s"][i]
            rows = []
            for rank, u in enumerate(s["roster"], 1):
                b = s["b"][str(u)]
                a = best.get(u)
                rows.append({"id": u, "n": b["n"], "e": b["e"], "rank": rank, "k": b["k"], "tro": b["tro"], "lv": b["lv"], "power": b["power"], "tesla": b["tesla"],
                             "used": self._used(war, u), "left": u in left,
                             "best": {"st": a["st"], "pc": a["pc"], "by": a["by"], "bn": self._name(war, a["by"]), "t": a["t"]} if a else None})
            return {"clan": {"id": s["cid"], "name": s["name"], "tag": s["tag"]}, "stars": sc[i]["st"], "pct": sc[i]["pc"],
                    "used": sum(self._used(war, u) for u in s["roster"]), "max": att * len(s["roster"]), "roster": rows}

        p = war["pend"].get(str(uid))
        v = {"id": war["id"], "size": war["size"], "phase": "ended" if war["ph"] == "ended" else ("prep" if time.time() < war["tb"] else "battle"),
             "t0": war["t0"], "tb": war["tb"], "te": war["te"], "ended_at": war["res"]["t"] if res else None,
             "me": {"id": uid, "side": "us", "in": inr, "rank": (war["s"][mine]["roster"].index(uid) + 1) if inr else 0, "used": self._used(war, uid) if inr else 0,
                    "left": max(0, att - self._used(war, uid)) if inr else 0, "max": att, "pending": {"base": int(p["base"]), "t": p["t"]} if p else None,
                    "gone": uid in left},
             "us": side_view(mine), "them": side_view(1 - mine),
             "my": [{"base": a["base"], "bn": self._name(war, a["base"]), "st": a["st"], "pc": a["pc"], "t": a["t"], "lost": bool(a.get("lost"))} for a in war["atk"] if a["by"] == uid],
             "log": [dict(e, side=rel(e["side"])) if "side" in e and e["side"] is not None else dict(e) for e in war["log"][-60:]],
             "res": None}
        if res:
            w = res["w"]
            v["res"] = {"winner": "draw" if w is None else ("us" if w == mine else "them"), "why": res["why"], "early": res["early"],
                        "us": {"st": res["sc"][mine]["st"], "pc": res["sc"][mine]["pc"]}, "them": {"st": res["sc"][1 - mine]["st"], "pc": res["sc"][1 - mine]["pc"]},
                        "prize": res["pz"].get(str(uid)), "sent": bool(res["pay"].get(str(uid), 1))}
        return v

    async def base(self, uid: int, buid: Any) -> Dict[str, Any]:
        """POST /api/clan/war {op:"base", id}: the frozen snapshot of one ENEMY base (any member of either clan may look, from the start of the prepare phase)."""
        if not self.flag():
            return {"ok": False, "why": "off"}
        await self._boot()
        try:
            buid = int(buid)
        except (TypeError, ValueError):
            return {"ok": False, "why": "not_foe"}
        cid, _c = await self._my_clan(uid)
        wid = await self.kv.get(K_UW % uid) or ((await self.kv.get(K_PTR % cid) or {}).get("id") if cid else None)
        war = await self._load(int(wid)) if wid else None
        if not war or war["ph"] == "ended":
            return {"ok": False, "why": "no_war"}
        side = self._side_of(war, uid)
        if side is None:
            side = 0 if war["s"][0]["cid"] == cid else 1 if war["s"][1]["cid"] == cid else None
        if side is None or str(buid) not in war["s"][1 - side]["b"]:
            return {"ok": False, "why": "not_foe"}
        spec = await self.kv.get(K_BASE % (int(wid), buid))
        if spec is None:
            return {"ok": False, "why": "no_war"}
        b = war["s"][1 - side]["b"][str(buid)]
        return {"ok": True, "base": {"id": buid, "n": b["n"], "e": b["e"], "k": b["k"], "lv": spec["levels"], "power": spec["power"], "tesla": spec["tesla"], "guard": spec.get("guard") or {},
                                    "layout": spec.get("layout")}}

    async def dev(self, uid: int, body: Dict[str, Any]) -> Dict[str, Any]:
        """owner tools: {shift: seconds} moves the clock of my war forward (look at the phases without waiting)"""
        await self._boot()
        try:
            shift = float(body.get("shift") or 0)
        except (TypeError, ValueError):
            return {"ok": False, "why": "bad"}
        wid = await self.kv.get(K_UW % uid)
        if not wid:
            return {"ok": False, "why": "no_war"}
        async with self._wlock(int(wid)):
            war = await self._load(int(wid))
            if not war or war["ph"] == "ended":
                return {"ok": False, "why": "no_war"}
            for k in ("t0", "tb", "te"):
                war[k] -= shift
            await self._save(war)
        await self._advance(int(wid), time.time())
        return {"ok": True}


# ------------------------------------------------------------------ HTTP: GET|POST /api/clan/war  (server.py mounts this with one line)
def mount(app: Any, store_fn: Any, auth: Any, limited: Any, is_owner: Any) -> None:
    from aiohttp import web

    def resp(obj: Dict[str, Any], status: int = 200) -> Any:
        r = web.json_response(obj, status=status)
        r.headers["Cache-Control"] = "private, no-cache"
        r.headers["X-Content-Type-Options"] = "nosniff"
        return r

    async def h_war(req: Any) -> Any:
        uid = auth(req)
        if uid is None:
            return resp({"ok": False, "reason": "locked"}, 403)
        if limited("w:" + str(uid), 40):
            return resp({"ok": False, "reason": "slow"}, 429)
        cw = store_fn().clanwar
        if req.method == "POST":
            try:
                body = await req.json()
            except Exception:  # noqa: BLE001
                body = {}
            body = body if isinstance(body, dict) else {}
            op = str(body.get("op") or "")
            if op == "search":
                r = await cw.search(uid, body.get("size"), body.get("roster"))
            elif op == "cancel":
                r = await cw.cancel(uid)
            elif op == "base":
                return resp(await cw.base(uid, body.get("id")))
            elif op == "dev":
                if not is_owner(uid):
                    return resp({"ok": False, "reason": "locked"}, 403)
                r = await cw.dev(uid, body)
            else:
                return resp({"ok": False, "reason": "bad"}, 400)
            if not r.get("ok"):
                return resp(r)
        return resp(dict(await cw.view(uid), ok=True))

    async def on_start(_app: Any) -> None:
        store_fn().clanwar.start()

    async def on_stop(_app: Any) -> None:
        await store_fn().clanwar.stop()

    app.router.add_get("/api/clan/war", h_war)
    app.router.add_post("/api/clan/war", h_war)
    app.on_startup.append(on_start)
    app.on_cleanup.append(on_stop)
