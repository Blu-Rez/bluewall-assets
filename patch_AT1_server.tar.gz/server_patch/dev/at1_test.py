#!/usr/bin/env python3
"""at1_test.py - AT1 friendly attack, SERVER half (bluewall/friendly.py + the AT1 lines in military.py / state.py / server.py).   Last line: "AT1 SERVER OK"
  1  isolation  the WHOLE stored state of both players (and the gift inbox) is byte-for-byte the same before / after a friendly scout + battle, except the attacker's `fb` record;
                a pending NORMAL target (`atk`), the attacker's army / spells / gems / cups / report list and the defender's shield / hits / gems / cups are all untouched
  2  target     the friend's REAL, CURRENT base (an upgrade made in between shows up), loot all zero, no match-up limit, kind / _victim hidden
  3  best       best result per friend (stars, then percent): a worse fight never lowers it, a better one raises it; tampered reports are clamped / refused
  4  access     stranger / blocked / self / garbage ids refused (blocked and stranger answer the same `not_friend`); unfriended while fighting; liveops off; replay / wrong id / expired
  5  limits     daily cap (resets at TEHRAN midnight, tested on the boundary second) + the gap between two scouts; both from the liveops section `friendly`
  6  adapters   friends.are_friends / is_blocked as sync AND async functions; best-list bounded
  7  http       POST /api/scout + /api/battle/end with mode:"friendly" and GET /api/friendly through the real aiohttp app; a request without `mode` still takes the normal path
"""
import asyncio, copy, json, math, os, sys, time
from datetime import datetime, timezone
os.environ["BLUEWALL_STATE"] = "memory"
ROOT = "/home/claude/bot/bluebot_v2"
sys.path.insert(0, "/home/claude/dev/stubcfg"); sys.path.insert(0, ROOT)
from bluewall import state as S, friendly as FR, military as MI, progress as PR

bad = 0
def say(ok, name, extra=""):
    global bad
    bad += 0 if ok else 1
    print(("ok   " if ok else "FAIL ") + name + (("   " + str(extra)[:400]) if extra and not ok else ""))

canon = lambda x: json.dumps(x, sort_keys=True, separators=(",", ":"))
def nofb(s):
    s = copy.deepcopy(s); s.pop("fb", None); return s

class LO:                                                                    # the three-line liveops stub every worker uses until OC1 is merged
    def __init__(s, **kw): s.d = {"enabled": True, "daily_cap": 20, "gap_s": 0, **kw}; s.on = True; s.reg = None
    def get(s, sec): return dict(s.d) if sec == "friendly" else {}
    def flag(s, n): return s.on if n == "friendly" else False
    def register(s, sec, d, v): s.reg = (sec, d, v)

class FRM:                                                                   # a stand-in for friends.py (FR1): sync functions
    def __init__(s): s.pairs = set(); s.blocks = set()
    def are_friends(s, a, b): return (a, b) in s.pairs or (b, a) in s.pairs
    def is_blocked(s, a, b): return (a, b) in s.blocks or (b, a) in s.blocks

class FRMA(FRM):                                                             # ... and the same as coroutines
    async def are_friends(s, a, b): return FRM.are_friends(s, a, b)
    async def is_blocked(s, a, b): return FRM.is_blocked(s, a, b)

async def mutate(st, uid, fn):
    async with st._lock(uid):
        s = await st._txn(uid); fn(s); await st.save(uid, s)

def rep_for(st_a, destruction, stars, **kw):
    home = MI.attack_army(st_a)
    sent = {u: n for u, n in home.items() if n > 0}
    u0 = next(iter(sent))
    return {"sent": sent, "lost": {u0: 1}, "destruction": destruction, "stars": stars, "loot": {"ruby": 10 ** 6, "emerald": 10 ** 6, "turq": 10 ** 6}, "spells": kw.get("spells", {})}

async def main():
    store = S.Store(); A, B, C, D = 2001, 2002, 2003, 2004
    lo = LO(); FR._LIVEOPS = lo
    for u, n in ((A, "Ali"), (B, "Bita"), (C, "Cyrus"), (D, "Dara")):
        await store.touch(u, n)
    assert await store.refer(B, A) and await store.refer(D, A)              # B and D opened the game from A's link: today's friends (the stub reads `frs`)
    await mutate(store, A, lambda s: (s.__setitem__("blk", [D]), s.__setitem__("spells", {"lightning": 1})))
    T = time.time()
    far = T + 4000                                                          # (past the shield; every call below passes `now`)
    await mutate(store, B, lambda s: s.__setitem__("shield", far + 99999))   # a shielded defender: friendly must not use / change the shield
    # an upgrade of the attacker that FINISHES during the first fight (T+1.5): the fight judges a settled COPY, but must never write that copy back
    await mutate(store, A, lambda s: s["q"].append({"e": "wall", "to": PR.level(s, "wall") + 1, "d": 5.0, "s": T, "end": T + 1.5, "paid": {}}))

    # ------------------------------------------------------------ 1 isolation + 2 target
    pending = await store.scout(A, True)                                    # a NORMAL target is pending (record `atk` = target + the scout cooldown clock)
    say(pending.get("ok") is True, "setup: a normal (bots-only) scout is pending", pending.get("why"))
    ids = (A, B, C, D)
    before = {u: canon(store._mem[u]) for u in ids}; inbox0 = canon(store._inbox)
    out = await FR.scout(store, A, B, now=T + 1)
    after_scout = {u: canon(store._mem[u]) for u in ids}
    say(out.get("ok") is True and out.get("mode") == "friendly", "scout: ok, mode friendly", out.get("why"))
    say(after_scout == before and canon(store._inbox) == inbox0, "scout: nothing stored changed (both players, all keys)")
    tg = out["target"]
    say(tg["mode"] == "friendly" and tg["friend"] == B and tg["loot"] == {g: 0 for g in MI.GEMS} and "kind" not in tg and "_victim" not in tg and tg["name"] == "Bita", "target: friendly, friend id, zero loot, kind / _victim hidden", tg)
    vB = store._mem[B]
    say(tg["levels"] == {e: PR.level(vB, e) for e in ("keep", "wall", "towers")}, "target: the friend's real levels", tg["levels"])
    say(out["cap"] == 20 and out["left"] == 20, "scout: budget 20 / 20", (out["cap"], out["left"]))
    rep = rep_for(store._mem[A], 60.0, 1, spells={"lightning": 1})
    res = await FR.end(store, A, tg["id"], rep, now=T + 2)
    say(res.get("ok") is True and res["info"]["mode"] == "friendly" and res["info"]["stars"] == 1 and res["info"]["loot"] == {g: 0 for g in MI.GEMS} and res["info"]["tro"] == 0, "end: ok, no loot, no cups", res.get("why") or res.get("info"))
    final = {u: json.loads(canon(store._mem[u])) for u in ids}
    same = {u: canon(nofb(final[u])) == canon(nofb(json.loads(before[u]))) for u in ids}
    say(same[A], "isolation: the attacker's whole state is the same except `fb` (army, spells, gems, cups, rep, atk, tq, shield ...)")
    say(same[B] and canon(final[B]) == before[B], "isolation: the defender's state is byte-for-byte identical (shield, hits, gems, cups)")
    say(same[C] and same[D] and canon(store._inbox) == inbox0, "isolation: bystanders and the gift inbox untouched")
    say(set(final[A].keys()) - set(json.loads(before[A]).keys()) == {"fb"}, "isolation: `fb` is the only new key", set(final[A].keys()) - set(json.loads(before[A]).keys()))
    say(final[A]["atk"] == json.loads(before[A])["atk"] and final[A]["atk"]["id"] == pending["target"]["id"], "isolation: the pending NORMAL target and its cooldown clock survive")
    say(len(final[A]["q"]) == 1 and final[A]["q"] == json.loads(before[A])["q"] and PR.level(final[A], "wall") == PR.level(json.loads(before[A]), "wall"),
        "isolation: an upgrade that finished DURING the fight is not written back (the fight judges a settled copy only)", final[A]["q"])
    say(final[A]["spells"] == {"lightning": 1}, "isolation: a spell reported as cast is NOT consumed")
    say(final[B].get("hits", []) == [] and final[A].get("rep", []) == json.loads(before[A]).get("rep", []), "isolation: no defender row, no attacker report row")
    fb = final[A]["fb"]
    say(fb["b"][str(B)][:2] == [1, 60] and fb["n"] == 1 and fb["d"] == FR.day_key(T + 2), "fb: best [1 star, 60 %], one fight today", fb)

    # ------------------------------------------------------------ 2b the friend's CURRENT base
    await mutate(store, B, lambda s: s["b"].__setitem__("keep", PR.level(s, "keep") + 1))
    out2 = await FR.scout(store, A, B, now=T + 20)
    say(out2["target"]["levels"]["keep"] == PR.level(store._mem[B], "keep"), "target: an upgrade the friend made in between shows up at once", out2["target"]["levels"])
    say(out2["target"]["id"] != tg["id"], "target: a new token per scout")

    # ------------------------------------------------------------ 3 best
    async def fight(d, s, now, **kw):
        o = await FR.scout(store, A, B, now=now)
        assert o.get("ok"), o
        return await FR.end(store, A, o["target"]["id"], rep_for(store._mem[A], d, s, **kw), now=now + 1)
    r = await fight(30.0, 0, T + 40); say(r["ok"] and r["info"]["best"] == [1, 60] and r["info"]["improved"] is False, "best: a worse fight does not lower it", r.get("info"))
    r = await fight(80.0, 2, T + 60); say(r["ok"] and r["info"]["best"] == [2, 80] and r["info"]["improved"] is True, "best: a better fight raises it", r.get("info"))
    r = await fight(80.0, 2, T + 80); say(r["ok"] and r["info"]["improved"] is False, "best: an equal fight is not an improvement")
    r = await fight(float("nan"), 3, T + 100); say(r["ok"] and r["info"]["stars"] == 0 and r["info"]["destruction"] == 0.0 and r["info"]["best"] == [2, 80], "best: NaN damage counts as 0, 3 stars claimed with 0 % become 0", r.get("info"))
    r = await fight(70.0, 3, T + 120); say(r["ok"] and r["info"]["stars"] == 2 and r["info"]["best"] == [2, 80], "best: 3 stars below 99.95 % become 2", r.get("info"))
    o = await FR.scout(store, A, B, now=T + 140)
    bad_units = rep_for(store._mem[A], 50.0, 1); bad_units["sent"] = {"spear": 999}
    r = await FR.end(store, A, o["target"]["id"], bad_units, now=T + 141); say(not r["ok"] and r["why"] == "bad_units", "end: more soldiers than owned -> bad_units", r)
    bad_sp = rep_for(store._mem[A], 50.0, 1, spells={"lightning": 5})
    r = await FR.end(store, A, o["target"]["id"], bad_sp, now=T + 141); say(not r["ok"] and r["why"] == "bad_spells", "end: more spells than owned -> bad_spells", r)
    r = await FR.end(store, A, o["target"]["id"], {"sent": {}, "lost": {}, "destruction": 90, "stars": 2}, now=T + 141); say(not r["ok"] and r["why"] == "implausible", "end: damage with no soldier -> implausible", r)
    r = await FR.end(store, A, o["target"]["id"], rep_for(store._mem[A], 40.0, 0), now=T + 141)
    say(r["ok"] is True, "end: the token is still valid after refused reports (nothing was consumed)", r.get("why"))
    r = await FR.end(store, A, o["target"]["id"], rep_for(store._mem[A], 40.0, 0), now=T + 142); say(not r["ok"] and r["why"] == "no_target", "end: replay of the same token -> no_target", r)
    r = await FR.end(store, A, "nope", rep_for(store._mem[A], 40.0, 0), now=T + 142); say(not r["ok"] and r["why"] == "no_target", "end: unknown token -> no_target")
    o = await FR.scout(store, A, B, now=T + 150)
    r = await FR.end(store, A, o["target"]["id"], rep_for(store._mem[A], 40.0, 0), now=T + 150 + MI.BATTLE_TIMEOUT + 1); say(not r["ok"] and r["why"] == "expired", "end: after BATTLE_TIMEOUT -> expired", r)
    say(final[B].get("shield") == store._mem[B].get("shield") and canon(nofb(store._mem[A])) == canon(nofb(final[A])), "isolation holds after every fight above (attacker minus fb, defender shield)")

    # ------------------------------------------------------------ 4 access
    for who, name in ((C, "stranger"), (D, "blocked friend")):
        r = await FR.scout(store, A, who, now=T + 200)
        say(not r["ok"] and r["why"] == "not_friend", "access: %s -> not_friend (a block is never revealed)" % name, r)
    for junk in (None, "abc", -5, 0, True, [1], {"a": 1}, float("nan"), 10 ** 30):
        r = await FR.scout(store, A, junk, now=T + 200)
        say(not r["ok"] and r["why"] in ("bad_friend", "not_friend"), "access: friend id %r refused" % (junk if not isinstance(junk, float) else "nan"), r)
    r = await FR.scout(store, A, A, now=T + 200); say(not r["ok"] and r["why"] == "bad_friend", "access: yourself -> bad_friend")
    r = await FR.scout(store, C, A, now=T + 200); say(not r["ok"] and r["why"] == "not_friend", "access: C scouting A, who never invited C -> not_friend (the stub is symmetric: B can scout A, C cannot)")
    r = await FR.scout(store, B, A, now=T + 200); say(r["ok"] is True, "access: the friendship works from both sides (B scouts A)", r.get("why"))
    # unfriended / blocked while the battle is on
    fm = FRM(); FR._FRIENDS = fm; fm.pairs.add((A, B))
    o = await FR.scout(store, A, B, now=T + 300); assert o["ok"], o
    snap = canon(store._mem[A]); fm.blocks.add((B, A))
    r = await FR.end(store, A, o["target"]["id"], rep_for(store._mem[A], 50.0, 1), now=T + 301)
    say(not r["ok"] and r["why"] == "not_friend" and canon(store._mem[A]) == snap, "access: blocked while fighting -> not_friend, nothing written", r)
    fm.blocks.clear()
    r = await FR.scout(store, A, B, now=T + 310); say(r["ok"], "adapter: the sync friends module (are_friends / is_blocked) is used instead of the stub", r.get("why"))
    fm.blocks.add((A, B)); r = await FR.scout(store, A, B, now=T + 320); say(not r["ok"] and r["why"] == "not_friend", "adapter: is_blocked is honoured in both directions")
    fa = FRMA(); fa.pairs.add((A, B)); FR._FRIENDS = fa
    r = await FR.scout(store, A, B, now=T + 330); say(r["ok"], "adapter: the same module as coroutines", r.get("why"))
    fa.pairs.clear(); r = await FR.scout(store, A, B, now=T + 340); say(not r["ok"] and r["why"] == "not_friend", "adapter: a pair that is not friends -> not_friend")
    FR._FRIENDS = None
    lo.on = False
    r = await FR.scout(store, A, B, now=T + 350); say(not r["ok"] and r["why"] == "off", "liveops: flag friendly off -> scout refused (off)", r)
    lo.on = True; o = await FR.scout(store, A, B, now=T + 360); lo.on = False
    r = await FR.end(store, A, o["target"]["id"], rep_for(store._mem[A], 50.0, 1), now=T + 361); say(not r["ok"] and r["why"] == "off", "liveops: switched off while fighting -> end refused (off)", r)
    lo.on = True
    say(lo.reg is not None and lo.reg[0] == "friendly" and lo.reg[1]["daily_cap"] == 20 and lo.reg[2]({"daily_cap": 5}) == [] and lo.reg[2]({"daily_cap": "x"}) != [] and lo.reg[2]({"gap_s": -1}) != [], "liveops: section `friendly` registered with its defaults and a working validator", lo.reg)

    # ------------------------------------------------------------ 5 limits
    lo.d.update({"daily_cap": 3, "gap_s": 0})
    day0 = datetime(2026, 11, 3, 20, 29, 50, tzinfo=timezone.utc).timestamp()           # 23:59:50 in Tehran (UTC+3:30, no DST)
    say(FR.day_key(day0 + 9) == "2026-11-03" and FR.day_key(day0 + 10) == "2026-11-04", "cap: the day changes at Tehran midnight (one second before / on the boundary)", (FR.day_key(day0 + 9), FR.day_key(day0 + 10)))
    await mutate(store, A, lambda s: s.pop("fb", None))
    for i in range(3):
        o = await FR.scout(store, A, B, now=day0 + i); assert o["ok"], o
        r = await FR.end(store, A, o["target"]["id"], rep_for(store._mem[A], 50.0, 1), now=day0 + i + 0.5)
        assert r["ok"], r
        say(r["left"] == 2 - i, "cap: fight %d of 3 done, %d left" % (i + 1, 2 - i), r.get("left"))
    r = await FR.scout(store, A, B, now=day0 + 5); say(not r["ok"] and r["why"] == "cap" and r["left"] == 0 and r["cap"] == 3, "cap: the 4th scout today -> cap", r)
    o = await FR.scout(store, A, B, now=day0 + 20)
    nxt = await FR.end(store, A, o["target"]["id"], rep_for(store._mem[A], 50.0, 1), now=day0 + 21)
    say(o["ok"] and nxt["ok"] and nxt["left"] == 2, "cap: after Tehran midnight the budget is fresh again (counter reset to 1)", (o.get("why"), nxt.get("left")))
    # the cap is lowered while a fight is pending: the end re-checks and writes nothing
    lo.d.update({"daily_cap": 5, "gap_s": 0})
    await mutate(store, A, lambda s: s.pop("fb", None))
    o = await FR.scout(store, A, B, now=day0 + 30); assert o["ok"], o
    r = await FR.end(store, A, o["target"]["id"], rep_for(store._mem[A], 50.0, 1), now=day0 + 31); assert r["ok"], r
    o = await FR.scout(store, A, B, now=day0 + 32); assert o["ok"], o
    lo.d.update({"daily_cap": 1}); snap = canon(store._mem[A])
    r = await FR.end(store, A, o["target"]["id"], rep_for(store._mem[A], 50.0, 1), now=day0 + 33)
    say(not r["ok"] and r["why"] == "cap" and canon(store._mem[A]) == snap, "cap: lowered while a fight is pending -> the end answers cap and writes nothing", r)
    lo.d.update({"daily_cap": 3, "gap_s": 10})
    await mutate(store, A, lambda s: s.pop("fb", None))
    FR._LAST.clear()
    o = await FR.scout(store, A, B, now=day0 + 100); say(o["ok"], "gap: first scout ok")
    r = await FR.scout(store, A, B, now=day0 + 103); say(not r["ok"] and r["why"] == "slow" and 6.5 <= r["wait"] <= 7.5, "gap: a second scout 3 s later -> slow, wait ~7 s", r)
    last = await FR.scout(store, A, B, now=day0 + 111); say(last["ok"], "gap: 11 s later -> ok", last.get("why"))
    say(FR._PEND[A]["id"] == last["target"]["id"] != o["target"]["id"], "pending: one slot per attacker, the newest scout's token is the valid one")
    r = await FR.end(store, A, o["target"]["id"], rep_for(store._mem[A], 50.0, 1), now=day0 + 112)
    say(not r["ok"] and r["why"] == "no_target", "pending: the older token is dead after a newer scout", r)
    lo.d.update({"daily_cap": 20, "gap_s": 0})

    # ------------------------------------------------------------ mode isolation
    n = await store.scout(A, True)
    say(n.get("ok") is True or n.get("why") == "slow", "normal path: a scout without mode is still a normal scout", n.get("why"))
    r = await store.battle_end(A, last["target"]["id"], rep_for(store._mem[A], 50.0, 1))
    say(not r["ok"] and r["why"] == "no_target", "mode: a friendly token cannot be settled by the NORMAL path (no losses / loot via the wrong door)", r.get("why"))
    r = await store.battle_end(A, last["target"]["id"], rep_for(store._mem[A], 50.0, 1), "friendly")
    say(r["ok"], "mode: the same token through Store.battle_end(mode=friendly) works", r.get("why"))
    r = await store.battle_end(A, (n.get("target") or {}).get("id", "x"), rep_for(store._mem[A], 50.0, 1), "friendly")
    say(not r["ok"] and r["why"] == "no_target", "mode: a NORMAL token cannot be settled as friendly", r.get("why"))
    r = await store.scout(A, False, "friendly", C); say(not r["ok"] and r["why"] == "not_friend", "Store.scout(mode=friendly) is wired to friendly.py")

    # ------------------------------------------------------------ 6 bounded
    old = FR.BEST_MAX; FR.BEST_MAX = 3
    st = copy.deepcopy(store._mem[A]); st["fb"] = {}
    for i, fid in enumerate((11, 12, 13, 14, 15)):
        p = {"id": "t%d" % i, "friend": fid, "t": T, "spec": {"power": 1.0, "name": "x"}, "done": False}
        why, info = FR.settle(st, p, "t%d" % i, rep_for(st, 50.0, 1), T + i + 1)
        assert why == "ok", why
    FR.BEST_MAX = old
    say(sorted(st["fb"]["b"]) == ["13", "14", "15"] and st["fb"]["n"] == 5, "best list is bounded (the oldest results go first)", sorted(st["fb"]["b"]))
    say(FR.best_of(st) == {"13": [1, 50], "14": [1, 50], "15": [1, 50]}, "best_of() shape for the friend cards")
    for junk in ({"fb": "x"}, {"fb": {"b": "x"}}, {"fb": {"b": {"1": "x"}}}):
        FR.best_of(junk)
    say(True, "best_of() survives a damaged record")
    st = await FR.status(store, A, now=T + 5000)
    say(st["ok"] and st["cap"] == 20 and isinstance(st["best"], dict) and str(B) in st["best"], "status(): budget + best", st)

    # ------------------------------------------------------------ 7 http
    from aiohttp.test_utils import TestClient, TestServer
    import bluewall.server as srv
    srv._bearer_uid = lambda req: int(req.headers.get("Authorization", "")[7:]) if req.headers.get("Authorization", "").startswith("Bearer ") and req.headers["Authorization"][7:].isdigit() else None
    store2 = srv.STORE
    P, Q = 3001, 3002
    await store2.touch(P, "Pari"); await store2.touch(Q, "Qasem"); assert await store2.refer(Q, P)
    FR._FRIENDS = None; lo.d.update({"daily_cap": 20, "gap_s": 0})
    async with TestClient(TestServer(srv.make_app())) as c:
        H = {"Authorization": "Bearer %d" % P}
        r = await c.post("/api/scout", json={"mode": "friendly", "friend": Q}); j = await r.json()
        say(r.status == 403 and j.get("reason") == "locked", "http: no token -> 403 locked")
        before_p = canon(nofb(store2._mem[P])); before_q = canon(store2._mem[Q])
        r = await c.post("/api/scout", json={"mode": "friendly", "friend": Q}, headers=H); j = await r.json()
        say(r.status == 200 and j["ok"] and j["target"]["mode"] == "friendly" and j["target"]["friend"] == Q, "http: POST /api/scout mode friendly", j.get("why"))
        tid = j["target"]["id"]
        r = await c.post("/api/battle/end", json={"mode": "friendly", "id": tid, "rep": rep_for(store2._mem[P], 55.0, 1)}, headers=H); j = await r.json()
        say(r.status == 200 and j["ok"] and j["info"]["mode"] == "friendly" and j["info"]["best"] == [1, 55], "http: POST /api/battle/end mode friendly", j.get("why"))
        say(canon(nofb(store2._mem[P])) == before_p and canon(store2._mem[Q]) == before_q, "http: state of both players unchanged except fb")
        r = await c.get("/api/friendly", headers=H); j = await r.json()
        say(r.status == 200 and j["ok"] and j["best"] == {str(Q): [1, 55]} and j["left"] == 19, "http: GET /api/friendly -> best + budget", j)
        r = await c.get("/api/friendly"); say(r.status == 403, "http: GET /api/friendly without a token -> 403")
        r = await c.post("/api/scout", json={"mode": "friendly", "friend": 9999}, headers=H); j = await r.json()
        say(j["ok"] is False and j["why"] == "not_friend", "http: a stranger -> not_friend", j)
        r = await c.post("/api/scout", json={"bots_only": True}, headers=H); j = await r.json()
        say(j.get("ok") is True and j["target"].get("mode") is None and "friend" not in j["target"], "http: a request WITHOUT mode is the normal path (bot target, no mode / friend)", j.get("why"))
        r = await c.post("/api/scout", json={"mode": "war", "friend": Q, "bots_only": True}, headers=H); j = await r.json()
        say(j.get("ok") is not True or j["target"].get("mode") is None, "http: an unknown mode never turns into a friendly fight", j.get("why"))

    print("AT1 SERVER OK" if not bad else "AT1 SERVER: %d FAILED" % bad)
    return 0 if not bad else 1
sys.exit(asyncio.run(main()))
