"""AT1 - friendly attack: a real battle against a FRIEND's real, current base in which nothing is lost and nothing is won, for both sides.

Contract (ROUND8_COMMON section 4): `mode: "friendly"` travels in the body of POST /api/scout (+ `friend`: the friend's id) and POST /api/battle/end.

What a friendly fight does NOT do (the tests compare the whole state of both players before / after, byte for byte):
  * no loot, no cups (`tro`), no shield made or used, no soldier / spell lost or used, no entry in the attacker's report list (`rep`) or the defender's `hits`,
    no red notice for the defender, no XP / mission / pass event, and the attacker's normal-attack record `st["atk"]` (target + 20 s scout cooldown) is left alone.
What it does write: ONE key of the attacker's state, `st["fb"]` = {"b": {friend id: [stars, percent, time]}, "d": "YYYY-MM-DD" (Tehran), "n": battles finished that day}.
The target that is being fought lives in this module's memory (`_PEND`, one slot per attacker, valid BATTLE_TIMEOUT): losing it on a restart only means the player scouts again.

Settings (liveops section `friendly`, friendly_defaults.json): enabled, daily_cap (20), gap_s (seconds between two friendly scouts).  Without liveops (before OC1 is merged) the defaults are used.
Friendship / blocking: friends.are_friends(a, b) / friends.is_blocked(a, b) (FR1, sync or async).  Until FR1 is merged a stub reads today's invite lists (`frs`, both directions) and a `blk` list.
A refused friend never learns why: not-a-friend and blocked both answer `not_friend`.
"""
from __future__ import annotations

import copy
import inspect
import json
import logging
import random
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from . import military as MI
from . import progress as PR

log = logging.getLogger("bluewall.friendly")

_BUILTIN = {"enabled": True, "daily_cap": 20, "gap_s": 10}
try:
    DEFAULTS: Dict[str, Any] = {**_BUILTIN, **json.loads(Path(__file__).with_name("friendly_defaults.json").read_text())}
except Exception:  # noqa: BLE001
    DEFAULTS = dict(_BUILTIN)

BEST_MAX = 200                                   # friends kept in the best-result record (the oldest result goes first)

try:
    from zoneinfo import ZoneInfo
    TEHRAN = ZoneInfo("Asia/Tehran")
except Exception:  # noqa: BLE001  (no tz database on the machine: Iran has had no DST since 2022, a fixed offset is exact)
    TEHRAN = timezone(timedelta(hours=3, minutes=30))

# test / integration hooks: set to a module-like object to replace liveops / friends (None = import the real one, else the built-in fallback)
_LIVEOPS: Any = None
_FRIENDS: Any = None
_PEND: Dict[int, Dict[str, Any]] = {}            # attacker uid -> {"id", "friend", "t", "spec", "mode", "done"}
_LAST: Dict[int, float] = {}                     # attacker uid -> time of the last friendly scout
_registered = False


def validate(d: Any) -> List[str]:
    """liveops validator: a list of error texts (empty = fine)."""
    if not isinstance(d, dict):
        return ["friendly: must be an object"]
    err = []
    if "enabled" in d and not isinstance(d["enabled"], bool):
        err.append("friendly.enabled: true / false")
    if "daily_cap" in d and not (isinstance(d["daily_cap"], int) and not isinstance(d["daily_cap"], bool) and 0 <= d["daily_cap"] <= 1000):
        err.append("friendly.daily_cap: whole number 0..1000")
    if "gap_s" in d and not (isinstance(d["gap_s"], (int, float)) and not isinstance(d["gap_s"], bool) and 0 <= d["gap_s"] <= 3600):
        err.append("friendly.gap_s: seconds 0..3600")
    return err


def _liveops():
    if _LIVEOPS is not None:
        return _LIVEOPS
    try:
        from . import liveops as L          # OC1 (not in the kit yet)
        return L
    except ImportError:
        return None


def cfg() -> Dict[str, Any]:
    """The `friendly` section, merged over the defaults; a broken value falls back to its default."""
    global _registered
    d = dict(DEFAULTS)
    lo = _liveops()
    if lo is not None:
        try:
            if not _registered and hasattr(lo, "register"):
                lo.register("friendly", DEFAULTS, validate)
                _registered = True
            got = lo.get("friendly")
            if isinstance(got, dict):
                d.update(got)
            if hasattr(lo, "flag"):
                d["enabled"] = bool(lo.flag("friendly")) and bool(d.get("enabled", True))
        except Exception as e:  # noqa: BLE001
            log.warning("friendly: liveops unreadable (%s): defaults", e)
    if validate(d):
        d = {k: (d[k] if not validate({k: d[k]}) else DEFAULTS[k]) for k in DEFAULTS}
    return d


def day_key(now: float) -> str:
    """The calendar day in Tehran (the daily cap resets at Tehran midnight)."""
    return datetime.fromtimestamp(now, TEHRAN).strftime("%Y-%m-%d")


def _uid(v: Any) -> Optional[int]:
    try:
        if isinstance(v, bool):
            return None
        n = int(v)
    except (TypeError, ValueError, OverflowError):
        return None
    return n if n > 0 else None


async def _call(fn, *a):
    r = fn(*a)
    return await r if inspect.isawaitable(r) else r


async def _load(store, uid: int) -> Optional[Dict[str, Any]]:
    from .state import StateUnavailable
    try:
        async with store._lock(uid):
            return await store.load(uid)
    except StateUnavailable:
        return None


async def are_friends(store, a: int, b: int) -> bool:
    fr = _FRIENDS
    if fr is None:
        try:
            from . import friends as fr         # FR1 (not in the kit yet)
        except ImportError:
            fr = None
    if fr is not None and hasattr(fr, "are_friends"):
        return bool(await _call(fr.are_friends, a, b))
    sa = await _load(store, a)                  # stub: today's friends = the invite lists (the inviter's `frs`), either direction
    if sa is not None and b in [int(x) for x in sa.get("frs", [])]:
        return True
    sb = await _load(store, b)
    return sb is not None and a in [int(x) for x in sb.get("frs", [])]


async def is_blocked(store, a: int, b: int) -> bool:
    fr = _FRIENDS
    if fr is None:
        try:
            from . import friends as fr
        except ImportError:
            fr = None
    if fr is not None and hasattr(fr, "is_blocked"):
        return bool(await _call(fr.is_blocked, a, b)) or bool(await _call(fr.is_blocked, b, a))
    for x, y in ((a, b), (b, a)):               # stub: a `blk` list in the state (nothing writes it yet)
        s = await _load(store, x)
        if s is not None and y in [int(z) for z in s.get("blk", [])]:
            return True
    return False


def _settled(st: Dict[str, Any], now: float) -> Dict[str, Any]:
    """A settled COPY (finished upgrades / trained soldiers counted) for reading; the stored record is never rewritten with it."""
    c = copy.deepcopy(st)
    PR.settle(c, now)
    MI.settle(c, now)
    PR.expire_mine_boost(c, now)
    return c


def _used_today(st: Dict[str, Any], now: float) -> int:
    fb = st.get("fb") if isinstance(st.get("fb"), dict) else {}
    return int(fb.get("n", 0) or 0) if fb.get("d") == day_key(now) else 0


def best_of(st: Dict[str, Any]) -> Dict[str, List[int]]:
    fb = st.get("fb") if isinstance(st.get("fb"), dict) else {}
    b = fb.get("b") if isinstance(fb.get("b"), dict) else {}
    return {str(k): [int(v[0]), int(v[1])] for k, v in b.items() if isinstance(v, (list, tuple)) and len(v) >= 2}


async def scout(store, uid: int, friend_raw: Any, now: Optional[float] = None) -> Dict[str, Any]:
    """POST /api/scout {mode:"friendly", friend:<id>}: the friend's real, current base as a target.  Reads only; writes nothing."""
    now = time.time() if now is None else now
    c = cfg()
    if not c["enabled"]:
        return {"ok": False, "why": "off"}
    fid = _uid(friend_raw)
    if fid is None or fid == uid:
        return {"ok": False, "why": "bad_friend"}
    if not await are_friends(store, uid, fid) or await is_blocked(store, uid, fid):
        return {"ok": False, "why": "not_friend"}                                      # (the same answer for «not a friend» and «blocked»: a block is never revealed)
    me = await _load(store, uid)
    if me is None:
        return {"ok": False, "why": "unavailable"}
    me = _settled(me, now)
    used, cap = _used_today(me, now), int(c["daily_cap"])
    if used >= cap:
        return {"ok": False, "why": "cap", "cap": cap, "left": 0}
    wait = float(c["gap_s"]) - (now - _LAST.get(uid, -1e12))
    if wait > 0:
        return {"ok": False, "why": "slow", "wait": round(wait, 1)}
    if MI.space_of(MI.attack_army(me)) <= 0:
        return {"ok": False, "why": "no_army"}
    v = await _load(store, fid)
    if v is None:
        return {"ok": False, "why": "unavailable"}
    v = _settled(v, now)
    rng = random.Random()
    spec = MI.player_target(me, v, fid, rng, now, fair=False)                           # (the real base as it is now: levels, tesla, guard, layout)
    if spec is None:                                                                    # (cannot happen with fair=False; kept as a guard)
        return {"ok": False, "why": "bad_friend"}
    spec["loot"] = {g: 0 for g in MI.GEMS}                                              # (nothing to win)
    spec["mode"] = "friendly"
    spec["kind"] = "friend"
    tid = "f%x%x" % (int(now * 1000), rng.randrange(1 << 20))
    if len(_PEND) > 5000:                                                               # (bounded: drop what has expired)
        for k in [k for k, p in _PEND.items() if now - float(p.get("t", 0)) > MI.BATTLE_TIMEOUT]:
            _PEND.pop(k, None)
    _PEND[uid] = {"id": tid, "friend": fid, "t": now, "spec": spec, "mode": "friendly", "done": False}
    _LAST[uid] = now
    tgt = {"id": tid, **{k: val for k, val in spec.items() if not k.startswith("_") and k != "kind"}, "friend": fid}
    out = store.view(me, None, uid)
    out.update({"ok": True, "why": None, "target": tgt, "mode": "friendly", "cap": cap, "left": cap - used})
    return out


def settle(st: Dict[str, Any], pend: Optional[Dict[str, Any]], tid: str, rep: Dict[str, Any], now: float) -> Tuple[str, Optional[Dict[str, Any]]]:
    """Called by military.settle_battle(mode="friendly").  Validates the report like a normal one, but applies NOTHING except st["fb"] (best result + today's counter)."""
    if not pend or pend.get("id") != tid or pend.get("done"):
        return "no_target", None
    if now - float(pend.get("t", 0)) > MI.BATTLE_TIMEOUT:
        return "expired", None
    if not isinstance(rep, dict):
        return "bad", None
    sent = {u: MI._cnt(n) for u, n in MI._dict(rep.get("sent")).items() if u in MI.UNITS and MI._cnt(n) > 0}
    lost = {u: MI._cnt(n) for u, n in MI._dict(rep.get("lost")).items() if u in MI.UNITS and MI._cnt(n) > 0}
    home = MI.attack_army(st)
    for u, n in sent.items():
        if n > int(home.get(u, 0)):
            return "bad_units", None
    for u, n in lost.items():
        if n > sent.get(u, 0):
            return "bad_losses", None
    cast = {k: MI._cnt(n) for k, n in MI._dict(rep.get("spells")).items() if k in MI.SPELLS and MI._cnt(n) > 0}
    for k, n in cast.items():
        if n > int(st.get("spells", {}).get(k, 0)):
            return "bad_spells", None
    destruction = MI._num(rep.get("destruction"), 0.0, 100.0)
    stars = int(MI._num(rep.get("stars"), 0, 3))
    need = float((pend.get("spec") or {}).get("power", 0) or 0)
    sp = sum(n * MI.unit_power(u, MI.forge_mult(st), MI.unit_level(st, u)) for u, n in sent.items())
    if not sent and not cast and (destruction > 0 or stars):
        return "implausible", None
    if destruction > 20 and sp < need * (destruction / 100.0) * 0.18:
        return "implausible", None
    if stars >= 1 and destruction < 50:
        stars = 0
    if stars >= 3 and destruction < 99.95:
        stars = 2
    pct = int(round(destruction))
    fb = st["fb"] if isinstance(st.get("fb"), dict) else {}
    st["fb"] = fb
    today = day_key(now)
    if fb.get("d") != today:
        fb["d"], fb["n"] = today, 0
    fb["n"] = int(fb.get("n", 0) or 0) + 1
    best = fb["b"] if isinstance(fb.get("b"), dict) else {}
    fb["b"] = best
    key = str(int(pend["friend"]))
    old = best.get(key)
    better = not (isinstance(old, (list, tuple)) and len(old) >= 2) or (stars, pct) > (int(old[0]), int(old[1]))
    if better:
        best[key] = [stars, pct, int(now)]
        if len(best) > BEST_MAX:
            for k in sorted(best, key=lambda x: int(best[x][2]) if len(best[x]) > 2 else 0)[:len(best) - BEST_MAX]:
                best.pop(k, None)
    pend["done"] = True
    b = best[key]
    info = {"mode": "friendly", "stars": stars, "destruction": destruction, "loot": {g: 0 for g in MI.GEMS}, "tro": 0, "best": [int(b[0]), int(b[1])], "improved": bool(better),
            "report": {"mode": "friendly", "target": (pend.get("spec") or {}).get("name"), "stars": stars, "destruction": destruction, "loot": {g: 0 for g in MI.GEMS}, "lost": {}, "sent": sent, "spells": {}, "tro": 0}}
    return "ok", info


async def end(store, uid: int, tid: str, rep: Dict[str, Any], now: Optional[float] = None) -> Dict[str, Any]:
    """POST /api/battle/end {mode:"friendly", id, rep}."""
    now = time.time() if now is None else now
    c = cfg()
    if not c["enabled"]:
        return {"ok": False, "why": "off"}
    p = _PEND.get(uid)
    if not p or p.get("id") != tid or p.get("done"):
        return {"ok": False, "why": "no_target"}
    fid = int(p["friend"])
    if not await are_friends(store, uid, fid) or await is_blocked(store, uid, fid):
        _PEND.pop(uid, None)
        return {"ok": False, "why": "not_friend"}                                      # (unfriended / blocked while fighting)
    from .state import StateUnavailable
    try:
        async with store._lock(uid):
            st = await store.load(uid)
            chk = _settled(st, now)                                                     # (the army is judged on the settled copy; the stored record is not rewritten with it)
            if _used_today(chk, now) >= int(c["daily_cap"]):
                return {"ok": False, "why": "cap", "cap": int(c["daily_cap"]), "left": 0}
            why, info = MI.settle_battle(chk, tid, rep, now, mode="friendly", pend=p)
            if why == "ok":
                st["fb"] = chk["fb"]                                                    # (the ONLY change to the stored state)
                await store.save(uid, st)
                cap = int(c["daily_cap"])
                out = store.view(chk, None, uid)
                out.update({"ok": True, "why": None, "info": info, "mode": "friendly", "cap": cap, "left": max(0, cap - _used_today(chk, now))})
                return out
            if why == "expired":
                _PEND.pop(uid, None)
            return {"ok": False, "why": why}
    except StateUnavailable:
        return {"ok": False, "why": "unavailable"}


async def status(store, uid: int, now: Optional[float] = None) -> Dict[str, Any]:
    """GET /api/friendly: the daily budget + the best result against each friend (for the friend cards)."""
    now = time.time() if now is None else now
    c = cfg()
    st = await _load(store, uid)
    if st is None:
        return {"ok": False, "why": "unavailable"}
    cap = int(c["daily_cap"])
    return {"ok": True, "enabled": bool(c["enabled"]), "cap": cap, "left": max(0, cap - _used_today(st, now)), "best": best_of(st)}
