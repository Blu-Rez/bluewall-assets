import sys, json, base64, os, subprocess, time, shutil
from playwright.sync_api import sync_playwright
HERE = os.path.dirname(os.path.abspath(__file__))
_srv = None
def serve():
    global _srv
    if _srv: return
    _srv = subprocess.Popen([sys.executable, "-m", "http.server", "8765", "--bind", "127.0.0.1", "--directory", HERE], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1.0)
def render(jobs):
    """jobs = list of dict(url, clip, times, views, stick, frameH, out)"""
    serve()
    with sync_playwright() as p:
        b = p.chromium.launch(args=["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist", "--allow-file-access-from-files"])
        pg = b.new_page(viewport={"width": 800, "height": 600})
        pg.on("console", lambda m: print("console:", m.text) if m.type in ("error",) else None)
        pg.goto("http://127.0.0.1:8765/sheet.html"); pg.wait_for_function("window.READY === true", timeout=60000)
        for j in jobs:
            o = {k: v for k, v in j.items() if k != "out"}
            data = pg.evaluate("o => window.sheet(o)", o)
            open(j["out"], "wb").write(base64.b64decode(data.split(",", 1)[1])); print("wrote", j["out"])
        b.close()
    _srv.terminate()
if __name__ == "__main__":
    render(json.load(open(sys.argv[1])))
