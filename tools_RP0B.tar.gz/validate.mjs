import fs from 'fs'; import validator from 'gltf-validator';
for (const f of process.argv.slice(2)) {
  const r = await validator.validateBytes(new Uint8Array(fs.readFileSync(f)));
  const m = r.issues; console.log(f.split('/').pop(), 'errors', m.numErrors, 'warnings', m.numWarnings, 'infos', m.numInfos, m.messages.filter(x=>x.severity<=1).slice(0,3).map(x=>x.code+':'+x.pointer).join(' | '));
}
