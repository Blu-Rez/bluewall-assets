import { NodeIO } from '@gltf-transform/core';
import { ALL_EXTENSIONS } from '@gltf-transform/extensions';
import { MeshoptDecoder } from 'meshoptimizer';
import fs from 'fs';
await MeshoptDecoder.ready;
const io = new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({ 'meshopt.decoder': MeshoptDecoder });
const dir = process.argv[2];
const files = fs.readdirSync(dir).filter(f => f.endsWith('.glb')).sort();
for (const f of files) {
  let doc;
  try { doc = await io.read(dir + '/' + f); } catch (e) { console.log(f, 'ERR', String(e).slice(0,80)); continue; }
  const root = doc.getRoot();
  const anims = root.listAnimations();
  if (!anims.length) continue;
  const skins = root.listSkins();
  const joints = skins.length ? skins[0].listJoints().length : 0;
  const rootJ = skins.length ? skins[0].listJoints()[0].getName() : '-';
  const desc = anims.map(a => {
    let d = 0;
    for (const s of a.listSamplers()) { const t = s.getInput().getArray(); d = Math.max(d, t[t.length-1]); }
    return a.getName() + ':' + d.toFixed(2);
  });
  console.log(`## ${f}  joints=${joints} first=${rootJ}  anims(${anims.length}): ${desc.join(' ')}`);
}
