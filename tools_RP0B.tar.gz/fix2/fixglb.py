# usage: python3 fixglb.py in.glb out.glb   -> fixes vertices bound 100% to the static 'neutral_bone'
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pose import *
from glbwrite import rebuild
src, dst = sys.argv[1], sys.argv[2]
m = Model(src); js = m.js
at = js["meshes"][0]["primitives"][0]["attributes"]
nb = m.names.index("neutral_bone") if "neutral_bone" in m.names else -1
J, W = m.J.copy(), m.W.copy()
bad = np.where(((J == nb) & (W > 0.001)).any(1))[0] if nb >= 0 else np.array([], dtype=int)
print("vertices bound to neutral_bone:", len(bad))
if len(bad):
    good = np.setdiff1d(np.arange(len(J)), bad)
    for v in bad:
        d = np.linalg.norm(m.P[good] - m.P[v], axis=1); g = good[d.argmin()]
        J[v], W[v] = J[g], W[g]
    out = rebuild(js, m.b, {js["accessors"][at["JOINTS_0"]]["bufferView"]: J.astype(np.uint8).tobytes(),
                           js["accessors"][at["WEIGHTS_0"]]["bufferView"]: W.astype(np.float32).tobytes()})
    open(dst, "wb").write(out); print("wrote", dst, len(out))
else:
    open(dst, "wb").write(open(src, "rb").read()); print("nothing to fix, copied")
