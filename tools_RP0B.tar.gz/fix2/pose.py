import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "fix"))
from glbio import *
from collections import Counter

def slerp(q0, q1, t):
    d = np.dot(q0, q1)
    if d < 0: q1 = -q1; d = -d
    if d > 0.9995:
        q = q0 + t * (q1 - q0); return q / np.linalg.norm(q)
    th = np.arccos(d); return (np.sin((1 - t) * th) * q0 + np.sin(t * th) * q1) / np.sin(th)

def quat_to_R(q):
    x, y, z, w = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])

class Model:
    def __init__(self, path):
        self.js, self.b = load(path); js = self.js
        self.nodes = js["nodes"]; self.joints = js["skins"][0]["joints"]
        self.names = [self.nodes[j]["name"] for j in self.joints]
        prim = js["meshes"][0]["primitives"][0]; at = prim["attributes"]
        self.P = acc(js, self.b, at["POSITION"]).astype(np.float64)
        self.I = acc(js, self.b, prim["indices"]).reshape(-1, 3).astype(np.int64)
        self.J = acc(js, self.b, at["JOINTS_0"]).astype(np.int64); self.W = acc(js, self.b, at["WEIGHTS_0"]).astype(np.float64)
        self.ibm = acc(js, self.b, js["skins"][0]["inverseBindMatrices"]).astype(np.float64).reshape(-1, 4, 4).transpose(0, 2, 1)
        self.par = {}
        for i, n in enumerate(self.nodes):
            for c in n.get("children", []): self.par[c] = i
        self.anims = {a["name"]: a for a in js["animations"]}
    def sample(self, name):
        a = self.anims[name]; ch = {}
        for c in a["channels"]:
            s = a["samplers"][c["sampler"]]
            ch[(c["target"]["node"], c["target"]["path"])] = (acc(self.js, self.b, s["input"])[:, 0], acc(self.js, self.b, s["output"]).astype(np.float64))
        return ch
    def pose(self, ch, t):
        local = {}
        for i, n in enumerate(self.nodes):
            tr = np.array(n.get("translation", [0, 0, 0]), dtype=np.float64); q = np.array(n.get("rotation", [0, 0, 0, 1]), dtype=np.float64); s = np.array(n.get("scale", [1, 1, 1]), dtype=np.float64)
            for path in ("translation", "rotation", "scale"):
                if (i, path) in ch:
                    ts, vs = ch[(i, path)]
                    tt = min(max(t, ts[0]), ts[-1]); k = max(min(np.searchsorted(ts, tt) - 1, len(ts) - 2), 0)
                    f = 0 if ts[k+1] == ts[k] else (tt - ts[k]) / (ts[k+1] - ts[k])
                    if path == "rotation": q = slerp(vs[k], vs[k+1], f)
                    else:
                        v = vs[k] + f * (vs[k+1] - vs[k])
                        if path == "translation": tr = v
                        else: s = v
            M = np.eye(4); M[:3, :3] = quat_to_R(q) * s; M[:3, 3] = tr; local[i] = M
        W = {}
        def get(i):
            if i in W: return W[i]
            W[i] = (get(self.par[i]) @ local[i]) if i in self.par else local[i]; return W[i]
        return {i: get(i) for i in range(len(self.nodes))}
    def skin(self, world):
        S = np.stack([world[j] @ self.ibm[k] for k, j in enumerate(self.joints)])
        Ph = np.concatenate([self.P, np.ones((len(self.P), 1))], 1)
        out = np.zeros_like(self.P)
        for k in range(4):
            out += self.W[:, k:k+1] * np.einsum("nij,nj->ni", S[self.J[:, k]], Ph)[:, :3]
        return out
