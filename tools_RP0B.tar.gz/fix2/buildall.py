import sys, os, json, time, hashlib; SP=os.environ["SP"]; sys.path.insert(0, SP+"/fix2")
from sitlib import *
import q2t
def seam_deg(ch):
    m = 0.0
    for (n, p), (t, v) in ch.items():
        if p == "rotation": m = max(m, 2 * np.degrees(np.arccos(min(1, abs(float(np.dot(v[0], v[-1])))))))
    return m
def hip_drift(M, R, ch):
    ts = ch[(R.HIP, "translation")][0]; a = M.pose(ch, 0.0)[R.HIP][:3, 3]; b = M.pose(ch, ts[-1])[R.HIP][:3, 3]; return b - a
def build_hero(key, out_dir, only=None):
    dst = SP + f"/heroes/{key}.glb"; out = f"{out_dir}/{key}.glb"
    Ra = q2t.make(dst, "anims"); Rw = q2t.make(dst, "army"); M = Ra.M
    import t2t; Rt = t2t.make(dst)
    clips = {}   # name -> (ch, dur, meta)
    def add(name, R, clip, src_desc, loop=False, tag="q", **kw):
        kw = dict(kw); kw.setdefault('loop', loop)
        ch, dur, dy = R.clip(clip, **kw)
        if loop and not kw.get("pingpong") and seam_deg(ch) > 0.5 and not kw.get("close"):
            kw.update(close=0.3); ch, dur, dy = R.clip(clip, **kw)
        if tag == "q": e = q2t.dir_err(R, clip, ch, kw.get("trim"), dur, speed=kw.get("speed", 1.0), pp=kw.get("pingpong", False))
        else: e = t2t.err_report(R, clip, ch, kw.get("trim"), dur) + (0, 0)
        clips[name] = (ch, dur, dict(src=src_desc, loop=loop, dy=dy, seam=seam_deg(ch), err=e, tag=tag, drift=hip_drift(M, R, ch).tolist()))
    # ---- Quaternius sources
    add("slash_a", Rw, "Sword_Regular_A", "anims_army.glb Sword_Regular_A", mode="detrend")
    add("slash_b", Rw, "Sword_Regular_B", "anims_army.glb Sword_Regular_B", mode="detrend")
    add("slash_c", Ra, "Sword_Attack", "anims.glb Sword_Attack [0.45-1.25 s] x1.15", mode="detrend", trim=(0.45, 1.25), speed=1.15)
    add("heavy", Ra, "Sword_Attack", "anims.glb Sword_Attack [0-1.25 s] x1.35", mode="detrend", trim=(0.0, 1.25), speed=1.35)
    add("block", Rw, "Sword_Block", "anims_army.glb Sword_Block hold [0.22-0.64 s] ping-pong", loop=True, mode="detrend", trim=(0.22, 0.64), pingpong=True)
    add("interact", Ra, "Interact", "anims.glb Interact [0.15-1.7 s] x1.4", mode="detrend", trim=(0.15, 1.7), speed=1.4)
    # ---- Tripo library (Elina rig)
    add("swim", Rt, "swim", "Elina library swim (Tripo)", loop=True, tag="t", mode="loop")
    add("climb", Rt, "climb", "Elina library climb (Tripo), drift removed in all 3 axes", loop=True, tag="t", mode="loop", ymode="loop", ground="off")
    # ---- sit (Quaternius loop + synthesized transitions)
    sit = build_sit(Ra)
    for nm, (ch, d, info) in sit.items():
        clips[nm] = (ch, d, dict(src={"sit_idle": "anims.glb Sitting_Idle_Loop", "sit_down": "SYNTHESIZED: hero idle pose -> sit pose (local slerp, lean, eased hip)", "stand_up": "SYNTHESIZED: sit pose -> hero idle pose (local slerp, lean, eased hip)"}[nm], loop=(nm == "sit_idle"), dy=info.get("dy"), seam=seam_deg(ch), err=None, tag="s", drift=hip_drift(M, Ra, ch).tolist(), info=info))
    def rest_nodes(n, p): return np.array(M.nodes[n].get(p, {"translation": [0, 0, 0], "rotation": [0, 0, 0, 1], "scale": [1, 1, 1]}[p]), dtype=np.float64)
    order = ["sit_down", "sit_idle", "stand_up", "slash_a", "slash_b", "slash_c", "heavy", "block", "swim", "climb", "interact"]
    anims = []; meta = {}
    for nm in order:
        ch, d, m_ = clips[nm]; tl = TOLC.get(nm, TOL); red = reduce_channels(ch, rest_nodes, rtol_deg=tl[0], ptol=tl[1]); anims.append((nm, red)); m_["dur"] = d; m_["keys"] = sum(len(v[0]) for v in red.values()); meta[nm] = m_
    size = append_anims(dst, out, anims)
    return out, size, meta
TOL = (0.25, 0.001)
TOLC = {'swim': (0.5, 0.002), 'climb': (0.5, 0.002)}
if __name__ == "__main__":
    out_dir = SP + "/out"; os.makedirs(out_dir, exist_ok=True)
    keys = sys.argv[1:] or ["elina", "elika", "melika", "mobina", "aylin", "aylar"]
    allmeta = {}
    for k in keys:
        t0 = time.time(); out, size, meta = build_hero(k, out_dir); allmeta[k] = meta
        print(f"== {k}: {size/1e6:.2f} MB  ({time.time()-t0:.0f}s)")
        for nm, m in meta.items():
            e = m["err"]; es = "" if e is None else (f"dir {e[0]:.1f}/{e[1]:.1f}deg pos {e[2]:.1f}/{e[3]:.1f}%" if m["tag"] == "q" else f"pos-vs-src {e[0]:.2f}/{e[1]:.2f}%")
            print(f"   {nm:10s} {m['dur']:5.2f}s keys {m['keys']:5d} seam {m['seam']:5.2f} drift {np.round(m['drift'],3).tolist()} {es}")
    json.dump(allmeta, open(out_dir + "/meta.json", "w"), default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o), indent=1)
