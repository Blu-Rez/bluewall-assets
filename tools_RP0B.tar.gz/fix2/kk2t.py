"""KayKit Rig_Medium (T-pose, +Z, no fingers) -> Tripo hero game GLB."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from retarget import *
SP = "/tmp/claude-0/-home-claude/76475dc9-8f62-5f71-8a18-02485455571c/scratchpad"
KKSRC = SP + "/kk/legionary.glb"
def make(dst):
    pairs = {"Hip": "hips", "Spine01": "spine", "Spine02": "chest", "Head": "head"}
    kids = {}
    for s, sl in (("L", "l"), ("R", "r")):
        pairs.update({f"{s}_Upperarm": f"upperarm.{sl}", f"{s}_Forearm": f"lowerarm.{sl}", f"{s}_Hand": f"wrist.{sl}", f"{s}_Thigh": f"upperleg.{sl}", f"{s}_Calf": f"lowerleg.{sl}", f"{s}_Foot": f"foot.{sl}", f"{s}_ToeBase": f"toes.{sl}"})
        kids.update({f"{s}_Upperarm": (f"{s}_Forearm", f"lowerarm.{sl}"), f"{s}_Forearm": (f"{s}_Hand", f"wrist.{sl}"), f"{s}_Hand": (f"{s}_Mid1", f"hand.{sl}")})
    R = Retargeter(dst, KKSRC, pairs, kids, F=np.eye(3), src_mesh=False, src_pelvis="hips")
    R.foot_bones = ["foot.l", "foot.r", "toes.l", "toes.r"]
    # hip-travel scale from the thigh joint height (the KayKit 'hips' node sits below the pelvis joint)
    R.scale = R.restM[R.dn["L_Thigh"]][1, 3] / R.restS[R.sidx["upperleg.l"]][1, 3]
    return R
