"""World-delta retarget onto a (game) hero GLB, any source rig.  RP0B.
 D(t) = F R_src(t) (F R_src_rest)^-1 ;  R_dst(t) = D(t) · C_b · R_dst_rest
 C_b = swing that takes the dst rest bone direction onto the src rest bone direction (T-pose vs A-pose); identity for same-rig sources.
 Hip travel in world space, scaled by hip height; optional ground fit; drift modes."""
from skel import *

class Retargeter:
    def __init__(self, dst_path, src_path, pairs, bone_children, F=np.eye(3), src_mesh=False, src_pelvis="pelvis", dst_hip="Hip", dst_root="BoneRoot", scale=None):
        """pairs: {dst_name: src_name}; bone_children: {dst_name: (dst_child, src_child)} for the rest-direction correction C"""
        self.M = Model(dst_path); self.S = Model(src_path) if src_mesh else Skel(src_path); self.F = F
        M, S = self.M, self.S
        self.dn = {n.get("name"): i for i, n in enumerate(M.nodes)}
        self.sidx = {n.get("name"): i for i, n in enumerate(S.nodes)}; S.idx = self.sidx
        self.map = {self.dn[d]: self.sidx[s] for d, s in pairs.items() if d in self.dn and s in self.sidx}
        self.topo = []
        def _v(i):
            self.topo.append(i)
            for c in M.nodes[i].get("children", []): _v(c)
        for r in [i for i in range(len(M.nodes)) if i not in M.par]: _v(r)
        self.restM = M.pose({}, 0); self.restS = S.pose({}, 0)
        self.Rd0 = {i: R3(self.restM[i]) for i in range(len(M.nodes))}
        self.Rs0 = {j: F @ R3(self.restS[j]) for j in range(len(S.nodes))}
        self.HIP = self.dn[dst_hip]; self.ROOT = self.dn.get(dst_root)
        self.spel = self.sidx[src_pelvis]
        self.bind_hip = self.restM[self.HIP][:3, 3].copy()
        self.Ps0 = F @ self.restS[self.spel][:3, 3]
        self.scale = scale if scale else self.bind_hip[1] / self.Ps0[1]
        # rest-direction correction C (world), swing only
        self.C = {i: np.eye(3) for i in range(len(M.nodes))}
        for dname, (dc, sc) in bone_children.items():
            if dname not in self.dn or dc not in self.dn or dname not in pairs: continue
            i, ci = self.dn[dname], self.dn[dc]; j, cj = self.sidx[pairs[dname]], self.sidx[sc]
            vd = self.restM[ci][:3, 3] - self.restM[i][:3, 3]
            vs = F @ (self.restS[cj][:3, 3] - self.restS[j][:3, 3])
            if np.linalg.norm(vd) > 1e-6 and np.linalg.norm(vs) > 1e-6: self.C[i] = arc(vd, vs)
        self.inherit_C = {}
    def inherit(self, child, parent):
        """bones without a child pair take the correction of another bone"""
        if child in self.dn and parent in self.dn: self.C[self.dn[child]] = self.C[self.dn[parent]]
    def clip(self, clip, trim=None, dt=1/30., mode="detrend", ymode="keep", ground="auto", close=0.0, loop=False, hip_follow=True, rebase_y=False, fingers_gain=1.0, speed=1.0, hip_offset=None, pingpong=False):
        M, S, F = self.M, self.S, self.F
        chS = S.sample(clip); dur = max(v[0][-1] for v in chS.values())
        a, b = (0.0, dur) if trim is None else trim
        Tn = (b - a) / speed; n = int(round(Tn / dt)); ts = np.append(np.arange(n) * dt, Tn); ts_abs = a + ts * speed
        Rq = {i: [] for i in self.map}; Wpel = []; Wd_list = []
        for t in ts_abs:
            wS = S.pose(chS, t); Wd = {}
            for i in self.topo:
                pi = M.par.get(i)
                if i in self.map:
                    j = self.map[i]; D = (F @ R3(wS[j])) @ self.Rs0[j].T
                    Rw = D @ self.C[i] @ self.Rd0[i]
                else:
                    Rw = (Wd[pi] if pi is not None else np.eye(3)) @ quat_to_R(np.array(M.nodes[i].get("rotation", [0, 0, 0, 1.0])))
                Wd[i] = Rw
                if i in self.map: Rq[i].append(qfromR((Wd[pi].T if pi is not None else np.eye(3)) @ Rw))
            Wd_list.append(Wd)
            Wpel.append(F @ wS[self.spel][:3, 3])
        ch = {}
        for i, qs in Rq.items():
            q = cont(np.array(qs)); ch[(i, "rotation")] = (ts, q)
        Wp = np.array(Wpel); Wk = self.bind_hip[None] + self.scale * (Wp - self.Ps0[None])
        # ---- drift modes (world XZ, and Y for ymode='loop')
        net = Wk[-1] - Wk[0]; s_ = (ts / ts[-1])[:, None]
        if mode in ("loop", "detrend"):
            Wk[:, [0, 2]] -= s_ * net[[0, 2]]
            if mode == "loop": Wk[:, [0, 2]] += self.bind_hip[[0, 2]] - Wk[:, [0, 2]].mean(0)
        elif mode == "lock": Wk[:, [0, 2]] = self.bind_hip[[0, 2]]
        if ymode == "loop":
            Wk[:, 1] -= s_[:, 0] * net[1]; Wk[:, 1] += self.bind_hip[1] - Wk[:, 1].mean()
        if rebase_y: Wk[:, 1] -= Wk[0, 1] - self.bind_hip[1]
        if hip_offset is not None: Wk = Wk + np.array(hip_offset)[None]
        pi = M.par[self.HIP]; P_p0 = self.restM[pi][:3, 3]
        def hip_local(Wk_):
            return np.array([Wd_list[k][pi].T @ (Wk_[k] - P_p0) if pi in Wd_list[k] else Wk_[k] - P_p0 for k in range(len(ts))])
        ch[(self.HIP, "translation")] = (ts, hip_local(Wk))
        # ---- ground fit
        dy_stat = None
        if ground != "off":
            step = max(1, int(round(len(ts) / 36)))
            ks = list(range(0, len(ts), step)); ks = ks + ([len(ts) - 1] if ks[-1] != len(ts) - 1 else [])
            dys = []
            for k in ks:
                P = M.skin(M.pose(ch, ts[k]))
                low = float(P[:, 1].min())
                if ground == "auto" and isinstance(S, Model):
                    tgt = float(S.skin(S.pose(chS, ts_abs[k]))[:, 1].min())
                else:
                    tgt = self.ground_target(chS, ts_abs[k])
                dys.append(float(np.clip(tgt - low, -0.25, 0.25)))
            dy = np.interp(np.arange(len(ts)), ks, dys); Wk[:, 1] += dy
            ch[(self.HIP, "translation")] = (ts, hip_local(Wk)); dy_stat = (min(dys), max(dys))
        # ---- close the loop (blend last `close` seconds into the first pose)
        if loop and close > 0:
            u = np.clip((ts - (ts[-1] - close)) / close, 0, 1); u = (u * u * (3 - 2 * u))[:, None]
            for key, (t, v) in list(ch.items()):
                if key[1] == "rotation":
                    v = cont(qnorm(v)); v0 = v[0]; v1 = np.where(((v * v0).sum(1) < 0)[:, None], -v0[None], v0[None]); v = qnorm(v * (1 - u) + v1 * u)
                else: v = v * (1 - u) + v[0][None] * u
                ch[key] = (t, v)
        if pingpong:
            for key, (t, v) in list(ch.items()):
                t2 = np.concatenate([t, t[-1] + (t[-1] - t[::-1][1:])]); v2 = np.concatenate([v, v[::-1][1:]]); ch[key] = (t2, v2)
            ts = ch[(self.HIP, "translation")][0]
        return ch, float(ts[-1]), dy_stat
    def ground_target(self, chS, t):
        """src has no mesh: lowest foot/ball bone height above its rest value, scaled"""
        S = self.S; w = S.pose(chS, t); w0 = self.restS
        fb = [self.sidx[n] for n in self.foot_bones]
        cur = min(w[j][1, 3] for j in fb); rest = min(w0[j][1, 3] for j in fb)
        return self.rest_low + self.scale * (cur - rest)
    foot_bones = ["foot_l", "foot_r", "ball_l", "ball_r"]
    @property
    def rest_low(self):
        if not hasattr(self, "_rl"): self._rl = float(self.M.skin(self.restM)[:, 1].min())
        return self._rl

def reduce_channels(ch, rest_nodes, rtol_deg=0.15, ptol=0.0005):
    out = {}
    rtol = np.deg2rad(rtol_deg)
    for (n, p), (t, v) in ch.items():
        r = rest_nodes(n, p)
        if p == "rotation":
            v = cont(qnorm(v.copy())); dev = 2 * np.arccos(np.clip(np.abs(v @ r), 0, 1)).max()
            if dev < 1e-4: continue
            if np.ptp(v, axis=0).max() < 1e-5: t2, v2 = np.array([t[0], t[-1]]), v[[0, -1]]
            else: ix = reduce_keys(t, v, rtol, True); t2, v2 = t[ix], v[ix]
        else:
            dev = np.abs(v - r).max()
            if dev < 1e-4: continue
            if np.ptp(v, axis=0).max() < 1e-5: t2, v2 = np.array([t[0], t[-1]]), v[[0, -1]]
            else: ix = reduce_keys(t, v, ptol, False); t2, v2 = t[ix], v[ix]
        out[(n, p)] = (t2, v2)
    return out

def append_anims(src_glb, dst_glb, anims):
    """anims = [(name, {(node,path):(t,v)})]  appended after the old data; old animations stay byte-identical"""
    from glbwrite import rebuild
    js, b = load(src_glb); b = bytearray(b)
    while len(b) % 4: b.append(0)
    pool = bytearray(); new_acc = []
    base_acc = len(js["accessors"]); bv_idx = len(js["bufferViews"])
    def add(arr, typ, minmax=False):
        while len(pool) % 4: pool.extend(b"\0")
        off = len(pool); pool.extend(np.ascontiguousarray(arr, dtype="<f4").tobytes())
        a = {"bufferView": bv_idx, "byteOffset": off, "componentType": 5126, "count": int(len(arr)), "type": typ}
        if minmax: a["min"] = [float(arr.min())]; a["max"] = [float(arr.max())]
        new_acc.append(a); return base_acc + len(new_acc) - 1
    new_anims = []
    for name, ch in anims:
        samplers, channels = [], []
        for (n, p), (t, v) in ch.items():
            si = len(samplers)
            samplers.append({"input": add(t.reshape(-1, 1), "SCALAR", True), "output": add(v, "VEC4" if p == "rotation" else "VEC3"), "interpolation": "LINEAR"})
            channels.append({"sampler": si, "target": {"node": n, "path": p}})
        new_anims.append({"name": name, "samplers": samplers, "channels": channels})
    off0 = len(b); b.extend(pool)
    js["bufferViews"].append({"buffer": 0, "byteOffset": off0, "byteLength": len(pool)})
    js["accessors"].extend(new_acc); js["animations"].extend(new_anims)
    js["buffers"][0]["byteLength"] = len(b)
    j = json.dumps(js, separators=(",", ":")).encode(); j += b" " * (-len(j) % 4)
    body = struct.pack("<II", len(j), 0x4E4F534A) + j + struct.pack("<II", len(b), 0x004E4942) + bytes(b)
    open(dst_glb, "wb").write(b"glTF" + struct.pack("<II", 2, 12 + len(body)) + body)
    return len(b) + len(j)


def pose_local(R, ch_or_none, t, hip_world=None):
    """local quats of every node (rest where unanimated) + hip world position, for a dst model pose at time t"""
    M = R.M; out = {}
    for i, n in enumerate(M.nodes): out[i] = np.array(n.get("rotation", [0, 0, 0, 1.0]), dtype=np.float64)
    return out

def synth_transition(R, A, B, T, lean=0.30, ease=None, dt=1/30., hipA=None, hipB=None, ground=True, lean_bones=("Waist", "Spine01", "Spine02")):
    """local-space slerp from pose A to pose B (dict node->quat) with a forward lean bump and an eased hip path.
    A, B: dict(q={node: quat}, hip=world hip pos). Returns channels (rotation of all nodes that differ + Hip translation)."""
    M = R.M; n = int(round(T / dt)); ts = np.append(np.arange(n) * dt, T); u = ts / T
    ease = ease or (lambda x: x * x * x * (x * (6 * x - 15) + 10))
    s = np.array([ease(x) for x in u]); lb = [R.dn[b] for b in lean_bones]
    ch = {}; nodes = list(A["q"].keys())
    Rl = {}  # world lean matrix per frame
    th = lean * np.sin(np.pi * np.clip(u, 0, 1) ** 0.85)
    qs = {i: [] for i in nodes}; Wd_all = []
    for k in range(len(ts)):
        Wd = {}
        for i in R.topo:
            pi = M.par.get(i)
            if i in A["q"]:
                q = slerp(A["q"][i], B["q"][i], s[k]); Rl_ = quat_to_R(q)
            else:
                Rl_ = quat_to_R(np.array(M.nodes[i].get("rotation", [0, 0, 0, 1.0])))
            Rw = (Wd[pi] if pi is not None else np.eye(3)) @ Rl_
            if i in lb:
                c, sn = np.cos(th[k] / len(lb)), np.sin(th[k] / len(lb)); Rx = np.array([[1, 0, 0], [0, c, -sn], [0, sn, c]]); Rw = Rx @ Rw
            Wd[i] = Rw
            if i in A["q"]: qs[i].append(qfromR((Wd[pi].T if pi is not None else np.eye(3)) @ Rw))
        Wd_all.append(Wd)
    for i, q in qs.items(): ch[(i, "rotation")] = (ts, cont(np.array(q)))
    Wk = np.array([hipA + (hipB - hipA) * np.array([sx, sy, sx]) for sx, sy in [(e, e) for e in s]])
    pi = M.par[R.HIP]; P_p0 = R.restM[pi][:3, 3]
    hl = lambda W_: np.array([Wd_all[k][pi].T @ (W_[k] - P_p0) for k in range(len(ts))])
    ch[(R.HIP, "translation")] = (ts, hl(Wk))
    if ground:
        step = max(1, int(round(len(ts) / 30))); ks = list(range(0, len(ts), step)); ks += ([len(ts) - 1] if ks[-1] != len(ts) - 1 else [])
        dys = [float(np.clip(R.rest_low - float(M.skin(M.pose(ch, ts[k]))[:, 1].min()), -0.25, 0.25)) for k in ks]
        Wk[:, 1] += np.interp(np.arange(len(ts)), ks, dys); ch[(R.HIP, "translation")] = (ts, hl(Wk))
    return ch, float(T)
