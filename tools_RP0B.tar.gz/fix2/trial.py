import sys, os, time, json; SP=os.environ["SP"]; sys.path.insert(0, SP+"/fix2")
from q2t import *
def build(dst, out, specs):
    """specs = [(outname, which, clip, kwargs)]"""
    cache = {}; anims = []
    for name, which, clip, kw in specs:
        if which not in cache: cache[which] = make(dst, which)
        R = cache[which]; kw = dict(kw)
        ch, dur, dy = R.clip(clip, **kw)
        e = dir_err(R, clip, ch, kw.get("trim"), dur)
        M = R.M
        def rest_nodes(n, p): return np.array(M.nodes[n].get(p, {"translation":[0,0,0],"rotation":[0,0,0,1],"scale":[1,1,1]}[p]), dtype=np.float64)
        red = reduce_channels(ch, rest_nodes)
        anims.append((name, red)); print(f"  {name:12s} dur {dur:5.2f}s  dy {dy}  dir err mean/max {e[0]:.1f}/{e[1]:.1f}°  pos err mean/max {e[2]:.1f}/{e[3]:.1f}%  chans {len(red)} keys {sum(len(v[0]) for v in red.values())}")
    size = append_anims(dst, out, anims); print("wrote", out, size)
