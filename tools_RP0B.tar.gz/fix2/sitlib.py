import sys, os; SP=os.environ["SP"]; sys.path.insert(0, SP+"/fix2")
from q2t import *
def foot_xz(M, w): return np.array([(w[M.dn["L_Foot"]][[0,2],3] + w[M.dn["R_Foot"]][[0,2],3]) / 2]).ravel() if False else (w[M_idx(M,"L_Foot")][[0,2],3] + w[M_idx(M,"R_Foot")][[0,2],3]) / 2
_dn = {}
def M_idx(M, n):
    k = id(M)
    if k not in _dn: _dn[k] = {x.get("name"): i for i, x in enumerate(M.nodes)}
    return _dn[k][n]
def build_sit(R, T_down=1.2, T_up=1.0, lean=0.28, loop_close=0.3):
    """R = q2t.make(dst,'anims'). Returns dict name -> (channels, duration, info)"""
    M = R.M
    chB, dB, _ = R.clip("Sitting_Idle_Loop", mode="keep", ground="auto")
    wB = M.pose(chB, 0.0)
    chI = M.sample("idle"); wA = M.pose(chI, 0.0)
    def locq(ch, t):
        q = {}
        for i in R.map:
            if (i, "rotation") in ch:
                ts, v = ch[(i, "rotation")]; k = 0 if t <= ts[0] else min(np.searchsorted(ts, t) - 1, len(ts) - 2); f = 0 if ts[k+1] == ts[k] else (t - ts[k]) / (ts[k+1] - ts[k]); q[i] = slerp(v[k], v[k+1], min(max(f, 0), 1))
            else: q[i] = np.array(M.nodes[i].get("rotation", [0, 0, 0, 1.0]), dtype=np.float64)
        return q
    A = dict(q=locq(chI, 0.0), hip=wA[R.HIP][:3, 3].copy()); B = dict(q=locq(chB, 0.0), hip=wB[R.HIP][:3, 3].copy())
    fA = foot_xz(M, wA); fB = foot_xz(M, wB); off = np.array([0.0, 0.0, fA[1] - fB[1]])   # lock only the forward/back foot position; sideways stance stays the hero's own
    B["hip"] = B["hip"] + off
    out = {}
    chS, dS, dy = R.clip("Sitting_Idle_Loop", mode="keep", ground="auto", hip_offset=off, loop=True, close=loop_close)
    out["sit_idle"] = (chS, dS, dict(foot_lock_offset=off.round(3).tolist(), dy=dy))
    chD, dD = synth_transition(R, A, B, T_down, lean=lean, hipA=A["hip"], hipB=B["hip"])
    out["sit_down"] = (chD, dD, {})
    chU, dU = synth_transition(R, B, A, T_up, lean=lean, hipA=B["hip"], hipB=A["hip"])
    out["stand_up"] = (chU, dU, {})
    return out
