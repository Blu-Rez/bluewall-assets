"""Tripo library (Elina 79-bone, -Z) -> any sister game GLB (+Z)."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from retarget import *
SP = "/tmp/claude-0/-home-claude/76475dc9-8f62-5f71-8a18-02485455571c/scratchpad"
LIB = SP + "/r2/elina_all_fix.glb"
KEYB = ["L_Thigh","L_Calf","L_Foot","R_Thigh","R_Calf","R_Foot","L_Upperarm","L_Forearm","L_Hand","R_Upperarm","R_Forearm","R_Hand","Spine01","Spine02","Head"]

def make(dst, src=LIB):
    S = Model(src); names = set(S.names)
    D = Model(dst)
    pairs = {n: n for n in D.names if n in names}
    return Retargeter(dst, src, pairs, {}, F=np.eye(3), src_mesh=True, src_pelvis="Hip")

def err_report(R, clip, ch, trim, dur, n=14):
    """joint positions relative to Hip, src (flipped) vs dst, in % of dst height; plus hip world path error"""
    M, S, F = R.M, R.S, R.F
    chS = S.sample(clip); a = trim[0] if trim else 0.0
    H = float(M.skin(R.restM)[:, 1].max())
    errs = []
    for t in np.linspace(0, dur * 0.99, n):
        wd = M.pose(ch, t); ws = S.pose(chS, a + t)
        hd = wd[R.HIP][:3, 3]; hs = F @ ws[R.sidx["Hip"]][:3, 3]
        e = [np.linalg.norm((wd[R.dn[nm]][:3, 3] - hd) - (F @ ws[R.sidx[nm]][:3, 3] - hs)) for nm in KEYB]
        errs.append(np.mean(e) / H * 100)
    return float(np.mean(errs)), float(np.max(errs))
