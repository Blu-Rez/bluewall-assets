"""Skeleton-only + retarget helpers (RP0B). Source rig may have no skin/mesh (Quaternius packs)."""
import sys, os, json, struct, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pose import *

class Skel:
    def __init__(self, path):
        self.js, self.b = load(path); js = self.js
        self.nodes = js["nodes"]; self.par = {}
        for i, n in enumerate(self.nodes):
            for c in n.get("children", []): self.par[c] = i
        self.idx = {n.get("name"): i for i, n in enumerate(self.nodes)}
        self.anims = {a["name"]: a for a in js.get("animations", [])}
        self.topo = []
        def _v(i):
            self.topo.append(i)
            for c in self.nodes[i].get("children", []): _v(c)
        for r in [i for i in range(len(self.nodes)) if i not in self.par]: _v(r)
    sample = Model.sample
    pose = Model.pose

def R3(M4):
    R = M4[:3, :3].copy()
    for i in range(3): R[:, i] /= np.linalg.norm(R[:, i])
    return R

def qfromR(R):
    t = np.trace(R)
    if t > 0:
        s = np.sqrt(t + 1) * 2; q = [(R[2, 1] - R[1, 2]) / s, (R[0, 2] - R[2, 0]) / s, (R[1, 0] - R[0, 1]) / s, 0.25 * s]
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = np.sqrt(1 + R[0, 0] - R[1, 1] - R[2, 2]) * 2; q = [0.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s, (R[2, 1] - R[1, 2]) / s]
    elif R[1, 1] > R[2, 2]:
        s = np.sqrt(1 + R[1, 1] - R[0, 0] - R[2, 2]) * 2; q = [(R[0, 1] + R[1, 0]) / s, 0.25 * s, (R[1, 2] + R[2, 1]) / s, (R[0, 2] - R[2, 0]) / s]
    else:
        s = np.sqrt(1 + R[2, 2] - R[0, 0] - R[1, 1]) * 2; q = [(R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, 0.25 * s, (R[1, 0] - R[0, 1]) / s]
    q = np.array(q); return q / np.linalg.norm(q)

def arc(a, b):
    """shortest-arc rotation matrix taking unit vector a to unit vector b"""
    a = a / np.linalg.norm(a); b = b / np.linalg.norm(b)
    v = np.cross(a, b); c = float(np.dot(a, b)); s = np.linalg.norm(v)
    if s < 1e-9:
        if c > 0: return np.eye(3)
        # 180 deg: any perpendicular axis
        ax = np.cross(a, [1, 0, 0]);
        if np.linalg.norm(ax) < 1e-6: ax = np.cross(a, [0, 1, 0])
        ax /= np.linalg.norm(ax); return 2 * np.outer(ax, ax) - np.eye(3)
    K = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + K + K @ K * ((1 - c) / (s * s))

def qnorm(q): return q / np.linalg.norm(q, axis=-1, keepdims=True)

def cont(q):
    q = q.copy()
    for i in range(1, len(q)):
        if np.dot(q[i], q[i-1]) < 0: q[i] = -q[i]
    return q

def reduce_keys(t, v, tol, is_rot):
    n = len(t)
    if n <= 2: return np.arange(n)
    keep = {0, n - 1}; stack = [(0, n - 1)]
    while stack:
        a, b = stack.pop()
        if b - a < 2: continue
        idx = np.arange(a + 1, b)
        f = ((t[idx] - t[a]) / (t[b] - t[a]))[:, None]
        if is_rot:
            d = float(np.dot(v[a], v[b]))
            q1 = v[b] if d >= 0 else -v[b]
            est = qnorm(v[a][None] * (1 - f) + q1[None] * f)
            err = 2 * np.arccos(np.clip(np.abs((est * v[idx]).sum(1)), 0, 1))
        else:
            est = v[a][None] * (1 - f) + v[b][None] * f
            err = np.linalg.norm(est - v[idx], axis=1)
        k = int(err.argmax())
        if err[k] > tol:
            m = int(idx[k]); keep.add(m); stack.append((a, m)); stack.append((m, b))
    return np.array(sorted(keep))

def F_flip(): return np.diag([-1.0, 1.0, -1.0])
