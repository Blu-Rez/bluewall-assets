"""Quaternius (UE-style 66 node, T-pose, +Z) -> Tripo hero game GLB."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from retarget import *
SP = "/tmp/claude-0/-home-claude/76475dc9-8f62-5f71-8a18-02485455571c/scratchpad"
QSRC = {"anims": SP + "/dec/anims.glb", "army": SP + "/dec/anims_army.glb"}

def mapping():
    pairs = {"Hip": "pelvis", "Waist": "spine_01", "Spine01": "spine_02", "Spine02": "spine_03", "NeckTwist01": "neck_01", "Head": "Head"}
    kids = {"Hip": ("Waist", "spine_01"), "Waist": ("Spine01", "spine_02"), "Spine01": ("Spine02", "spine_03"), "Spine02": ("NeckTwist01", "neck_01"), "NeckTwist01": ("Head", "Head")}
    fin = {"Index": "index", "Mid": "middle", "Ring": "ring", "Pinky": "pinky", "Thumb": "thumb"}
    for s, sl in (("L", "l"), ("R", "r")):
        pairs.update({f"{s}_Clavicle": f"clavicle_{sl}", f"{s}_Upperarm": f"upperarm_{sl}", f"{s}_Forearm": f"lowerarm_{sl}", f"{s}_Hand": f"hand_{sl}",
                      f"{s}_Thigh": f"thigh_{sl}", f"{s}_Calf": f"calf_{sl}", f"{s}_Foot": f"foot_{sl}", f"{s}_ToeBase": f"ball_{sl}"})
        kids.update({f"{s}_Clavicle": (f"{s}_Upperarm", f"upperarm_{sl}"), f"{s}_Upperarm": (f"{s}_Forearm", f"lowerarm_{sl}"), f"{s}_Forearm": (f"{s}_Hand", f"hand_{sl}"),
                     f"{s}_Hand": (f"{s}_Mid1", f"middle_01_{sl}"), f"{s}_Thigh": (f"{s}_Calf", f"calf_{sl}"), f"{s}_Calf": (f"{s}_Foot", f"foot_{sl}"), f"{s}_Foot": (f"{s}_ToeBase", f"ball_{sl}")})
        for tn, qn in fin.items():
            for k in (1, 2, 3):
                pairs[f"{s}_{tn}{k}"] = f"{qn}_0{k}_{sl}"
                if k < 3: kids[f"{s}_{tn}{k}"] = (f"{s}_{tn}{k+1}", f"{qn}_0{k+1}_{sl}")
    return pairs, kids

def make(dst, which="anims"):
    pairs, kids = mapping()
    R = Retargeter(dst, QSRC[which], pairs, kids, F=np.eye(3), src_mesh=False, src_pelvis="pelvis")
    for s in ("L", "R"):
        for tn in ("Index", "Mid", "Ring", "Pinky", "Thumb"): R.inherit(f"{s}_{tn}3", f"{s}_{tn}2")
        R.inherit(f"{s}_ToeBase", f"{s}_Foot")
    R.inherit("Head", "NeckTwist01")
    # only the arm chain needs the T-pose -> A-pose swing; torso, clavicles and legs keep the hero's own rest stance
    for n in ["Hip","Waist","Spine01","Spine02","NeckTwist01","Head","L_Clavicle","R_Clavicle","L_Thigh","R_Thigh","L_Calf","R_Calf","L_Foot","R_Foot","L_ToeBase","R_ToeBase"]:
        R.C[R.dn[n]] = np.eye(3)
    return R

def dir_err(R, clip, ch, trim, dur, n=14, speed=1.0, pp=False):
    """bone-direction error (deg) for the limb/spine pairs, src vs dst, independent of proportions + end-effector position error (% height, proportion-limited)"""
    M, S = R.M, R.S; chS = S.sample(clip); a = trim[0] if trim else 0.0
    pairs, kids = mapping(); pl = [(d, kids[d][0], pairs[d], kids[d][1]) for d in kids if d in ("Waist","Spine01","Spine02","L_Upperarm","L_Forearm","L_Hand","L_Thigh","L_Calf","L_Foot","R_Upperarm","R_Forearm","R_Hand","R_Thigh","R_Calf","R_Foot")]
    H = float(M.skin(R.restM)[:, 1].max()); Hs = 1.69
    angs, poss = [], []
    for t in np.linspace(0, dur * 0.99, n):
        L = dur / 2 if pp else dur; tt = t if (not pp or t <= L) else 2 * L - t
        wd = M.pose(ch, t); ws = S.pose(chS, a + tt * speed)
        for d, dc, s, sc in pl:
            vd = wd[R.dn[dc]][:3, 3] - wd[R.dn[d]][:3, 3]; vs = ws[R.sidx[sc]][:3, 3] - ws[R.sidx[s]][:3, 3]
            angs.append(np.degrees(np.arccos(np.clip(np.dot(vd, vs) / np.linalg.norm(vd) / np.linalg.norm(vs), -1, 1))))
        hd = wd[R.HIP][:3, 3]; hs = ws[R.spel][:3, 3]
        for nm, sn in (("L_Hand", "hand_l"), ("R_Hand", "hand_r"), ("L_Foot", "foot_l"), ("R_Foot", "foot_r"), ("Head", "Head")):
            poss.append(np.linalg.norm((wd[R.dn[nm]][:3, 3] - hd) / H - (ws[R.sidx[sn]][:3, 3] - hs) / Hs) * 100)
    return float(np.mean(angs)), float(np.max(angs)), float(np.mean(poss)), float(np.max(poss))
