import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'fix'))
import numpy as np
from glbio import load, acc
LOOPS = ['sit_idle','block','swim','climb']
def seam(path):
    js, b = load(path); out = {}
    for a in js['animations']:
        if a['name'] not in LOOPS: continue
        mr = 0; mt = 0; vel = []
        for ch in a['channels']:
            s = a['samplers'][ch['sampler']]
            v = acc(js, b, s['output']); tt = acc(js, b, s['input'])[:,0]
            p = ch['target']['path']
            if p == 'rotation':
                d = abs(float(np.dot(v[0], v[-1]))); d = min(1.0, d)
                mr = max(mr, np.degrees(2*np.arccos(d)))
            elif p == 'translation':
                mt = max(mt, float(np.linalg.norm(v[0]-v[-1])))
        out[a['name']] = (round(mr,3), round(mt*100,3), round(float(tt[-1]),3))
    return out
rows = {}
for k in ['elina','elika','melika','mobina','aylin','aylar']:
    rows[k] = seam(f'deliver/patch/web/assets/rpg/{k}.glb')
print('| loop | ' + ' | '.join(rows) + ' |'); print('|---|' + '---|'*len(rows))
for n in LOOPS:
    print(f'| {n} | ' + ' | '.join(f'{rows[k][n][0]}° / {rows[k][n][1]} cm' for k in rows) + ' |')
