import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pose import *
m = Model(sys.argv[1])
I = m.I
E = np.concatenate([I[:, [0,1]], I[:, [1,2]], I[:, [2,0]]])
rest = np.linalg.norm(m.P[E[:,0]] - m.P[E[:,1]], axis=1)
idx = {n: m.joints[i] for i,n in enumerate(m.names)}
only = set(sys.argv[2:])
for name in m.anims:
    if only and name not in only: continue
    ch = m.sample(name); dur = max(v[0][-1] for v in ch.values())
    ts = np.linspace(0, dur, max(30, int(dur*12)))
    bad_tri = set(); ymin = 9; maxr = 0; hip_y=[]
    for t in ts:
        w = m.pose(ch, t); S = m.skin(w)
        L = np.linalg.norm(S[E[:,0]] - S[E[:,1]], axis=1)
        r = L / np.maximum(rest, 1e-5)
        bad = np.where((r > 4) & (L > 0.06))[0]
        for e in bad: bad_tri.add(int(e % len(I)))
        maxr = max(maxr, float(r.max())); ymin = min(ymin, float(S[:,1].min()))
    print(f"{name:16s} samples {len(ts):3d}  stretched tris {len(bad_tri):3d}  max edge ratio {maxr:5.1f}  lowest y {ymin:6.3f}")
