import json, struct
def rebuild(js, binbytes, replace):          # replace = {bufferView index: new bytes}
    bvs = js["bufferViews"]
    order = sorted(range(len(bvs)), key=lambda i: bvs[i].get("byteOffset", 0))
    out = bytearray()
    for i in order:
        data = replace.get(i, bytes(binbytes[bvs[i].get("byteOffset", 0): bvs[i].get("byteOffset", 0) + bvs[i]["byteLength"]]))
        while len(out) % 4: out.append(0)
        bvs[i]["byteOffset"] = len(out); bvs[i]["byteLength"] = len(data)
        out += data
    while len(out) % 4: out.append(0)
    js["buffers"][0]["byteLength"] = len(out)
    j = json.dumps(js, separators=(",", ":")).encode()
    j += b" " * (-len(j) % 4)
    body = struct.pack("<II", len(j), 0x4E4F534A) + j + struct.pack("<II", len(out), 0x004E4942) + bytes(out)
    return b"glTF" + struct.pack("<II", 2, 12 + len(body)) + body
