import json, struct, io
import numpy as np
from PIL import Image

CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}

def load(path):
    d = open(path, "rb").read()
    off, js, b = 12, None, None
    while off + 8 <= len(d):
        ln, t = struct.unpack_from("<II", d, off); body = d[off + 8: off + 8 + ln]
        if t == 0x4E4F534A: js = json.loads(body.decode("utf-8"))
        elif t == 0x004E4942: b = bytearray(body)
        off += 8 + ln
    return js, b

def acc(js, b, i):
    a = js["accessors"][i]; v = js["bufferViews"][a["bufferView"]]
    o = v.get("byteOffset", 0) + a.get("byteOffset", 0)
    n = NC[a["type"]]; dt = np.dtype(CT[a["componentType"]])
    stride = v.get("byteStride")
    if stride and stride != n * dt.itemsize:
        arr = np.ndarray((a["count"], n), dtype=dt, buffer=bytes(b), offset=o, strides=(stride, dt.itemsize)).copy()
    else:
        arr = np.frombuffer(bytes(b), dtype=dt, count=a["count"] * n, offset=o).reshape(a["count"], n).copy()
    return arr

def world_positions(js):
    nodes = js["nodes"]; par = {}
    for i, n in enumerate(nodes):
        for c in n.get("children", []): par[c] = i
    def local(n):
        if "matrix" in n: return np.array(n["matrix"], dtype=np.float64).reshape(4, 4).T
        t = np.array(n.get("translation", [0, 0, 0]), dtype=np.float64)
        q = np.array(n.get("rotation", [0, 0, 0, 1]), dtype=np.float64)
        s = np.array(n.get("scale", [1, 1, 1]), dtype=np.float64)
        x, y, z, w = q
        R = np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
        M = np.eye(4); M[:3, :3] = R * s; M[:3, 3] = t
        return M
    W = {}
    def get(i):
        if i in W: return W[i]
        M = local(nodes[i])
        W[i] = (get(par[i]) @ M) if i in par else M
        return W[i]
    return {i: get(i) for i in range(len(nodes))}
