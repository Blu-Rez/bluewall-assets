#!/bin/bash
# CN1 server test: the old clan + social tests, then the new route/rule test on memory state, then the same on a REAL Redis
# (a private redis-server on 127.0.0.1:6391 db 5, started here if needed; it is flushed by the test - never point this at a real one).
D=$(cd "$(dirname "$0")" && pwd); FAIL=0
python3 $D/clan_test.py 2>&1 | tail -1 | grep -q "^clan ok" && echo "OK   clan_test (updated for the CN1 rules)" || { echo "FAIL clan_test"; FAIL=1; }
python3 $D/social_test.py 2>&1 | tail -1 | grep -q "^social ok" && echo "OK   social_test" || { echo "FAIL social_test"; FAIL=1; }
python3 $D/cn1_test.py 2>&1 | tail -3 | grep -q "^CN1 SERVER OK$" && echo "OK   cn1_test (memory state)" || { echo "FAIL cn1_test (memory)"; python3 $D/cn1_test.py 2>&1 | grep -E "^FAIL|Error" | head -8; FAIL=1; }
if command -v redis-server >/dev/null 2>&1; then
  redis-cli -p 6391 ping >/dev/null 2>&1 || { redis-server --port 6391 --save "" --appendonly no --daemonize yes --bind 127.0.0.1 >/dev/null 2>&1; sleep 1; }
  CN1_REDIS=1 python3 $D/cn1_test.py 2>&1 | tail -3 | grep -q "^CN1 SERVER OK (redis)$" && echo "OK   cn1_test (real Redis: search index + cup totals)" || { echo "FAIL cn1_test (redis)"; CN1_REDIS=1 python3 $D/cn1_test.py 2>&1 | grep -E "^FAIL|Error" | head -8; FAIL=1; }
else echo "SKIP cn1_test on Redis (no redis-server here) - the search index and the cup totals are then NOT proven"; fi
[ $FAIL = 0 ] && echo "CN1 SERVER OK" || echo "CN1 SERVER FAILED"; exit $FAIL
