"""CN1 server test: the clan routes + rules with four main accounts (A leader, B, C, D) and a few helpers - every route, every refusal.

    python3 dev/cn1_test.py            memory state (BLUEWALL_STATE=memory)
    CN1_REDIS=1 python3 dev/cn1_test.py   the same run on a REAL Redis (port 6391, db 5; started by cn1_test.sh) - covers the search index and the cup totals

Talks to the real aiohttp app (make_app) in-process with bearer sessions, so the guards, rate limits and JSON shapes are the shipped ones.
liveops does not exist in the kit yet (OC1 builds it): a three-line stub with get / flag / register stands in for it.
Prints `CN1 SERVER OK` when nothing failed.
"""
import asyncio, json, os, sys, time, types

REDIS = bool(os.environ.get("CN1_REDIS"))
if REDIS:
    os.environ["BLUEBOT_REDIS_URL"] = "redis://127.0.0.1:6391"; os.environ["BLUEBOT_QUEUE_DB"] = "5"; os.environ.pop("BLUEWALL_STATE", None)
else:
    os.environ["BLUEWALL_STATE"] = "memory"
sys.path.insert(0, "/home/claude/dev/stubcfg"); sys.path.insert(0, "/home/claude/bot/bluebot_v2")

LO = types.ModuleType("bluewall.liveops"); LO.CFG, LO.FLAGS, LO.REG = {}, set(), {}
LO.get = lambda s: dict(LO.CFG.get(s, {})); LO.flag = lambda n: n in LO.FLAGS; LO.register = lambda s, d, v: LO.REG.__setitem__(s, (d, v))
sys.modules["bluewall.liveops"] = LO

from aiohttp.test_utils import TestClient, TestServer
from bluewall import server as SV, clan_ext as CX, auth as A
STORE = SV.STORE
FAIL = []


def T(cond, msg):
    if not cond:
        FAIL.append(msg); print("FAIL", msg)


TOK = {}
async def api(c, uid, method, path, body=None, rl=True):
    """one call as player `uid` (rl: forget the rate limiter first - the limiter itself is tested separately)"""
    if rl: SV._RL.clear()
    h = {"Authorization": "Bearer " + TOK.setdefault(uid, A.make_session(uid, SV._main_token()))}
    r = await (c.get(path, headers=h) if method == "GET" else c.post(path, json=body, headers=h))
    j = await r.json(); j["_s"] = r.status
    return j


async def setk(uid, keep=None, tro=None, **kw):
    async with STORE._lock(uid):
        s = await STORE._txn(uid)
        if keep is not None: s["b"]["keep"] = keep
        if tro is not None: s["tro"] = tro
        s.update(kw)
        await STORE.save(uid, s)
    if tro is not None: await STORE._lb_set(uid, await STORE.load(uid))


async def mk(uid, name, keep=2, tro=0):
    await STORE.touch(uid, name); await setk(uid, keep=keep, tro=tro)


def ids(l): return [x["id"] for x in l]


async def main():
    A_, B_, C_, D_, E_, E2 = 4001, 4002, 4003, 4004, 4005, 4006
    async with TestClient(TestServer(SV.make_app())) as c:
        P = lambda uid, op, **kw: api(c, uid, "POST", "/api/clan", dict(op=op, **kw))      # through HTTP: success answers with the fresh view, a refusal with {ok:false, reason:"no", why, ...}
        X = lambda uid, op, **kw: STORE.clans.command(uid, op, kw)                          # the same op straight on the store: the raw result (role / changed / id / wait)
        G = lambda uid, path="/api/clan": api(c, uid, "GET", path)
        if REDIS:
            r = await STORE._redis(); assert r is not None and "6391" in str(r.connection_pool.connection_kwargs.get("port", "")), "not the private test Redis"
            await r.flushdb()
        T("clan" in LO.REG and LO.REG["clan"][0] == CX.DEFAULTS and LO.REG["clan"][1] is CX.validate, "liveops section `clan` is registered with defaults + validate when the server starts")

        # ---- 0. guards
        for path in ("/api/clan", "/api/clan/find", "/api/clan/requests", "/api/clan/feed"):
            r = await c.get(path); T(r.status == 403 and (await r.json())["reason"] == "locked", "no login -> 403 locked " + path)
            r = await c.get(path, headers={"Authorization": "Bearer v1.1.2.zzz"}); T(r.status == 403, "bad token -> 403 " + path)
        r = await c.post("/api/clan", json={"op": "leave"}); T(r.status == 403, "POST without login -> 403")
        for uid, n, k in ((A_, "Ana", 2), (B_, "Bob", 2), (C_, "Cy", 2), (D_, "Dee", 1), (E_, "Eli", 2), (E2, "Eve", 2)):
            await mk(uid, n, keep=k)

        # ---- 1. create: every refusal, then the real thing
        j = await P(D_, "create", name="Blue Fleet", tag="BF"); T(j["why"] == "low" and j["need"] == 2 and j["_s"] == 200, "create: castle too low %s" % j)
        await setk(D_, keep=2)
        for kw, why in (({"name": "Bl", "tag": "BF"}, "name"), ({"name": "Blue Fleet", "tag": "b"}, "tag"), ({"name": "Blue Fleet", "tag": "TOOLONG"}, "tag"),
                        ({"name": "Blue Fleet", "tag": "BF", "desc": "x" * 121}, "desc"), ({"name": "Blue Fleet", "tag": "BF", "badge": "zzz"}, "badge"),
                        ({"name": "Blue Fleet", "tag": "BF", "type": "private"}, "type"), ({"name": "Blue Fleet", "tag": "BF", "min": -1}, "mincups"),
                        ({"name": "Blue Fleet", "tag": "BF", "min": "5"}, "mincups"), ({"name": "Blue Fleet", "tag": "BF", "min": 99999}, "mincups"),
                        ({"name": "Blue Fleet", "tag": "BF", "min": True}, "mincups")):
            j = await P(A_, "create", **kw); T(j["ok"] is False and j["why"] == why, "create refused with %s: got %s" % (why, j))
        j = await P(A_, "create", name="  Blue   Fleet ", tag="bf", desc="  Hello   there ‮ ", badge="wolf", type="request", min=100)
        T(j["ok"] and j["_s"] == 200 and j["mine"]["id"] > 0, "create ok"); cid1 = j["mine"]["id"]
        T((await P(A_, "create", name="Another", tag="AN"))["why"] == "in_clan", "create while in a clan")
        T((await P(B_, "create", name="blue fleet", tag="BX"))["why"] == "taken", "names are unique, case-blind")
        j = await STORE.clans.create(E_, "Second", "SC"); T(j["ok"], "old 3-argument create still works"); cid2 = j["id"]
        v = await G(A_); m = v["mine"]
        T(v["_s"] == 200 and v["ok"] and m["name"] == "Blue Fleet" and m["tag"] == "BF" and m["desc"] == "Hello there" and m["badge"] == "wolf" and m["type"] == "request" and m["min"] == 100, "view: stored fields %s" % {k: m.get(k) for k in ("name", "tag", "desc", "badge", "type", "min")})
        T(m["role"] == "leader" and m["me_owner"] and m["owner"] == A_ and m["n"] == 1 and m["max"] == 30 and m["req_n"] == 0 and m["members"][0]["role"] == "leader" and m["members"][0]["owner"], "view: leader fields")
        T(m["can"] == {"edit": True, "requests": True, "kick": True, "promote": True, "transfer": True}, "view: leader can %s" % m["can"])
        T(v["flags"] == {"chat_clan": False, "clan_war": False} and v["min_keep"] == 2 and v["desc_max"] == 120 and v["types"] == ["open", "request", "closed"] and v["wait"] == 0, "view: flags off + limits %s" % v["flags"])
        LO.FLAGS.update({"chat_clan", "clan_war"}); v2 = await G(A_); T(v2["flags"] == {"chat_clan": True, "clan_war": True}, "view: flags follow liveops"); LO.FLAGS.clear()
        j = await STORE.clans._get(cid2); T(j["badge"] and j["type"] == "open" and j["min"] == 0 and j["desc"] == "", "old create gets the defaults")

        # ---- 2. find: prefix, tag, filters, the button each card gets
        await setk(B_, tro=120); await setk(C_, tro=130); await setk(D_, tro=50); await setk(E2, tro=200)
        f = await G(B_, "/api/clan/find"); T(f["ok"] and ids(f["list"]) == [cid1, cid2] and f["low"] is False and f["max"] == 30, "find: best clans %s" % ids(f["list"]))
        T(set(f["list"][0]) == {"id", "name", "tag", "n", "max", "tro", "r", "badge", "type", "min", "desc", "act"}, "find: card keys %s" % sorted(f["list"][0]))
        T([x["act"] for x in f["list"]] == ["request", "join"] and [x["act"] for x in (await G(D_, "/api/clan/find"))["list"]] == ["cups", "join"], "find: the button each card gets (B has 120 cups, D 50, clan 1 wants 100)")
        for q, want in (("blue", [cid1]), ("BLUE", [cid1]), ("Blue F", [cid1]), ("bf", [cid1]), ("#bf", [cid1]), ("sec", [cid2]), ("SC", [cid2]), ("zzz", []), ("lue", [])):
            f = await G(B_, "/api/clan/find?q=" + q.replace(" ", "%20").replace("#", "%23")); T(ids(f["list"]) == want, "find q=%r -> %s (want %s)" % (q, ids(f["list"]), want))
        T(ids((await G(B_, "/api/clan/find?type=open"))["list"]) == [cid2] and ids((await G(B_, "/api/clan/find?type=request"))["list"]) == [cid1] and (await G(B_, "/api/clan/find?type=closed"))["list"] == [], "find: type filter")
        T(ids((await G(B_, "/api/clan/find?min=50"))["list"]) == [cid2] and ids((await G(B_, "/api/clan/find?min=100"))["list"]) == [cid1, cid2], "find: min = clans you can enter by cups")
        T((await G(B_, "/api/clan/find?min=x"))["_s"] == 400 and (await G(B_, "/api/clan/find?type=zzz"))["_s"] == 400, "find: bad query -> 400")
        await setk(D_, keep=1); T((await G(D_, "/api/clan/find"))["low"] is True, "find: low castle flagged"); await setk(D_, keep=2)
        T(all(x["act"] is None for x in (await G(A_, "/api/clan/find"))["list"]), "find: no buttons for someone already in a clan")
        await mk(4999, "Spam"); codes = []
        for i in range(45): codes.append((await api(c, 4999, "GET", "/api/clan/find", rl=False))["_s"])
        T(codes[:40] == [200] * 40 and codes[40:] == [429] * 5, "find: rate limit 40 per minute %s" % codes[38:43])

        # ---- 3. entering a request clan: join is refused, closed refuses everything
        T((await P(B_, "join", id=cid1))["why"] == "request", "join a request clan -> request")
        T((await P(B_, "join", id=99999))["why"] == "gone", "join a clan that does not exist")
        T((await P(B_, "join", id="x"))["_s"] == 400 and (await P(B_, "nope"))["_s"] == 400 and (await P(B_, "kick"))["_s"] == 400, "bad ids / ops -> 400")
        T((await P(A_, "edit", type="closed"))["ok"], "edit type closed")
        T((await P(B_, "join", id=cid1))["why"] == "closed" and (await P(B_, "request", id=cid1))["why"] == "closed", "closed refuses join + request")
        T((await P(A_, "edit", type="request"))["ok"], "edit type back to request")

        # ---- 4. requests
        j = await P(D_, "request", id=cid1); T(j["why"] == "cups" and j["need"] == 100, "request below the cups needed %s" % j)
        T((await P(B_, "request", id=cid2))["why"] == "open", "request an open clan -> just join")
        T((await P(B_, "request", id=cid1))["ok"], "request ok"); T((await P(B_, "request", id=cid1))["ok"], "request again is harmless")
        vb = await G(B_); T(vb["mine"] is None and vb["my_req"]["id"] == cid1 and vb["top"][0]["act"] in ("pending", "request"), "view: my_req of a player without a clan")
        T([x["act"] for x in (await G(B_, "/api/clan/find"))["list"] if x["id"] == cid1] == ["pending"], "find: pending shows")
        rq = await G(A_, "/api/clan/requests"); T(rq["ok"] and [x["id"] for x in rq["requests"]] == [B_] and rq["requests"][0]["n"] == "Bob" and rq["requests"][0]["ok"] is True and set(rq["requests"][0]) == {"id", "n", "e", "tro", "lg", "k", "t", "ok"}, "requests list %s" % rq)
        T((await G(A_))["mine"]["req_n"] == 1, "view: req_n")
        T((await G(B_, "/api/clan/requests"))["why"] == "none" and (await G(B_, "/api/clan/feed"))["why"] == "none", "requests / feed need a clan")
        T((await G(E_, "/api/clan/requests"))["requests"] == [], "another clan's leader sees none of them")
        T((await P(E2, "request", id=cid1))["ok"], "E2 requests clan 1")
        T((await X(A_, "edit", type="request"))["changed"] == [], "edit with nothing new changes nothing")
        T((await P(E_, "edit", type="request"))["ok"], "clan 2 becomes a request clan")
        T((await P(E2, "request", id=cid2))["why"] == "pending", "one request at a time")
        T((await P(E2, "cancel"))["ok"] and (await P(E2, "cancel"))["why"] == "none", "cancel, then nothing to cancel")
        T((await P(E2, "request", id=cid2))["ok"] and (await P(E2, "cancel"))["ok"], "request somewhere else after cancelling")
        T((await P(B_, "cancel"))["ok"] and (await G(A_, "/api/clan/requests"))["requests"] == [], "B cancels: the leader's list is empty"); T((await P(B_, "request", id=cid1))["ok"], "B asks again")
        T((await P(C_, "request", id=cid1))["ok"], "C asks"); T((await P(A_, "reject", id=C_))["ok"] and (await P(A_, "reject", id=C_))["why"] == "gone", "reject, then it is gone")
        T((await G(C_))["my_req"] is None, "rejected: no pending request any more"); T((await P(C_, "request", id=cid1))["ok"], "C may ask again")
        T((await P(A_, "accept", id=9999))["why"] == "gone", "accept somebody who never asked")
        j = await P(A_, "accept", id=C_); T(j["ok"], "accept C %s" % j); T((await P(A_, "accept", id=C_))["why"] == "gone", "accept twice")
        T((await P(C_, "request", id=cid1))["why"] == "in_clan" and (await P(C_, "join", id=cid2))["why"] == "in_clan", "in a clan: no request / join")
        T((await P(C_, "accept", id=B_))["why"] == "perm", "a plain member cannot accept")
        T((await P(A_, "promote", id=C_))["ok"], "promote C to elder"); j = await P(C_, "accept", id=B_); T(j["ok"], "an elder can accept (perms.requests = elder) %s" % j)
        T((await P(B_, "request", id=cid1))["why"] == "in_clan", "B is in now")
        await P(A_, "edit", min=40); T((await P(D_, "request", id=cid1))["ok"], "D asks (cups 50 >= 40)")
        LO.CFG["clan"] = {"perms": {"requests": "co-leader"}}; T((await P(C_, "accept", id=D_))["why"] == "perm", "config: only co-leaders accept now"); LO.CFG["clan"] = {}
        LO.CFG["clan"] = {"max_members": 3}; T((await P(C_, "accept", id=D_))["why"] == "full", "config: capacity 3 -> full"); T((await P(E2, "request", id=cid1))["why"] == "full", "request to a full clan"); LO.CFG["clan"] = {}
        T([x["act"] for x in (await G(4999, "/api/clan/find"))["list"] if x["id"] == cid1] != [] , "find as a stranger")
        j = await P(C_, "accept", id=D_); T(j["ok"], "accept D %s" % j)
        # who is where: A leader, B member, C elder, D member
        T(await STORE.clans.clan_of(B_) == cid1 and sorted(await STORE.clans.members(cid1)) == [A_, B_, C_, D_] and await STORE.clans.clan_of(4999) == 0 and await STORE.clans.members(99999) == [], "clan_of / members helpers")
        await P(A_, "edit", min=100); await P(A_, "edit", type="request")

        # ---- 5. roles and who may do what to whom
        T((await X(A_, "promote", id=B_))["role"] == "elder" and (await P(A_, "promote", id=B_))["ok"] and {m["id"]: m["role"] for m in (await G(A_))["mine"]["members"]}[B_] == "co-leader", "A promotes B twice")
        T((await P(A_, "promote", id=B_))["why"] == "rank", "nobody becomes leader by promotion")
        T((await P(A_, "promote", id=A_))["why"] == "self" and (await P(A_, "promote", id=9999))["why"] == "gone" and (await P(A_, "kick", id=A_))["why"] == "none", "self / stranger")
        T((await X(B_, "promote", id=D_))["role"] == "elder", "co-leader promotes a member"); T((await P(B_, "promote", id=D_))["why"] == "rank", "...but not up to his own rank")
        T((await P(B_, "promote", id=C_))["why"] == "rank", "co-leader cannot make a second co-leader")
        T((await X(B_, "demote", id=D_))["role"] == "member" and (await P(B_, "demote", id=D_))["why"] == "floor", "demote down to member, not below")
        T([(await P(B_, k, id=A_))["why"] for k in ("promote", "demote", "kick")] == ["rank"] * 3, "co-leader cannot touch the leader")
        T([(await P(C_, k, id=D_))["why"] for k in ("promote", "demote", "kick")] == ["perm"] * 3 and [(await P(D_, k, id=C_))["why"] for k in ("promote", "demote", "kick")] == ["perm"] * 3, "elders and members cannot manage")
        a = lambda v, t: next(x for x in v["mine"]["members"] if x["id"] == t)["acts"]
        va, vb, vc, vd = [await G(u) for u in (A_, B_, C_, D_)]
        T(a(va, B_) == ["demote", "kick", "transfer"] and a(va, C_) == ["promote", "demote", "kick", "transfer"] and a(va, D_) == ["promote", "kick", "transfer"] and a(va, A_) == [], "acts as leader %s" % [a(va, x) for x in (B_, C_, D_)])
        T(a(vb, A_) == [] and a(vb, C_) == ["demote", "kick"] and a(vb, D_) == ["promote", "kick"] and a(vc, D_) == [] and a(vd, C_) == [], "acts as co-leader / elder / member")
        T([vx["mine"]["can"] for vx in (vb, vc, vd)] == [{"edit": True, "requests": True, "kick": True, "promote": True, "transfer": False}, {"edit": False, "requests": True, "kick": False, "promote": False, "transfer": False}, {"edit": False, "requests": False, "kick": False, "promote": False, "transfer": False}], "view: can per role")
        T(vc["mine"]["req_n"] == 0 and vd["mine"]["req_n"] == 0 and [m["role"] for m in va["mine"]["members"] if m["id"] == B_] == ["co-leader"], "view: req_n / roles")
        # edit
        T((await P(C_, "edit", desc="x"))["why"] == "perm" and (await P(D_, "edit", desc="x"))["why"] == "perm" and (await P(E2, "edit", desc="x"))["why"] == "none", "edit: only co-leader and up")
        j = await X(B_, "edit", desc="New  text", badge="lion", type="open", min=10); T(j["ok"] and j["changed"] == ["desc", "badge", "type", "min"], "edit all four %s" % j)
        m = (await G(A_))["mine"]; T((m["desc"], m["badge"], m["type"], m["min"]) == ("New text", "lion", "open", 10), "edit shows in the view")
        T((await X(B_, "edit", badge="\U0001F43A"))["changed"] == ["badge"] and (await G(A_))["mine"]["badge"] == "wolf", "edit: an old emoji becomes its crest id")
        T([(await P(B_, "edit", **kw))["why"] for kw in ({"desc": "y" * 121}, {"badge": "nope"}, {"type": "x"}, {"min": 5001}, {"min": 1.5}, {})] == ["desc", "badge", "type", "mincups", "mincups", "none"], "edit refusals")
        await P(B_, "edit", type="request", min=100)

        # ---- 6. transfer, leave (the leader cannot walk out), the 12 h wait
        T((await P(B_, "transfer", id=D_))["why"] == "perm" and (await P(A_, "transfer", id=A_))["why"] == "self" and (await P(A_, "transfer", id=9999))["why"] == "gone", "transfer refusals")
        T((await P(A_, "leave"))["why"] == "leader", "the leader cannot leave while others are in")
        T((await P(A_, "transfer", id=B_))["ok"], "transfer to B")
        va, vb = await G(A_), await G(B_)
        T(va["mine"]["role"] == "co-leader" and va["mine"]["owner"] == B_ and not va["mine"]["me_owner"] and vb["mine"]["role"] == "leader" and vb["mine"]["me_owner"] and vb["mine"]["can"]["transfer"], "roles after the transfer")
        T((await P(A_, "transfer", id=C_))["why"] == "perm", "the old leader cannot transfer again")
        j = await P(A_, "leave"); T(j["ok"] and j["mine"] is None and 43190 <= j["wait"] <= 43200, "co-leader leaves, the view carries the wait %s" % j.get("wait"))
        j = await P(A_, "create", name="Third", tag="TH"); T(j["why"] == "wait" and 43190 <= j["wait"] <= 43200, "12 h wait: create %s" % j)
        T((await P(A_, "join", id=cid2))["why"] == "wait" and (await P(A_, "request", id=cid1))["why"] == "wait", "12 h wait: join / request")
        T(40000 < (await G(A_))["wait"] <= 43200 and 40000 < (await G(A_, "/api/clan/find"))["wait"] <= 43200, "view + find carry the wait")
        await setk(A_, cwait=0)
        # ---- 7. kick + the 24 h ban from THAT clan
        T((await P(D_, "kick", id=B_))["why"] == "perm" and (await P(B_, "kick", id=B_))["why"] == "none" and (await P(B_, "kick", id=9999))["why"] == "gone" and (await P(E2, "kick", id=B_))["why"] == "none", "kick refusals")
        T((await P(B_, "kick", id=C_))["ok"] and (await G(C_))["mine"] is None, "leader kicks an elder")
        j = await P(C_, "request", id=cid1); T(j["why"] == "banned" and 86300 < j["wait"] <= 86400, "kicked: 24 h before coming back %s" % j)
        T((await P(C_, "join", id=cid2))["why"] == "request", "...but another clan is fine (it asks for a request)")
        LO.CFG["clan"] = {"kick_ban_s": 3600}; T((await P(B_, "kick", id=D_))["ok"], "kick D with a 1 h ban configured"); j = await P(D_, "request", id=cid1); T(j["why"] == "banned" and 3500 < j["wait"] <= 3600, "config kick_ban_s %s" % j); LO.CFG["clan"] = {}
        T([x["act"] for x in (await G(D_, "/api/clan/find"))["list"] if x["id"] == cid1] == ["banned"], "find: banned shows")
        T(sorted(await STORE.clans.members(cid1)) == [B_], "clan 1 is B alone now")
        # leave with a configured short wait
        LO.CFG["clan"] = {"leave_wait_s": 1}; await P(E_, "edit", type="open")
        T((await P(D_, "join", id=cid2))["ok"] and (await P(D_, "leave"))["wait"] == 1, "config leave_wait_s (the view says 1 s)")
        T((await P(D_, "join", id=cid2))["why"] == "wait", "...inside the wait"); await asyncio.sleep(1.2); T((await P(D_, "join", id=cid2))["ok"], "...after it"); LO.CFG["clan"] = {}

        # ---- 8. the feed
        fd = await G(B_, "/api/clan/feed"); ks = [e["k"] for e in fd["feed"]]
        T(fd["ok"] and ks.count("create") == 1 and ks.count("join") == 3 and ks.count("promote") == 4 and ks.count("demote") == 1 and ks.count("edit") >= 4 and ks.count("transfer") == 1 and ks.count("leave") == 1 and ks.count("kick") == 2, "feed kinds %s" % ks)
        T(all(fd["feed"][i]["t"] >= fd["feed"][i + 1]["t"] for i in range(len(fd["feed"]) - 1)) and ks[0] == "kick", "feed is newest first")
        e = next(x for x in fd["feed"] if x["k"] == "kick"); T(e["an"] == "Bob" and e["bn"] in ("Cy", "Dee") and e["a"] == B_, "feed: names are kept with the event %s" % e)
        e = next(x for x in fd["feed"] if x["k"] == "join" and x.get("x") == "req"); T(e["an"] in ("Cy", "Bob", "Dee"), "feed: a join through a request is marked")
        LO.CFG["clan"] = {"feed_max": 10}
        await mk(4010, "F0", tro=200); T((await P(B_, "edit", type="open", min=0))["ok"], "clan 1 open for the feed test"); T((await P(4010, "join", id=cid1))["ok"], "F0 joins")
        for i in range(12): T((await P(B_, "promote" if i % 2 == 0 else "demote", id=4010))["ok"], "toggle %d" % i)
        fd = await G(B_, "/api/clan/feed"); T(len(fd["feed"]) == 10 and fd["feed"][0]["k"] == "demote", "feed keeps only feed_max entries (%d)" % len(fd["feed"])); LO.CFG["clan"] = {}
        T(len((await G(B_, "/api/clan/feed"))["feed"]) == 10, "an old long feed is cut when it is next written, not before")

        # ---- 9. capacity + a race for the last place
        LO.CFG["clan"] = {"max_members": 4}
        for i in range(3): await mk(4020 + i, "H%d" % i, tro=10)
        T(sorted(await STORE.clans.members(cid1)) == [B_, 4010], "clan 1 members before the race")
        res = await asyncio.gather(*[P(4020 + i, "join", id=cid1) for i in range(3)])
        T(sum(1 for r in res if r["ok"]) == 2 and sorted(r.get("why") for r in res if not r["ok"]) == ["full"], "capacity 4: of three joins two fit %s" % [(r["ok"], r.get("why")) for r in res])
        for i in range(6): await mk(4030 + i, "G%d" % i, tro=10)
        LO.CFG["clan"] = {"max_members": 5}                                                  # one place left
        res = await asyncio.gather(*[P(4030 + i, "join", id=cid1) for i in range(6)])
        T(sum(1 for r in res if r["ok"]) == 1 and len(await STORE.clans.members(cid1)) == 5 and len(set(await STORE.clans.members(cid1))) == 5, "race for the last place: exactly one wins %s" % [r.get("why") for r in res])
        f = await G(4999, "/api/clan/find"); x = next(x for x in f["list"] if x["id"] == cid1); T(x["n"] == 5 and x["max"] == 5 and x["act"] == "full", "find: full card"); LO.CFG["clan"] = {}

        # ---- 10. expiry, a clan that disappears, the last leader
        await mk(4040, "Hana"); await mk(4041, "Iris", tro=0); await mk(4042, "Jay", tro=0)
        j = await P(4041, "create", name="Third Clan", tag="T3", type="request"); cid3 = j["mine"]["id"]
        T((await P(4042, "request", id=cid3))["ok"], "J asks clan 3")
        T((await P(4040, "request", id=cid3))["ok"], "Hana asks clan 3")
        cc = await STORE.clans._get(cid3); cc["req"][str(4040)] = int(time.time()) - 4 * 86400; await STORE.clans._put(cc)
        rq = await G(4041, "/api/clan/requests"); T([x["id"] for x in rq["requests"]] == [4042], "an old request (4 days) is not listed %s" % rq)
        T((await G(4040))["my_req"] is None and (await P(4040, "request", id=cid3))["ok"], "...and can be made again")
        T((await P(4041, "leave"))["ok"], "the last leader leaves: the clan is deleted"); T(await STORE.clans._get(cid3) is None, "clan 3 is gone")
        T((await G(4042))["my_req"] is None and (await P(4042, "join", id=cid1))["ok"], "J's request to the deleted clan counts as none (he can join elsewhere at once)")
        T(ids((await G(B_, "/api/clan/find?q=third"))["list"]) == [], "the deleted clan is not found"); await setk(4041, cwait=0)
        T((await P(4041, "create", name="Third Clan", tag="T3"))["ok"], "its name is free again")

        # ---- 11. settings: bad liveops values are ignored, the validator speaks
        LO.CFG["clan"] = {"max_members": "zzz", "desc_max": -3, "perms": {"edit": "member", "kick": "nobody", "bogus": "leader"}}
        T(CX.cfg()["max_members"] == 30 and CX.cfg()["desc_max"] == 120 and CX.cfg()["perms"] == CX.DEFAULTS["perms"], "bad config values are ignored"); LO.CFG["clan"] = {}
        T(CX.validate(CX.DEFAULTS) == [] and CX.validate({"max_members": 1}) and CX.validate({"leave_wait_s": "x"}) and CX.validate({"perms": {"edit": "member"}}) and CX.validate({"perms": {"zzz": "leader"}}) and CX.validate([]), "validate()")
        T(json.load(open("/home/claude/bot/bluebot_v2/bluewall/clan_defaults.json")) == CX.DEFAULTS, "clan_defaults.json == the defaults in use")
        # ---- 12. what leaves the server: public data only
        txt = json.dumps([await G(B_), await G(B_, "/api/clan/find"), await G(B_, "/api/clan/feed"), await G(B_, "/api/clan/requests")])
        T(not any(k in txt for k in ("cwait", "cban", "creq", "token", "gems", "ruby", "gnew", "init_data")), "no private field in any payload")
        mem = (await G(B_))["mine"]["members"][0]; T(set(mem) == {"id", "n", "e", "tro", "lg", "k", "owner", "role", "seen", "me", "acts"}, "member card keys %s" % sorted(mem))
        T(set((await G(B_))["mine"]) >= {"id", "name", "tag", "n", "max", "tro", "r", "badge", "type", "min", "desc", "owner", "members", "me_owner", "role", "req_n", "can"}, "mine keys (old ones kept)")
        # ---- 13. the cup total of a clan, the search index (and its rebuild for clans made before CN1), a non-Latin name
        tot = sum((await STORE.clans._trophies(cid1)).values()); f = await G(B_, "/api/clan/find"); x = next(x for x in f["list"] if x["id"] == cid1)
        T(x["tro"] == tot and tot >= 120, "clan total %d == sum of its members' cups %d" % (x["tro"], tot))
        await mk(4050, "Parsa", tro=40); j = await P(4050, "create", name="\u06a9\u0644\u0646 \u0622\u0628\u06cc", tag="ka", desc="\u0633\u0644\u0627\u0645"); cid4 = j["mine"]["id"]
        from urllib.parse import quote
        T(ids((await G(B_, "/api/clan/find?q=" + quote("\u0622")))["list"]) == [] and ids((await G(B_, "/api/clan/find?q=" + quote("\u06a9\u0644")))["list"]) == [cid4], "search with a Persian prefix (matches the start of a name only)")
        if REDIS:
            r = await STORE._redis(); await r.delete(CX.K_LEX, CX.K_LEXV); STORE.clans._lex_ok = False
            T(ids((await G(B_, "/api/clan/find?q=blue"))["list"]) == [cid1] and ids((await G(B_, "/api/clan/find?q=sec"))["list"]) == [cid2] and await r.exists(CX.K_LEXV) == 1, "the index is rebuilt from the names HASH for clans that existed before CN1")
            T(await r.zcard(CX.K_LEX) >= 2 * 4, "index holds a name and a tag entry per clan")
    print("clans in this run: %d; checks failed: %d" % (cid3, len(FAIL)))
    return len(FAIL)


bad = asyncio.run(main())
print("CN1 SERVER OK" + (" (redis)" if REDIS else "") if not bad else "CN1 SERVER FAILED (%d)" % bad)
sys.exit(1 if bad else 0)
