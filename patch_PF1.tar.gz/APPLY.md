# APPLY — patch_PF1.tar.gz (for the mother)
Base: kit `kit` branch (HEAD 24f78c7 at the time). Extract at the repo root: `bluewall/client/src/{main.js,perf.js,perfhud.js,pf_probe.js}`, `workers/dev/pf1_*`, `workers/dev/pf1/*`, `patch.diff` (main.js / perf.js / perfhud.js / new pf_probe.js, `patch -p1 < patch.diff`).
main.js is the only shared file: 18 lines marked `// PF1:` (listed in report_PF1.md section 6). `web/app/wall.js` is NOT in the patch: rebuild with `client/build.sh`.
Wire the owner button in ui.js (not touched): `BW_bench.run().then(...)`; `BW_bench.busy`.
Check: `bash dev/pf1_test.sh` -> PF1 OK; `bash dev/gate_w.sh` -> GATE_W: ALL OK (noRoute 614).
Kill switches: `?pfoff=1` (every PF1 behaviour off), `?nomskip=1` (matrix skip), `?aa=0` (MSAA off, for phone A/B only).
