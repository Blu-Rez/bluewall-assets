// SM1: decimate + resize + (optionally) meshopt-pack a skinned Studio GLB.   node sm1_lod.mjs SRC DST TRIS TEXPX PACK
//   TRIS  = triangle target for the whole file (>= what the file has: no simplification)
//   TEXPX = longest side of the textures in px (0: leave the textures alone)         PACK = 1: EXT_meshopt_compression (the game's loaders have the decoder: assets.js / tr2_life.js)
// From workers/tools/lod_geo.mjs (same simplifier, same flags) with the two things a SKINNED model needs: JOINTS_0 / WEIGHTS_0 keep their integer / normalized types, and the skin weights take part
// in the error metric.  No quantize: the vertex positions stay float (crowd.js / unit_swap.js read them for the height and the LOD2 capsule).
import { NodeIO } from '@gltf-transform/core';
import { ALL_EXTENSIONS } from '@gltf-transform/extensions';
import { weld, prune, dedup, textureCompress, reorder, dequantize } from '@gltf-transform/functions';
import { EXTMeshoptCompression } from '@gltf-transform/extensions';
import { MeshoptDecoder, MeshoptSimplifier, MeshoptEncoder } from 'meshoptimizer';
import sharp from 'sharp';
import fs from 'fs';
await MeshoptDecoder.ready; await MeshoptSimplifier.ready; await MeshoptEncoder.ready;
const io = new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({ 'meshopt.decoder': MeshoptDecoder, 'meshopt.encoder': MeshoptEncoder });
const prims = (d) => d.getRoot().listMeshes().flatMap((m) => m.listPrimitives());
const tris = (d) => prims(d).reduce((t, p) => t + (p.getIndices() ? p.getIndices().getCount() : p.getAttribute('POSITION').getCount()) / 3, 0);
const [, , src, dst, targetS, texS, packS, keepNormalS] = process.argv;
const target = +targetS, texpx = +texS, pack = packS === '1';
const d = await io.read(src);
// the battle crowd shades 692 bodies: the base colour is what is seen at 4-5 m tall on a phone; a normal map (a second 1-2K texture + tangent maths per pixel) is dropped unless KEEPNORMAL=1
if (keepNormalS !== '1') for (const m of d.getRoot().listMaterials()) m.setNormalTexture(null);
await d.transform(dequantize());
const before = tris(d);
if (target < before) await d.transform(weld());
const have = tris(d);
let msg = `tris ${before}`;
if (target < have) {
  const P = prims(d); const per = P.map((p) => p.getIndices().getCount() / 3);
  P.forEach((p, n) => {
    const want = Math.max(64, Math.floor(target * per[n] / have));
    const ia = Uint32Array.from(p.getIndices().getArray()); const pa = Float32Array.from(p.getAttribute('POSITION').getArray());
    const nv = pa.length / 3; const uvA = p.getAttribute('TEXCOORD_0'), wA = p.getAttribute('WEIGHTS_0');
    const st = 2 + (wA ? 4 : 0); const at = new Float32Array(nv * st);
    for (let v = 0; v < nv; v++) {
      if (uvA) { at[v * st] = uvA.getArray()[v * 2]; at[v * st + 1] = uvA.getArray()[v * 2 + 1]; }
      if (wA) { const w = wA.getArray(); const sc = wA.getComponentType() === 5121 ? 1 / 255 : wA.getComponentType() === 5123 ? 1 / 65535 : 1; for (let k = 0; k < 4; k++) at[v * st + 2 + k] = w[v * 4 + k] * sc; }
    }
    const aw = [1, 1].concat(wA ? [0.5, 0.5, 0.5, 0.5] : []);
    const [ni, err] = want >= ia.length / 3 ? [ia, 0] : MeshoptSimplifier.simplifyWithAttributes(ia, pa, 3, at, st, aw, null, want * 3, 1.0, ['Permissive']);
    const used = new Map(); const out = new Uint32Array(ni.length);
    for (let k = 0; k < ni.length; k++) { const v = ni[k]; let m = used.get(v); if (m === undefined) { m = used.size; used.set(v, m); } out[k] = m; }
    for (const sem of p.listSemantics()) {
      const acc = p.getAttribute(sem); const es = acc.getElementSize(); const sa = acc.getArray(); const arr = new sa.constructor(used.size * es);
      for (const [v, m] of used) for (let k = 0; k < es; k++) arr[m * es + k] = sa[v * es + k];
      acc.setArray(arr);
    }
    p.getIndices().setArray(out);
    msg += ` | prim${n} ${ni.length / 3} err ${err.toFixed(4)}`;
  });
}
await d.transform(prune({ keepLeaves: true }), dedup());
if (texpx > 0) await d.transform(textureCompress({ encoder: sharp, targetFormat: 'webp', resize: [texpx, texpx], quality: 82 }));
// (gltf-transform's meshopt() also QUANTIZES positions / normals / uv to int16: the swap code and crowd.js need float positions, so only the lossless entropy coding is applied here)
if (pack) { await d.transform(reorder({ encoder: MeshoptEncoder, target: 'size' })); d.createExtension(EXTMeshoptCompression).setRequired(true).setEncoderOptions({ method: EXTMeshoptCompression.EncoderMethod.QUANTIZE }); }
await io.write(dst, d);
console.log(`sm1_lod: ${msg} -> ${tris(d)} tris, tex<=${texpx || 'as is'}${pack ? ', meshopt' : ''}, ${(fs.statSync(dst).size / 1024).toFixed(1)} KB`);
