#!/usr/bin/env python3
# sm1_proof.py [parts] - SM1 proof driver: dev/sm1_units.html (the real bunits.js + unit_swap.js + crowd.js, software GL) with the three SAMPLE soldiers of dev/sm1_table.json.
#   parts: side strips height heading slide carry cost   (default: all)        env: OUT=/home/claude/work/sm1/proof  KEYS=spear,mage,archer  NODRAW=1 (cost: draw commands swallowed, CPU side only)
# writes PNGs + sm1_proof.json (every number the report quotes) into OUT.  Needs the static server (dev/up.sh, port 8777) and app_sm1_units.js (esbuild, see sm1_test.sh).
import asyncio, base64, io, json, os, sys, time
from playwright.async_api import async_playwright
from PIL import Image, ImageDraw, ImageFont
OUT = os.environ.get('OUT', '/home/claude/work/sm1/proof'); os.makedirs(OUT, exist_ok=True)
KEYS = os.environ.get('KEYS', 'spear,mage,archer').split(',')
PAGE = os.environ.get('PAGE', 'sm1_units')       # sm1_units = the game's crowd.js as it is;  sm1_units_lod1 = the same page on a COPY of the game source with workers/docs/SM1_crowd_lod1.patch applied (see sm1_test.sh)
ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-precise-memory-info', '--js-flags=--expose-gc']
NODRAW = "(()=>{ window.__nd={on:true}; const P=['drawElements','drawArrays','drawElementsInstanced','drawArraysInstanced','drawRangeElements']; for(const k of P){ const o=WebGL2RenderingContext.prototype[k]; WebGL2RenderingContext.prototype[k]=function(a,b,c,d,e,f){ if(window.__nd.on) return; return o.call(this,a,b,c,d,e,f); }; } })();"
SPEED = {k: r.get('speed') for k, r in json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sm1_clips.json')))['keys'].items() if r.get('speed')}
RES = {'keys': KEYS, 'parts': {}}
if os.environ.get('MERGE', '1') == '1' and os.path.exists(OUT + '/sm1_proof.json'):       # (a run of one part keeps the numbers of the others)
    try: RES['parts'] = json.load(open(OUT + '/sm1_proof.json')).get('parts', {})
    except Exception: pass
def log(*a): print(time.strftime('%H:%M:%S'), *a, flush=True)
def img(url): return Image.open(io.BytesIO(base64.b64decode(url.split(',', 1)[1]))).convert('RGB')
def save(): json.dump(RES, open(OUT + '/sm1_proof.json', 'w'), indent=1)
def font(n=15):
    try: return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', n)
    except Exception: return ImageFont.load_default()
def sheet(frames, labels, cols, path, title=None):
    w, h = frames[0].size; rows = (len(frames) + cols - 1) // cols; top = 28 if title else 0
    S = Image.new('RGB', (w * cols, h * rows + top), (20, 20, 24)); d = ImageDraw.Draw(S)
    if title: d.text((8, 4), title, fill=(255, 255, 255), font=font(16))
    for i, (f, l) in enumerate(zip(frames, labels)):
        x, y = (i % cols) * w, top + (i // cols) * h; S.paste(f, (x, y)); d.rectangle([x, y, x + w, y + 20], fill=(0, 0, 0)); d.text((x + 4, y + 2), l, fill=(255, 255, 255), font=font(13))
    S.save(path); return path

async def boot(b, nodraw=False, vp=(1500, 620)):
    ctx = await b.new_context(viewport={'width': vp[0], 'height': vp[1]}, device_scale_factor=1)
    if nodraw: await ctx.add_init_script(NODRAW)
    pg = await ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append('page: ' + str(e)[:300])); pg.on('console', lambda m: errs.append(m.type + ': ' + m.text[:300]) if m.type in ('error', 'warning') and '404' not in m.text else None)
    await pg.goto('http://127.0.0.1:8777/%s.html?table=sm1_table.json&w=%d&h=%d' % (PAGE, vp[0], vp[1]))
    for i in range(240):
        if await pg.evaluate('!!window.__sm1Ready'): break
        await asyncio.sleep(0.5)
    else: raise SystemExit('page did not start: %s' % errs[:3])
    return pg, errs

async def part_side(pg):
    r = await pg.evaluate('__sm1.side(%s)' % json.dumps(KEYS)); im = img(r['png']); d = ImageDraw.Draw(im)
    for l in r['labels']: d.rectangle([l['x'] - 70, l['y'] + 6, l['x'] + 250, l['y'] + 26], fill=(0, 0, 0)); d.text((l['x'] - 66, l['y'] + 8), 'SM1-A  #%d  %s   body | model' % (KEYS.index(l['key']) + 1, l['key']), fill=(255, 255, 255), font=font(14))
    im.save(OUT + '/side.png'); RES['parts']['side'] = {'slots': r['slots']}; log('side', {k: v['state'] for k, v in r['slots'].items()})

async def part_strips(pg):
    out = {}
    for k in KEYS:
        row = await pg.evaluate('__sm1.row(%s)' % json.dumps(k)); atk = row['clips']['atk']; atk0 = atk[0] if isinstance(atk, list) else atk
        vk = SPEED.get(k, 9.0)
        for st, n, t in (('idle', 6, 2.0), ('run', 8, 0.9), ('atk', 8, 1.0), ('hit', 6, 0.5)):
            r = await pg.evaluate('__sm1.strip(%s, %s, {n: %d, t: %s, v: %s, w: 380, h: 480})' % (json.dumps(k), json.dumps(st), n, t, vk))
            ims = [img(f) for f in r['frames']]; labs = ['%s %s t=%.2f%s' % (i['state'], i['clip'], i['t'], ' x%.2f' % i['speed'] if i['speed'] else '') for i in r['info']]
            p = sheet(ims, labs, 4, '%s/strip_%s_%s.png' % (OUT, k, st), '%s - %s' % (k, st)); out.setdefault(k, {})[st] = r['info']; log('strip', k, st, r['info'][0], '...', r['info'][-1])
    RES['parts']['strips'] = out

async def part_height(pg):
    out = {}
    for k in KEYS:
        r = await pg.evaluate('__sm1.height(%s)' % json.dumps(k))
        for m in ('model', 'body', 'bindpose'): img(r[m]['png']).save('%s/height_%s_%s.png' % (OUT, k, m)); r[m].pop('png')
        out[k] = r; log('height', k, r)
    RES['parts']['height'] = out

async def part_heading(pg):
    out = {}
    for k in KEYS:
        r = await pg.evaluate('__sm1.heading(%s)' % json.dumps(k)); fr = r.pop('frames')
        sheet([img(fr['toward']), img(fr['away'])], ['walking TOWARD the camera: the front must show', 'walking AWAY from the camera: the back'], 2, '%s/heading_%s.png' % (OUT, k), '%s yaw %s' % (k, r['yaw_row']))
        out[k] = r; log('heading', k, r['model_forward'], [c['error_deg'] for c in r['cases']])
    RES['parts']['heading'] = out

async def part_slide(pg):
    out = {}
    for k in KEYS:
        row = await pg.evaluate('__sm1.row(%s)' % json.dumps(k)); cl = row['clips']; runc, walkc = cl['run'], cl['walk']
        rows = []
        # at the reference speeds (playback 1.0): the walk at walkRef, the run clip at ref
        for clip, ref in ((walkc, row['walkRef']), (runc, row['ref'])):
            if clip == walkc and runc == walkc and ref != row['walkRef']: continue
            if ref is None: continue
            r = await pg.evaluate('__sm1.slide(%s, %s, 1.0, %s)' % (json.dumps(k), json.dumps(clip), ref)); r['ref'] = ref; r['at'] = 'ref speed'; rows.append(r); log('slide', k, clip, 'at', ref, 'm/s:', {x: r.get(x) for x in ('p50_cms', 'p95_cms', 'flat_p50_cms', 'flat_p95_cms', 'max_cms')})
        # the speeds a soldier really goes, with the playback speed runPlay would choose (bunits.js clamps: walk 0.4..1.6, run 0.4..1.9)
        tab = []
        for v in sorted({2, 4, 6, 8, 10, 12, round(SPEED.get(k, 9.0), 1)}):
            single = runc == walkc; ref = row['ref'] if row['ref'] else row['walkRef']; wr = row['walkRef']
            wmax = None if single else max(1.0, min(max((wr * ref) ** 0.5, 0.5 * wr), 1.6 * wr))
            if (not single) and wmax and v < wmax: clip, pb = walkc, min(1.6, max(0.4, v / wr))
            else: clip, pb = (runc if not single else walkc), min(1.9, max(0.4, v / ref))
            r = await pg.evaluate('__sm1.slide(%s, %s, %s, %s)' % (json.dumps(k), json.dumps(clip), pb, v)); r['at'] = 'ground speed %s' % v; tab.append(r)
        wo = None
        if row['walkRef'] and SPEED.get(k):                                                              # the same soldier with only a Walk preset: the walk at battle speed (playback clamped to 1.9)
            pbw = min(1.9, max(0.4, SPEED[k] / row['walkRef'])); wo = await pg.evaluate('__sm1.slide(%s, %s, %s, %s)' % (json.dumps(k), json.dumps(walkc), pbw, SPEED[k])); wo['at'] = 'walk only, battle speed'; log('slide walk-only', k, wo.get('playback'), wo.get('ground_speed'), wo.get('p50_cms'), wo.get('p95_cms'))
        out[k] = {'at_ref': rows, 'table': tab, 'walk_only': wo}; log('slide table', k, [(t['ground_speed'], t['clip'], round(t['playback'], 2), t['p50_cms'], t['p95_cms']) for t in tab])
    RES['parts']['slide'] = out

async def part_carry(pg):
    out = {}
    for k, w in (('spear', ['spear']), ('archer', ['bow']), ('mage', ['staff'])):
        if k not in KEYS: continue
        r = await pg.evaluate('__sm1.carry(%s, %s)' % (json.dumps(k), json.dumps(w))); fr = r.pop('frames')
        sheet([img(f['png']) for f in fr], ['t=%.2f s' % f['t'] for f in fr], 3, '%s/carry_%s.png' % (OUT, k), '%s: %s in the hand, clip %s (contact %s s)' % (k, '+'.join(w), r['clip'], r.get('contact')))
        out[k] = r; log('carry', k, 'mixamo:', r['mixamo']['carry'], 'game:', r['game']['carry']['ok'], 'held', r['held'][-1])
    RES['parts']['carry'] = out

async def part_cost(b):
    out = []
    comp = {'spear': 300, 'archer': 250, 'mage': 142}
    for th in (1, 4):
        for tbn in ('body', 'model'):
            for cam in ('wide', 'close'):
                pg, errs = await boot(b, nodraw=os.environ.get('NODRAW', '1') == '1', vp=(844, 390)); cdp = await pg.context.new_cdp_session(pg)
                await cdp.send('Emulation.setCPUThrottlingRate', {'rate': th})
                r = await pg.evaluate('__sm1.cost({comp: %s, tb: %s, cam: %s, frames: 90, label: "x%d"})' % (json.dumps(comp), json.dumps(tbn), json.dumps(cam), th)); r['throttle'] = th
                if th == 1 and tbn == 'model' and cam == 'close': pass
                try: img(r['png']).save('%s/cost_%s_%s.png' % (OUT, tbn, cam))
                except Exception: pass
                r.pop('png'); r['errors'] = errs[:3]; out.append(r)
                log('cost x%d' % th, tbn, cam, {k: r[k] for k in ('units', 'build_ms', 'update_ms', 'render_cpu_ms', 'calls', 'tris', 'bone_texture_kb_total')})
                await pg.context.close()
    RES['parts']['cost'] = out

async def main():
    sel = sys.argv[1:] or ['side', 'strips', 'height', 'heading', 'slide', 'carry', 'cost']
    async with async_playwright() as p:
        b = await p.chromium.launch(args=ARGS)
        if any(s in sel for s in ('side', 'strips', 'height', 'heading', 'slide', 'carry')):
            pg, errs = await boot(b)
            for s in ('side', 'strips', 'height', 'heading', 'slide', 'carry'):
                if s in sel: await globals()['part_' + s](pg); save()
            RES['errors'] = errs[:12]; log('page errors', errs[:6])
        if 'cost' in sel: await part_cost(b); save()
        await b.close()
    save(); log('done ->', OUT)
asyncio.run(main())
