#!/bin/bash
# sm1_test.sh - SM1: Studio file -> battle soldier.   static -> samples (sm1_apply.py on the Melika G1 export) -> proof pages (esbuild, software GL) -> numeric checks.
#   Ends with "SM1 OK" (everything measured is inside its limit) or "SM1 FAIL (...)".   env: PARTS="side strips height heading slide carry cost" (default all)   ~10 min.
#   The LOD1 numbers come from a COPY of the game source with workers/docs/SM1_crowd_lod1.patch applied (the game's crowd.js is not touched by SM1).
D=$(cd "$(dirname "$0")" && pwd); W=${W:-/home/claude/work/sm1}; C=/home/claude/bot/bluebot_v2/bluewall/client; SRC=$C/src
export PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers; mkdir -p "$W"; cd "$D" || exit 1
FAIL=0; ok(){ echo "OK   $1"; }; bad(){ echo "FAIL $1"; FAIL=1; }
# ---- static
python3 -m py_compile sm1_apply.py sm1_doc.py sm1_proof.py sm1_tp1_clips.py sm1_test.py && ok "python compiles" || bad "python compile"
bash up.sh >/dev/null 2>&1
# the crowd.js patch applies to the game source as it is, and the copy builds
M=$W/mirror; rm -rf "$M"; mkdir -p "$M/bluewall/client"; cp -r "$SRC" "$M/bluewall/client/src"; ln -s "$(dirname "$C")/web" "$M/bluewall/web"
( cd "$M" && patch -p1 --silent < "$D/sm1_crowd_lod1.patch" ) && ok "workers/docs/SM1_crowd_lod1.patch applies to the game's crowd.js" || bad "crowd patch does not apply"
sed "s#'../bot/bluebot_v2/bluewall/client/src/#'../work/sm1/mirror/bluewall/client/src/#g" sm1_units.js > sm1_units_lod1.js; sed 's/app_sm1_units.js/app_sm1_units_lod1.js/' sm1_units.html > sm1_units_lod1.html
( cd $C && NODE_PATH=$C/node_modules npx esbuild "$D/sm1_units.js" --bundle --format=iife --log-level=error --outfile="$D/app_sm1_units.js" && NODE_PATH=$C/node_modules npx esbuild "$D/sm1_units_lod1.js" --bundle --format=iife --log-level=error --outfile="$D/app_sm1_units_lod1.js" ) && ok "proof pages build (game source + patched copy)" || { bad "proof page build"; echo "SM1 FAIL (build)"; exit 1; }
# ---- the three samples (never entered into the game: dev/sm1_assets + dev/sm1_table.json)
bash sm1_samples.sh > $W/samples.log 2>&1 && ok "samples built (spear / mage / archer)" || { bad "samples"; tail -5 $W/samples.log; echo "SM1 FAIL (samples)"; exit 1; }
# ---- proof
PARTS=${PARTS:-side strips height heading slide carry cost}
python3 sm1_proof.py $PARTS > $W/proof.log 2>&1 && ok "proof ran ($PARTS)" || { bad "proof run"; tail -8 $W/proof.log; }
PAGE=sm1_units_lod1 OUT=$W/proof_lod1 python3 sm1_proof.py cost > $W/proof_lod1.log 2>&1 && ok "proof ran (cost with the LOD1 patch)" || { bad "proof lod1 run"; tail -8 $W/proof_lod1.log; }
python3 sm1_test.py "$W" || FAIL=1
[ $FAIL = 0 ] && echo "SM1 OK" || echo "SM1 FAIL (see FAIL lines)"
