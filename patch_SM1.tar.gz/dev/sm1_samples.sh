#!/bin/bash
# SM1: builds the three SAMPLE soldiers of the proof (NOT entered into the game: they live in dev/sm1_assets and dev/sm1_table.json only).
#   spear  = the Melika G1 Studio export (Walk + Run + Idle + Jump presets)           -> sm1_spear.glb
#   mage   = the same file with only its Walk preset (the owner's "Walk only" case)   -> sm1_mage.glb
#   archer = the G1 export again, with the Run preset                                 -> sm1_archer.glb
# usage: bash sm1_samples.sh [G1.glb]      needs numpy + scipy + node (see sm1_apply.py)
set -e
D=$(cd "$(dirname "$0")" && pwd); W=${W:-/home/claude/work/sm1}; A=$D/sm1_assets; mkdir -p "$W" "$A"
G1=${1:-$W/G1_sample.glb}
[ -f "$W/G1_walkonly.glb" ] || python3 - "$G1" "$W/G1_walkonly.glb" <<'PY'
import sys; sys.path.insert(0, '.'); import os; sys.path.insert(0, os.environ.get('D', '.'))
import sm1_tp1_clips as T
js, b = T.load_glb(sys.argv[1]); D = T.Skel(js); cl = [c for c in T.read_clips(js, b, D) if c['name'].lower() == 'walk']
js2, b2 = T.compact_and_add(js, b, cl); T.write_glb(sys.argv[2], js2, b2)
PY
export D
for spec in "spear:$G1:--alt" "mage:$W/G1_walkonly.glb:--alt" "archer:$G1:"; do
  k=${spec%%:*}; r=${spec#*:}; f=${r%:*}; opt=${r##*:}
  python3 $D/sm1_apply.py $k "$f" $A/sm1_$k.glb --row $W/row_$k.json --report $W/rep_$k.json $opt | grep -v "^prune"
  python3 $D/sm1_apply.py $k "$f" $A/sm1_${k}_gn.glb --game-names --tris1 0 --report $W/rep_${k}_gn.json | grep -v "^prune" | head -1
done
python3 - <<PY
import json, glob, os
D = "$D"; W = "$W"
t = json.load(open(os.environ.get('UNIT_MODELS', '/home/claude/bot/bluebot_v2/bluewall/client/src/unit_models.json')))
for k in ('spear', 'mage', 'archer'):
    r = json.load(open('%s/row_%s.json' % (W, k)))[k]; r['model'] = 'sm1_' + k; r['note'] = 'SM1 SAMPLE (Melika G1, not an owner soldier)'; t['units'][k] = r
json.dump(t, open(D + '/sm1_table.json', 'w'), indent=1)
print('sm1_table.json: rows filled ->', [k for k, r in t['units'].items() if r['model']])
PY
