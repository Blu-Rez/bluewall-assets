// SM1: node sm1_info.mjs FILE.glb  ->  one JSON line: triangles, joints, clips (name, seconds, keys, KB), texture sizes, the mesh height in the bind pose.  Reads meshopt-packed files too.
import { NodeIO } from '@gltf-transform/core';
import { ALL_EXTENSIONS } from '@gltf-transform/extensions';
import { MeshoptDecoder } from 'meshoptimizer';
import fs from 'fs';
await MeshoptDecoder.ready;
const io = new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({ 'meshopt.decoder': MeshoptDecoder });
const f = process.argv[2]; const d = await io.read(f); const R = d.getRoot();
let tris = 0, ymin = 1e9, ymax = -1e9, verts = 0;
for (const m of R.listMeshes()) for (const p of m.listPrimitives()) {
  tris += (p.getIndices() ? p.getIndices().getCount() : p.getAttribute('POSITION').getCount()) / 3; verts += p.getAttribute('POSITION').getCount();
  const mn = p.getAttribute('POSITION').getMinNormalized([]), mx = p.getAttribute('POSITION').getMaxNormalized([]); ymin = Math.min(ymin, mn[1]); ymax = Math.max(ymax, mx[1]);
}
const skin = R.listSkins()[0];
const clips = R.listAnimations().map((a) => {
  let keys = 0, bytes = 0, T = 0;
  for (const s of a.listSamplers()) { keys += s.getInput().getCount(); T = Math.max(T, s.getInput().getMax([])[0]); bytes += s.getInput().getCount() * 4 + s.getOutput().getCount() * s.getOutput().getElementSize() * 4; }
  return { name: a.getName(), seconds: +T.toFixed(3), channels: a.listChannels().length, keys, kb_raw: +(bytes / 1024).toFixed(1) };
});
const tex = R.listTextures().map((t) => ({ mime: t.getMimeType(), size: t.getSize(), kb: +(t.getImage().length / 1024).toFixed(1) }));
console.log(JSON.stringify({ file: f, kb: +(fs.statSync(f).size / 1024).toFixed(1), tris, verts, joints: skin ? skin.listJoints().length : 0, meshes: R.listMeshes().length, materials: R.listMaterials().length, height: +(ymax - ymin).toFixed(4), ext: d.getRoot().listExtensionsUsed().map((e) => e.extensionName), clips, tex }));
