#!/usr/bin/env python3
# sm1_doc.py - writes workers/docs/SM1_CLIPS.md from dev/sm1_clips.json (+ the TP1 manifest verdicts, + the measured numbers of the samples when their reports exist).
#   called by:  python3 sm1_apply.py --table [OUT.md]
import json, os
HERE = os.path.dirname(os.path.abspath(__file__))
W = os.environ.get('W', '/home/claude/work/sm1')


def _verdicts():
    return {c['name']: c for c in json.load(open(os.path.join(HERE, 'sm1_clips_manifest.json')))['clips'] if c.get('name')}


def _j(p):
    try: return json.load(open(p))
    except Exception: return None


def _slot_names(r):
    out = []
    for k in ('idle', 'walk', 'run', 'hit', 'death'):
        v = r.get(k)
        if v and v not in ('own',): out.append(v)
    out += list(r.get('atk') or []) + list(r.get('alt') or []) + list(r.get('alt_idle') or [])
    return list(dict.fromkeys(out))


def write(table, outmd):
    V = _verdicts(); K = table['keys']; order = table['order']
    pipe = [k for k in order if K[k]['pipeline']]; keep = [k for k in order if not K[k]['pipeline']]
    L = []; a = L.append
    a('# SM1 - which TP1 clip goes in which slot, for every unit key (generated: `python3 dev/sm1_apply.py --table`, from `dev/sm1_clips.json`)\n')
    a('The machine-readable twin of this page is `dev/sm1_clips.json`; `dev/sm1_apply.py KEY studio.glb out.glb` reads it, cuts exactly these clips out of the TP1 library (`TP1_clips`, 52 clips, 24 fps, retargeted onto the Studio mixamo rig) and writes the row of `unit_models.json`.')
    a('Clip names are the names of `TP1_clips_manifest.json`. **%d of %d unit keys are soldiers the pipeline can build** (a humanoid on the 65-bone mixamo rig); the other %d keep today\'s body (riders, flyers, siege machines) and are listed at the end with what they need.\n' % (len(pipe), len(order), len(keep)))
    a('## 1. The slots (what the game plays, and which clip fills it)\n')
    a('| slot | what the game does with it | source |')
    a('|---|---|---|')
    a('| idle | loop while standing | library `battle_idle` (ready stance, knees slightly bent): its own motion is only ~0.7 cm at the head of a 4.6 m figure, so the cut multiplies it x6 about its mean pose (max 6 deg per joint) - a breathing stance, loop still closed |')
    a('| walk | loop while the unit goes slower than `walkMax` | the **Studio file\'s own Walk preset**, one gait cycle cut so that frame 0 = last frame (`walkRef` = the ground speed the stance foot does not slide at, measured) |')
    a('| run | loop at battle speed | the **Studio file\'s own Run preset** if it has one; else the Walk again (played faster by the game, clamp 1.9x - see section 4). Giants / beasts: always the Walk |')
    a('| atk | one swing per hit; the blow lands on the sim\'s damage moment | library clip of the row below, cut from the start of the strongest burst; `contact` (s, measured: the hand\'s fastest moment) is written to the row so `bunits.js` plays it at `contact / hitTOf` (clamp 0.5..2.2); the tail eases into the idle pose |')
    a('| hit | 0.4 s flinch (`bunits.js`: `hitUntil = t + 0.4`) | library `hit_heavy`, the 0.6 s after its onset squeezed into 0.4 s, ending in the idle pose |')
    a('| death | frozen pose + dissolve (D1) | the pose is taken from the baked clip: `death_forward` is listed for the day the game plays one; it is **not** shipped now (file budget) |\n')
    a('## 2. Per unit key\n')
    a('`h` = standing height in game metres (today\'s recipe); `speed` = ground speed in a battle (m/s) = unitdefs spd x 3.1 x 2.9; `hit_t` = when the sim counts the damage (s after the swing starts), `atk_sp` = playback speed the attack is cut for. `weak` / `seat` = the TP1 verdict of a clip used (weak = small motion, seat = a rider\'s clip with straight legs).\n')
    a('| key | role | h m | speed | idle | walk | run | attack (alt) | hit | death | flags |')
    a('|---|---|---|---|---|---|---|---|---|---|---|')
    for k in pipe:
        r = K[k]; fl = list(r.get('flags') or [])
        for n in _slot_names(r):
            v = V.get(n, {}).get('verdict')
            if v in ('weak', 'seat') and not any(n in f for f in fl): fl.append('%s: %s' % (v, n))
        run = 'own Run preset, else Walk faster' if r['run'] == 'own' else 'Walk only (giants / beasts do not sprint)'
        idle = r['idle'] + (' (alt ' + ', '.join(r['alt_idle']) + ')' if r.get('alt_idle') else '')
        atk = ', '.join(r['atk']) + (' (' + ', '.join(r['alt']) + ')' if r.get('alt') else '')
        a('| %s | %s | %s | %s | %s | Studio Walk | %s | %s | %s | %s | %s |' % (k, r['role'], r['h'], r.get('speed', ''), idle, run, atk, r['hit'], r['death'], '; '.join(fl) or '-'))
    a('\nNotes per key:\n')
    for k in pipe:
        if K[k].get('note'): a('- **%s** - %s' % (k, K[k]['note']))
    a('\n## 3. The library `sprint` is not used\n')
    a('The TP1 `sprint` clip is "sprinting fast, in place": the legs pedal on the spot. Measured on the library retargeted onto a 4.6 m Studio figure (`gait()`: the speed of the planted foot against the body): **sprint 0.01 m/s** (it would need ~9 m/s), **walk 4.16 m/s**. A soldier running on `sprint` would skate at the full battle speed, so `run` is the Studio file\'s own Run preset or the Walk.\n')
    rs = [(k, _j('%s/rep_%s.json' % (W, k))) for k in ('spear', 'mage', 'archer')]
    pf = _j('%s/proof/sm1_proof.json' % W)
    a('## 4. Walk only, or Walk + Run: what the owner gets (measured)\n')
    a('Infantry goes ~9 m/s in a battle. The game plays the run clip at `v / ref`, clamped to 1.9x, and the walk below `walkMax`. A Studio Walk covers ~%.1f m/s of a 4.6 m figure at 1.0x, so on the Walk alone the feet cover at most ~%.1f m/s while the body goes 9 m/s: the figure skates.' % (3.79, 1.9 * 3.79))
    if pf and 'slide' in pf.get('parts', {}):
        S = pf['parts']['slide']; a('\nMeasured on the delivered files in three.js (planted foot speed against the ground, cm/s of the final figure; p50 / p95):\n')
        a('| model | clip | ground speed m/s | playback | p50 | p95 |'); a('|---|---|---|---|---|---|')
        for k in ('spear', 'mage'):
            if k not in S: continue
            for t in S[k]['table']:
                a('| %s | %s | %s | %.2f | %s | %s |' % (k, t['clip'], t['ground_speed'], t['playback'], t['p50_cms'], t['p95_cms']))
        wo = S.get('spear', {}).get('walk_only')
        if wo: a('\nThe same 4.6 m soldier (`spear`) with ONLY the Walk preset, at its battle speed %s m/s: Walk at %.2fx -> planted foot %s cm/s p50, %s cm/s p95 (with the Run preset: see the `run` rows).' % (wo['ground_speed'], wo['playback'], wo['p50_cms'], wo['p95_cms']))
        a('\n`spear` has the Run preset, `mage` only the Walk. **Without a Run preset an infantry soldier skates at several m/s - ask for Walk AND Run.**')
    a('\n## 5. File budget (what `sm1_apply.py` enforces and reports)\n')
    a('| item | budget | measured on the 3 samples |'); a('|---|---|---|')
    if rs[0][1]:
        r = rs[0][1]; f = r['file']
        a('| LOD0 triangles | <= 6000 (692 soldiers at once) | %s (Studio file: %s) |' % (f['tris'], r['model'].get('tris')))
        a('| LOD1 triangles | <= 1500 (`_lod1.glb`, no clips, 512 px texture) | %s tris, %s KB file |' % (r['lod1'].get('tris'), r['lod1']['kb']))
        a('| file (mesh + texture + clips) | - | %s KB (%s clips) |' % (f['kb'], len(f['clips'])))
        a('| baked animation texture | - | %s KB |' % f.get('bake_texture_kb', '?'))
    a('| texture | one material, 1024 px base colour (webp), normal map dropped | |')
    a('| bones | 65 `mixamorig:*` | 65 |\n')
    a('## 6. Needs Tripo (what a unit needs that is not a Studio soldier)\n')
    a('| unit key | model needed | size | look |'); a('|---|---|---|---|')
    for k in order:
        r = K[k]; ns = r['needs'] if isinstance(r['needs'], list) else ([r['needs']] if r['needs'] else [])
        for n in ns:
            p = [x.strip() for x in n.split(' · ')]; name = p[0]; size = p[1] if len(p) > 1 else ''; look = ' · '.join(p[2:]) if len(p) > 2 else ''
            a('| %s | %s | %s | %s |' % (k, name, size, look))
    a('\nThe pipeline soldiers need nothing else: the owner builds them in Studio (see `SM1_OWNER_GUIDE_fa.md`).\n')
    a('## 7. Keys that keep today\'s body\n')
    a('| key | kind | why | what TP1 has |'); a('|---|---|---|---|')
    for k in keep:
        r = K[k]; a('| %s | %s | %s | %s |' % (k, r['kind'], r['why'], '; '.join(r.get('flags') or []) or '-'))
    open(outmd, 'w').write('\n'.join(L) + '\n'); print('wrote', outmd, len(L), 'lines')

