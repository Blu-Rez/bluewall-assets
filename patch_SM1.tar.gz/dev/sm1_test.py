#!/usr/bin/env python3
# sm1_test.py W  - the numeric checks of sm1_test.sh (reads what sm1_samples.sh / sm1_proof.py wrote).  Prints OK / FAIL lines; exit 1 on any FAIL.
import json, os, re, subprocess, sys
W = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/work/sm1'
D = os.path.dirname(os.path.abspath(__file__)); SRC = '/home/claude/bot/bluebot_v2/bluewall'
fails = []
def ok(m): print('OK   ' + m)
def bad(m): print('FAIL ' + m); fails.append(m)
def chk(c, m, detail=''):
    (ok if c else bad)(m + ((' - ' + str(detail)) if detail != '' else ''))
J = lambda p: json.load(open(p))
P = J(W + '/proof/sm1_proof.json')['parts']; PL = J(W + '/proof_lod1/sm1_proof.json')['parts']
T = J(D + '/sm1_table.json'); CL = J(D + '/sm1_clips.json')
# ---- the files (budget): LOD0 <= 6000 triangles, LOD1 <= 1500, 65 joints, only the clips the row names
for k in ('spear', 'mage', 'archer'):
    r = J('%s/rep_%s.json' % (W, k)); row = T['units'][k]; f = r['file']
    chk(f['tris'] <= 6000, '%s: LOD0 triangles <= 6000' % k, f['tris'])
    chk(r['lod1']['tris'] is not None and r['lod1']['tris'] <= 1500, '%s: LOD1 triangles <= 1500' % k, r['lod1']['tris'])
    chk(f['joints'] == 65, '%s: 65 bones' % k, f['joints'])
    cl = row['clips']; want = {cl['idle'], cl['walk'], cl['run'], cl['hit']} | set(cl['atk'] if isinstance(cl['atk'], list) else [cl['atk']])
    chk(set(f['clips']) == want, '%s: the file holds exactly the clips of its row' % k, sorted(f['clips']))
    chk(all(0.05 < v < 5 for v in row['contact'].values()), '%s: contact times in range' % k, row['contact'])
    chk(f['kb'] < 1500, '%s: file under 1.5 MB' % k, '%s KB' % f['kb'])
# ---- height: the bind pose of the delivered file at the game scale = the row's h (1 %), the crowd's figure within 3 % of the mixer's idle range
for k, h in P['height'].items():
    chk(abs(h['bindpose']['err_pct']) <= 1.0, '%s: h = %s m (bind pose silhouette %s m)' % (k, h['row_h'], h['bindpose']['metres']), '%s %%' % h['bindpose']['err_pct'])
    chk(h['crowd_vs_mixer_ok'], '%s: the crowd figure stands where the mixer\'s idle does' % k, '%s..%s vs %s..%s m' % (h['model']['range']['min'], h['model']['range']['max'], h['mixer_idle']['min'], h['mixer_idle']['max']))
# ---- heading: the toes point where the unit walks
for k, h in P['heading'].items():
    e = [abs(c['error_deg']) for c in h['cases']]
    chk(max(e) <= 3.0, '%s: facing = walking direction' % k, 'max error %.2f deg' % max(e))
# ---- feet: three.js on the delivered file, planted foot against the ground (the whole sole planted), at the speed the clip is made for
for k, s in P['slide'].items():
    for r in s['at_ref']:
        lim = 40 if r['clip'] == 'walk' else 120
        chk(r['flat_p50_cms'] is not None and r['flat_p50_cms'] <= lim, '%s: %s feet at %s m/s: flat-foot slide p50 <= %d cm/s' % (k, r['clip'], r['ref'], lim), '%s cm/s (p95 %s)' % (r['flat_p50_cms'], r['flat_p95_cms']))
# ---- weapon in the hand (carry.js on the game-named copy)
NEED = ['Hip', 'Pelvis', 'Spine02', 'L_Hand', 'R_Hand', 'Head', 'L_Thigh', 'L_Calf', 'L_Foot', 'R_Thigh', 'R_Calf', 'R_Foot']
for k, c in P['carry'].items():
    chk(c['game']['game_bones_found'] == NEED, '%s: carry.js finds all %d game bones on the game-named copy' % (k, len(NEED)), c['game'].get('missing'))
    last = c['held'][-1]; chk(last and all(h['where'] == 'hand' and h['parent'] in ('L_Hand', 'R_Hand') for h in last), '%s: the weapon is in the hand during the attack' % k, last)
    chk(c['mixamo']['carry']['ok'], '%s: carry.js does not throw on the raw mixamo names (it skips the hand weapons)' % k)
# ---- cost of 692 soldiers: not above today's bodies (CPU side, software GL: the GPU is NOT measured)
def pick(rows, tb, cam, th): return next(r for r in rows if r['tb'] == tb and r['cam'] == cam and r['throttle'] == th)
for name, rows in (('crowd.js as it is', P['cost']), ('with the LOD1 patch', PL['cost'])):
    for cam in ('wide', 'close'):
        b, m = pick(rows, 'body', cam, 1), pick(rows, 'model', cam, 1)
        chk(m['tris'] <= b['tris'], '692 soldiers, %s camera, %s: triangles <= today\'s bodies' % (cam, name), '%d vs %d' % (m['tris'], b['tris']))
        chk(m['calls'] <= b['calls'], '692 soldiers, %s camera, %s: draw calls <= today\'s bodies' % (cam, name), '%d vs %d' % (m['calls'], b['calls']))
        chk(m['update_ms']['avg'] <= b['update_ms']['avg'] * 1.5 + 0.3, '692 soldiers, %s camera, %s: update ms/frame within 1.5x + 0.3 ms of today\'s' % (cam, name), '%.2f vs %.2f ms' % (m['update_ms']['avg'], b['update_ms']['avg']))
# ---- the game files: only what SM1 may touch, every edit marked
allowed = {'client/src/unit_models.json', 'client/src/unit_swap.js', 'client/src/bunits.js'}
out = subprocess.run(['bash', '-c', "cd %s && diff -rq /home/claude/base_snapshot . -x node_modules -x '__pycache__' -x '*.pyc' -x dist -x app 2>/dev/null | grep -v '^Only in .*: __' || true" % SRC], capture_output=True, text=True).stdout
changed = set(); new = set()
for ln in out.splitlines():
    m = re.match(r'Files (\S+) and (\S+) differ', ln)
    if m: changed.add(re.sub(r'^\./', '', m.group(2)))
    m = re.match(r'Only in (\S+): (\S+)', ln)
    if m and m.group(1).startswith('.'): new.add(re.sub(r'^\./', '', os.path.join(m.group(1), m.group(2))))
extra = {c for c in changed | new if c not in allowed and not c.startswith('web/assets/sm1_')}
chk(not extra, 'no game file outside unit_models.json / unit_swap.js / bunits.js changed (web/app, pkg, server .py, gate scripts untouched)', sorted(extra) if extra else sorted(changed | new))
for f in ('client/src/unit_swap.js', 'client/src/bunits.js'):
    d = subprocess.run(['diff', '/home/claude/base_snapshot/' + f, SRC + '/' + f], capture_output=True, text=True).stdout
    added = [l[2:] for l in d.splitlines() if l.startswith('> ')]
    chk(all('SM1' in l for l in added) or not added, '%s: every added line is marked SM1' % f, [l[:60] for l in added if 'SM1' not in l][:3])
mine = []
for f in ('client/src/unit_swap.js', 'client/src/bunits.js', 'client/src/unit_models.json'):
    mine += [l for l in open(SRC + '/' + f).read().splitlines() if 'SM1' in l]
chk(not any(re.search(r'\b(bot|ربات)\b', l, re.I) for l in mine), 'no "bot" / "ربات" in the lines SM1 added', len(mine))
tbl = J(SRC + '/client/src/unit_models.json')
chk(all(r['model'] is None for r in tbl['units'].values()), 'no real soldier enters the game without the owner\'s number: every row of unit_models.json still has model null')
chk(all('walkRef' in r and 'contact' in r and 'lod1' in r for r in tbl['units'].values()), 'every row has walkRef / contact / lod1')
print('SM1 checks: %d FAIL' % len(fails)); sys.exit(1 if fails else 0)
