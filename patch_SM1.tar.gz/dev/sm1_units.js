// sm1_units.js - SM1 proof page (dev/sm1_units.html, driven by dev/sm1_proof.py).  The three SAMPLE soldiers (dev/sm1_table.json: spear / mage / archer rows filled by dev/sm1_apply.py, files in dev/sm1_assets)
// run through the REAL bunits.js + unit_swap.js + crowd.js, next to today's bodies.   Nothing here enters the game.
//   __sm1.side(keys)                   today's body | the model, standing, one screenshot
//   __sm1.strip(key, state, opts)      one unit playing a state (idle / run / atk / hit) -> frames (png dataURLs) + what the views said (state, clip, speed)
//   __sm1.height(key)                  the figure's real height from its silhouette (px -> m through the camera) vs the row's h  (and today's body for scale)
//   __sm1.heading(key)                 numeric: where the model's toes point after the row's yaw, against the way the unit goes (deg);  + two frames: walking toward / away from the camera
//   __sm1.slide(key, clip, pb, v)      the planted foot's speed against the GROUND in three.js's own animation (the delivered, packed file, an AnimationMixer, the figure walking at v) - cm/s
//   __sm1.carry(key)                   WC1 combat/carry.js on the 65-bone rig, with and without the game's bone names: which bones it finds, frames of the weapon in the hand during the attack
//   __sm1.cost(cfg)                    the cost of N soldiers in crowd.js: build ms, update ms / frame, render CPU ms / frame, draw calls, triangles, bone texture bytes
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import { createUnitViews } from '../bot/bluebot_v2/bluewall/client/src/bunits.js';
import { SWAP_TABLE, swapKeys, checkRow } from '../bot/bluebot_v2/bluewall/client/src/unit_swap.js';
import { create as carryCreate, unitWeapon } from '../bot/bluebot_v2/bluewall/web/assets/rpg/combat/carry.js';

const Q = new URLSearchParams(location.search);
const R = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true, alpha: false });
R.setPixelRatio(1); R.shadowMap.enabled = false; document.body.style.margin = '0'; document.body.appendChild(R.domElement);
const scene = new THREE.Scene(); scene.background = new THREE.Color(0xa9c8e6);
scene.add(new THREE.HemisphereLight(0xffffff, 0x556644, 1.25)); const dl = new THREE.DirectionalLight(0xffffff, 1.6); dl.position.set(40, 80, 30); scene.add(dl);
// the ground has a 2 m grid so that a sliding foot shows against it
const gc = document.createElement('canvas'); gc.width = gc.height = 64; { const g = gc.getContext('2d'); g.fillStyle = '#6f8f4a'; g.fillRect(0, 0, 64, 64); g.fillStyle = '#4d6a32'; g.fillRect(0, 0, 64, 3); g.fillRect(0, 0, 3, 64); }
const gtex = new THREE.CanvasTexture(gc); gtex.wrapS = gtex.wrapT = THREE.RepeatWrapping; gtex.repeat.set(1000, 1000); gtex.colorSpace = THREE.SRGBColorSpace;
const ground = new THREE.Mesh(new THREE.PlaneGeometry(2000, 2000), new THREE.MeshStandardMaterial({ map: gtex, roughness: 1 })); ground.rotation.x = -Math.PI / 2; scene.add(ground);
const cam = new THREE.PerspectiveCamera(30, 1, 0.5, 4000);
const size = (w, h) => { R.setSize(w, h); cam.aspect = w / h; cam.updateProjectionMatrix(); };
size(+(Q.get('w') || 1500), +(Q.get('h') || 620));

let TABLE = JSON.parse(JSON.stringify(SWAP_TABLE));
const empty = (t) => { const e = JSON.parse(JSON.stringify(t)); for (const k of Object.keys(e.units)) { const r = e.units[k]; r.model = null; r.anims = null; r.h = null; r.clips = null; r.ref = null; r.walkRef = null; r.contact = null; r.lod2 = null; } return e; };
const mkUnit = (id, type, x, z, face, extra = {}) => ({ id, type, x, z, face, side: 'A', active: true, tier: 0, hp: 1, dead: false, hpMax: 1, ...extra });
const mkViews = (units, tb) => createUnitViews({ M: {}, scene, sim: { units, defenders: [] }, forgeLevel: 1, enemyLevel: 1, height: () => 0, hooks: {}, swap: tb });
const png = () => R.domElement.toDataURL('image/png');
const live = [];                                                                                       // views to dispose before the next scene
const dispose = () => { while (live.length) live.pop().dispose(); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rowOf = (key) => TABLE.units[key];

// ------------------------------------------------------------------ today's body | the model
async function side(keys) {
  dispose(); size(1500, 620); ground.visible = true; scene.background = new THREE.Color(0xa9c8e6);
  const sp = 8, mk = (xs, tb, ids) => keys.map((k, i) => mkUnit(ids + i, k, i * sp + xs, 0, Math.PI * 0.15));
  const ua = mk(0, null, 1), ub = mk(sp * 0.45, null, 100);
  const va = await mkViews(ua, empty(TABLE)), vb = await mkViews(ub, TABLE); live.push(va, vb);
  const cx = (keys.length - 1) * sp * 0.5 + sp * 0.22;
  cam.fov = 26; cam.updateProjectionMatrix(); cam.position.set(cx, 3.0, 24); cam.lookAt(cx, 2.4, 0); cam.updateMatrixWorld(true);
  for (let i = 0; i < 40; i++) { va.update(i / 30, 1 / 30, cam); vb.update(i / 30, 1 / 30, cam); }
  R.render(scene, cam);
  const sb = vb.slots(); return { slots: Object.fromEntries(keys.map((k) => [k, sb[k]])), png: png(), labels: keys.map((k, i) => { const v = new THREE.Vector3(i * sp + sp * 0.22, 0, 0).project(cam); return { key: k, x: Math.round((v.x * 0.5 + 0.5) * R.domElement.width), y: Math.round((-v.y * 0.5 + 0.5) * R.domElement.height) }; }) };
}

// ------------------------------------------------------------------ one unit, one state, n frames
async function strip(key, state, { n = 8, t = 1.0, v = 6, w = 420, h = 520, body = false, fov = 30, back = false, atkIndex = 0 } = {}) {
  dispose(); size(w, h); ground.visible = true; scene.background = new THREE.Color(0xa9c8e6);
  const tb = body ? empty(TABLE) : TABLE, face = Math.PI / 2;                                           // heading +x, the camera looks along -z: a side view
  const u = mkUnit(1, key, 0, 0, face), views = await mkViews([u], tb); live.push(views);
  const row = rowOf(key), H = body || !row.h ? 4.6 : row.h;
  cam.fov = fov; cam.updateProjectionMatrix();
  const frames = [], info = []; let tt = 0; const dt = 1 / 60;
  const place = () => { cam.position.set(u.x, H * 0.52, H * 3.3); cam.lookAt(u.x, H * 0.5, 0); cam.updateMatrixWorld(true); };
  const step = (secs) => { const k = Math.max(1, Math.round(secs / dt)); for (let i = 0; i < k; i++) { if (state === 'run') u.x += v * dt; tt += dt; place(); views.update(tt, dt, cam); } };
  // settle: 1 s standing (idle), then the state
  for (let i = 0; i < 60; i++) { tt += dt; place(); views.update(tt, dt, cam); }
  const vw = () => views.views.get(1);
  if (state === 'atk') views.event({ k: 'melee', u: 1 }, tt);
  if (state === 'hit') views.event({ k: 'hurt', id: 1 }, tt);
  if (state === 'run') { step(0.6); } else step(1 / 60);                                                // (run: speed up first - the smoothed ground speed and the clip switch;  atk / hit: one tick so the first frame shows the state)
  for (let f = 0; f < n; f++) {
    const pt = vw() && vw().parts[0];
    place(); R.render(scene, cam);                                                                      // (no extra update here: a tick without movement would pull the smoothed ground speed down)
    frames.push(png()); info.push({ t: +(tt).toFixed(3), state: vw() && vw().state, clip: pt && pt.p.name, speed: pt && +(pt.sp || 1).toFixed(2), x: +u.x.toFixed(2), vv: vw() && +vw().v.toFixed(2), ref: pt && pt.P.ref, walkMax: pt && pt.P.walkMax });
    step(t / n);
  }
  return { key, state, frames, info, h: H };
}

// ------------------------------------------------------------------ height from the silhouette
const magenta = (d, o) => d[o] - d[o + 1] > 60 && d[o + 2] - d[o + 1] > 60;
function silhouette(D) {                                                                                  // -> metres tall at distance D (the figure is thin in depth), px, width
  const g = document.createElement('canvas'); g.width = R.domElement.width; g.height = R.domElement.height; const c = g.getContext('2d', { willReadFrequently: true }); c.drawImage(R.domElement, 0, 0);
  const d = c.getImageData(0, 0, g.width, g.height).data; let top = g.height, bot = -1, left = g.width, right = -1;
  for (let y = 0; y < g.height; y++) for (let x = 0; x < g.width; x++) { const o = (y * g.width + x) * 4; if (!magenta(d, o)) { top = Math.min(top, y); bot = Math.max(bot, y); left = Math.min(left, x); right = Math.max(right, x); } }
  const mPerPx = (2 * D * Math.tan((cam.fov * Math.PI) / 360)) / g.height;
  return { px: bot - top + 1, metres: +((bot - top + 1) * mPerPx).toFixed(3), widthMetres: +((right - left + 1) * mPerPx).toFixed(3) };
}
async function height(key) {
  const row = rowOf(key), out = { row_h: row.h }, D = 60;
  const frame = () => { cam.fov = 14; cam.updateProjectionMatrix(); cam.position.set(0, 2.5, D); cam.lookAt(0, 2.5, 0); cam.updateMatrixWorld(true); };
  // 1. the delivered file, no animation (bind pose), scaled the way the game scales it (row.h / the mesh's own height): must be row.h
  dispose(); size(600, 700); ground.visible = false; scene.background = new THREE.Color(0xff00ff);
  const g = await loadFile(row.model), root = new THREE.Group(); root.add(g.scene); g.scene.updateMatrixWorld(true);
  const bb = new THREE.Box3().setFromObject(g.scene, true), hb = bb.max.y - bb.min.y; root.scale.setScalar(row.h / hb); root.rotation.y = (row.yaw * Math.PI) / 180; scene.add(root);
  g.scene.traverse((o) => { if (o.isSkinnedMesh) o.skeleton.pose(); });
  frame(); R.render(scene, cam); out.bindpose = { ...silhouette(D), file_mesh_height: +hb.toFixed(4) }; out.bindpose.png = png();
  out.bindpose.err_pct = +(((out.bindpose.metres - row.h) / row.h) * 100).toFixed(2);
  // 2. the same file under a mixer: the range of the silhouette over the idle clip (knees bend: the figure is a little lower than the bind pose)
  const idle = g.animations.find((a) => a.name === (Array.isArray(row.clips.idle) ? row.clips.idle[0] : row.clips.idle)), mx = new THREE.AnimationMixer(g.scene); mx.clipAction(idle).play();
  const hs = []; for (let i = 0; i < 12; i++) { mx.setTime((i / 12) * idle.duration); g.scene.updateMatrixWorld(true); R.render(scene, cam); hs.push(silhouette(D).metres); }
  out.mixer_idle = { min: Math.min(...hs), max: Math.max(...hs) }; scene.remove(root);
  // 3. the crowd (real bunits + unit_swap + crowd.js): the same figure standing, and today's body for scale
  for (const mode of ['model', 'body']) {
    dispose(); const u = mkUnit(1, key, 0, 0, 0), views = await mkViews([u], mode === 'body' ? empty(TABLE) : TABLE); live.push(views);
    frame(); for (let i = 0; i < 30; i++) views.update(i / 30, 1 / 30, cam); R.render(scene, cam);
    out[mode] = { ...silhouette(D), png: png() };
    const vw = views.views.get(1), pt = vw && vw.parts[0]; out[mode].state = vw && vw.state; out[mode].clip = pt && pt.p && pt.p.name;
    if (mode === 'model') {                                                                              // the crowd over one idle cycle (the baked texture is sampled at 30 fps)
      const cs = []; for (let i = 0; i < 24; i++) { views.update(1 + i / 12, 1 / 12, cam); R.render(scene, cam); cs.push(silhouette(D).metres); } out.model.range = { min: Math.min(...cs), max: Math.max(...cs) };
    }
  }
  out.crowd_vs_mixer_ok = out.model.range.min >= out.mixer_idle.min * 0.97 && out.model.range.max <= out.mixer_idle.max * 1.03;
  out.crowd_vs_bindpose_pct = +(((out.model.metres - row.h) / row.h) * 100).toFixed(2);
  return out;
}

// ------------------------------------------------------------------ the delivered file under three.js's own mixer
const loader = new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);
const loadFile = (name) => loader.loadAsync('sm1_assets/' + name + '.glb');
const boneOf = (root, name) => { const n = name.replace(/:/g, ''); let b = null; root.traverse((o) => { if (o.isBone && o.name === n) b = o; }); return b; };           // (three's loader strips the ':' of 'mixamorig:Hips')
const V3 = () => new THREE.Vector3();

async function heading(key) {
  const row = rowOf(key), g = await loadFile(row.model), clip = g.animations.find((a) => a.name === row.clips.walk) || g.animations[0];
  const root = g.scene, mx = new THREE.AnimationMixer(root); const act = mx.clipAction(clip); act.play(); mx.setTime(0); root.updateMatrixWorld(true);
  const f = V3();
  for (const s of ['Left', 'Right']) { const a = boneOf(root, 'mixamorig:' + s + 'Foot'), t = boneOf(root, 'mixamorig:' + s + 'ToeBase'); f.add(t.getWorldPosition(V3()).sub(a.getWorldPosition(V3()))); }
  f.y = 0; f.normalize();
  const res = { file: row.model, yaw_row: row.yaw, model_forward: [+f.x.toFixed(3), +f.z.toFixed(3)], cases: [] };
  for (const face of [0, 1.0, -2.2, Math.PI / 2]) {                                                       // the unit's heading (u.face, atan2(dx, dz)): what bunits does is p.yaw = v.yaw + yawOff, rotation about +y
    const th = face + (row.yaw * Math.PI) / 180, c = Math.cos(th), s = Math.sin(th), fx = f.x * c + f.z * s, fz = -f.x * s + f.z * c;
    const want = [Math.sin(face), Math.cos(face)], ang = (Math.atan2(fx * want[1] - fz * want[0], fx * want[0] + fz * want[1]) * 180) / Math.PI;
    res.cases.push({ heading_rad: +face.toFixed(2), error_deg: +ang.toFixed(2) });
  }
  // the pictures: the unit walks toward the camera (we must see the face / front), then away (the back)
  dispose(); size(900, 520); ground.visible = true; scene.background = new THREE.Color(0xa9c8e6);
  const H = row.h; const u = mkUnit(1, key, 0, -40, 0), views = await mkViews([u], TABLE); live.push(views);
  cam.fov = 30; cam.updateProjectionMatrix(); const frames = {}, info = {};
  for (const [name, face, z0, dir] of [['toward', 0, -60, 1], ['away', Math.PI, 20, -1]]) {
    u.x = 0; u.z = z0; u.face = face; let tt = 0; const dt = 1 / 60;
    for (let i = 0; i < 100; i++) {                                                                       // the unit walks 6 m/s along its heading; the lens stands 3.4 heights away on the +z side: the unit comes toward it (+z, heading 0: the front shows) / goes away from it (-z, heading pi: the back shows)
      u.z += dir * 6 * dt; tt += dt; const cz = u.z + H * 3.4;
      cam.position.set(0, H * 0.55, cz); cam.lookAt(0, H * 0.5, u.z); cam.updateMatrixWorld(true); views.update(tt, dt, cam);
    }
    const pt = views.views.get(1).parts[0]; info[name] = { state: views.views.get(1).state, clip: pt.p.name, speed: +(pt.sp || 1).toFixed(2) };
    R.render(scene, cam); frames[name] = png();
  }
  res.frames = frames; res.info = info; res.bone_check = 'forward = mean(toe - ankle) of the delivered file at walk frame 0, rotated by the row yaw';
  return res;
}

async function slide(key, clipName, pb, v, { seconds = 6, hz = 240 } = {}) {
  const row = rowOf(key), g = await loadFile(row.model), clip = g.animations.find((a) => a.name === clipName);
  if (!clip) return { error: 'no clip ' + clipName };
  const root = new THREE.Group(); root.add(g.scene);
  // the same scale the game gives it: the file's mesh height -> row.h
  g.scene.updateMatrixWorld(true); const box = new THREE.Box3().setFromObject(g.scene, true), hb = box.max.y - box.min.y, k = row.h / hb; root.scale.setScalar(k);
  const mx = new THREE.AnimationMixer(g.scene), act = mx.clipAction(clip); act.timeScale = pb; act.play();
  const J = {}; for (const s of ['Left', 'Right']) { J[s + 'Toe'] = boneOf(g.scene, 'mixamorig:' + s + 'ToeBase'); J[s + 'Ank'] = boneOf(g.scene, 'mixamorig:' + s + 'Foot'); }
  const yaw = (row.yaw * Math.PI) / 180; root.rotation.y = yaw;                                         // (the figure's forward is then +z)
  const dt = 1 / hz, N = Math.round(seconds * hz), P = []; const p = V3();
  // minimum heights over the clip (the ground = the lowest the toe / ankle goes)
  const pos = {}; for (const kk of Object.keys(J)) pos[kk] = [];
  for (let i = 0; i <= N; i++) {
    mx.setTime(i * dt * 1.0); root.position.set(0, 0, v * i * dt); root.updateMatrixWorld(true);
    for (const kk of Object.keys(J)) pos[kk].push(J[kk].getWorldPosition(V3()).clone());
  }
  const hip = boneOf(g.scene, 'mixamorig:Hips'); const hipH = hip ? 0 : 0;
  const gT = Math.min(...['LeftToe', 'RightToe'].flatMap((kk) => pos[kk].map((q) => q.y))), gA = Math.min(...['LeftAnk', 'RightAnk'].flatMap((kk) => pos[kk].map((q) => q.y)));
  const tol = 0.02 * 0.55 * k;                                                                                // 2 % of the hip height (model 0.55 m) in game metres - the same tolerance dev/sm1_apply.py uses
  const rec = [], flat = [];
  for (const side of ['Left', 'Right']) {
    const hw = Math.round(hz / 30);                                                                              // the speed is the foot's travel over +-1/30 s (the crowd bakes its poses at 30 fps; a 4 ms difference would only see the key-to-key kinks of the 24 fps clip)
    for (let i = hw; i < N - hw; i++) {
      const T0 = pos[side + 'Toe'], A0 = pos[side + 'Ank'];
      const tP = T0[i].y - gT < tol, aP = A0[i].y - gA < tol; if (!tP && !aP) continue;
      const q = tP ? T0 : A0, sx = (q[i + hw].x - q[i - hw].x) / (2 * hw * dt), sz = (q[i + hw].z - q[i - hw].z) / (2 * hw * dt);
      const w = Math.hypot(sx, sz);                                                                         // the planted point's speed against the GROUND (m/s)
      if (w >= v) continue;                                                                                 // (moving backward against the body = slower than the ground speed; the swing foot skims the ground faster than v)
      rec.push(w * 100); if (tP && aP) flat.push(w * 100);
    }
  }
  const pc = (a, q) => { if (!a.length) return null; const s = a.slice().sort((x, y) => x - y); return +s[Math.min(s.length - 1, Math.floor(q * s.length))].toFixed(1); };
  return { key, clip: clipName, playback: pb, ground_speed: v, scale: +k.toFixed(3), planted_samples: rec.length, p50_cms: pc(rec, 0.5), p95_cms: pc(rec, 0.95), max_cms: rec.length ? +Math.max(...rec).toFixed(1) : null, flat_p50_cms: pc(flat, 0.5), flat_p95_cms: pc(flat, 0.95), ground_toe: +gT.toFixed(4), ground_ankle: +gA.toFixed(4) };
}

// ------------------------------------------------------------------ WC1 carry.js on the 65-bone rig
const NEED = ['Hip', 'Pelvis', 'Spine02', 'L_Hand', 'R_Hand', 'Head', 'L_Thigh', 'L_Calf', 'L_Foot', 'R_Thigh', 'R_Calf', 'R_Foot'];
async function carry(key, weapons) {
  const row = rowOf(key), out = { key, tries: {} };
  // 1. the delivered mixamo-named file: which of the game's bones does it have, and what does carry.js do with it
  const gm = await loadFile(row.model); const namesM = []; gm.scene.traverse((o) => { if (o.isBone) namesM.push(o.name); });
  out.mixamo = { bones: namesM.length, game_bones_found: NEED.filter((n) => namesM.includes(n)) };
  try {
    const w = await loadFile('sword'); const obj = unitWeapon(THREE, w.scene.clone(true), 'sword');
    const ctl = carryCreate({ T: THREE, hero: { model: gm.scene }, items: [{ w: { url: 'sword.glb', len: 0.5, kind: 'sword' }, obj }], emit: null });
    out.mixamo.carry = { ok: true, items: ctl.state() };
  } catch (e) { out.mixamo.carry = { ok: false, error: String(e.message || e).slice(0, 160) }; }
  // 2. the file with the game's names (sm1_apply.py --game-names = sis_build.py's renaming + a Pelvis): same call
  const gg = await loadFile(row.model + '_gn'); const namesG = []; gg.scene.traverse((o) => { if (o.isBone) namesG.push(o.name); });
  out.game = { bones: namesG.length, game_bones_found: NEED.filter((n) => namesG.includes(n)), missing: NEED.filter((n) => !namesG.includes(n)), clips: gg.animations.map((a) => a.name) };
  dispose(); size(1500, 520); ground.visible = true; scene.background = new THREE.Color(0xa9c8e6);
  const hb = new THREE.Box3().setFromObject(gg.scene, true), H = hb.max.y - hb.min.y, f = H / 1.75;       // model units per hero metre (the carry table is in the hero frame, len in metres of the hero)
  const mx = new THREE.AnimationMixer(gg.scene); scene.add(gg.scene);
  const KIND = { sword: ['sword', 0.9], spear: ['spear', 1.9], staff: ['skel_staff', 1.6], bow: ['bow', 1.0] };
  const items = [];
  for (const kd of weapons) {
    const [asset, len] = KIND[kd], wg = await loadFile(asset); const kind = kd === 'staff' ? 'staff' : kd;
    // the stand-in props are whole prop scenes, not WC1 library nodes (pivot at the base, ymin 0, long axis = +Y): stand the long axis up first
    const o = wg.scene.clone(true), bb0 = new THREE.Box3().setFromObject(o), sz = bb0.getSize(V3()); out.weapons = out.weapons || {}; out.weapons[kd] = { asset, bbox: [+sz.x.toFixed(3), +sz.y.toFixed(3), +sz.z.toFixed(3)] };
    const wrap = new THREE.Group(); wrap.add(o); if (sz.x >= sz.y && sz.x >= sz.z) wrap.rotation.z = Math.PI / 2; else if (sz.z >= sz.y && sz.z >= sz.x) wrap.rotation.x = Math.PI / 2; wrap.updateMatrixWorld(true);
    const hold = new THREE.Group(); hold.add(wrap); hold.updateMatrixWorld(true);
    items.push({ w: { url: asset + '.glb', len: len * f, kind, slot: 'R' }, obj: unitWeapon(THREE, hold, kind) });
  }
  const ctl = carryCreate({ T: THREE, hero: { model: gg.scene }, items, emit: null });
  out.game.carry = { ok: true, items: ctl.state(), calls: ctl.calls() };
  const names = row.clips.atk; const atk = Array.isArray(names) ? names[0] : names; const clip = gg.animations.find((a) => a.name === atk);
  out.clip = atk; out.contact = row.contact && row.contact[atk];
  ctl.setDrawn(true); out.game.carry.drawn = ctl.state();
  const frames = []; const cx = H * 0.5;
  const pts = [0, 0.25, 0.5, 0.75, 1.0].map((q) => q * (clip ? clip.duration : 1));
  if (out.contact) pts.splice(2, 0, out.contact);
  pts.sort((a, b) => a - b);
  const act = mx.clipAction(clip); act.play();
  const held = [];
  gg.scene.position.set(0, 0, 0); gg.scene.rotation.y = (row.yaw * Math.PI) / 180;
  cam.fov = 28; cam.updateProjectionMatrix();
  for (const t of pts) {
    mx.setTime(t); ctl.update(0.016, true); gg.scene.updateMatrixWorld(true);
    // 3 views per time would be too many: one 3/4 view
    cam.position.set(H * 1.7, H * 0.7, H * 2.6); cam.lookAt(0, H * 0.5, 0); cam.updateMatrixWorld(true); R.render(scene, cam); frames.push({ t: +t.toFixed(3), png: png() });
    const st = ctl.state(); held.push(st.map((s) => ({ kind: s.kind, where: s.where, parent: s.parent })));
  }
  out.frames = frames; out.held = held; scene.remove(gg.scene); ctl.dispose();
  return out;
}

// ------------------------------------------------------------------ the cost of N soldiers
async function cost({ comp, tb = 'model', cam: camName = 'wide', frames = 90, label = '' }) {
  dispose(); size(844, 390); ground.visible = true; scene.background = new THREE.Color(0xa9c8e6);
  const units = []; let id = 1, total = 0; for (const c of Object.values(comp)) total += c;
  const cols = Math.ceil(Math.sqrt(total * 1.4)), sp = 3.4; let i = 0;
  for (const [type, c] of Object.entries(comp)) for (let k = 0; k < c; k++, i++) units.push(mkUnit(id++, type, (i % cols) * sp, -Math.floor(i / cols) * sp, Math.PI / 2, { v: 5 + (i % 7) * 0.6 }));
  const t0 = performance.now(), views = await mkViews(units, tb === 'model' ? TABLE : empty(TABLE)); live.push(views); const build = performance.now() - t0;
  const W = (cols - 1) * sp, Dp = Math.ceil(total / cols) * sp;
  cam.fov = 52; cam.aspect = 844 / 390; cam.updateProjectionMatrix();
  if (camName === 'wide') cam.position.set(W * 0.5, 62, 70); else cam.position.set(W * 0.5, 14, 40);
  cam.lookAt(W * 0.5, 0, -Dp * 0.45); cam.updateMatrixWorld(true);
  let tt = 0; const dt = 1 / 30, upd = [], rend = [], calls = [], tris = [];
  for (let f = 0; f < frames + 30; f++) {
    for (const u of units) { u.x += u.v * dt; if (u.x > W + 40) u.x = -20; }
    tt += dt; const a = performance.now(); views.update(tt, dt, cam); const b = performance.now(); R.render(scene, cam); const c = performance.now();
    if (f >= 30) { upd.push(b - a); rend.push(c - b); calls.push(R.info.render.calls); tris.push(R.info.render.triangles); }
  }
  const avg = (a) => a.reduce((x, y) => x + y, 0) / a.length, p95 = (a) => a.slice().sort((x, y) => x - y)[Math.floor(a.length * 0.95)];
  const kinds = {}; let texBytes = 0;
  for (const [n, k] of Object.entries(views.kinds)) { const img = k.texture && k.texture.image; const b = img && img.data ? img.data.byteLength : 0; texBytes += b; kinds[n] = { drawn: k.drawn, bone_texture_kb: Math.round(b / 1024), rows: img ? img.height : 0 }; }
  R.render(scene, cam);
  return { label, tb, cam: camName, units: total, comp, build_ms: Math.round(build), update_ms: { avg: +avg(upd).toFixed(2), p95: +p95(upd).toFixed(2) }, render_cpu_ms: { avg: +avg(rend).toFixed(2), p95: +p95(rend).toFixed(2) },
    calls: Math.round(avg(calls)), tris: Math.round(avg(tris)), bone_texture_kb_total: Math.round(texBytes / 1024), kinds, mem: { ...R.info.memory }, png: png() };
}

window.__sm1 = {
  keys: () => swapKeys(TABLE), row: (k) => rowOf(k), check: (k) => checkRow(k, rowOf(k)),
  side, strip, height, heading, slide, carry, cost, dispose,
  setTable: async (url) => { TABLE = await (await fetch(url)).json(); return Object.keys(TABLE.units).filter((k) => TABLE.units[k].model); },
};
(async () => { if (Q.get('table')) await window.__sm1.setTable(Q.get('table')); window.__sm1Ready = true; })();
