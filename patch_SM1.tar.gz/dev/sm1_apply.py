#!/usr/bin/env python3
"""sm1_apply.py - SM1: one command turns a Tripo Studio soldier (rigged, mixamo 65 joints, ONLY the Walk preset) into a battle soldier.

  python3 sm1_apply.py KEY STUDIO.glb OUT.glb [--h METRES] [--yaw auto|DEG] [--alt] [--keep-mesh] [--game-names] [--tris0 6000] [--tris1 1500] [--tex 1024] [--no-pack]
                       [--row ROW.json] [--report REPORT.json] [--lib sm1_clips_lib.glb]
  python3 sm1_apply.py --table [OUT.md]        regenerate docs/SM1_CLIPS.md from sm1_clips.json
  python3 sm1_apply.py --keys                   the 37 keys and what each does

IN : KEY = a key of client/src/unit_models.json (see sm1_clips.json), STUDIO.glb = the Studio export (65 `mixamorig:*` joints, any size / orientation).
OUT: OUT.glb = the model (decimated to <= tris0 triangles if it is bigger, texture <= --tex px, meshopt-packed) + ONLY the clips the table wants for that key, named exactly as the table's
     row says, each cut to its action (one gait cycle for walk / run, one swing for an attack) - 100x smaller than the 10 s library clips; OUT_lod1.glb = the same mesh at <= tris1 triangles;
     the ROW (JSON) = the line for client/src/unit_models.json:  model, h, yaw, clips, ref (run), walkRef, contact, lod2.   Nothing is hand-built or recoloured: the mesh and its texture are the
     owner's (only decimated / resized), the motion is the TP1 library retargeted (R_dst(t) = R_src(t) R_src_rest^-1 R_dst_rest, as RP0A / TP1) or the model's own Walk.
Maths and numbers: every figure printed here is computed from the files (foot sliding, speeds, contact frame, bytes, triangles); nothing is a guess.  Needs numpy + scipy (+ node for decimation).
"""
import sys, os, json, math, copy, struct, subprocess, shutil, tempfile, argparse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import numpy as np
from scipy.spatial.transform import Rotation as Rot
import sm1_tp1_clips as T                      # TP1_clips.py of branch inbox/TP1, unchanged

FPS = T.FPS                                    # 24: the library / Studio rate (the game bakes at 30 fps: crowd.js)
GAME_FPS = 30.0
HIPS = T.HIPS
TABLE = os.path.join(HERE, 'sm1_clips.json')
LIB = os.path.join(HERE, 'sm1_clips_lib.glb')
BUDGET = dict(tris0=6000, tris1=1500, joints=65)
ACT_MAX = 2.4                                  # s: the longest attack clip we ship
HIT_MAX = 1.0                                  # s: the longest stretch of the library's hit reaction that is used
HIT_PLAY = 0.4                                 # s: bunits.js plays the hit state for 0.4 s (v.hitUntil = t + 0.4) and then cross-fades to the idle: the shipped hit clip IS that long, it ends in the idle pose
CLOSE = 0.2                                    # s: loop closure blend


# ---------------------------------------------------------------- skeleton helpers
def fk(S, c):
    """world joint positions (N,3) and rotations (N,3,3) of every joint of clip c (hips translation included)"""
    N = len(c['times']); h = S.idx[HIPS]; Rw = {}; Pw = {}
    ps = S.Parm + c['hips'] @ S.Rarm.T
    for j in S.order:
        q = c['rot'].get(S.names[j]); Rl = Rot.from_quat(q if q is not None else np.tile(S.q_rest[j], (N, 1))).as_matrix()
        pr = S.par[j]; Rp = Rw[pr] if pr in Rw else S.Rarm
        Rw[j] = Rp @ Rl
        Pw[j] = ps if j == h else Pw[pr] + (Rw[pr] @ S.t_rest[j][:, None])[..., 0]
    return Pw, Rw


def jp(S, Pw, name): return Pw[S.idx['mixamorig:' + name]]


def model_facts(js, binb, S):
    """height (m, of the mesh at bind pose), facing, triangles, joints"""
    ymin, ymax, tris = 1e9, -1e9, 0
    for m in js.get('meshes', []):
        for pr in m['primitives']:
            a = js['accessors'][pr['attributes']['POSITION']]; ymin = min(ymin, a['min'][1]); ymax = max(ymax, a['max'][1])
            tris += (js['accessors'][pr['indices']]['count'] if 'indices' in pr else a['count']) // 3
    # the skeleton may sit under a scaled node: the mesh bounds are in mesh space, the bind pose in world: use the head joint to cross-check
    head = S.Pw[S.idx['mixamorig:Head']][1]
    fwd = np.zeros(2)
    for s in ('Left', 'Right'):
        a = S.Pw[S.idx['mixamorig:%sFoot' % s]]; b = S.Pw[S.idx['mixamorig:%sToeBase' % s]]
        fwd += np.array([b[0] - a[0], b[2] - a[2]])
    fwd /= (np.linalg.norm(fwd) or 1)
    yaw = -math.degrees(math.atan2(fwd[0], fwd[1]))            # three.js: rotateY(yaw) turns the file's forward onto +Z (the way a unit walks)
    if yaw <= -179.5: yaw = 180.0
    return dict(height=float(ymax - ymin), head_joint=float(head), tris=int(tris), joints=len(S.joints), fwd=fwd.tolist(), yaw=float(yaw), hip_h=float(S.hip_h))


# ---------------------------------------------------------------- clip utilities
def sub(c, i0, i1):
    """frames i0..i1 inclusive as a clip starting at t = 0"""
    n = i1 - i0 + 1
    return dict(name=c['name'], times=np.arange(n) / FPS, rot={k: v[i0:i1 + 1].copy() for k, v in c['rot'].items()}, hips=c['hips'][i0:i1 + 1].copy())


def energy(S, c):
    """degrees / frame summed over every joint (the library's 'activity'), per frame (N-1 values, padded)"""
    Q = np.stack([T.qcont(q) for q in c['rot'].values()], 1)
    d = np.abs((Q[1:] * Q[:-1]).sum(2)).clip(0, 1)
    e = np.degrees(2 * np.arccos(d)).sum(1)
    return np.concatenate([[e[0]], e])


def smooth(x, n):
    n = max(1, int(n)); k = np.ones(n) / n
    return np.convolve(np.pad(x, (n // 2, n - 1 - n // 2), mode='edge'), k, mode='valid')


def close_loop(c, nc=0):
    """a clean wrap for the baked crowd (frame 0 == last frame).  The mismatch between the last and the first pose (hips drift + every joint rotation) is removed as a straight ramp over the WHOLE cut,
    not as a blend at the end: a ramp changes a planted foot's speed by (mismatch / duration) - invisible - while an end blend makes the foot rush for the last 0.2 s."""
    N = len(c['times']); fr = (np.arange(N) / (N - 1.0))
    c['hips'] = c['hips'] - (c['hips'][-1] - c['hips'][0])[None] * fr[:, None]
    for nm, q in c['rot'].items():
        d = Rot.from_quat(q[0]) * Rot.from_quat(q[-1]).inv(); rv = d.as_rotvec()
        q[:] = T.qcont((Rot.from_rotvec(rv[None] * fr[:, None]) * Rot.from_quat(q)).as_quat())
    return c


IDLE_GAIN = 6.0                                # x: the library's battle_idle breathes by 0.7 cm at the head of a 4.6 m figure (a statue); its own motion about its mean pose is multiplied
IDLE_MAXDEG = 6.0                              # deg: ... but no joint leaves its mean pose by more than this


def breathe(c, gain=IDLE_GAIN, maxdeg=IDLE_MAXDEG):
    """a closed idle loop: every joint's rotation (and the hips' height) about its OWN mean pose x gain (limited to maxdeg per joint).  The loop stays closed (same function of the same poses).  -> (clip, applied gain per joint max)"""
    for nm, q in c['rot'].items():
        R = Rot.from_quat(q); m = R.mean(); d = (m.inv() * R).as_rotvec(); mx = float(np.degrees(np.linalg.norm(d, axis=1)).max())
        g = gain if mx * gain <= maxdeg else (maxdeg / mx if mx > 1e-6 else 1.0); g = max(1.0, g)
        q[:] = T.qcont((m * Rot.from_rotvec(d * g)).as_quat())
    hm = c['hips'].mean(0); c['hips'] = hm + (c['hips'] - hm) * min(gain, 4.0)
    return c


def descriptor(S, c):
    """pose descriptor per frame: hands / feet / toes / head relative to the hips, in the hips' heading frame, in units of hip height"""
    Pw, Rw = fk(S, c); h = S.idx[HIPS]; names = ['LeftHand', 'RightHand', 'LeftFoot', 'RightFoot', 'LeftToeBase', 'RightToeBase', 'Head', 'LeftForeArm', 'RightForeArm', 'LeftLeg', 'RightLeg']
    X = np.concatenate([(jp(S, Pw, n) - Pw[h]) for n in names], 1) / S.hip_h
    return X, Pw


def find_cycle(S, c, tmin, tmax, start_max=0.6):
    """the shortest stretch [i0, i0+L] whose end pose equals its start pose (same foot in front): one full gait cycle / one breath.  -> (i0, L, err)"""
    X, _ = descriptor(S, c); N = len(X); res = []
    lmin, lmax = int(round(tmin * FPS)), int(round(tmax * FPS))
    for L in range(lmin, min(lmax, N - 2) + 1):
        best = None
        for i0 in range(0, min(N - L - 1, int(start_max * N)) + 1):
            # closure of the pose AND of its velocity (a clean wrap)
            e = np.linalg.norm(X[i0 + L] - X[i0]) + 0.5 * np.linalg.norm((X[min(i0 + L + 1, N - 1)] - X[i0 + L]) - (X[min(i0 + 1, N - 1)] - X[i0]))
            if best is None or e < best[0]: best = (e, i0)
        res.append((L, best[1], best[0]))
    if not res: raise ValueError('clip too short for a cycle')
    emin = min(r[2] for r in res)
    pick = next(r for r in res if r[2] <= max(1.35 * emin, emin + 0.02))      # the SHORTEST one that is nearly as good as the best (not two cycles)
    return pick[1], pick[0], float(pick[2])


# ---------------------------------------------------------------- gait: speed + foot sliding
def gait(S, c, scale):
    """for a CLOSED looping walk / run clip (root motion removed = 'in place', first frame == last): the ground speed it was made for = the speed of the planted foot against the body (m/s of the game
    figure, `scale` = game metres per model metre), and how much that foot slides when the body moves at exactly that speed.
    planted = the toe (else the ankle, at heel strike) is within 2 % of the hip height of its lowest height in the clip AND moving backward against the body; slide = |foot velocity along the walking line + v*|, v* = median backward foot speed
    of the planted frames; lateral = |foot velocity across it|.  All in cm/s of the game figure."""
    Pw, _ = fk(S, c); n = len(c['times']) - 1; dt = 1.0 / FPS                           # n distinct frames (the last repeats the first)
    fwd = np.zeros(2)
    for s in ('Left', 'Right'):
        a = S.Pw[S.idx['mixamorig:%sFoot' % s]]; b = S.Pw[S.idx['mixamorig:%sToeBase' % s]]; fwd += np.array([b[0] - a[0], b[2] - a[2]])
    fwd /= np.linalg.norm(fwd); lat = np.array([-fwd[1], fwd[0]])
    tol = 0.02 * S.hip_h
    J = {}
    for side in ('Left', 'Right'):
        for part, nm in (('toe', 'ToeBase'), ('ank', 'Foot')):
            p = jp(S, Pw, side + nm)[:n]; J[side, part] = p
    ground = {part: min(J[s, part][:, 1].min() for s in ('Left', 'Right')) for part in ('toe', 'ank')}
    out = dict(frames=n + 1, period=float(n * dt))
    vs, ls, rec, flat = [], [], [], []
    for side in ('Left', 'Right'):
        pl = {}
        for part in ('toe', 'ank'):
            p = J[side, part]; pl[part] = (p[:, 1] - ground[part]) < tol
        use_toe = pl['toe']; use_ank = pl['ank'] & ~pl['toe']
        for part, m in (('toe', use_toe), ('ank', use_ank)):
            p = J[side, part]; sp = p[:, 0] * fwd[0] + p[:, 2] * fwd[1]; lp = p[:, 0] * lat[0] + p[:, 2] * lat[1]
            ds = (np.roll(sp, -1) - np.roll(sp, 1)) / (2 * dt); dl = (np.roll(lp, -1) - np.roll(lp, 1)) / (2 * dt)
            for i in np.where(m & (ds < 0))[0]:
                rec.append((-ds[i], abs(dl[i])))
                if pl['toe'][i] and pl['ank'][i]: flat.append(-ds[i])                         # (the whole sole on the ground)              # (low AND moving backward against the body: the swing foot skims the ground too, going forward)
    if len(rec) < 4: out.update(ok=False); return out
    r = np.array(rec); v = float(np.median(r[:, 0]))
    slide = np.abs(r[:, 0] - v) * scale * 100; lat_s = r[:, 1] * scale * 100
    out.update(ok=True, speed_model=v, speed=v * scale, planted_frames=len(rec), planted_pct=100.0 * len(rec) / (2 * n),
               slide_p50=float(np.percentile(slide, 50)), slide_p95=float(np.percentile(slide, 95)), slide_max=float(slide.max()),
               lat_p95=float(np.percentile(lat_s, 95)), slide_p95_pct=float(np.percentile(slide, 95) / max(1e-9, v * scale * 100) * 100))
    if flat: fl = np.abs(np.array(flat) - v) * scale * 100; out.update(flat_frames=len(flat), slide_flat_p50=float(np.percentile(fl, 50)), slide_flat_p95=float(np.percentile(fl, 95)))
    out['step_len'] = float(v * (out['period'] / 2.0) * scale)                           # metres of the game figure per step (two steps per cycle)
    return out


def play_table(speeds, walk, run, walk_ref, ref, walk_max):
    """what runPlay (bunits.js, with the SM1 hook) does at each ground speed v (m/s): clip, playback speed p, and the planted foot's speed against the ground = |v - p * v*| (cm/s of the game figure).
    walk is None -> one clip (the walk) for every speed: p = clamp(v / ref, 0.4, 1.9)"""
    rows = []
    for v in speeds:
        if walk is not None and walk_max and v < walk_max:
            p = min(1.6, max(0.4, v / walk_ref)); clip, vs = 'walk', walk['speed']
        else:
            p = min(1.9, max(0.4, v / ref)); clip, vs = ('run' if walk is not None else 'walk'), run['speed']
        rows.append(dict(v=v, clip=clip, playback=round(p, 2), slide_cms=round(abs(v - p * vs) * 100, 0), slide_pct=round(100 * abs(v - p * vs) / v, 0)))
    return rows


# ---------------------------------------------------------------- attacks: contact frame + the cut
def hand_speed(S, c):
    Pw, _ = fk(S, c); dt = 1.0 / FPS; h = S.idx[HIPS]
    sp = {}
    for side in ('Left', 'Right'):
        p = jp(S, Pw, side + 'Hand') - Pw[h] * 0.0                                   # body is locked: world == body frame
        sp[side] = np.linalg.norm(np.gradient(p, dt, axis=0), axis=1)
    return sp


EASE = 0.3                                     # s: the last stretch of a swing / hit clip eases into the idle pose (the crowd cross-fades skin MATRICES for 0.25 s: two far-apart arm poses blended linearly fold the arm up through the head)


def ease_out(c, ref, dur=EASE):
    """the last `dur` s of c are blended (smoothstep) onto the first pose of `ref` (the idle loop): rotations by slerp, hips by lerp.  -> c"""
    N = len(c['times']); n = min(N - 1, int(round(dur * FPS))); w = np.zeros(N)
    t = np.arange(n + 1) / float(n); w[N - 1 - n:] = t * t * (3 - 2 * t)
    for nm, q in c['rot'].items():
        r0 = ref['rot'].get(nm)
        if r0 is None: continue
        A = Rot.from_quat(q); B = Rot.from_quat(np.tile(r0[0], (N, 1))); d = (A.inv() * B).as_rotvec()
        q[:] = T.qcont((A * Rot.from_rotvec(d * w[:, None])).as_quat())
    c['hips'] = c['hips'] + (ref['hips'][0][None] - c['hips']) * w[:, None]
    return c


def cut_attack(S, c, ct_target, tail=0.45, max_len=ACT_MAX):
    """-> (clip, info): the swing of c cut so that the blow's contact frame (the hand's fastest moment inside the strongest burst) lies ct_target s after the start"""
    e = smooth(energy(S, c), 3); N = len(e)
    # strongest burst = the 0.5 s window with the largest energy
    w = int(0.5 * FPS); csum = np.concatenate([[0], np.cumsum(e)]); win = csum[w:] - csum[:-w]; pk = int(win.argmax()) + w // 2
    thr = max(0.6, 0.12 * e[max(0, pk - w):pk + w].max())
    b0 = pk
    while b0 > 0 and (e[b0 - 1] > thr or (b0 > 3 and e[max(0, b0 - 6):b0].max() > thr)): b0 -= 1
    b1 = pk
    while b1 < N - 1 and (e[b1 + 1] > thr or e[b1 + 1:min(N, b1 + 6)].max() > thr): b1 += 1
    sp = hand_speed(S, c); side = max(sp, key=lambda k: sp[k][b0:b1 + 1].max()); hs = smooth(sp[side], 3)
    seg = slice(max(0, pk - w), min(N, pk + w)); ct = int(np.argmax(hs[seg])) + seg.start
    i0 = max(0, ct - int(round(ct_target * FPS)), b0 - int(0.15 * FPS)) if ct - b0 > ct_target * FPS else max(0, b0 - int(0.05 * FPS))
    i1 = min(N - 1, b1 + int(tail * FPS))
    if (i1 - i0) / FPS > max_len: i1 = i0 + int(max_len * FPS)
    cc = sub(c, i0, i1)
    return cc, dict(src_window=[round(i0 / FPS, 2), round(i1 / FPS, 2)], burst=[round(b0 / FPS, 2), round(b1 / FPS, 2)], hand=side, contact=round((ct - i0) / FPS, 3),
                    contact_src=round(ct / FPS, 3), duration=round((i1 - i0) / FPS, 3), peak_hand_speed=round(float(hs[ct]), 3))


def retime(c, factor):
    """the clip played `factor` x faster (factor > 1: shorter): rotations by slerp between the source frames, hips by lerp"""
    from scipy.spatial.transform import Slerp
    N = len(c['times']); n = int(round((N - 1) / factor)) + 1; u = np.minimum(np.arange(n) * factor, N - 1.0); i0 = np.minimum(u.astype(int), N - 2); f = u - i0
    out = dict(name=c['name'], times=np.arange(n) / FPS, rot={}, hips=c['hips'][i0] * (1 - f)[:, None] + c['hips'][i0 + 1] * f[:, None])
    for nm, q in c['rot'].items():
        A = Rot.from_quat(q[i0]); B = Rot.from_quat(q[i0 + 1]); out['rot'][nm] = T.qcont((A * Rot.from_rotvec((A.inv() * B).as_rotvec() * f[:, None])).as_quat())
    return out


def cut_hit(S, c):
    """the reaction from its onset, played at HIT_PLAY s: the library's 0.6 s after the onset squeezed into 0.4 s (a flinch is quick), and the last part eased into the idle pose by the caller"""
    e = smooth(energy(S, c), 3); thr = max(0.6, 0.15 * e.max()); on = int(np.argmax(e > thr))
    i0 = max(0, on - int(0.05 * FPS)); i1 = min(len(e) - 1, i0 + int(0.6 * FPS))
    k = (i1 - i0) / FPS / HIT_PLAY
    return retime(sub(c, i0, i1), k), dict(src_window=[round(i0 / FPS, 2), round(i1 / FPS, 2)], duration=HIT_PLAY, retime=round(k, 2))


# ---------------------------------------------------------------- the model's own walk
def own_clip(jd, bd, D, names):
    for c in T.read_clips(jd, bd, D):
        if c['name'].strip().lower() in names: return c
    return None


# ---------------------------------------------------------------- bytes
def clip_bytes(jd, bd, c):
    """size of ONE clip (KB) as stored: rotation + hips tracks after key reduction"""
    base_js, base_b = T.compact_and_add(jd, bd, [])
    js, b = T.compact_and_add(jd, bd, [c])
    return (len(b) - len(base_b)) / 1024.0


# ---------------------------------------------------------------- mesh: decimate / pack with node (sm1_lod.mjs, from tools/lod_geo.mjs)
GT = os.environ.get('SM1_GT', '/tmp/claude-0/gt')
KEEP_NORMAL = False


def node_lod(src, dst, tris, tex, pack, weld=True):
    mjs = os.path.join(HERE, 'sm1_lod.mjs'); tgt = os.path.join(GT, 'sm1_lod.mjs')
    shutil.copyfile(mjs, tgt)
    r = subprocess.run(['node', tgt, os.path.abspath(src), os.path.abspath(dst), str(tris), str(tex), '1' if pack else '0', '1' if KEEP_NORMAL else '0'], capture_output=True, text=True, cwd=GT)
    if r.returncode: raise SystemExit('sm1_lod.mjs failed:\n' + r.stdout + r.stderr)
    return r.stdout.strip()


# ---------------------------------------------------------------- game names (carry.js / rpg.js hero rig names): same rename as workers/dev/sis_build.py
def to_game_names(js, binb):
    SRC2MIX = {'Hip': 'mixamorig:Hips', 'Waist': 'mixamorig:Spine', 'Spine01': 'mixamorig:Spine1', 'Spine02': 'mixamorig:Spine2', 'Head': 'mixamorig:Head'}
    for s, m in (('L', 'Left'), ('R', 'Right')):
        SRC2MIX.update({s + '_Clavicle': 'mixamorig:%sShoulder' % m, s + '_Upperarm': 'mixamorig:%sArm' % m, s + '_Forearm': 'mixamorig:%sForeArm' % m, s + '_Hand': 'mixamorig:%sHand' % m,
                        s + '_Thigh': 'mixamorig:%sUpLeg' % m, s + '_Calf': 'mixamorig:%sLeg' % m, s + '_Foot': 'mixamorig:%sFoot' % m, s + '_ToeBase': 'mixamorig:%sToeBase' % m})
        for g, mx in (('Index', 'Index'), ('Mid', 'Middle'), ('Ring', 'Ring'), ('Pinky', 'Pinky'), ('Thumb', 'Thumb')):
            for k in (1, 2, 3): SRC2MIX['%s_%s%d' % (s, g, k)] = 'mixamorig:%sHand%s%d' % (m, mx, k)
    MIX2GAME = {v: k for k, v in SRC2MIX.items()}; MIX2GAME['mixamorig:Neck'] = 'Neck'
    js = copy.deepcopy(js); used = set()
    for nd in js['nodes']:
        nm = nd.get('name')
        if nm in MIX2GAME: nd['name'] = MIX2GAME[nm]
        elif nm and nm.startswith('mixamorig:'): nd['name'] = nm[len('mixamorig:'):].replace('Left', 'L_').replace('Right', 'R_')
        if nd.get('name') in used: raise SystemExit('duplicate joint name ' + nd['name'])
        used.add(nd.get('name'))
    # a `Pelvis` joint: identity child of Hip (carry.js mounts belts / scabbards on it)
    nodes = js['nodes']; sk = js['skins'][0]; hip = next(i for i, n in enumerate(nodes) if n.get('name') == 'Hip')
    nodes.append({'name': 'Pelvis'}); pi = len(nodes) - 1; nodes[hip].setdefault('children', []).append(pi); sk['joints'].append(pi)
    a = js['accessors'][sk['inverseBindMatrices']]; bv = js['bufferViews'][a['bufferView']]; off = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
    ibm = np.frombuffer(binb, dtype='<f4', count=a['count'] * 16, offset=off).reshape(a['count'], 16)
    new = np.vstack([ibm, ibm[sk['joints'].index(hip)][None]]).astype('<f4'); out = bytearray(binb)
    while len(out) % 4: out += b'\0'
    js['bufferViews'].append({'buffer': 0, 'byteOffset': len(out), 'byteLength': new.nbytes}); out += new.tobytes()
    js['accessors'].append({'bufferView': len(js['bufferViews']) - 1, 'componentType': 5126, 'count': int(new.shape[0]), 'type': 'MAT4'})
    sk['inverseBindMatrices'] = len(js['accessors']) - 1
    return js, bytes(out)


# ---------------------------------------------------------------- LOD2 capsule colours from the albedo (head / body / legs by vertex height); the dev page measures + refines them (dev/sm1_units.js cal)
def acc_f(js, binb, i):
    """any float accessor (SCALAR..VEC4), tightly packed or strided -> (n, k) float array"""
    a = js['accessors'][i]; assert a['componentType'] == 5126, 'float accessor expected'
    k = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[a['type']]; bv = js['bufferViews'][a['bufferView']]; o = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
    st = bv.get('byteStride', 4 * k)
    raw = np.frombuffer(binb, dtype=np.uint8, count=st * (a['count'] - 1) + 4 * k, offset=o)
    return np.stack([np.frombuffer(raw[j * st:j * st + 4 * k].tobytes(), dtype='<f4') for j in range(a['count'])]) if st != 4 * k else np.frombuffer(binb, dtype='<f4', count=a['count'] * k, offset=o).reshape(a['count'], k)


def lod2_colours(js, binb, hb):
    try:
        from PIL import Image
        import io
    except Exception:
        return None
    pr = js['meshes'][0]['primitives'][0]; at = pr['attributes']
    if 'TEXCOORD_0' not in at or 'material' not in pr: return None
    mat = js['materials'][pr['material']]; pb = mat.get('pbrMetallicRoughness', {})
    P = acc_f(js, binb, at['POSITION']); UV = acc_f(js, binb, at['TEXCOORD_0'])
    tex = pb.get('baseColorTexture')
    if tex is None:
        bc = pb.get('baseColorFactor', [0.7, 0.7, 0.7, 1])[:3]; img = None
    else:
        tx = js['textures'][tex['index']]; src = tx.get('source', (tx.get('extensions', {}).get('EXT_texture_webp') or {}).get('source')); im = js['images'][src]
        if 'bufferView' not in im: return None
        bv = js['bufferViews'][im['bufferView']]; o = bv.get('byteOffset', 0); img = Image.open(io.BytesIO(binb[o:o + bv['byteLength']])).convert('RGB'); bc = None
    y = (P[:, 1] - P[:, 1].min()) / max(1e-6, np.ptp(P[:, 1]))
    def mean(mask):
        if mask.sum() == 0: return [0.5, 0.5, 0.5]
        if img is None: return [float(v) for v in bc]
        w, h = img.size; u = np.clip((UV[mask, 0] % 1.0) * (w - 1), 0, w - 1).astype(int); v = np.clip((UV[mask, 1] % 1.0) * (h - 1), 0, h - 1).astype(int)
        px = np.asarray(img)[v, u].astype(float) / 255.0
        return [float(x) for x in px.mean(0)]
    hexv = lambda rgb: int(round(rgb[0] * 255)) << 16 | int(round(rgb[1] * 255)) << 8 | int(round(rgb[2] * 255))
    return dict(skin=hexv(mean(y > 0.83)), cloth=hexv(mean((y > 0.38) & (y <= 0.83))), legs=hexv(mean(y <= 0.38)))


# ---------------------------------------------------------------- the table / docs
def load_table():
    return json.load(open(TABLE))


def cmd_keys():
    t = load_table()
    for k in t['order']:
        r = t['keys'][k]
        print('%-14s %-9s %s' % (k, 'pipeline' if r['pipeline'] else r['kind'], r.get('role') or r.get('why')))


def apply(key, studio, out, a):
    tb = load_table(); R = tb['keys'].get(key)
    if R is None: raise SystemExit('unknown key %r (see --keys)' % key)
    if not R['pipeline']:
        raise SystemExit('%s keeps today\'s body (%s): %s\n  needs: %s' % (key, R['kind'], R['why'], '; '.join(R['needs'])))
    h = a.h or R['h']
    jl, bl = T.load_glb(a.lib); L = T.Skel(jl); lc = {c['name']: c for c in T.read_clips(jl, bl, L)}
    jd, bd = T.load_glb(studio); D = T.Skel(jd)
    assert set(L.names[j] for j in L.joints) == set(D.names[j] for j in D.joints), 'different joint names: not a Studio mixamo rig (65 mixamorig:* joints)'
    facts = model_facts(jd, bd, D)
    # ---- the mesh first (decimate + texture + pack) so that the clips are added to the final bytes
    tmp = tempfile.mkdtemp(prefix='sm1_'); mesh0 = os.path.join(tmp, 'mesh0.glb'); log = []
    if a.keep_mesh: shutil.copyfile(studio, mesh0)
    else: log.append(node_lod(studio, mesh0, a.tris0, a.tex, False))
    jm, bm = T.load_glb(mesh0); Dm = T.Skel(jm)
    mfacts = model_facts(jm, bm, Dm)
    yaw = facts['yaw'] if a.yaw == 'auto' else float(a.yaw)
    hb = facts['height']; scale = h / hb                                           # game metres per model metre (unit_swap scales the file to h exactly like this)
    rep = dict(key=key, studio=os.path.basename(studio), h=h, scale=round(scale, 4), model=dict(facts, tris_out=mfacts['tris']), clips={}, warnings=[])
    # ---- which clips (slot -> library clip); alt swings only with --alt
    atk = list(R['atk']) + (list(R['alt'][:1]) if a.alt else [])
    slots = dict(idle=R['idle'], walk=R['walk'], run=R['run'], atk=atk, hit=R['hit'])
    for nm in [R['idle'], R['hit']] + atk:
        if nm not in lc: raise SystemExit('library has no clip ' + nm)
    verdict = {c['name']: c['verdict'] for c in json.load(open(os.path.join(HERE, 'sm1_clips_manifest.json')))['clips'] if c.get('name')}
    for nm in set([R['idle'], R['hit']] + atk):
        if verdict.get(nm) in ('weak', 'seat', 'reject'): rep['warnings'].append('clip %s is %s in the TP1 verdicts' % (nm, verdict[nm]))
    cuts = {}                                                                       # name -> clip (ready for the file)
    # ---- walk: the model's own Walk preset (ground truth of its stride); the library's if the file has none
    def gaitrep(c, src, i0, Lc, err):
        return dict(kind='loop', src=src, cycle_src=[round(i0 / FPS, 2), round((i0 + Lc) / FPS, 2)], closure_err=round(err, 4), **{k: (round(v, 3) if isinstance(v, float) else v) for k, v in gait(D, c, scale).items()})
    own = own_clip(jd, bd, D, ('walking', 'walk'))
    if own is not None:
        w = T.retarget(D, D, own, 'loop', True); rep['walk_source'] = 'own Walk preset'
    else:
        w = T.retarget(L, D, lc['walk'], 'keep', False); rep['walk_source'] = 'library walk (the file has no Walk)'; rep['warnings'].append('no Walk preset in the Studio file: the library walk is used (its stride is not the model\'s own)')
    w['name'] = 'walk'
    i0, Lc, err = find_cycle(D, w, 0.6, 2.4); c = close_loop(sub(w, i0, i0 + Lc), int(CLOSE * FPS)); c['name'] = 'walk'; cuts['walk'] = c
    rep['clips']['walk'] = gaitrep(c, rep['walk_source'], i0, Lc, err)
    # ---- run: the model's own Run preset if it has one (and the unit may run), else the Walk again (played faster by the game).  The library `sprint` is not used (the legs pedal on the spot).
    def lib(nm, mode):
        r = T.retarget(L, D, lc[nm], 'keep', False); r['name'] = nm; return r
    own_run = None if R['run'] == 'walk' else own_clip(jd, bd, D, ('running', 'run'))
    if own_run is None:
        run_name = 'walk'
        if R['run'] != 'walk': rep['warnings'].append('no Run preset in the Studio file: the Walk is played faster for running (feet slide above ~%.1f m/s, see play table)' % (1.9 * rep['clips']['walk'].get('speed', 0)))
    else:
        run_name = 'run'; r = T.retarget(D, D, own_run, 'loop', True); r['name'] = 'run'
        i0, Lc, err = find_cycle(D, r, 0.3, 1.6); c = close_loop(sub(r, i0, i0 + Lc), int(0.12 * FPS)); c['name'] = 'run'; cuts['run'] = c
        rep['clips']['run'] = gaitrep(c, 'own Run preset', i0, Lc, err)
    idle = lib(R['idle'], 'loop'); i0, Lc, err = find_cycle(D, idle, 2.0, 3.2, 0.7); c = close_loop(sub(idle, i0, i0 + Lc), int(CLOSE * FPS)); c['name'] = R['idle']; e0 = float(energy(D, c).mean()); c = breathe(c); cuts[R['idle']] = c
    rep['clips'][R['idle']] = dict(kind='loop', src='library', cycle_src=[round(i0 / FPS, 2), round((i0 + Lc) / FPS, 2)], closure_err=round(err, 4), duration=round(Lc / FPS, 2), breathe_gain=IDLE_GAIN, deg_per_frame=[round(e0, 2), round(float(energy(D, c).mean()), 2)])
    hr = lib(R['hit'], 'lock'); c, inf = cut_hit(D, hr); c['name'] = R['hit']; c = ease_out(c, cuts[R['idle']], 0.15); cuts[R['hit']] = c; rep['clips'][R['hit']] = dict(kind='once', src='library', **inf)
    hit_t = R['hit_t']; ct_target = hit_t * R['atk_sp']
    contact = {}
    for nm in atk:
        r = lib(nm, 'lock'); c, inf = cut_attack(D, r, ct_target); c['name'] = nm; c = ease_out(c, cuts[R['idle']]); cuts[nm] = c
        inf['playback_speed'] = round(inf['contact'] / hit_t, 3); contact[nm] = inf['contact']
        if not (0.5 <= inf['playback_speed'] <= 2.2): rep['warnings'].append('%s: contact %.2f s -> playback speed %.2f is outside the game\'s 0.5..2.2 clamp' % (nm, inf['contact'], inf['playback_speed']))
        rep['clips'][nm] = dict(kind='once', src='library', **inf)
    # ---- bytes per clip + the file
    order = list(dict.fromkeys([R['idle'], 'walk', run_name] + atk + [R['hit']]))      # (a unit whose run is the walk ships the walk once)
    clips = [cuts[n] for n in order]
    js2, b2 = T.compact_and_add(jm, bm, clips)
    for n, c in zip(order, clips): rep['clips'][n]['kb'] = round(clip_bytes(jm, bm, c), 1); rep['clips'][n]['frames_baked'] = int(round((c['times'][-1]) * GAME_FPS))
    rawm = os.path.join(tmp, 'raw_mixamo.glb'); T.write_glb(rawm, js2, b2)                                          # (python reads this one for the numbers below: the game-named copy has no mixamorig:* names)
    if a.game_names: js2, b2 = to_game_names(js2, b2)
    raw = os.path.join(tmp, 'raw.glb'); T.write_glb(raw, js2, b2)
    if a.no_pack: shutil.copyfile(raw, out)
    else: log.append(node_lod(raw, out, 10 ** 9, 0, True))
    # LOD1: the same mesh, no clips, <= tris1 (the skeleton stays: the game can pair it with LOD0)
    if a.tris1:
        lod1 = os.path.splitext(out)[0] + '_lod1.glb'; js0, b0 = T.compact_and_add(jm, bm, []); m1 = os.path.join(tmp, 'mesh_noanim.glb'); T.write_glb(m1, js0, b0); msg1 = node_lod(m1, lod1, a.tris1, min(a.tex, 512), True); log.append(msg1); import re; t1 = re.search(r'-> (\d+) tris', msg1); rep['lod1'] = dict(file=os.path.basename(lod1), kb=round(os.path.getsize(lod1) / 1024, 1), tris=int(t1.group(1)) if t1 else None)
    # ---- numbers of the file
    jo, bo = T.load_glb(rawm); fo = model_facts(jo, bo, T.Skel(jo))                      # (the same file before the meshopt pack / the renaming; python cannot read packed buffers)
    baked = sum(r['frames_baked'] for r in rep['clips'].values())
    rep['file'] = dict(name=os.path.basename(out), kb=round(os.path.getsize(out) / 1024, 1), tris=fo['tris'], joints=fo['joints'], clips=order,
                       clips_kb=round(sum(r['kb'] for r in rep['clips'].values()), 1), baked_frames=baked, bake_texture_kb=round(baked * fo['joints'] * 64 / 1024.0, 1))
    # budgets
    if fo['tris'] > BUDGET['tris0']: rep['warnings'].append('LOD0 %d triangles > %d' % (fo['tris'], BUDGET['tris0']))
    if fo['joints'] != BUDGET['joints']: rep['warnings'].append('%d joints (a Studio mixamo rig has 65)' % fo['joints'])
    # ---- the row + what the game's runPlay does with it
    W = rep['clips']['walk']; RUN = rep['clips'][run_name]
    walkref = W.get('speed'); runref = RUN.get('speed')
    single = (run_name == 'walk')
    if not single and walkref and runref:
        wmax = max(1.0, min(max(math.sqrt(walkref * runref), 0.5 * walkref), 1.6 * walkref))       # (== unit_swap.js part.walkMax) the speed where walk -> run: the playback of the walk and of the run are symmetric around 1.0 there
    else: wmax = None
    rep['play_table'] = play_table([1, 2, 3, 4, 6, 8, 10, 12, 15], None if single else W, RUN, walkref, runref, wmax) if (walkref and runref) else None
    row = dict(model=os.path.splitext(os.path.basename(out))[0], anims=None, h=round(h, 3), yaw=round(yaw, 1), clips=dict(idle=R['idle'], run=run_name, walk='walk', atk=atk if len(atk) > 1 else atk[0], hit=R['hit']),
               ref=round(runref, 2) if runref else None, walkRef=round(walkref, 2) if walkref else None, contact={n: contact[n] for n in atk}, lod1=(os.path.splitext(os.path.basename(out))[0] + '_lod1') if a.tris1 else None,
               lod2=lod2_colours(jo, bo, fo['height']), note='SM1 ' + key + ' (from ' + os.path.basename(studio) + ')')
    rep['row'] = row
    if a.row: json.dump({key: row}, open(a.row, 'w'), indent=1)
    if a.report: json.dump(rep, open(a.report, 'w'), indent=1, default=float)
    shutil.rmtree(tmp, ignore_errors=True)
    return rep, log


def cmd_table(outmd):
    import sm1_doc
    sm1_doc.write(load_table(), outmd)


if __name__ == '__main__':
    ap = argparse.ArgumentParser(add_help=True, description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('args', nargs='*'); ap.add_argument('--h', type=float); ap.add_argument('--yaw', default='auto'); ap.add_argument('--alt', action='store_true')
    ap.add_argument('--keep-mesh', action='store_true'); ap.add_argument('--keep-normal', action='store_true'); ap.add_argument('--game-names', action='store_true'); ap.add_argument('--no-pack', action='store_true')
    ap.add_argument('--tris0', type=int, default=BUDGET['tris0']); ap.add_argument('--tris1', type=int, default=BUDGET['tris1']); ap.add_argument('--tex', type=int, default=1024)
    ap.add_argument('--row'); ap.add_argument('--report'); ap.add_argument('--lib', default=LIB); ap.add_argument('--table', action='store_true'); ap.add_argument('--keys', action='store_true')
    a = ap.parse_args()
    KEEP_NORMAL = a.keep_normal
    if a.keys: cmd_keys(); sys.exit(0)
    if a.table: cmd_table(a.args[0] if a.args else os.path.join(HERE, '..', 'docs', 'SM1_CLIPS.md')); sys.exit(0)
    if len(a.args) != 3: ap.print_help(); sys.exit(1)
    rep, log = apply(*a.args, a)
    for l in log: print(l)
    f = rep['file']
    print('%s -> %s | %.1f KB | %d tris | %d joints | clips %s (%.1f KB) | bake texture %.0f KB' % (rep['key'], f['name'], f['kb'], f['tris'], f['joints'], ','.join(f['clips']), f['clips_kb'], f['bake_texture_kb']))
    for w in rep['warnings']: print('WARN:', w)
    print('ROW:', json.dumps({rep['key']: rep['row']}, default=float))
