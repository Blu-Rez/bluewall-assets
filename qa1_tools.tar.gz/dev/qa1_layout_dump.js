// qa1_layout_dump.js (QA1, read-only): dumps the home map's layout (gate, keep, plaza, storages, roads, bridges, fields, mill, worksites, river, mines...) to work/qa1/layout_dump.json
import * as L from '/home/claude/bot/bluebot_v2/bluewall/client/src/layout.js';
import { buildRoads, ROADS, YARDS } from '/home/claude/bot/bluebot_v2/bluewall/client/src/roads.js';
import { planQuarter } from '/home/claude/bot/bluebot_v2/bluewall/client/src/storeyards.js';
import { hamlets } from '/home/claude/bot/bluebot_v2/bluewall/client/src/hamlets.js';
import * as fs from 'fs';
L.setMap('night'); buildRoads();
const r = (v) => Math.round(v * 100) / 100, pt = (o) => (o ? Object.fromEntries(Object.entries(o).filter(([k, v]) => typeof v === 'number' || typeof v === 'string').map(([k, v]) => [k, typeof v === 'number' ? r(v) : v])) : null);
const out = {
  gate: pt(L.GATE), gateSeg: L.GATE_SEG, keep: pt(L.KEEP), plaza: pt(L.PLAZA), windmill: pt(L.WINDMILL), lake: pt(L.LAKE), camp: pt(L.CAMP), pasture: pt(L.PASTURE), muster: pt(L.MUSTER), lair: pt(L.LAIR),
  moat: pt(L.MOAT), outer: L.OUTER && { n: L.OUTER.length, pts: L.OUTER.map((p) => [r(p[0]), r(p[1])]) }, inner: L.INNER && { n: L.INNER.length, pts: L.INNER.map((p) => [r(p[0]), r(p[1])]) },
  town: L.TOWN && L.TOWN.map((p) => [r(p[0]), r(p[1])]), tgates: (L.TGATES || []).map(pt), townGates: (L.TOWN_GATES || []).map(pt), wgates: (L.WGATES || []).map(pt),
  farms: (L.FARMS || []).map(pt), sites: (L.SITES || []).map(pt), mines: (L.MINES || []).map(pt), rbridges: (L.RBRIDGES || []).map(pt), mount: L.MOUNT,
  river: L.RIVER && L.RIVER.map((p) => [r(p[0]), r(p[1])]), streams: (L.STREAMS || []).map((s) => ({ id: s.id, pts: s.pts.map((p) => [r(p[0]), r(p[1])]) })),
  roads: ROADS.map((q) => ({ name: q.name, kind: q.kind, w: q.w, tier: q.tier, closed: !!q.closed, n: q.pts.length, a: q.pts[0].map(r), b: q.pts[q.pts.length - 1].map(r) })), yards: YARDS.map(pt),
  hamlets: hamlets().map(pt), quarter: (() => { const Q = planQuarter(); return Q ? [...Q.stores, ...Q.vaults].map((y) => ({ id: y.id, kind: y.kind, x: r(y.x), z: r(y.z), ry: r(y.ry) })) : null; })(),
  heightAt: {}, 
};
for (const [n, x, z] of [['origin', 0, 0]]) out.heightAt[n] = r(L.height(x, z));
fs.mkdirSync('/home/claude/work/qa1', { recursive: true });
fs.writeFileSync('/home/claude/work/qa1/layout_dump.json', JSON.stringify(out, null, 1));
console.log('keys', Object.keys(out).join(','), 'roads', out.roads.length, 'quarter', out.quarter && out.quarter.length);
