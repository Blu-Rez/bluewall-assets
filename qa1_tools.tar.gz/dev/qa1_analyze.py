#!/usr/bin/env python3
# qa1_analyze.py (QA1, read-only): frames + res/*.json  ->  pixel checks, contact sheets, QA1_defects.md
#   python3 dev/qa1_analyze.py report            # metrics of every frame, merge with the page checks and manual_defects.json, write work/qa1/QA1_defects.md (+ sheets)
#   python3 dev/qa1_analyze.py sheets            # per-station sheets (3 cameras x the hours) and 12-station contact sheets
import glob, json, os, re, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont
BASE = '/home/claude/work/qa1/'; OUT = BASE + 'out/'; HOURS = ['day', 'dusk', 'night']; CAMS = ['strat', 'third', 'first']
S = json.load(open(BASE + 'stations_resolved.json')) if os.path.exists(BASE + 'stations_resolved.json') else json.load(open(BASE + 'stations.json'))
ST = {s['id']: s for s in S}
SEV = {'A': 0, 'B': 1, 'C': 2}
# ---------------------------------------------------------------- who owns what (a guess from the station group and the scene name)
GROUP_OWNER = {'castle': 'castle_tr2.js + castle.js (TR2_S3)', 'treasury': 'storeyards.js / vault.js (ST1_R2)', 'roads': 'roads.js (GR1_R2)', 'fields': 'sc_farm.js / crops.js (TR2)', 'mills': 'worksites mills (TR2_S4 ws:mill_*)',
               'worksites': 'worksites (TR2_S4 ws:*)', 'river': 'terrain.js / moat.js (GR1_R2)', 'bridges': 'TR2 bridges (TR2_H)', 'edges': 'terrain.js / ground_near.js (GR1_R2)', 'access': 'rpg.js ramps (RP1C_R3)', 'town': 'town.js / TR2 homes (TR2_H)'}
NAME_OWNER = [(r'gr1-tuft', 'ground_near.js (GR1_R2)'), (r'bank-life', 'moat.js (GR1_R2)'), (r'sc_rocks', 'sc_rocks.js'), (r'sc_bush', 'sc_bush.js'), (r'sc_shadow', 'sc_shadow.js'), (r'wslife|late:wslife', 'wslife.js (AN1_R3)'),
              (r'crowd', 'crowd.js (AN1_R3)'), (r'castle-tr2|static-tr2', 'castle_tr2.js (TR2_S3)'), (r'props_town', 'tr2 town props (TR2_H)'), (r'townplan|homes|civic', 'town.js / b1_townplan.js (TR2_H)'), (r'ws:|worksites', 'worksites (TR2_S4)'),
              (r'terrain|backdrop|water', 'terrain.js (GR1_R2)'), (r'sky', 'sky.js (GR1_R2)'), (r'st1crystal|gem-pile|vault|storage', 'storeyards.js / vault.js (ST1_R2)'), (r'late:defenses|ballista|catapult', 'defense.js (TR2)'), (r'pack#rp', 'cull.js proxy (RP1C_R3) of the named pack')]
def owner_for(name, group):
    for rx, o in NAME_OWNER:
        if re.search(rx, name or '', re.I): return o
    return GROUP_OWNER.get(group, '?')
def sev_rank(d): return (SEV[d['sev']], d.get('prio', 5))

# ---------------------------------------------------------------- pixel checks on a frame
def metrics(path, tag):
    im = np.asarray(Image.open(path).convert('RGB')).astype(np.float32); H, W, _ = im.shape
    L = (0.2126 * im[..., 0] + 0.7152 * im[..., 1] + 0.0722 * im[..., 2]) / 255.0
    band = L[: int(H * 0.2)]; thr = 0.04 if tag != 'night' else 0.007
    dark = band < thr; fd = float(dark.mean())
    hts = []                                                                                     # the dark "ceiling": how many rows from the top are dark in each column
    for x in range(W):
        col = dark[:, x]; n = int(np.argmin(col)) if not col.all() else col.size; hts.append(n)
    hts = np.array(hts, dtype=np.float32); jag = float(np.abs(np.diff(hts)).mean()); fill = float((hts > 0).mean())
    mag = float(((im[..., 0] > 200) & (im[..., 2] > 200) & (im[..., 1] < 70)).mean())
    blk = float((im.max(axis=2) <= 1.0)[int(H * 0.2):].mean())
    return dict(sky_dark=round(fd, 4), sky_jag=round(jag, 2), sky_cols=round(fill, 3), sky_h=round(float(hts.mean()), 1), magenta=round(mag, 5), black_below=round(blk, 4), mean_luma=round(float(L.mean()), 3), flat=round(float(L[::4, ::4].std()), 4))

def load_res(tag):
    out = {}
    for f in sorted(glob.glob(OUT + tag + '/res/S*.json')):
        try: out[os.path.basename(f)[:-5]] = json.load(open(f))
        except Exception: pass
    return out

def frame_path(sid, key, cam, tag): return OUT + '%s/frames/%s_%s__%s__%s.png' % (tag, sid, key, cam, tag)

def collect():
    """every defect as {id?, sid, cam, hours:set, what, sev, owner, frame, prio}"""
    D = {}
    def add(sid, cam, tag, what, sev, owner=None, frame=None, kind='x', prio=5, extra=None):
        s = ST[sid]; key = (sid, cam, kind, what)
        e = D.setdefault(key, dict(sid=sid, cam=cam, hours=[], what=what, sev=sev, owner=owner or GROUP_OWNER.get(s['group'], '?'), frame={}, prio=prio, kind=kind))
        if tag not in e['hours']: e['hours'].append(tag)
        if frame: e['frame'][tag] = frame
        if SEV[sev] < SEV[e['sev']]: e['sev'] = sev
    metr = {}; AUTO = {}; SKY = {}
    for tag in HOURS:
        R = load_res(tag)
        for sid, r in R.items():
            s = ST.get(sid)
            if not s: continue
            for d in (r.get('defects') or []) + ((r.get('hero') or {}).get('defects') or []):
                if d['what'].startswith('the hero cannot walk from'): continue          # superseded: the diag run (bridge cross-sections, traces, reach map) decides, see manual_defects.json
                cam = d.get('cam', 'third'); fp = frame_path(sid, s['key'], cam if cam in CAMS else 'third', tag)
                add(sid, cam, tag, d['what'], d['sev'], owner='rpg.js collision / camera (RP1C_R3) + the building at the spot: ' + GROUP_OWNER.get(s['group'], '?'), frame=fp, kind='hero', prio=1)
            cdi = r.get('camdist') or {}
            if cdi and cdi.get('camD', 9) < 1.5: add(sid, 'third', tag, 'third-person camera squeezed to %.2f m behind her (normal %.1f m): the frame is mostly her back or hair, the spot is wedged against a wall / prop' % (cdi['camD'], cdi.get('base', 3.6)), 'B', owner='rpg.js camera spring (RP1C_R3) + the wall / prop at the spot', frame=frame_path(sid, s['key'], 'third', tag), kind='cam', prio=1)
            sc = r.get('scan2') or (r.get('scan') if (r.get('pagev') or 1) >= 2 else None) or {}   # v1 scan skipped flags/masts -> not trusted
            for kind, lst in (('pole', sc.get('pole', [])), ('tall', sc.get('tall', [])), ('floating', sc.get('floating', []))):
                for o in lst:
                    if min(o['w'], o['d'], o['h']) < 0.05 and kind == 'floating': continue                  # degenerate (hidden / flattened instance)
                    key = (kind, re.sub(r'[^A-Za-z0-9:_#/]', '', o['name'])[-60:], round(o['x'] / 8), round(o['z'] / 8)); e = AUTO.setdefault(key, dict(o=o, st=[], tags=[]))
                    if sid not in e['st']: e['st'].append(sid)
                    if tag not in e['tags']: e['tags'].append(tag)
            z = r.get('zfight2') or (r.get('zfight') if (r.get('pagev') or 1) >= 2 else None) or {}   # v1 zfight had the hero in the picture -> contaminated
            if 0.01 < z.get('frac', 0) <= 0.05:
                cells = z.get('cells', []); k = int(np.argmax(cells)) if cells else 0
                add(sid, 'third', tag, 'z-fighting flicker: %.2f %% of the flat pixels flip when the camera moves 3 cm (worst cell %d,%d of 8x4)' % (z['frac'] * 100, k % 8, k // 8), 'A' if z['frac'] > 0.03 else 'B', owner=GROUP_OWNER.get(s['group'], '?') + ' (coplanar surfaces)', frame=frame_path(sid, s['key'], 'third', tag), kind='zf', prio=2)
            elif z.get('frac', 0) > 0.05: add(sid, 'third', tag, 'z-fight probe NOT valid here (%.1f %% of the flat pixels flip): a surface within about 1 m of the camera moves too much for a 3 cm shift (parallax), not a flicker' % (z['frac'] * 100), 'C', owner='probe limit', frame=frame_path(sid, s['key'], 'third', tag), kind='zf-invalid', prio=9)
            elif 0.004 < z.get('frac', 0) <= 0.01: add(sid, 'third', tag, 'weak z-fight candidate: %.2f %% of the flat pixels flip with a 3 cm camera shift (worst cell %d,%d); could also be shadow-edge shimmer' % (z['frac'] * 100, int(np.argmax(z.get('cells', [0]))) % 8, int(np.argmax(z.get('cells', [0]))) // 8), 'C', owner=GROUP_OWNER.get(s['group'], '?') + ' (coplanar surfaces / shadow edge)', frame=frame_path(sid, s['key'], 'third', tag), kind='zf-weak', prio=6)
        for f in sorted(glob.glob(OUT + tag + '/frames/S*__*__%s.png' % tag)):
            m = re.match(r'(S\d+)_(.+)__(strat|third|first)__%s\.png' % tag, os.path.basename(f))
            if not m: continue
            sid, key, cam = m.groups(); mt = metrics(f, tag); metr[os.path.basename(f)] = mt; s = ST.get(sid)
            if not s: continue
            sky = 'black / empty pixels in the sky band: %.1f %% of the top 20 %% rows are %s (jaggedness %.1f px per column, the dark ceiling covers %.0f %% of the columns, average height %.0f px)' % (mt['sky_dark'] * 100, 'darker than luma 0.04' if tag != 'night' else 'near-black (luma < 0.007)', mt['sky_jag'], mt['sky_cols'] * 100, mt['sky_h'])
            if mt['sky_cols'] < 0.15 and mt['sky_dark'] > 0.03: sky += ' -> narrow columns only: most likely the thin black masts crossing the sky band, not a hole in the sky'
            if mt['sky_dark'] > 0.03 and cam != 'strat' and mt['sky_cols'] >= 0.15: SKY.setdefault(tag, []).append((mt['sky_dark'], sid, cam, f, sky))
            if mt['magenta'] > 0.0005: add(sid, cam, tag, 'magenta (missing / default texture) pixels: %.2f %% of the frame' % (mt['magenta'] * 100), 'B', frame=f, kind='mag', prio=2)
            if cam == 'first' and mt['flat'] < 0.03: add(sid, cam, tag, 'view blocked: the whole first-person frame is one near-uniform colour (luma std %.3f): the eye is against or inside a surface' % mt['flat'], 'A', owner='rpg.js collision / eye placement (RP1C_R3) + the object at the spot', frame=f, kind='flat', prio=1)
            if tag != 'night' and mt['black_below'] > 0.005: add(sid, cam, tag, 'pure-black pixels below the sky band: %.2f %% of the frame (a hole / an unlit surface)' % (mt['black_below'] * 100), 'B', frame=f, kind='blk', prio=3)
    for (kind, name, rx, rz), e in AUTO.items():                                                    # one line per scene object, with every station that sees it
        o = e['o']; sid = e['st'][0]; s = ST[sid]; also = (' (also in range of ' + ', '.join(e['st'][1:6]) + (' ...' if len(e['st']) > 6 else '') + ')') if len(e['st']) > 1 else ''
        asp = o['h'] / max(0.05, max(o['w'], o['d']))
        if kind == 'pole': what, sev, pr = 'pole-like structure %.1f m tall, %.1f x %.1f m (aspect %.0f), not a building: %s at (%.0f, %.0f)%s%s' % (o['h'], o['w'], o['d'], asp, o['name'], o['x'], o['z'], (' x%d' % o['n']) if o['n'] > 1 else '', also), ('B' if o['h'] > 12 and max(o['w'], o['d']) < 1.0 else 'C'), 2
        elif kind == 'tall': what, sev, pr = 'object taller than 4 m that is not in the building list: %.1f m tall, %.1f x %.1f m: %s at (%.0f, %.0f)%s%s' % (o['h'], o['w'], o['d'], o['name'], o['x'], o['z'], (' x%d' % o['n']) if o['n'] > 1 else '', also), ('B' if o['h'] > 14 else 'C'), 3
        else: what, sev, pr = 'floating (scan only, not looked at): bottom %.2f m above the terrain height, %.1f x %.1f x %.1f m: %s at (%.0f, %.0f)%s%s' % (o['y0'], o['w'], o['h'], o['d'], o['name'], o['x'], o['z'], (' x%d' % o['n']) if o['n'] > 1 else '', also), 'C', 8
        for tg in e['tags']:
            add(sid, 'third', tg, what, sev, owner=owner_for(o['name'], s['group']), frame=frame_path(sid, s['key'], 'third', tg), kind=kind + ':auto', prio=pr)
    for tag, lst in SKY.items():                                                                      # one line per hour: the worst frame + the others
        lst.sort(reverse=True); fd, sid, cam, f, txt = lst[0]; others = ', '.join('%s %s %.0f %%' % (x[1], x[2], x[0] * 100) for x in lst[1:9]) + (' ...' if len(lst) > 9 else '')
        add(sid, cam, tag, txt + ((' | also dark in: ' + others + ' (%d frames in all)' % len(lst)) if others else ''), 'B', owner='terrain.js far rings / sky.js (GR1_R2): mountain shadow sides and upper sky get no ambient fill', frame=f, kind='sky', prio=2)
    man = BASE + 'manual_defects.json'
    if os.path.exists(man):
        for m in json.load(open(man)):
            sid = m['sid']; s = ST[sid]
            for tag in m.get('hours', ['day']):
                add(sid, m.get('cam', 'third'), tag, m['what'], m['sev'], owner=m.get('owner') or GROUP_OWNER.get(s['group'], '?'), frame=(OUT + m['frame'] if m.get('frame') else frame_path(sid, s['key'], m.get('cam', 'third') if m.get('cam', 'third') in CAMS else 'third', tag)), kind='manual:' + m.get('kind', 'look'), prio=m.get('prio', 2))
    return list(D.values()), metr

def report():
    defects, metr = collect(); json.dump(metr, open(BASE + 'metrics.json', 'w'), indent=0)
    defects.sort(key=lambda d: (SEV[d['sev']], d['prio'], int(d['sid'][1:]), d['cam']))
    appendix = [d for d in defects if d['kind'] in ('floating:auto', 'zf-invalid') or (d['kind'].endswith(':auto') and d['sev'] == 'C')]
    defects = [d for d in defects if d not in appendix]
    n = {'A': 0, 'B': 0, 'C': 0}
    for i, d in enumerate(defects): d['qid'] = 'QA1-%03d' % (i + 1); n[d['sev']] += 1
    done = {t: len([1 for s in S if os.path.exists(frame_path(s['id'], s['key'], 'third', t))]) for t in HOURS}
    L = ['# QA1_defects — strict map inspection of the home map (hero first / third person + strategic)', '',
         'Kit: `branch kit`, state **WC1 merged / p56 installed / p57 not built** (KIT_VERSION last line 16:25 15 Oct 2026). Walker: `dev/qa1_walk.py` (read-only on the game), pixel checks `dev/qa1_analyze.py`. Frames 844x390, quality `high` (shadows + bloom), software GL.',
         'Stations walked (third-person frame exists): day %d / night %d / dusk %d of %d.   **Defects: A %d · B %d · C %d**' % (done['day'], done['night'], done['dusk'], len(S), n['A'], n['B'], n['C']), '',
         'Format: `ID · station · camera · hour · what · severity (A blocks / B ugly / C polish) · owner file (guess) · frame`.  Ranked: A first, then B, then C; inside a class the hard checks (collision, sky, poles, z-fight) before looks.', '']
    for sv, title in (('A', 'A — blocks'), ('B', 'B — ugly'), ('C', 'C — polish')):
        L.append('## ' + title); L.append('')
        rows = [d for d in defects if d['sev'] == sv]
        if not rows: L.append('(none found by the automatic checks or by looking at the frames — see "not proven")'); L.append('')
        for d in rows:
            s = ST[d['sid']]; fr = next(iter(d['frame'].values()), '')
            rel = os.path.relpath(fr, BASE) if fr else '-'
            L.append('%s · %s %s · %s · %s · %s · %s · %s · `%s`' % (d['qid'], d['sid'], s['key'], d['cam'], '+'.join(d['hours']), d['what'], d['sev'], d['owner'], rel))
        L.append('')
    L += ['## Scan-only candidates (found by the scene scan, NOT looked at, low confidence; not counted above)', '']
    for d in appendix:
        fr = next(iter(d['frame'].values()), ''); L.append('- %s %s · %s · %s · %s · `%s`' % (d['sid'], ST[d['sid']]['key'], '+'.join(d['hours']), d['what'], d['owner'], os.path.relpath(fr, BASE) if fr else '-'))
    L += ['']
    L += ['## Stations and coverage (frames present: s = strategic, t = third person, f = first person)', '', '| ID | station | day | dusk | night |', '|---|---|---|---|---|']
    for st in S:
        cells = []
        for t in HOURS:
            cells.append(''.join(c[0] for c in CAMS if os.path.exists(frame_path(st['id'], st['key'], c, t))) or '-')
        L.append('| %s | %s | %s |' % (st['id'], st['key'], ' | '.join(cells)))
    L += reach_section()
    L += ['', '## NOT proven / limits of this inspection (be honest)', '',
          '- **Phone feel is not proven.** Every frame is software GL (swiftshader, 2 CPU cores), quality `high`, 844x390, dpr 1. No GPU, no touch, no real frame time; anything that depends on GPU precision (z-fight distance, shadow acne, bloom, water reflection tiles) may look different on a phone, better or worse.',
          '- Day / dusk / night are the pinned hours 12.5 / 18.3 / 23 (one page load per hour; the clock is advanced by the tool, not by the game loop); transitions between hours are not looked at. Stations 25-45 (the extra bridges, edges, mill, worksites, field 2, inner wall) were taken at DAY only.',
          '- Automatic checks cover a box of 70 m around each station (scan) and a 3 cm camera shift (z-fight probe at 422x195). A z-fight that only shows at 100 m+ or only while moving fast is NOT covered. Thin objects (masts) alias on a phone more than here. All numbers in this list come from tool page v4 or later (the first runs with a frozen LOD clock were thrown away and re-taken).',
          '- The hero was placed by the tool on the nearest free dry spot (<= 40 m from the planned spot). Walking from station to station with the real physics was done in the dusk pass only (24 legs, 21 passed, 3 stalls, all three explained or retracted above); the 13 bridges were then walked in both directions and the 4 failing crossings were traced second by second. Reachability on foot of the other stations is not proven.',
          '- The A lines about the bridges are what the game own proof walker (rp.walkTo: BFS on 1 m cells, then real physics) and free() / ground() say. They do NOT prove that a human could not find a way out (swim along the river to a gentle bank, jump, a respawn button); they prove that the straight way across fails at the listed bridges and that no side collision exists.',
          '- No stairs / ramps / steps exist in the scene (CLIMB_ON=false), so the wall walk and tower tops are NOT inspected at all; the "stairs" and "wall walk" stations show the tower base by the gate only.',
          '- Ugliness findings are my judgement of single frames at 844x390; items marked "doubtful" are on the list on purpose (you asked to be strict). Two objects stay unnamed (the black bar on the hill behind field 1 at S19, the black long hull in the north-edge camp at S40): the scene scan did not find them.',
          '- Other quality presets (ultra / medium / low) and other weather (`w=clear` only) are not inspected. Crowds, fights and the UI layer were not part of this job.']
    open(BASE + 'QA1_defects.md', 'w').write('\n'.join(L)); print('wrote QA1_defects.md', n, done)
    return defects


def reach_section():
    """the game's own reach map, the 33-leg diag run and the bridge probes, as a short section"""
    L = ['', '## Reachability and bridges (the game own tools: reach map, proof walker, free() / ground())', '']
    try:
        D1 = json.load(open(OUT + 'day/diag/diag.json')); R = json.load(open(OUT + 'day/diag/reach.json'))
        bl = R.get('blobs', [])[:6]
        L.append('- **Reach map (rp.reachMap, 2 m cells, edge 420 m):** %.2f %% of %d m2 of land is reachable on foot (%d m2 not). Largest dead pockets: %s. They are strips of land between the moat and the outer wall and a mountain-foot pocket at the west edge; harmless but unreachable (frame `out/diag/frames/d1_reachmap.png`: green reachable, red unreachable, blue water, grey solid, brown steep).' % (R['reachPct'], R['landArea_m2'], R['landArea_m2'] - R['reachArea_m2'], '; '.join('%d m2 at (%d,%d)' % (b['area'], b['x'], b['z']) for b in bl)))
        tg = [x for x in D1 if x['name'].startswith('tgate')]; L.append('- **Town gates:** %d of %d walks through both gates (in and out) passed. The dusk-pass stall at the east town gate (S20 to S21) was a transient: the same walk restarted from the stall spot (154.9, 73.4) passed in 117 s.' % (sum(1 for x in tg if (x.get('walk') or {}).get('ok')), len(tg)))
        br = {x['name']: x for x in D1 if x['name'].startswith('bridge')}
        L.append('- **Bridges, walker (game physics) both directions:** %d of %d crossings passed; the %d that failed are %s.' % (sum(1 for x in br.values() if (x.get('walk') or {}).get('ok')), len(br), sum(1 for x in br.values() if not (x.get('walk') or {}).get('ok')), ', '.join(sorted(k for k, x in br.items() if not (x.get('walk') or {}).get('ok')))))
        D2 = json.load(open(OUT + 'day2/diag/diag.json')); BR = json.load(open(BASE + 'layout_dump.json'))['rbridges']
        bx = {x['name']: x['out']['rows'] for x in D2 if x['name'].startswith('bx_')}; lat = {x['name']: x['out'] for x in D2 if x['name'].startswith('lat_')}
        L += ['', '| bridge | len x wid | flat deck (y 0.72) | banks above deck | steepest end slope | sideways pushes through the parapet | walker A to B / B to A |', '|---|---|---|---|---|---|---|']
        for i, b in enumerate(BR, 1):
            rows = bx.get('bx_bridge%02d' % i)
            if not rows: continue
            g0 = [(r['al'], r['g'][2]) for r in rows]; deck = [a for a, g in g0 if abs(g - 0.72) < 0.02]; dl = (min(deck), max(deck)) if deck else (0, 0)
            ms = max(abs(g0[k + 1][1] - g0[k][1]) for k in range(len(g0) - 1)); bank = max([g for a, g in g0 if abs(a) >= b['len'] / 2 + 4] or [0])
            lw = lat.get('lat_bridge%02d' % i) or []; thr = sum(1 for r in lw if r['lat'] > 3.5)
            ab = (br.get('bridge%02d_AtoB') or {}) if False else br.get('bridge%02d_AtoB' % i, {}); ba = br.get('bridge%02d_BtoA' % i, {})
            f = lambda x: 'ok' if (x.get('walk') or {}).get('ok') else 'STUCK'
            L.append('| %d | %d x %.1f | %.0f m | %.1f m | %.2f m/m | %d of %d | %s / %s |' % (i, b['len'], b['wid'], dl[1] - dl[0], bank, ms, thr, len(lw), f(ab), f(ba)))
        L += ['', 'Reading: the four STUCK bridges (6, 8, 12, 13) are exactly the ones whose deck ends meet a bank steeper than about 1.5 m per metre; the hero can drop onto the deck but not climb off the far end. No bridge has side collision. Raw data: `diag.json` files in `qa1_tools.tar.gz`.']
    except Exception as e:
        L.append('- (diag data not available: %s)' % e)
    return L

# ---------------------------------------------------------------- sheets
def thumb(path, w, h):
    try: return Image.open(path).convert('RGB').resize((w, h), Image.LANCZOS)
    except Exception: im = Image.new('RGB', (w, h), (30, 30, 30)); return im
def sheets():
    os.makedirs(BASE + 'sheets', exist_ok=True); f = ImageFont.load_default()
    for s in S:                                                                                        # one sheet per station: rows = hours, columns = strategic / third / first, FULL size 844x390 per tile
        tags = [t for t in HOURS if any(os.path.exists(frame_path(s['id'], s['key'], c, t)) for c in CAMS)]
        if not tags: continue
        im = Image.new('RGB', (844 * 3, 390 * len(tags)), (0, 0, 0)); d = ImageDraw.Draw(im)
        for r, t in enumerate(tags):
            for c, cam in enumerate(CAMS):
                p = frame_path(s['id'], s['key'], cam, t)
                if os.path.exists(p): im.paste(Image.open(p).convert('RGB'), (c * 844, r * 390))
                d.text((c * 844 + 6, r * 390 + 4), '%s %s %s %s' % (s['id'], s['key'], cam, t), fill=(255, 255, 0), font=f)
        im.save(BASE + 'sheets/%s_%s.jpg' % (s['id'], s['key']), quality=86)
    for t in HOURS:                                                                                      # 12 stations per contact sheet: a row per station, three thumbnails (strategic / third / first)
        have = [s for s in S if any(os.path.exists(frame_path(s['id'], s['key'], c, t)) for c in CAMS)]
        for k in range(0, len(have), 12):
            grp = have[k:k + 12]; tw, th = 422, 195; im = Image.new('RGB', (tw * 3, th * len(grp)), (0, 0, 0)); d = ImageDraw.Draw(im)
            for r, s in enumerate(grp):
                for c, cam in enumerate(CAMS):
                    im.paste(thumb(frame_path(s['id'], s['key'], cam, t), tw, th), (c * tw, r * th)); d.text((c * tw + 4, r * th + 3), '%s %s %s' % (s['id'], s['key'], cam), fill=(255, 255, 0), font=f)
            im.save(BASE + 'sheets/contact_%s_%02d.jpg' % (t, k // 12 + 1), quality=84)
    print('sheets done', len(glob.glob(BASE + 'sheets/*.jpg')))
if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'report'
    if cmd == 'report': report()
    elif cmd == 'sheets': sheets()
    else: report(); sheets()
