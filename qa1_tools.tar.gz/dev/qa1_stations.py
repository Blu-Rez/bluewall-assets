#!/usr/bin/env python3
# qa1_stations.py (QA1, read-only): builds work/qa1/stations.json from work/qa1/layout_dump.json (made by qa1_layout_dump.js from the game's own layout / roads / storeyards modules).
# One station = {id, key, name, group, x, z, lx, lz} : the spot the hero is put on (snapped to the nearest free dry ground in the page) and the point she looks at.
import json, math, os
BASE = '/home/claude/work/qa1/'
d = json.load(open(BASE + 'layout_dump.json'))
S = []
def add(key, name, group, x, z, lx, lz, **kw):
    S.append(dict(id='S%02d' % (len(S) + 1), key=key, name=name, group=group, x=round(x, 1), z=round(z, 1), lx=round(lx, 1), lz=round(lz, 1), **kw))
def toward(x, z, tx, tz, k):                      # point k metres from (x,z) towards (tx,tz)
    l = math.hypot(tx - x, tz - z) or 1; return x + (tx - x) / l * k, z + (tz - z) / l * k
G = d['gate']; n = (G['nx'], G['nz'])
add('gate_out', 'Castle gate from outside (the approach)', 'castle', G['x'] + n[0] * 16, G['z'] + n[1] * 16, G['x'], G['z'])
add('gate_in', 'Inside the gate, looking into the town', 'castle', G['x'] - n[0] * 10, G['z'] - n[1] * 10, G['x'] - n[0] * 40, G['z'] - n[1] * 40)
P = d['plaza']; add('plaza', 'Plaza', 'castle', P['x'] + 7, P['z'] + 3, P['x'], P['z'])
K = d['keep']; px, pz = toward(K['x'], K['z'], P['x'], P['z'], 17); add('keep_entry', 'Keep entrance', 'castle', px, pz, K['x'], K['z'])
add('wall_outer', 'Outer wall, outside, from 6 m', 'castle', -999, -999, 0, 0, wall=dict(k=0, side=1, d=6))          # x,z filled in the page from rp.wallSpot()
add('wall_inner', 'Same wall piece from the town side (wall walk is climb-OFF: ramps / stairs belong to RP1C)', 'castle', -999, -999, 0, 0, wall=dict(k=0, side=-1, d=6))
for q in d['quarter']:                              # the nine storages: stand 11 m in front of the door (local +z), look at the yard
    dx, dz = math.sin(q['ry']), math.cos(q['ry'])
    add('storage_' + q['id'], 'Storage %s (%s)' % (q['id'], q['kind']), 'treasury', q['x'] + dx * 11, q['z'] + dz * 11, q['x'], q['z'])
add('vault_row', 'Vault row seen from the south (ruby | gold | emerald, turquoise behind)', 'treasury', -12, 132, -12, 100)
R = {r['name']: r for r in d['roads']}
for nm, label in (('main', 'main dirt road, east end'), ('west', 'west road end'), ('farm', 'farm road end (north)')):
    r = R[nm]; ax, az, bx, bz = r['a'][0], r['a'][1], r['b'][0], r['b'][1]; dx, dz = bx - ax, bz - az; l = math.hypot(dx, dz) or 1; dx, dz = dx / l, dz / l
    add('road_' + nm, 'Road end: ' + label, 'roads', bx - dx * 10, bz - dz * 10, bx + dx * 30, bz + dz * 30)
for i, f in enumerate(d['farms']):
    add('field%d' % (i + 1), 'Field %d (farm)' % (i + 1), 'fields', f['x'] - 36, f['z'], f['x'], f['z'])
W = d['windmill']; add('windmill', 'Windmill', 'mills', W['x'] - 15, W['z'], W['x'], W['z'])
site = {s['id']: s for s in d['sites']}
add('watermill', 'Water mill 1 (end of its road)', 'mills', -103.3 - 10, -182.8, -103.3, -182.8)
for sid, label in (('lumber1', 'Lumber camp 1'), ('quarry', 'Quarry')):
    s = site[sid]; add('ws_' + sid, 'Worksite: ' + label, 'worksites', s['x'] - 14, s['z'], s['x'], s['z'])
# river bank: the river point nearest to the town; stand 9 m off on the town side
rv = d['river']; best = min(rv, key=lambda p: math.hypot(p[0], p[1])); bx, bz = toward(best[0], best[1], 0, 0, 12); add('river_bank', 'River bank nearest to the town', 'river', bx, bz, best[0], best[1])
for i, b in enumerate(d['rbridges']):
    sx, sz = b['x'] + b['nx'] * (b['len'] / 2 + 9), b['z'] + b['nz'] * (b['len'] / 2 + 9)
    add('bridge%02d' % (i + 1), 'Bridge %d (%d m x %.1f m)' % (i + 1, b['len'], b['wid']), 'bridges', sx, sz, b['x'], b['z'])
for nm, ang in (('E', 0), ('S', 90), ('W', 180), ('N', 270)):
    a = math.radians(ang); r = 410
    add('edge_' + nm, 'Map edge %s (the soft edge at 410 m, looking out)' % nm, 'edges', math.cos(a) * r, math.sin(a) * r, math.cos(a) * (r + 80), math.sin(a) * (r + 80))
add('stairs', 'Stair / ramp / steps (found in the page by name; fallback = the raised bridge approach)', 'access', -999, -999, 0, 0, find='step|stair|ramp')
add('house_yard', 'A house yard (nearest cottage disc 40-90 m from the plaza)', 'town', -999, -999, 0, 0, house=True)
CORE = ['gate_out', 'gate_in', 'plaza', 'keep_entry', 'wall_outer'] + ['storage_' + k for k in ('wood', 'stone', 'iron', 'gold', 'oil', 'food', 'ruby', 'emerald', 'turq')] + ['vault_row', 'road_main', 'road_west', 'road_farm', 'field1', 'windmill', 'river_bank', 'house_yard', 'stairs', 'bridge01']
assert len(CORE) == 24 and all(any(q['key'] == k for q in S) for k in CORE)
S = [q for k in CORE for q in S if q['key'] == k] + [q for q in S if q['key'] not in CORE]            # the first 24 = the mother's 24 (one of each kind of place); the rest = every other bridge / edge / mill / worksite
for i, q in enumerate(S): q['id'] = 'S%02d' % (i + 1); q['core'] = i < 24
json.dump(S, open(BASE + 'stations.json', 'w'), indent=1)
print(len(S), 'stations ->', BASE + 'stations.json'); print(', '.join(s['id'] + ':' + s['key'] for s in S))
