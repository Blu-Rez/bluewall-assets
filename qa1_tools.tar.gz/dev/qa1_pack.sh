#!/bin/bash
# qa1_pack.sh — package everything QA1 has so far (defect list, all frames as JPEG, sheets, tools) and push it to inbox/QA1.  Each push REPLACES the branch, so every push carries the whole set.
set -e
B=/home/claude/work/qa1; P=$B/push; rm -rf $P; mkdir -p $P/out
cd /home/claude && python3 dev/qa1_analyze.py report | tail -1 && python3 dev/qa1_analyze.py sheets | tail -1
mkdir -p $B/out/diag/frames; for f in $B/out/day/diag/*.png; do cp -f $f $B/out/diag/frames/d1_$(basename $f); done; for f in $B/out/day2/diag/*.png; do cp -f $f $B/out/diag/frames/d2_$(basename $f); done 2>/dev/null || true
python3 - <<'PY'
import glob, os
from PIL import Image
B='/home/claude/work/qa1/'; P=B+'push/'
n=0
for f in glob.glob(B+'out/*/frames/*.png'):
    rel=os.path.relpath(f,B)[:-4]+'.jpg'; d=P+os.path.dirname(rel); os.makedirs(d,exist_ok=True)
    Image.open(f).convert('RGB').save(P+rel,quality=84); n+=1
print(n,'frames as jpg')
PY
sed 's#\.png`#.jpg`#g' $B/QA1_defects.md > $P/QA1_defects.md
cd $P && tar czf qa1_frames.tar.gz out && rm -rf out
cd $B && tar czf $P/qa1_sheets.tar.gz sheets
cd /home/claude && tar czf $P/qa1_tools.tar.gz dev/qa1_walk.py dev/qa1_page.js dev/qa1_stations.py dev/qa1_analyze.py dev/qa1_layout_dump.js dev/qa1_pack.sh work/qa1/manual_defects.json work/qa1/stations_resolved.json work/qa1/diag.json work/qa1/diag2.json work/qa1/diag3.json work/qa1/out/day/diag/diag.json work/qa1/out/day/diag/reach.json work/qa1/out/day2/diag/diag.json $(ls work/qa1/out/day3/diag/diag.json 2>/dev/null)
cp $B/stations_resolved.json $P/ 2>/dev/null || true
ls -la $P
bash /home/claude/bot/bluebot_v2/workers/push_result.sh QA1 $P/QA1_defects.md $P/qa1_frames.tar.gz $P/qa1_sheets.tar.gz $P/qa1_tools.tar.gz 2>&1 | tail -3
