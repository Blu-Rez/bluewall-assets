// layout_sync.js — TR2-S5: where the player's layout lives.  Online it is the server's (docs/layout_api.md: GET / POST /api/layout, the same Bearer token as every other call); without a session
// (dev pages, offline) it is this browser's localStorage.  A save that fails is kept and tried again (the layout never gets lost to a bad connection).
const KEY = 'bw_layout_v1';
const lsGet = () => { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { return null; } };
const lsPut = (v) => { try { if (v) localStorage.setItem(KEY, JSON.stringify(v)); else localStorage.removeItem(KEY); } catch (e) { /* private mode */ } };
function fetchT(url, opt = {}, ms = 15000) {
  if (typeof AbortController === 'undefined') return fetch(url, opt);
  const ac = new AbortController(), tm = setTimeout(() => ac.abort(), ms);
  return fetch(url, { ...opt, signal: ac.signal }).finally(() => clearTimeout(tm));
}
export function createLayoutSync(econ, { onServer = null } = {}) {
  let pending = null, retry = 0, tries = 0;
  const online = () => !!(econ && econ.token);
  const hdr = () => ({ Authorization: 'Bearer ' + econ.token, 'Content-Type': 'application/json' });
  async function load() {                                            // -> the record ({ v, g, m }) or null (= the default layout)
    if (!online()) return lsGet();
    try {
      const r = await fetchT('/api/layout', { headers: hdr(), cache: 'no-store' }, 10000), j = await r.json();
      if (j && j.ok) return j.layout || null;
    } catch (e) { console.warn('layout load', e); }
    return lsGet();                                                  // (the server could not be asked: the last copy this browser saw)
  }
  async function flush() {
    const rec = pending; if (!rec && rec !== false) return; clearTimeout(retry);
    if (!online()) { lsPut(rec && Object.keys(rec.m).length ? rec : null); pending = null; return { ok: true, local: true }; }
    try {
      const r = await fetchT('/api/layout', { method: 'POST', headers: hdr(), body: JSON.stringify({ layout: rec }) }), j = await r.json();
      if (j && j.ok) { if (pending === rec) pending = null; tries = 0; lsPut(j.layout && Object.keys(j.layout.m).length ? j.layout : null); if (onServer) onServer(j); return j; }
      if (j && j.why === 'rate') { lsPut(rec); if (++tries < 6) retry = setTimeout(flush, 4000 * tries); return { ok: false, why: 'rate' }; }      // (too many saves: kept in this browser, tried again later)
      if (j && j.why && j.why !== 'bad') { pending = null; if (onServer) onServer(j); return j; }        // (the server judged it: nothing to retry; 'rate' = too many saves, try again later)
    } catch (e) { console.warn('layout save', e); }
    lsPut(rec); if (++tries < 6) retry = setTimeout(flush, 4000 * tries);        // (kept in this browser, tried again)
    return { ok: false, why: 'net' };
  }
  const save = (rec) => { pending = rec || false; return flush(); };
  return { load, save, flush, get pending() { return !!pending; } };
}
