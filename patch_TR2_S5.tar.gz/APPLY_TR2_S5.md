# APPLY — patch_TR2_S5.tar.gz (for the mother)   ·   merge LAST (after RP1C_R3), as the order in ROUND3_JOBS says
Base: kit **p53 + the gate tree of 15 Oct 10:15** (the `base_snapshot` the diff is made against: no `// TR2-S5:` marker in it).  Extract at the repo root (`tar xzf patch_TR2_S5.tar.gz` → `bluewall/…`, `workers/dev/…`, `workers/docs/…`, `patch.diff`).  Either copy the full files or `cd <kit root> && patch -p1 < patch.diff`.
**Read the three conflict candidates first** (other chats own those files): `stores.js` (ST1), `town_plan.js` / `b1_layout.js` (B1 / TR2 town), `world.js` + `main.js` + `wslife.js` + `battle.js` (shared hooks, small).

| file | change | lines |
|---|---|---|
| `client/src/layout_store.js` | NEW — the player's layout = overrides only `{v, g, m:{id:[x,z,ry]}}`, ≤ 8 KB, `quant()`; pure data | 50 |
| `client/src/layout_rules.js` | NEW — `checkPose` (12 rules), `records()`, `checkMove`, `checkSwap`, `invalidIds`, `genKeep`, `geomForServer` | 187 |
| `client/src/layout_live.js` | NEW — commit / swap / undo / reset / load / enterBattle: the staged (one slice a frame) re-plan of everything that stands on the map | 135 |
| `client/src/layout_ui.js` | NEW — the editor (Arrange button, pick, drag, turn 15°, ✓ / ✕, undo, swap, green spots, ghost, release-magnet 2 m); 3D bits built on first open | 254 |
| `client/src/layout_sync.js` | NEW — GET / POST `/api/layout` (or localStorage offline), retry | 37 |
| `client/src/town_plan.js` | `townPlan0()` = the planner's default (untouched), `townPlan()` = default + overrides (cache by `LS.rev()`), `planId`, `isMovableLot`, `planLots0`, keys on battle specs | +20 −6 |
| `client/src/stores.js` | `planStoresDefault()` / `planStores()` (applied); `buildStores` draws the six into their OWN group (one Batcher) in slices (`rebuildSteps()` one per moved store + one merge, cached by pose); torches / pools move in place | +55 −10 |
| `client/src/b1_layout.js` | the six store records come from `planStoresDefault()` (the planner stays on the default plan) | +2 −2 |
| `client/src/town.js` | `planStoresDefault as planStores` (the generic fill houses keep off the DEFAULT store grounds) | +1 −1 |
| `client/src/town_build.js` | `retargetTown()` (battle blocks re-made from the lots' new places, same ids by block key), `ctx.townSlots`, the rebake signature includes the moved lots + stores, `genKeep` (generic houses under a moved lot / store are not drawn), lot id on picks | +31 −6 |
| `client/src/world.js` | pick(b,id,lot); `planLots0`; buildStores with scene; `get targets()` hides switched-off blocks; `layoutParts` | +10 −6 |
| `client/src/wslife.js` | `respawn(siteIds, storeIds)` (people / carts of moved sites and of sites that haul to a moved store) | +13 −1 |
| `client/src/main.js` | create live / sync / ui, load on `econ` load, tick + update in the loop (**11 lines**, limit 60) | +11 |
| `client/src/battle.js` | `enterBattle(target.layout)` / `settled()` at the start of the build, `leaveBattle()` in `restoreWorld` (**2 lines**) | +2 |
| `workers/dev/tr2_layout_test.{sh,js}` | NEW — `TR2 LAYOUT OK` (200 random moves, planners agree, invalid refused, swap / undo / reset, record round trip, defender's layout, battle sim, **server mock round trip**) | |
| `workers/dev/tr2_s5_{frames,frames2,drag,perf}.py` | NEW — the browser proofs (frames, real pointer events, kit-vs-mine draw calls) | |
| `workers/dev/tr2_s5_vectors.{js,sh}`, `tr2_s5_server_model.js` | NEW — regenerate the server data; the server's logic + endpoint mock in JS | |
| `workers/docs/layout_api.md`, `tr2_s5_geom.json`, `tr2_s5_vectors.json`, `tr2_s5_fuzz.json`, `tr2_s5_ref_rules.py` | NEW — the server spec (also pushed alone as `TR2_S5_server`) | |

Not touched: `web/app/*`, `pkg/`, `dev/gate*.sh`, server `*.py`, `terrain.js`, `roads.js`, the hero files, the army modules. **Rebuild the release bundle** so `web/app/wall.js` carries the code.

## Merge notes
1. **ST1 (stores / vaults) merges first and rewrites `stores.js`.**  Keep ST1's looks and re-apply only the contract below on top: `planStoresDefault()` (what the planner finds) + `planStores()` (default + `LS.ovr('store_<id>')`, cached by `LS.rev()`, entries get `moved: true`), `buildStores(ctx, {M, height, scene, onMeshes})` returning `{list, setFill, meshes, rebuild(), rebuildSteps()}` where the six halls are drawn into **their own Batcher group** (so they can move) from `planStores()`, torches / glow pools moved in place, `list` = `[{id,x,y,z,ry}]`.  If ST1 changes the hall's footprint, change `STORE_FP` in `layout_rules.js` (full rectangle + `core`) and run the test + `tr2_s5_vectors.sh` again (the default layout must stay valid: the test checks it).
2. **GR1 (roads / ground) merges before this.**  Streets are read from `townLayout().streets` and the ground from `L.height` — nothing to change, but **re-run `bash dev/tr2_s5_vectors.sh`** (new `streets` / `heights` data for the server) and `bash dev/tr2_layout_test.sh`.
3. `town_plan.js` / `b1_layout.js`: the planner still runs on the default plan only (`townPlan0()`); everything that stood on `townPlan()` now reads the applied view.  If B1 changes lot ids, `planId()` changes and old records are re-judged on load (unknown ids dropped).
4. After merging run: `bash dev/gate_w.sh` (noRoute stays 614 — the gate's battle sim uses the recorded default targets), `bash dev/tr2_layout_test.sh` → `TR2 LAYOUT OK`, `python3 workers/docs/tr2_s5_ref_rules.py` → `PORT OK` + `FUZZ OK`.
5. The server part is `TR2_S5_server` (spec only): `layout_api.md`.  Until the server has `/api/layout`, the client keeps the layout in localStorage and the editor works the same.

Rollback: remove the `layoutSync` / `layoutUI` lines in `main.js` (the «Arrange» button disappears, no layout is ever loaded = the default town); nothing else needs to change.
