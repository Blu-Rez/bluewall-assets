#!/usr/bin/env python3
"""render_views.py GLB OUTDIR [views...]  -> OUTDIR/<view>.png  (hero = 844x390 hero-camera crop, rpg.js camera)"""
import asyncio, base64, sys, os, json, subprocess, time, socket
from playwright.async_api import async_playwright
WEB = '/home/claude/work/tp1/web'
SIZES = {'front': (420, 620), 'back': (420, 620), 'side': (420, 620), 'q34': (420, 620), 'face': (420, 420), 'hands': (420, 420), 'hero': (844, 390)}
def serve(port):
    p = subprocess.Popen([sys.executable, '-m', 'http.server', str(port), '--bind', '127.0.0.1'], cwd=WEB, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(40):
        try: socket.create_connection(('127.0.0.1', port), 0.2).close(); break
        except OSError: time.sleep(0.1)
    return p
async def main(glb, outdir, views):
    os.makedirs(outdir, exist_ok=True); port = 8791 + (os.getpid() % 100); srv = serve(port)
    # expose the GLB through the served dir
    link = os.path.join(WEB, 'g_%d.glb' % port); 
    if os.path.lexists(link): os.remove(link)
    os.symlink(os.path.abspath(glb), link)
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
            pg = await b.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200])); pg.on('console', lambda m: errs.append(m.text[:200]) if m.type == 'error' else None)
            await pg.goto('http://127.0.0.1:%d/tp1_views.html?glb=/g_%d.glb' % (port, port))
            for _ in range(240):
                if await pg.evaluate('!!window.__ready'): break
                await asyncio.sleep(0.5)
            else: print('NOT READY', errs[:3]); return
            meta = await pg.evaluate('window.__meta')
            for v in views:
                w, h = SIZES[v]; d = await pg.evaluate('([n,w,h]) => window.shot(n,w,h)', [v, w, h])
                open(os.path.join(outdir, v + '.png'), 'wb').write(base64.b64decode(d.split(',')[1]))
            json.dump(meta, open(os.path.join(outdir, 'meta.json'), 'w')); print('ok', glb, 'errors', errs[:3])
            await b.close()
    finally:
        srv.terminate(); os.remove(link)
if __name__ == '__main__':
    asyncio.run(main(sys.argv[1], sys.argv[2], sys.argv[3:] or list(SIZES)))
