#!/usr/bin/env python3
"""tp1_compare.py NEW.glb [--cur CUR.glb ...] [--ref-front F.png --ref-back B.png] --out DIR
Numbered comparison sheet + metrics (tris, textures, bone-name compat vs the game rig, skin-weight sanity at shoulders / hips / skirt).
Rows = every model given (first --cur ones, then NEW). Columns = 1 front, 2 back, 3 side, 4 3/4, 5 hands, 6 face, 7 hero camera 844x390."""
import argparse, json, os, struct, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, os.path.dirname(__file__))
import glbinfo
CORE = ['Pelvis', 'Spine02', 'Head', 'L_Clavicle', 'R_Clavicle', 'L_Upperarm', 'R_Upperarm', 'L_Hand', 'R_Hand', 'L_Thigh', 'R_Thigh', 'L_Foot', 'R_Foot', 'BoneRoot', 'Hip']
MIXAMO = {'mixamorig:Hips': 'Pelvis', 'mixamorig:Spine1': 'Spine01', 'mixamorig:Spine2': 'Spine02', 'mixamorig:Head': 'Head', 'mixamorig:LeftShoulder': 'L_Clavicle', 'mixamorig:RightShoulder': 'R_Clavicle',
          'mixamorig:LeftArm': 'L_Upperarm', 'mixamorig:RightArm': 'R_Upperarm', 'mixamorig:LeftHand': 'L_Hand', 'mixamorig:RightHand': 'R_Hand', 'mixamorig:LeftUpLeg': 'L_Thigh', 'mixamorig:RightUpLeg': 'R_Thigh',
          'mixamorig:LeftFoot': 'L_Foot', 'mixamorig:RightFoot': 'R_Foot'}
CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}
def read_acc(js, binc, i):
    a = js['accessors'][i]; bv = js['bufferViews'][a['bufferView']]; dt = np.dtype(CT[a['componentType']]); n = NC[a['type']]
    stride = bv.get('byteStride') or dt.itemsize * n; off = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
    raw = np.frombuffer(binc, dtype=np.uint8, count=stride * (a['count'] - 1) + dt.itemsize * n, offset=off)
    arr = np.lib.stride_tricks.as_strided(raw, shape=(a['count'], dt.itemsize * n), strides=(stride, 1)).copy().view(dt).reshape(a['count'], n)
    if a.get('normalized'): arr = arr.astype(np.float32) / np.iinfo(dt).max
    return arr
def weights(path):
    js, binc, _ = glbinfo.load(path)
    if set(js.get('extensionsRequired', [])) & {'EXT_meshopt_compression', 'KHR_draco_mesh_compression'}: return {'skipped': 'compressed GLB (meshopt/draco): decode first'}
    sk = js.get('skins') or []
    if not sk: return {'skipped': 'no skin'}
    names = [js['nodes'][j].get('name', str(j)) for j in sk[0]['joints']]
    P, J, W = [], [], []
    for m in js['meshes']:
        for pr in m['primitives']:
            at = pr['attributes']
            if 'JOINTS_0' not in at: continue
            P.append(read_acc(js, binc, at['POSITION']).astype(np.float32)); J.append(read_acc(js, binc, at['JOINTS_0']).astype(np.int64)); W.append(read_acc(js, binc, at['WEIGHTS_0']).astype(np.float32))
    if not P: return {'skipped': 'no JOINTS_0'}
    P, J, W = np.concatenate(P), np.concatenate(J), np.concatenate(W)
    s = W.sum(1); y0, y1 = P[:, 1].min(), P[:, 1].max(); h = (P[:, 1] - y0) / (y1 - y0 + 1e-9)
    def has(nm_sub, v):   # per vertex: total weight on joints whose name contains any of nm_sub
        idx = [i for i, n in enumerate(names) if any(x in n for x in nm_sub)]
        return (W * np.isin(J, idx)).sum(1)
    sh = has(['Clavicle', 'Upperarm', 'UpperarmTwist'], 0); th = has(['Thigh', 'Pelvis', 'Hip'], 0)
    out = {'verts': int(len(P)), 'weight_sum_min': float(s.min()), 'weight_sum_bad_pct': float((np.abs(s - 1) > 0.02).mean() * 100),
           'max_influences_pct_4': float(((W > 1e-4).sum(1) == 4).mean() * 100), 'unweighted_pct': float((s < 1e-3).mean() * 100)}
    # regions in normalised height: shoulders 0.72-0.86 , hips/skirt 0.40-0.58, lower skirt 0.20-0.40
    def mixed(sel, a, b):  # share of region verts whose weight is split across >=2 joints with >0.25 each
        w2 = np.sort(W[sel], axis=1)[:, ::-1]; return float(((w2[:, 1] > 0.25)).mean() * 100) if sel.sum() else None
    r1 = (h > 0.72) & (h < 0.86); r2 = (h > 0.40) & (h < 0.58); r3 = (h > 0.20) & (h < 0.40)
    out['shoulder_band'] = {'verts': int(r1.sum()), 'split_2joints_pct': mixed(r1, 0, 0), 'arm_weight_mean': float(sh[r1].mean()) if r1.sum() else None}
    out['hip_band'] = {'verts': int(r2.sum()), 'split_2joints_pct': mixed(r2, 0, 0), 'leg_weight_mean': float(th[r2].mean()) if r2.sum() else None}
    out['skirt_band'] = {'verts': int(r3.sum()), 'split_2joints_pct': mixed(r3, 0, 0)}
    return out
def compat(names, cur_names):
    s = set(names); c = set(cur_names)
    if any(n.startswith('mixamorig') for n in names): kind = 'mixamo names (needs a name map)'
    elif all(k in s for k in CORE[:13]): kind = '1:1 with the game rig (core bones present)'
    else: kind = 'other'
    return {'kind': kind, 'joints': len(names), 'missing_vs_game': sorted(c - s)[:60], 'extra_vs_game': sorted(s - c)[:60],
            'missing_core': [k for k in CORE if k not in s]}
def label(sheet, x, y, w, text, n=None):
    d = ImageDraw.Draw(sheet); d.rectangle((x, y, x + w, y + 20), fill='#10151f'); d.text((x + 4, y + 4), text, fill='#ffffff')
    if n is not None: d.ellipse((x + 4, y + 24, x + 30, y + 50), fill='#ffd23f', outline='black'); d.text((x + 13 if n < 10 else x + 9, y + 31), str(n), fill='black')
def main():
    ap = argparse.ArgumentParser(); ap.add_argument('new'); ap.add_argument('--cur', action='append', default=[]); ap.add_argument('--out', required=True)
    ap.add_argument('--ref-front'); ap.add_argument('--ref-back'); a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    models = [(os.path.basename(p), p, True) for p in a.cur] + [(os.path.basename(a.new) + ' (NEW)', a.new, False)]
    cur_names = glbinfo.info(a.cur[0])['joint_names'] if a.cur else []
    rep = {}; rows = []
    for i, (nm, p, iscur) in enumerate(models):
        d = os.path.join(a.out, 'views_%d' % i); subprocess.run([sys.executable, os.path.join(os.path.dirname(__file__), 'render_views.py'), p, d], check=True, stdout=subprocess.DEVNULL)
        info = glbinfo.info(p); rep[nm] = {'stats': {k: v for k, v in info.items() if k not in ('joint_names', 'clip_names', 'file')}, 'clip_names': info['clip_names'],
                                           'bones': compat(info['joint_names'], cur_names) if cur_names else {'joints': info['joint_names']}, 'skin_weights': weights(p)}
        rows.append((nm, d))
    cols = ['front', 'back', 'side', 'q34', 'hands', 'face', 'hero']; W = {'front': 210, 'back': 210, 'side': 210, 'q34': 210, 'hands': 210, 'face': 210, 'hero': 422}; Hh = 310
    sw = sum(W.values()) + 4 * 2; extra = 1 if (a.ref_front or a.ref_back) else 0
    sheet = Image.new('RGB', (sw, (len(rows) + extra) * (Hh + 22)), '#222'); y = 0
    for nm, d in rows:
        x = 0
        for n, c in enumerate(cols, 1):
            im = Image.open(os.path.join(d, c + '.png')).convert('RGB'); w = W[c]; im = im.resize((w, int(im.height * w / im.width)))
            if im.height > Hh: im = im.crop((0, (im.height - Hh) // 2, w, (im.height - Hh) // 2 + Hh))
            sheet.paste(im, (x, y + 22)); label(sheet, x, y, w, ('%d %s' % (n, c)) + ('   ' + nm if n == 1 else ''), n); x += w
        y += Hh + 22
    if extra:
        x = 0
        for ref, tag in ((a.ref_front, 'ref front'), (a.ref_back, 'ref back')):
            if ref:
                im = Image.open(ref).convert('RGB'); im = im.resize((int(im.width * Hh / im.height), Hh)); sheet.paste(im, (x, y + 22)); label(sheet, x, y, im.width, tag); x += im.width
    sheet.save(os.path.join(a.out, 'TP1_sheet.png')); json.dump(rep, open(os.path.join(a.out, 'TP1_metrics.json'), 'w'), indent=1)
    for nm, r in rep.items():
        s = r['stats']; print(nm, '| tris', s['tris'], '| tex', s['textures'], '| mat', s['materials'], '| joints', s['joints'], '| clips', s['clips'], '| MB', s['MB'])
        b = r['bones']; print('   bones:', b.get('kind', ''), '| missing core', b.get('missing_core'), '| skin', {k: v for k, v in r['skin_weights'].items() if k in ('weight_sum_bad_pct', 'skipped')})
if __name__ == '__main__': main()
