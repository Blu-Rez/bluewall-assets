#!/usr/bin/env python3
"""Pure-python GLB stats: tris, materials, textures (px), skins/joints/bone names, clips, weights sanity."""
import json, struct, sys
def load(p):
    b = open(p, 'rb').read()
    assert b[:4] == b'glTF', 'not a glb'
    off = 12; js = None; binc = b''
    while off < len(b):
        ln, tp = struct.unpack_from('<II', b, off); d = b[off+8:off+8+ln]
        if tp == 0x4E4F534A: js = json.loads(d)
        elif tp == 0x004E4942: binc = d
        off += 8 + ln
    return js, binc, len(b)
def img_size(js, binc, i):
    im = js['images'][i]
    if 'bufferView' not in im: return None
    bv = js['bufferViews'][im['bufferView']]; d = binc[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']]
    if d[:8] == b'\x89PNG\r\n\x1a\n': return struct.unpack('>II', d[16:24]) + ('png',)
    if d[:4] == b'RIFF' and d[8:12] == b'WEBP':
        if d[12:16] == b'VP8 ': w,h = struct.unpack('<HH', d[26:30]); return (w&0x3fff, h&0x3fff, 'webp')
        if d[12:16] == b'VP8L': v = struct.unpack('<I', d[21:25])[0]; return ((v&0x3fff)+1, ((v>>14)&0x3fff)+1, 'webp')
        if d[12:16] == b'VP8X': return (int.from_bytes(d[24:27],'little')+1, int.from_bytes(d[27:30],'little')+1, 'webp')
    i2 = 2
    if d[:2] == b'\xff\xd8':
        while i2 < len(d):
            if d[i2] != 0xFF: i2 += 1; continue
            m = d[i2+1]
            if m in (0xC0,0xC1,0xC2): h,w = struct.unpack('>HH', d[i2+5:i2+9]); return (w,h,'jpg')
            i2 += 2 + struct.unpack('>H', d[i2+2:i2+4])[0]
    return (0,0,'?')
def info(p):
    js, binc, size = load(p); acc = js['accessors']; tris = 0; verts = 0
    for m in js.get('meshes', []):
        for pr in m['primitives']:
            if pr.get('mode', 4) != 4: continue
            tris += (acc[pr['indices']]['count'] if 'indices' in pr else acc[pr['attributes']['POSITION']]['count']) // 3
            verts += acc[pr['attributes']['POSITION']]['count']
    nodes = js['nodes']; sk = js.get('skins', [])
    joints = [nodes[j].get('name', str(j)) for j in sk[0]['joints']] if sk else []
    clips = [a.get('name') for a in js.get('animations', [])]
    imgs = [img_size(js, binc, i) for i in range(len(js.get('images', [])))]
    mats = js.get('materials', [])
    return dict(file=p, MB=round(size/1e6,2), tris=tris, verts=verts, materials=len(mats),
                alpha=[m.get('alphaMode','OPAQUE') for m in mats], textures=imgs, skins=len(sk),
                joints=len(joints), joint_names=joints, clips=len(clips), clip_names=clips,
                ext=js.get('extensionsUsed', []))
if __name__ == '__main__':
    for p in sys.argv[1:]:
        d = info(p); print(json.dumps({k: v for k, v in d.items() if k not in ('joint_names','clip_names')}))
        print('  joints:', ' '.join(d['joint_names'])); print('  clips :', ' '.join(map(str, d['clip_names'])))
