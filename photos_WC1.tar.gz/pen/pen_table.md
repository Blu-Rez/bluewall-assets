| class | carried: worst cm (clip) | samples >1 cm of 1087 | worst per item (cm) | scabbard worst cm | in hand: worst cm |
|---|---|---|---|---|---|
| short sword (hip) | 7.3 (punch_b) | 318 | 0:7.3 | 5.8 | 7.2 |
| big sword (back) | 3.3 (cast) | 121 | 0:3.3 | 0.0 | 8.6 |
| dagger pair (both hips) | 4.9 (cast) | 66 | 0:4.2, 1:4.9 | 2.9 | 8.0 |
| bow (back) + quiver (hip) | 4.3 (kick_a) | 1058 | 0:2.5, 1:4.3 | 0.0 | 11.9 |
| staff (hand) | — (never carried) | — | — | — | 11.6 (cry) |
| spear (back) | 2.8 (cast) | 21 | 0:2.8 | 0.0 | 11.1 |
| hammer (back) | 1.6 (jump) | 22 | 0:1.6 | 0.0 | 9.9 |
