dev/ -> workers/dev/ of the kit; owned/ -> bluewall/ (docs/...); csv/ -> information only
