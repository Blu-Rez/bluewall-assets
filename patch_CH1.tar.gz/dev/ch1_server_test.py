#!/usr/bin/env python3
"""CH1 server test: bluewall/chat.py (+ chat_defaults.json) and the 2-line server.py diff, on a MERGED COPY of the kit (nothing in the kit tree is touched).
   python3 dev/ch1_server_test.py            last line:  CH1 SERVER OK
 1 merge      the diff applies to the kit's server.py, the merged package imports, the routes exist
 2 config     chat_defaults.json passes validate(); bad edits are named; sane() clamps nonsense; liveops register / get / flag (3-line stub)
 3 text       links, @names, phone numbers cut · hidden links refused · 140 limit · zero-width / zalgo / bidi · banned words fa + en (spaced, leet, repeated)
 4 rate       1 message / 2 s, 15 / min, the same text inside 30 s dropped, level gate of the global room, quick-chat
 5 channels   global / clan / dm: who may read and write, canonical names, friends only (config), unread counters, read pointers
 6 block      a blocked player's messages never reach the blocker (global, clan, DM, unread) - both directions; the sender still sees their own
 7 report     N reports from N different players -> automatic mute (same reporter twice = once, self, gone, level, rate), strikes, owner mute, owner immune
 8 buffers    sizes 300 / 200 / 100 and the 48 h / 7 d / 14 d retention, ids stay increasing, reset flag, memory stays bounded, concurrent writers
 9 redis      the same scenarios on a REAL redis-server (memory and Redis must agree), Redis down = StateUnavailable (503 busy)
10 two        two (three) real accounts over HTTP through the real server app: auth, level gate, global, clan (real Clans), DM (invite friends), report, mute
"""
import asyncio, hashlib, hmac, importlib, importlib.util, json, os, random, shutil, subprocess, sys, tempfile, time, types, urllib.parse
os.environ["BLUEWALL_STATE"] = "memory"
KIT = os.environ.get("CH1_KIT", "/home/claude/bot/bluebot_v2/bluewall")
HERE = os.path.dirname(os.path.abspath(__file__))
STUB = next(p for p in (os.path.join(HERE, "stubcfg"), "/home/claude/dev/stubcfg") if os.path.isdir(p))
NEW = next((p for p in (os.environ.get("CH1_NEW"), os.path.join(HERE, "..", "server_patch", "NEW"), os.path.join(HERE, "server_patch", "NEW"), "/home/claude/work/ch1/server_patch/NEW") if p and os.path.isfile(os.path.join(p, "chat.py"))), None)
assert NEW, "chat.py not found (set CH1_NEW)"
DIFF = os.path.join(NEW, "..", "server.py.diff")

bad = 0
import logging
logging.getLogger("bluewall.chat").setLevel(logging.ERROR)                  # (the owner-mute / auto-mute warnings are expected here)


def ck(ok, name, extra=""):
    global bad
    bad += 0 if ok else 1
    print(("ok   " if ok else "FAIL ") + name + (("   " + str(extra)[:300]) if extra and not ok else ""))


# ====================================================================== 1 merge
TMP = tempfile.mkdtemp(prefix="ch1_merged_")
PKG = os.path.join(TMP, "bluewall")
os.makedirs(PKG)
for f in os.listdir(KIT):
    if f.endswith((".py", ".json")) or f == "BUILD":
        shutil.copy(os.path.join(KIT, f), PKG)
shutil.copy(os.path.join(NEW, "chat.py"), PKG)
shutil.copy(os.path.join(NEW, "chat_defaults.json"), PKG)
r = subprocess.run(["patch", "-p1", "--no-backup-if-mismatch", "-i", os.path.abspath(DIFF)], cwd=PKG, capture_output=True, text=True)
ck(r.returncode == 0, "merge: server.py.diff applies to the kit's server.py", r.stdout + r.stderr)
nmark = open(os.path.join(PKG, "server.py"), encoding="utf-8").read().count("# CH1:")
ck(nmark == 2, "merge: server.py carries exactly 2 marked CH1 lines (rule: <= 6)", nmark)
sys.path.insert(0, TMP)
sys.path.insert(0, STUB)

REG = []
LOCFG = {}                                                           # what the liveops stub answers for get("chat")  (None = the defaults)
FLAGS = {}
LO = types.SimpleNamespace(get=lambda s: LOCFG.get(s), flag=lambda n: FLAGS.get(n, True), register=lambda s, d, v: REG.append((s, d, v)))   # the 3-line liveops stub
import bluewall                                                      # noqa: E402
sys.modules["bluewall.liveops"] = LO
from bluewall import chat as CH                                      # noqa: E402
from bluewall import server as SV                                    # noqa: E402
from bluewall.state import STORE, StateUnavailable                   # noqa: E402
from bluewall import progress as PR                                  # noqa: E402

ck(CH.__file__.startswith(TMP), "merge: the merged package is the one under test")
ck(len(REG) == 1 and REG[0][0] == "chat" and REG[0][2] is CH.validate, "liveops: register('chat', defaults, validate) was called at import", REG[:1])
app0 = SV.make_app()
routes = {(r.method, r.resource.canonical) for r in app0.router.routes()}
need = {("GET", "/api/chat"), ("POST", "/api/chat/send"), ("POST", "/api/chat/report"), ("POST", "/api/chat/read"), ("POST", "/api/chat/mute"), ("GET", "/api/chat/reports")}
ck(need <= routes, "merge: the six chat routes are on the real app", need - routes)

# ====================================================================== fixtures
T = [1_700_000_000.0]
CH._now = lambda: T[0]


def tick(s):
    T[0] += s


class FakeStore:
    def __init__(self, r=None):
        self.r = r

    async def _redis(self):
        return self.r


class World:
    """profiles, friends, clans, blocks: the stand-ins for FR1 / CN1 (sync AND async flavours are exercised)"""
    def __init__(self):
        self.p, self.fr, self.bl, self.cl = {}, set(), set(), {}

    async def prof_fn(self, uid):
        return {"n": "P%d" % uid, "e": "swords", "k": self.p.get(uid, 5), "clan": 0}

    def are_friends(self, a, b):
        return (min(a, b), max(a, b)) in self.fr

    async def is_blocked(self, a, b):
        return (a, b) in self.bl                                         # (directional on purpose: Chat itself must look both ways)

    def clan_of(self, uid):
        return self.cl.get(uid, 0)

    def friend(self, a, b):
        self.fr.add((min(a, b), max(a, b)))


def mk(w, redis=None):
    c = CH.Chat()
    c.store, c.prof_fn = FakeStore(redis), w.prof_fn
    c.bind(friends=w, clans=w)
    return c


def texts(out):
    return [m["x"] for m in out.get("msgs", [])]


async def S(c, uid, text, ch="global", dt=2.1, **kw):
    """send one message, then let the clock run so the next one passes the 2-second rule"""
    o = await c.send(uid, ch, text, **kw)
    tick(dt)
    return o


# ====================================================================== 2 config
async def t_config():
    D = CH.DEFAULTS
    ck(CH.validate(D) == [], "config: chat_defaults.json passes validate()", CH.validate(D))
    ck(len(D["quick"]) == 12 and [e["id"] for e in D["quick"]] == list(range(1, 13)), "config: 12 quick-chat entries with ids 1..12")
    ck(not any("bot" in e["t"].lower() or "ربات" in e["t"] for e in D["quick"]), "config: no bot-word in quick-chat texts (game-text rule)")
    ck(len(D["banned"]) >= 50 and any("کیر" in w for w in D["banned"]) and any(w == "fuck" for w in D["banned"]), "config: banned list has Persian and English words", len(D["banned"]))
    ck(D["channels"]["global"]["min_keep"] == 3 and D["rate"] == {"gap_s": 2, "per_min": 15, "dup_s": 30} and D["max_len"] == 140, "config: defaults are the spec (level 3, 2 s / 15 per min / 30 s dup, 140)")
    ck(D["channels"]["global"]["cap"] == 300 and D["channels"]["global"]["ttl_h"] == 48 and D["channels"]["clan"]["cap"] == 200 and D["channels"]["clan"]["ttl_d"] == 7
       and D["channels"]["dm"]["cap"] == 100 and D["channels"]["dm"]["ttl_d"] == 14, "config: retention defaults 300/48h, 200/7d, 100/14d")

    def edit(path, v):
        d = json.loads(json.dumps(D))
        o = d
        for k in path[:-1]:
            o = o[k]
        if v is KeyError:
            del o[path[-1]]
        else:
            o[path[-1]] = v
        return CH.validate(d)
    ck(edit(["rate", "gap_s"], 0), "validate: gap 0 s refused")
    ck(edit(["rate", "per_min"], "15"), "validate: a string for a number refused")
    ck(edit(["max_len"], 5000), "validate: max_len 5000 refused")
    ck(edit(["channels", "global", "on"], "yes"), "validate: a non-boolean switch refused")
    ck(edit(["channels", "dm"], KeyError), "validate: a missing channel refused")
    ck(edit(["banned"], ["x" * 60]), "validate: a banned entry over 40 characters refused")
    ck(edit(["banned"], "fuck"), "validate: banned must be a list")
    ck(edit(["quick", 0, "t"], "see t.me/x"), "validate: a quick-chat text with a link refused")
    ck(edit(["quick", 1, "id"], 1), "validate: duplicate quick-chat ids refused")
    ck(edit(["quick"], []), "validate: an empty quick list refused")
    ck(CH.validate([]) and CH.validate(None), "validate: not an object refused")
    ck(edit(["rate", "gap_s"], 3) == [] and edit(["banned"], ["newword", "~sub"]) == [], "validate: a normal edit passes")
    s = CH.sane({"rate": {"per_min": -5, "gap_s": "x"}, "max_len": 1e9, "channels": {"global": {"cap": 10 ** 9, "min_keep": 0}}, "banned": "nope", "quick": [{"id": "a"}, 5]})
    ck(s["rate"]["per_min"] == 1 and s["rate"]["gap_s"] == 2.0 and s["max_len"] == 300 and s["channels"]["global"]["cap"] == CH.HARD_CAP and s["channels"]["global"]["min_keep"] == 1
       and s["banned"] == [] and s["quick"] == [], "sane(): nonsense is clamped / dropped, never raises", s["rate"])
    ck(CH.sane(None)["max_len"] == 140 and CH.sane({"x": 1})["channels"]["dm"]["friends_only"] is True, "sane(): None / unknown keys give the defaults")
    ck(CH.cfg()["max_len"] == 140, "liveops: get('chat') = None gives the defaults")
    LOCFG["chat"] = {"max_len": 100, "rate": {"gap_s": 5}}
    ck(CH.cfg()["max_len"] == 100 and CH.cfg()["rate"]["gap_s"] == 5.0 and CH.cfg()["rate"]["per_min"] == 15, "liveops: an edit applies at once and merges over the defaults")
    LOCFG.clear()
    FLAGS["chat_dm"] = False
    ck(CH.flag("chat_dm") is False and CH.flag("chat_global") is True, "liveops: flag() is read")
    FLAGS.clear()
    sys.modules.pop("bluewall.liveops")
    CH.reset_liveops_cache()
    ck(CH.cfg()["max_len"] == 140 and CH.flag("chat_global") is True, "liveops: without the module the defaults and 'on' are used")
    sys.modules["bluewall.liveops"] = LO
    CH.reset_liveops_cache()


# ====================================================================== 3 text
def t_text():
    ct = lambda s: CH.clean_text(s, 140)
    ck(ct("hello world") == ("hello world", "", False), "text: a plain message is untouched")
    ck(ct("join t.me/scamchannel now")[0] == "join now" and ct("join t.me/scamchannel now")[2], "text: t.me link cut, the rest kept, flagged")
    ck(ct("visit https://evil.com/x?y=1 ok")[0] == "visit ok", "text: https link cut")
    ck(ct("go www.evil.org please")[0] == "go please", "text: www link cut")
    ck(ct("buy at shop.example.ir/p now")[0] == "buy at now", "text: bare domain with a path cut")
    ck(ct("my id @someone yo")[0] == "my id yo" and ct("＠fullwidth name")[0] == "name", "text: @username cut (also full-width)")
    ck(ct("call 09123456789 now")[0] == "call now", "text: Iranian mobile number cut")
    ck(ct("call 0912 345 6789 now")[0] == "call now", "text: spaced number cut")
    ck(ct("tel +98 912 123 45 67 ok")[0] == "tel ok", "text: +98 number cut")
    ck(ct("۰۹۱۲۳۴۵۶۷۸۹ زنگ بزن")[0] == "زنگ بزن", "text: Persian-digit number cut")
    ck(ct("٠٩١٢٣٤٥٦٧٨٩ call")[0] == "call", "text: Arabic-digit number cut")
    ck(ct("555-1234 call")[0] == "call", "text: 7 digits with a separator cut")
    ck(ct("I have 15000000 gems and 1,000,000 ore")[0] == "I have 15000000 gems and 1,000,000 ore", "text: game numbers (8 digits / commas) are NOT cut")
    ck(ct("level 10 20 30 done")[0] == "level 10 20 30 done", "text: short number groups are NOT cut")
    ck(ct("site(dot)com")[1] == "link" and ct("t . me / foo")[1] == "link" and ct("evil [dot] ir/x")[1] == "link", "text: links written to dodge the first pass are refused")
    ck(ct("t.me/x")[1] == "empty" and ct("@abc")[1] == "empty" and ct("   ")[1] == "empty", "text: nothing left = refused (empty)")
    ck(ct("​​​")[1] == "empty" and ct("‌‌")[1] == "empty" and ct("‮﻿")[1] == "empty", "text: zero-width / bidi / BOM only = empty")
    ck(ct("ab‮cd")[0] == "abcd", "text: bidi override removed")
    ck(ct("سلام، می‌خواهم بازی کنم")[0] == "سلام، می‌خواهم بازی کنم", "text: Persian with ZWNJ is untouched")
    ck(ct("👨‍👩‍👧 hi")[0] == "👨‍👩‍👧 hi", "text: emoji with ZWJ untouched")
    z = ct("h" + "́̂̃̄̅̆̇̈" + "i")[0]
    ck(z is not None and len(z) == 4, "text: zalgo marks capped at 2 in a row", z)
    ck(ct("line1\nline2\r\nline3")[0] == "line1 line2 line3", "text: newlines become spaces")
    ck(ct("a" * 141)[0] == "aaaaa" and ct("noooooooooooooo")[0] == "nooooo", "text: runs of one character are capped at 5")
    ck(ct(("word " * 40).strip())[1] == "long" and ct(("word " * 28).strip())[0] is not None and len(("word " * 28).strip()) == 139, "text: 140 limit (139 ok, 199 refused)")
    ck(ct("x" * 600)[1] == "long" and ct("ab " * 100)[1] == "long", "text: huge input refused")
    ck(len(CH.clean_text("é" * 140 + "x" * 0, 140)[0] or "") <= 140 and CH.clean_text("a b " * 36, 140)[1] == "long", "text: limit counts after cleaning of invisibles")
    B = CH.cfg()["banned"]
    bw = lambda s: CH.bad_word(s, B)
    for s in ("fuck you", "FUCK", "f u c k", "f.u.c.k", "fuuuuck", "sh!t", "$hit", "b1tch", "motherfucker", "asshole!!", "you are a cunt", "n i g g e r"):
        ck(bw(s), "banned (en): %r" % s)
    for s in ("hello there", "classic", "assassin", "Scunthorpe", "cocktail", "dickens", "grape", "shiitake", "passion", "bass", "analysis", "I will attack at dawn", "good game"):
        ck(not bw(s), "not banned (en): %r" % s, bw(s))
    for s in ("کیر", "کیری تو", "کیرخر", "کسکش", "ک س ک ش", "مادر جنده", "مادرجنده", "پدرسگ", "حرامزاده", "سلام کون", "كير", "گوه نخور", "شرط‌بندی", "عنتر"):
        ck(bw(s), "banned (fa): %r" % s)
    for s in ("سلام دوستان خوبین", "هیچ کس نیست", "کن", "کشور", "کسی اینجاست؟", "بیا حمله کنیم", "قلعه من لول ۵ شد", "ممنون", "کلان ما قوی است", "سگ", "کیرم"):
        if s == "کیرم":
            continue
        ck(not bw(s), "not banned (fa): %r" % s, bw(s))
    t0 = time.perf_counter()
    words = CH.cfg()["banned"] + ["~w%dx" % i for i in range(2900)]
    CH.bad_word("warm up", words)
    t1 = time.perf_counter()
    for _ in range(100):
        CH.bad_word("a normal sentence about the castle and the army we are raising today", words)
    dt = (time.perf_counter() - t1) / 100
    ck(dt < 0.02, "banned: a 3000-word list costs %.2f ms per message (< 20 ms)" % (dt * 1000), dt)


# ====================================================================== 4 rate
async def t_rate(c, w, name):
    w.p[10] = 5
    ck((await c.send(10, "global", "first"))["ok"], name + "rate: 1st message ok")
    o = await c.send(10, "global", "second")
    ck(not o["ok"] and o["why"] == "rate" and 1.9 <= o["wait"] <= 2.0, name + "rate: 2nd at +0 s refused with wait ~2 s", o)
    tick(1.0)
    o = await c.send(10, "global", "third")
    ck(not o["ok"] and o["why"] == "rate" and 0.9 <= o["wait"] <= 1.0, name + "rate: at +1 s still refused (wait ~1 s)", o)
    tick(1.05)
    ck((await c.send(10, "global", "fourth"))["ok"], name + "rate: at +2.05 s ok")
    tick(2.05)
    n_ok = 2
    for i in range(30):                                                  # every 2.05 s: the per-minute cap (15) must bite
        o = await c.send(10, "global", "burst %d" % i)
        if o["ok"]:
            n_ok += 1
        else:
            break
        tick(2.05)
    ck(n_ok == 15 and not o["ok"] and o["why"] == "rate" and o["wait"] > 0, name + "rate: the 16th message inside a minute is refused (15 / min)", (n_ok, o))
    tick(o["wait"] + 0.1)
    ck((await c.send(10, "global", "after wait"))["ok"], name + "rate: it works again after the wait")
    tick(3)
    a = await c.send(10, "global", "Same Text")
    tick(3)
    b = await c.send(10, "global", "same   text")
    tick(3)
    d = await c.send(10, "global", "other text")
    ck(a["ok"] and not b["ok"] and b["why"] == "dup" and d["ok"], name + "rate: the same text again inside 30 s is dropped (case / spaces ignored)", (a, b, d))
    tick(31)
    ck((await c.send(10, "global", "SAME text"))["ok"], name + "rate: the same text after 30 s is fine")
    w.p[11] = 2
    tick(3)
    o = await c.send(11, "global", "I am new")
    ck(not o["ok"] and o["why"] == "level" and o["need"] == 3, name + "level: castle level 2 cannot write in Global (need 3)", o)
    fe = await c.fetch(11, "global")
    ck(fe["ok"] and fe["me"]["k"] == 2 and fe["me"]["need_k"] == 3, name + "level: reading Global is allowed and `me` says what is needed")
    w.friend(11, 10)
    ck((await c.send(11, "dm:10", "hi friend"))["ok"], name + "level: a level-2 player can still DM a friend")
    w.p[11] = 3
    c.forget(11)
    tick(3)
    ck((await c.send(11, "global", "now level three"))["ok"], name + "level: level 3 may write")
    # quick chat
    tick(3)
    q = await c.send(10, "global", q=5)
    ck(q["ok"] and q["msg"]["x"] == "GG!" and q["msg"]["q"] == 5, name + "quick: id 5 sends the server's own text", q)
    tick(3)
    q2 = await c.send(10, "global", q=5)
    ck(not q2["ok"] and q2["why"] == "dup", name + "quick: the same quick message twice inside 30 s is dropped")
    tick(3)
    ck((await c.send(10, "global", q=99)).get("why") == "bad" and (await c.send(10, "global", q="x")).get("why") == "bad" and (await c.send(10, "global", None)).get("why") == "bad", name + "quick: unknown id / not a number / nothing at all = bad")
    tick(3)
    ck((await c.send(10, "global", 12345)).get("why") == "bad", name + "send: a non-string text = bad")
    tick(3)
    o = await c.send(10, "global", "so t.me/abc 09121234567 @me nice")
    ck(o["ok"] and o["msg"]["x"] == "so nice" and o["cleaned"], name + "send: links / numbers cut and the answer says cleaned", o)
    tick(3)
    o = await c.send(10, "global", "fuck this")
    ck(not o["ok"] and o["why"] == "banned" and "msg" not in o, name + "send: banned word refused", o)
    tick(3)
    o = await c.send(10, "global", "t.me/x")
    ck(not o["ok"] and o["why"] == "empty", name + "send: only a link = empty", o)


# ====================================================================== 5 channels
async def t_channels(c, w, name):
    for u in (1, 2, 3, 4, 5):
        w.p[u] = 5
    w.cl = {1: 7, 2: 7, 3: 8}
    w.friend(1, 2)
    w.friend(1, 3)
    # unread of Global: the first look starts "now"
    await S(c, 4, "before anyone looked")
    u = await c.unread(5)
    ck(u["g"] == 0, name + "unread: the first visit starts from now (0 even though 1 message exists)", u)
    await S(c, 4, "one")
    await S(c, 3, "two")
    await S(c, 5, "mine")                                                # (own message: moves the pointer of 5)
    await S(c, 4, "three")
    u = await c.unread(5)
    ck(u["g"] == 1, name + "unread: only others' messages after my pointer count (my own send moved it)", u)
    f = await c.fetch(5, "global")
    ck(texts(f) == ["before anyone looked", "one", "two", "mine", "three"] and f["last"] == 5 and f["unread"]["g"] == 1, name + "fetch: newest first-load returns all 5 oldest->newest", texts(f))
    ck(f["cfg"]["max_len"] == 140 and len(f["cfg"]["quick"]) == 12 and f["cfg"]["poll"]["open_s"] == 3, name + "fetch: the first load carries cfg (max_len, 12 quick, poll)")
    f2 = await c.fetch(5, "global", after=3)
    ck(texts(f2) == ["mine", "three"] and "cfg" not in f2, name + "fetch: after=<id> returns only newer, no cfg", texts(f2))
    f3 = await c.fetch(5, "global", after=5)
    ck(f3["msgs"] == [] and f3["last"] == 5 and not f3["more"], name + "fetch: nothing new = empty list")
    r = await c.read(5, "global", 5)
    ck(r["ok"] and r["unread"]["g"] == 0, name + "read: upto=last clears the counter", r)
    ck((await c.read(5, "global", 999))["ok"] and (await c.unread(5))["g"] == 0, name + "read: upto beyond the last id is clamped")
    ck((await c.read(5, "global", "x")).get("why") == "bad" and (await c.read(5, "nope", 1)).get("why") == "bad", name + "read: junk = bad")
    for i in range(5):
        await S(c, 4 if i % 2 else 3, "page %d" % i)
    fa = await c.fetch(5, "global", after=5, n=2)
    ck(texts(fa) == ["page 0", "page 1"] and fa["more"], name + "fetch: n limits and `more` says there is more", texts(fa))
    fl = await c.fetch(5, "global", n=3)
    ck(texts(fl) == ["page 2", "page 3", "page 4"] and not fl["more"], name + "fetch: first load with n=3 = the newest 3", texts(fl))
    # message shape
    m = f["msgs"][0]
    ck(set(m) == {"i", "u", "n", "e", "k", "t", "x"} and m["u"] == 4 and m["n"] == "P4" and m["k"] == 5 and isinstance(m["t"], int), name + "message: public shape is {i,u,n,e,k,t,x} and nothing private", m)
    # clan
    o = await S(c, 1, "clan hello", "clan")
    ck(o["ok"], name + "clan: 'clan' means my clan", o)
    o = await S(c, 2, "clan reply", "clan:7")
    ck(o["ok"], name + "clan: clan:<my id> works")
    fc = await c.fetch(1, "clan")
    ck(fc["ch"] == "clan:7" and texts(fc) == ["clan hello", "clan reply"], name + "clan: the answer names the real channel", fc.get("ch"))
    ck((await c.fetch(3, "clan:7")).get("why") == "forbidden" and (await c.send(3, "clan:7", "hax")).get("why") == "forbidden", name + "clan: another clan's room is forbidden (read and write)")
    ck((await c.fetch(4, "clan")).get("why") == "no_clan" and (await c.send(4, "clan", "x")).get("why") == "no_clan" and (await c.fetch(4, "clan:7")).get("why") == "no_clan", name + "clan: no clan = no_clan")
    ck("clan hello" not in texts(await c.fetch(5, "global", n=60)), name + "clan: clan messages never appear in Global")
    ck((await c.fetch(1, "clan:abc")).get("why") in ("bad", "forbidden") and (await c.fetch(1, "clan:-3")).get("why") in ("bad", "forbidden"), name + "clan: junk ids refused")
    uc = await c.unread(2)
    ck(uc["c"] == 0, name + "clan unread: first visit starts from now", uc)
    await S(c, 1, "ping", "clan")
    ck((await c.unread(2))["c"] == 1, name + "clan unread: counts the other member's message")
    w.cl[1] = 0
    c.forget(1)
    ck((await c.fetch(1, "clan")).get("why") == "no_clan", name + "clan: after leaving the room is closed to me")
    w.cl[1] = 7
    # DM
    o = await S(c, 1, "hi 2", "dm:2")
    ck(o["ok"], name + "dm: dm:<peer> works between friends", o)
    f = await c.fetch(2, "dm:1")
    ck(f["ch"] == "dm:1:2" and f["peer"] == 1 and texts(f) == ["hi 2"], name + "dm: canonical name dm:<low>:<high>, both sides see one thread", f.get("ch"))
    f = await c.fetch(1, "dm:1:2")
    ck(f["ch"] == "dm:1:2" and f["peer"] == 2, name + "dm: the canonical form is accepted by a participant")
    ck((await c.fetch(3, "dm:1:2")).get("why") == "forbidden" and (await c.send(3, "dm:1:2", "spy")).get("why") == "forbidden", name + "dm: a third person cannot read or write a thread")
    ck((await c.send(1, "dm:1", "self")).get("why") == "forbidden" and (await c.send(1, "dm:0", "x")).get("why") in ("forbidden", "bad"), name + "dm: not to myself / peer 0")
    ck((await c.send(1, "dm:4", "stranger")).get("why") == "dm_no", name + "dm: a non-friend is refused (dm_no)")
    ck((await c.fetch(1, "dm:4")).get("why") == "dm_no", name + "dm: and cannot be read either")
    ck((await c.fetch(1, "dm:x")).get("why") == "bad" and (await c.fetch(1, "dm:1:2:3")).get("why") == "bad" and (await c.fetch(1, "weird")).get("why") == "bad", name + "dm: junk channel names = bad")
    un = await c.unread(2)
    ck(un["dm"] == 1, name + "dm unread: the friend's message counts", un)
    sm = await c.unread(2, dm_list=True)
    ck(len(sm["dmp"]) == 1 and sm["dmp"][0]["u"] == 1 and sm["dmp"][0]["un"] == 1 and sm["dmp"][0]["x"] == "hi 2" and sm["dmp"][0]["n"] == "P1", name + "dm list: peer, unread, last text and name", sm.get("dmp"))
    await c.read(2, "dm:1", 1)
    ck((await c.unread(2))["dm"] == 0, name + "dm unread: read clears")
    await S(c, 2, "pong", "dm:1")
    sm = await c.unread(1, dm_list=True)
    ck(sm["dm"] == 1 and sm["dmp"][0]["x"] == "pong", name + "dm list: the other side sees the reply as unread")
    # config switches
    LOCFG["chat"] = {"channels": {"dm": {"friends_only": False}}}
    ck((await S(c, 1, "to a stranger", "dm:4"))["ok"], name + "config: friends_only=false lets anyone DM")
    LOCFG["chat"] = {"channels": {"global": {"on": False}}}
    ck((await c.send(1, "global", "closed")).get("why") == "off" and (await c.fetch(1, "global")).get("why") == "off" and (await c.fetch(1))["me"]["on"]["global"] is False, name + "config: a channel switched off refuses read and write")
    LOCFG["chat"] = {"channels": {"global": {"min_keep": 9}}}
    ck((await c.send(1, "global", "too low")).get("why") == "level", name + "config: min_keep is read live")
    LOCFG.clear()
    FLAGS["chat_clan"] = False
    ck((await c.send(1, "clan", "x")).get("why") == "off" and (await c.fetch(1))["me"]["on"]["clan"] is False, name + "config: the liveops flag chat_clan turns the clan room off")
    FLAGS.clear()
    LOCFG["chat"] = {"banned": ["bluecheese"]}
    ck((await c.send(5, "global", "bluecheese rocks")).get("why") == "banned" and (await c.send(5, "global", "fuck"))["ok"] is True, name + "config: the banned list is the liveops one (edit applies at once)")
    LOCFG.clear()


# ====================================================================== 6 block
async def t_block(c, w, name):
    for u in (1, 2, 3):
        w.p[u] = 5
    w.cl = {1: 9, 2: 9, 3: 9}
    w.friend(1, 2)
    await S(c, 3, "seed")
    await c.unread(1)
    await S(c, 2, "from two", "global")
    await S(c, 3, "from three", "global")
    await S(c, 2, "clan from two", "clan")
    await S(c, 2, "dm from two", "dm:1")
    w.bl.add((1, 2))                                                     # 1 blocks 2
    f = await c.fetch(1, "global")
    ck("from two" not in texts(f) and "from three" in texts(f), name + "block: the blocker no longer sees the blocked player in Global", texts(f))
    ck("clan from two" not in texts(await c.fetch(1, "clan")), name + "block: ... nor in the clan room")
    ck(texts(await c.fetch(1, "dm:2")) == [], name + "block: ... nor in the DM thread")
    f2 = await c.fetch(2, "global")
    ck("from two" in texts(f2) and "from three" in texts(f2), name + "block: the blocked player still sees their own messages and the others'", texts(f2))
    ck("from two" in texts(await c.fetch(3, "global")), name + "block: a third player sees the blocked player normally")
    ck("from two" not in texts(await c.fetch(1, "global", after=0, n=60)), name + "block: also on a bigger page")
    w.bl.clear()
    w.bl.add((2, 1))                                                     # now 2 blocks 1: 1's messages must not reach 2 either (both directions)
    await S(c, 1, "from one", "global")
    ck("from one" not in texts(await c.fetch(2, "global")) and "from one" in texts(await c.fetch(3, "global")), name + "block: it works in both directions")
    w.bl.clear()
    w.bl.add((1, 2))
    await c.read(1, "global", await c.be.last_id("global"))
    await S(c, 2, "ghost", "global")
    await S(c, 2, "ghost 2", "clan")
    await S(c, 2, "ghost 3", "dm:1")
    un = await c.unread(1)
    ck(un["g"] == 0 and un["c"] == 0 and un["dm"] == 0, name + "block: the blocked player's new messages do not raise any unread counter", un)
    await S(c, 3, "visible", "global")
    ck((await c.unread(1))["g"] == 1, name + "block: unread still counts everybody else")
    w.bl.clear()
    ck("from two" in texts(await c.fetch(1, "global", n=60)), name + "block: lifting the block shows the old messages again")


# ====================================================================== 7 report / mute
async def t_report(c, w, name):
    for u in (20, 21, 22, 23, 24, 25, 26):
        w.p[u] = 5
    w.p[27] = 2
    c.is_owner = lambda u: u == 29
    w.p[29] = 5
    ids = []
    for t in ("bad one", "bad two", "bad three"):
        o = await S(c, 20, t, "global", dt=3)
        ids.append(o["msg"]["i"])
    r = await c.report(21, "global", ids[0], "abuse")
    ck(r == {"ok": True}, name + "report: first report ok", r)
    r = await c.report(21, "global", ids[0])
    ck(r["ok"] and r.get("dup"), name + "report: the same player reporting the same message again is a no-op (dup)")
    r = await c.report(21, "global", ids[1])
    ck(r["ok"] and not r.get("dup") and await c.muted_left(20) == 0, name + "report: a second message by the same reporter counts as the same reporter (still 1)")
    r = await c.report(22, "global", ids[0], "spam")
    ck(r["ok"] and await c.muted_left(20) == 0, name + "report: 2 different reporters are not enough")
    ck((await c.report(27, "global", ids[0])).get("why") == "level", name + "report: a level-2 account cannot report")
    ck((await c.report(20, "global", ids[0])).get("why") == "self", name + "report: not my own message")
    ck((await c.report(23, "global", 999999)).get("why") == "gone", name + "report: unknown message = gone")
    ck((await c.report(23, "global", "x")).get("why") == "bad" and (await c.report(23, "zzz", 1)).get("why") == "bad", name + "report: junk = bad")
    ck((await c.report(23, "clan", ids[0])).get("why") == "no_clan", name + "report: a channel I cannot see cannot be reported in")
    r = await c.report(23, "global", ids[2], "other")
    left = await c.muted_left(20)
    ck(r == {"ok": True} and 1795 <= left <= 1800, name + "report: the 3rd DIFFERENT reporter mutes the author for 30 min automatically (and the reporter is not told)", (r, left))
    o = await c.send(20, "global", "let me talk")
    ck(not o["ok"] and o["why"] == "muted" and 1790 <= o["left"] <= 1800, name + "mute: the muted author cannot send", o)
    ck((await c.send(20, "dm:21", "x")).get("why") in ("muted", "dm_no") and (await c.fetch(20, "global"))["ok"] and (await c.fetch(20))["me"]["mute"] > 0, name + "mute: reading still works and `me.mute` tells the time left")
    rl = await c.reports(10)
    ck(len(rl) == 4 and rl[0]["x"] == "bad three" and rl[0]["au"] == 20 and rl[0]["by"] == 23 and rl[-1]["why"] == "abuse", name + "report: the owner's list has the text, author, reporter (newest first)", rl[:1])
    tick(1801)
    ck(await c.muted_left(20) == 0 and (await c.send(20, "global", "back again"))["ok"], name + "mute: it ends by itself")
    o = await c.report(21, "global", ids[2])
    ck(o["ok"] and await c.muted_left(20) == 0, name + "report: after an automatic mute the counter starts again from zero")
    # strikes
    tick(3)
    for i in range(4):
        o = await S(c, 24, "fuck %d" % i, "global", dt=0.3)
        ck(o["why"] == "banned" and "muted" not in o, name + "strike %d: banned word refused, no mute yet" % (i + 1))
    o = await S(c, 24, "fuck 5", "global", dt=0.3)
    ck(o["why"] == "banned" and o.get("muted") == 600, name + "strike 5: 5 banned attempts in 10 min = automatic mute of 10 min", o)
    o = await c.send(24, "global", "a clean message")
    ck(not o["ok"] and o["why"] == "muted", name + "strike: and now even clean messages wait")
    tick(601)
    tick(3)
    ck((await c.send(24, "global", "a clean message"))["ok"], name + "strike: the mute ended")
    # owner mute
    r = await c.mute(25, 120, "spam")
    ck(r["ok"] and (await c.send(25, "global", "x")).get("why") == "muted" and 115 <= await c.muted_left(25) <= 120, name + "mute: chat.mute(uid, secs, why) by hand")
    await c.mute(25, 0)
    ck(await c.muted_left(25) == 0 and (await c.send(25, "global", "free"))["ok"], name + "mute: secs=0 lifts it")
    r = await c.mute(25, 10 ** 12)
    ck(r["left"] == 30 * 86400, name + "mute: capped at 30 days")
    await c.mute(25, 0)
    # owner is immune to automatic mutes and to word filters
    ow = (await S(c, 29, "owner speaks", "global", dt=3))["msg"]["i"]
    for rr in (21, 22, 23, 24):
        await c.report(rr, "global", ow)
    ck(await c.muted_left(29) == 0, name + "report: the owner is never muted by reports")
    ck((await c.send(29, "global", "fuck (owner)", owner=True))["ok"], name + "owner: owner=True skips the word filter")
    # reporter rate
    LOCFG["chat"] = {"report": {"max_per_10min": 2}}
    msgs = []
    for u in (20, 21, 22):
        tick(3)
        msgs.append((await c.send(u, "global", "target %d" % u))["msg"]["i"])
    r1, r2, r3 = [await c.report(26, "global", i) for i in msgs]
    ck(r1["ok"] and r2["ok"] and r3.get("why") == "rate", name + "report: a reporter is limited (max_per_10min)", (r1, r2, r3))
    tick(601)
    ck((await c.report(26, "global", msgs[2]))["ok"], name + "report: the limit is a window")
    LOCFG.clear()


# ====================================================================== 8 buffers
async def t_buffers(c, w, name, big=True):
    n_users = 60
    for u in range(100, 100 + n_users):
        w.p[u] = 5
    w.cl = {u: 3 for u in range(100, 100 + n_users)}
    N = 1000 if big else 400

    async def flood(ch, count):
        for i in range(count):
            o = await c.send(100 + (i % n_users), ch, "m%d" % i)
            assert o["ok"], o
            tick(0.5)
    await flood("global", N)
    be = c.be
    g = await c.fetch(100, "global", n=60)
    last = await be.last_id("global")
    if await be._redis_on():
        total = int((await (await be.r()).zcard(CH.K + "m:global")))
    else:
        total = len(be.ch["global"]["q"])
    ck(last == N and total == 300, name + "buffer: %d messages sent, Global keeps 300, ids run on to %d" % (N, N), (last, total))
    ck(g["msgs"][-1]["x"] == "m%d" % (N - 1) and g["msgs"][-1]["i"] == N and len(g["msgs"]) == 60, name + "buffer: the newest page is the newest messages")
    old = await c.fetch(100, "global", after=10, n=60)                    # (id 10 was trimmed long ago)
    ck(len(old["msgs"]) == 60 and old["msgs"][0]["i"] == N - 299, name + "buffer: asking after a trimmed id starts at the oldest kept message", old["msgs"][0]["i"])
    rs = await c.fetch(100, "global", after=N + 50)
    ck(rs.get("reset") is True and rs["last"] == N and len(rs["msgs"]) > 0, name + "buffer: after > last id = the channel was reset: the newest page + reset flag")
    await flood("clan", 250)
    cl = await c.fetch(100, "clan", n=60)
    tot = int(await (await be.r()).zcard(CH.K + "m:clan:3")) if await be._redis_on() else len(be.ch["clan:3"]["q"])
    ck(tot == 200 and cl["last"] == 250, name + "buffer: a clan keeps 200", (tot, cl["last"]))
    for u in range(100, 104):
        w.friend(100, u)
    for i in range(150):
        await c.send(100 + (i % 2) + 1, "dm:100", "d%d" % i)
        tick(2.1)
        if i % 2:
            await c.send(100, "dm:101", "e%d" % i)
            tick(2.1)
    dm = "dm:100:101"
    tot = int(await (await be.r()).zcard(CH.K + "m:" + dm)) if await be._redis_on() else len(be.ch[dm]["q"])
    ck(tot == 100, name + "buffer: a DM thread keeps 100", tot)
    # retention by time
    await c.send(130, "global", "last of the day")
    tick(47 * 3600)
    g = await c.fetch(100, "global", n=60)
    ck(len(g["msgs"]) > 0, name + "retention: after 47 h Global is still there")
    tick(2 * 3600)
    g = await c.fetch(100, "global", n=60)
    ck(g["msgs"] == [] and g["last"] >= N, name + "retention: after 49 h nothing older than 48 h is served (ids keep their place)", len(g["msgs"]))
    o = await c.send(131, "global", "fresh start")
    g = await c.fetch(100, "global", n=60)
    ck(o["ok"] and texts(g) == ["fresh start"] and o["msg"]["i"] > N, name + "retention: the next message trims the expired ones; ids keep rising", (texts(g)[:3], o))
    if not await be._redis_on():
        ck(len(be.ch["global"]["q"]) == 1, name + "retention: and memory really let go of them", len(be.ch["global"]["q"]))
    tick(6 * 86400 - 50 * 3600)                                           # (now about 6 d after the clan and DM floods)
    ck(texts(await c.fetch(100, "clan", n=60)) != [] and texts(await c.fetch(100, dm, n=60)) != [], name + "retention: clan (7 d) and DM (14 d) are still there after ~6 d")
    tick(2 * 86400)
    ck(texts(await c.fetch(100, "clan", n=60)) == [] and texts(await c.fetch(100, dm, n=60)) != [], name + "retention: after ~8 d the clan room is empty, the DM (14 d) is not")
    tick(7 * 86400)
    ck(texts(await c.fetch(100, dm, n=60)) == [], name + "retention: after ~15 d the DM is empty")
    # concurrent writers: ids unique and in order
    tick(100)
    res = await asyncio.gather(*[c.send(100 + i, "global", "par %d" % i) for i in range(50)])
    ids = sorted(r["msg"]["i"] for r in res if r["ok"])
    g = await c.fetch(100, "global", n=60)
    seq = [m["i"] for m in g["msgs"]]
    ck(len(ids) == 50 and ids == list(range(ids[0], ids[0] + 50)) and seq == sorted(seq) and len(set(seq)) == len(seq), name + "concurrency: 50 simultaneous writers get 50 distinct, contiguous, ordered ids", ids[:5])


async def t_memory_bound():
    w = World()
    c = mk(w)
    be, now = c.be, T[0]
    cap = CH.cfg()
    from collections import deque
    for i in range(4600):
        be.ch["dm:%d:%d" % (i, i + 1)] = {"seq": 1, "q": deque([{"i": 1, "u": 1, "n": "x", "t": now, "x": "y"}]), "touch": now + i}
    now += 61
    await be.append("global", {"u": 1, "n": "x", "t": now, "x": "y"}, 300, 48 * 3600, now, c._ttls(cap))
    ck(len(be.ch) <= 4000, "bounded: 4600 distinct channels never keep more than 4000 in memory", len(be.ch))
    for i in range(30000):
        be.ptr[i] = {"g": 1}
    now += 61
    await be.append("global", {"u": 1, "n": "x", "t": now, "x": "y"}, 300, 48 * 3600, now, c._ttls(cap))
    ck(len(be.ptr) <= 20000, "bounded: 30000 read-pointer records are cut back", len(be.ptr))


# ====================================================================== runner for both backends
async def both(fn, *args, name_prefix=""):
    for kind in ("memory",) + (("redis",) if REDIS else ()):
        w = World()
        r = None
        if kind == "redis":
            r = await REDIS.flushdb() or REDIS
        c = mk(w, REDIS if kind == "redis" else None)
        c.be._redis_on = (lambda cc=c: _on(cc))
        await fn(c, w, "[%s] " % kind, *args)


async def _on(c):
    return (await c.be.r()) is not None


# ====================================================================== 10 over HTTP, two real accounts
TOK = os.environ.get("BOT_TOKEN", "123456:TESTTOKENabcdefghijk")


def init_data(uid, name="Wing"):
    d = {"auth_date": str(int(time.time())), "query_id": "AAE", "user": json.dumps({"id": uid, "first_name": name}, separators=(",", ":"))}
    dcs = "\n".join("%s=%s" % (k, v) for k, v in sorted(d.items()))
    sk = hmac.new(b"WebAppData", TOK.encode(), hashlib.sha256).digest()
    d["hash"] = hmac.new(sk, dcs.encode(), hashlib.sha256).hexdigest()
    return urllib.parse.urlencode(d)


async def t_http():
    from aiohttp.test_utils import TestClient, TestServer
    CH._now = time.time
    CH.CHAT.store = CH.CHAT.prof_fn = CH.CHAT.friends = CH.CHAT.clans = None
    CH.CHAT._pc.clear()
    LOCFG["chat"] = {"rate": {"gap_s": 0.2}}
    app = SV.make_app()
    srv = TestServer(app)
    cl = TestClient(srv)
    await cl.start_server()

    async def api(method, path, tok=None, body=None, **q):
        h = {"Authorization": "Bearer " + tok} if tok else {}
        r = await (cl.get(path, headers=h, params=q) if method == "GET" else cl.post(path, headers=h, json=body if body is not None else {}))
        return r.status, await r.json()

    toks = {}
    for uid, nm in ((777, "Owner"), (2001, "Alice"), (2002, "Bob"), (2003, "Cara"), (2004, "Dan")):
        s, a = await api("POST", "/api/auth", body={"init_data": init_data(uid, nm)})
        assert s == 200 and a["ok"], (uid, s, a)
        toks[uid] = a["token"]
    ck(True, "http: five accounts authenticated through the real /api/auth")
    A, B, C, D, O = toks[2001], toks[2002], toks[2003], toks[2004], toks[777]
    ok_, _j = await api("POST", "/api/chat/send", None, {"ch": "global", "t": "x"})
    ck(ok_ == 403 and _j["reason"] == "locked", "http: no token = 403 locked")
    ok_, _j = await api("GET", "/api/chat", None)
    ck(ok_ == 403, "http: GET without a token = 403")
    await STORE.refer(2002, 2001)                                         # (Bob opened the game from Alice's link: today's friends)
    for uid, lv in ((2001, 5), (2003, 5), (2004, 1)):
        st = await STORE.load(uid)
        st["b"]["keep"] = lv
        await STORE.save(uid, st)
        CH.CHAT.forget(uid)
    s, j = await api("POST", "/api/chat/send", B, {"ch": "global", "t": "hi from bob"})
    ck(s == 200 and j["why"] == "level" and j["need"] == 3, "http: Bob (castle 1) cannot write in Global yet", (s, j))
    s, j = await api("GET", "/api/chat", B, ch="global")
    ck(s == 200 and j["ok"] and j["msgs"] == [] and j["me"]["k"] == 1, "http: but he can read it", (s, j))
    s, j = await api("POST", "/api/chat/send", A, {"ch": "global", "t": "hello world"})
    ck(s == 200 and j["ok"] and j["msg"]["n"] == "Alice" and j["msg"]["k"] == 5 and j["msg"]["u"] == 2001, "http: Alice writes in Global (name and castle level come from her kingdom)", (s, j))
    s, j = await api("GET", "/api/chat", B, ch="global")
    ck(texts(j) == ["hello world"] and j["last"] == 1, "http: Bob sees it", (s, j))
    st = await STORE.load(2002)
    st["b"]["keep"] = 4
    await STORE.save(2002, st)
    CH.CHAT.forget(2002)
    s, j = await api("POST", "/api/chat/send", B, {"ch": "global", "t": "hi alice"})
    ck(s == 200 and j["ok"], "http: Bob reached castle 4 and writes", (s, j))
    await asyncio.sleep(0.25)
    s, j = await api("GET", "/api/chat", A, ch="global", after=1)
    ck(texts(j) == ["hi alice"] and j["unread"]["g"] == 1, "http: Alice polls after=1 and gets Bob's message + her unread counter", (s, j))
    s, j = await api("POST", "/api/chat/read", A, {"ch": "global", "upto": 2})
    ck(s == 200 and j["unread"]["g"] == 0, "http: /read clears it")
    await asyncio.sleep(0.25)
    s, j = await api("POST", "/api/chat/send", A, {"ch": "global", "t": "again"})
    s2, j2 = await api("POST", "/api/chat/send", A, {"ch": "global", "t": "too fast"})
    ck(s2 == 429 and j2["why"] == "rate" and j2["wait"] > 0, "http: the 2-second rule answers 429 with `wait`", (s2, j2))
    await asyncio.sleep(0.25)
    s, j = await api("POST", "/api/chat/send", A, {"ch": "global"})
    ck(s == 400, "http: no text = 400", (s, j))
    s, j = await api("POST", "/api/chat/send", A, {"ch": "nowhere", "t": "x"})
    ck(s == 400, "http: an unknown channel = 400", (s, j))
    s, j = await api("GET", "/api/chat", A, ch="global", after="x")
    ck(s == 400, "http: junk query = 400")
    s, j = await api("GET", "/api/chat", A)
    ck(s == 200 and "msgs" not in j and set(j["unread"]) >= {"g", "c", "dm"}, "http: no channel = counters only (the cheap badge poll)", (s, j))
    # clan through the real Clans
    r = await STORE.clans.create(2001, "Blue Wolves", "BW")
    cid = r["id"]
    await STORE.clans.join(2002, cid)
    for uid in (2001, 2002):
        CH.CHAT.forget(uid)
    await asyncio.sleep(0.25)
    s, j = await api("POST", "/api/chat/send", A, {"ch": "clan", "t": "wolves unite"})
    ck(s == 200 and j["ok"], "http: Alice writes in her clan room (real Clans)", (s, j))
    s, j = await api("GET", "/api/chat", B, ch="clan:%d" % cid)
    ck(texts(j) == ["wolves unite"] and j["ch"] == "clan:%d" % cid, "http: Bob (clan member) reads it", (s, j))
    s, j = await api("GET", "/api/chat", C, ch="clan")
    ck(s == 200 and j["why"] == "no_clan", "http: Cara (no clan) gets no_clan", (s, j))
    s, j = await api("GET", "/api/chat", C, ch="clan:%d" % cid)
    ck(s == 200 and j["why"] == "no_clan", "http: ... also when she asks for the room by id", (s, j))
    # DM: Alice <-> Bob are friends (invite link); Cara is not
    await asyncio.sleep(0.25)
    s, j = await api("POST", "/api/chat/send", A, {"ch": "dm:2002", "t": "psst bob"})
    ck(s == 200 and j["ok"], "http: Alice DMs Bob (his invite link made them friends)", (s, j))
    s, j = await api("GET", "/api/chat", B, ch="dm:2001", dm=1)
    ck(texts(j) == ["psst bob"] and j["ch"] == "dm:2001:2002" and j["unread"]["dm"] == 1 and j["unread"]["dmp"][0]["u"] == 2001 and j["unread"]["dmp"][0]["n"] == "Alice", "http: Bob reads it, unread + peer list say who", (s, j))
    s, j = await api("POST", "/api/chat/send", C, {"ch": "dm:2001", "t": "hello alice"})
    ck(s == 200 and j["why"] == "dm_no", "http: Cara is not Alice's friend: dm_no", (s, j))
    # report + automatic mute across three accounts
    st = await STORE.load(2004)
    st["b"]["keep"] = 5
    await STORE.save(2004, st)
    CH.CHAT.forget(2004)
    s, j = await api("POST", "/api/chat/send", D, {"ch": "global", "t": "i am a nuisance"})
    mid = j["msg"]["i"]
    rep = []
    for tk in (A, B, C):
        s, j = await api("POST", "/api/chat/report", tk, {"ch": "global", "id": mid, "why": "abuse"})
        rep.append((s, j))
    ck(all(s == 200 and j["ok"] for s, j in rep), "http: three players report the same message", rep)
    await asyncio.sleep(0.25)
    s, j = await api("POST", "/api/chat/send", D, {"ch": "global", "t": "still here"})
    ck(s == 200 and j["why"] == "muted" and j["left"] > 1700, "http: Dan is muted for 30 minutes", (s, j))
    s, j = await api("GET", "/api/chat/reports", A)
    ck(s == 403, "http: /reports is owner only")
    s, j = await api("GET", "/api/chat/reports", O)
    ck(s == 200 and len(j["reports"]) == 3 and j["reports"][0]["x"] == "i am a nuisance" and j["reports"][0]["an"] == "Dan", "http: the owner reads the report list", (s, j))
    s, j = await api("POST", "/api/chat/mute", A, {"uid": 2004, "secs": 0})
    ck(s == 403, "http: /mute is owner only")
    s, j = await api("POST", "/api/chat/mute", O, {"uid": 2004, "secs": 0, "why": "forgiven"})
    ck(s == 200 and j["ok"], "http: the owner lifts the mute")
    await asyncio.sleep(0.25)
    s, j = await api("POST", "/api/chat/send", D, {"ch": "global", "t": "sorry everyone"})
    ck(s == 200 and j["ok"], "http: Dan can talk again", (s, j))
    s, j = await api("POST", "/api/chat/mute", O, {"uid": 2002, "secs": 300, "why": "test"})
    await asyncio.sleep(0.25)
    s, j = await api("POST", "/api/chat/send", B, {"ch": "global", "t": "muted bob"})
    ck(j["why"] == "muted", "http: the owner mutes Bob by hand")
    s, j = await api("GET", "/api/chat", B, ch="global")
    ck(j["ok"] and j["me"]["mute"] > 250, "http: Bob can still read and sees the time left")
    s, j = await api("POST", "/api/chat/mute", O, {"uid": "x", "secs": 5})
    ck(s == 400, "http: owner mute with a junk uid = 400")
    s, j = await api("POST", "/api/chat/send", O, {"ch": "global", "t": "owner here"})
    ck(j["ok"], "http: the owner (castle max) writes")
    await cl.close()
    LOCFG.clear()


# ====================================================================== 9 redis
REDIS = None
_proc = None


async def start_redis():
    global REDIS, _proc
    import redis.asyncio as aioredis
    port = 6399
    d = tempfile.mkdtemp(prefix="ch1_redis_")
    _proc = subprocess.Popen(["redis-server", "--port", str(port), "--save", "", "--appendonly", "no", "--dir", d, "--bind", "127.0.0.1"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    REDIS = aioredis.from_url("redis://127.0.0.1:%d" % port, decode_responses=True)
    for _ in range(50):
        try:
            if await REDIS.ping():
                return
        except Exception:  # noqa: BLE001
            await asyncio.sleep(0.1)
    raise RuntimeError("redis-server did not start")


async def t_redis_down():
    import redis.asyncio as aioredis
    w = World()
    c = mk(w, aioredis.from_url("redis://127.0.0.1:1", decode_responses=True))
    t0 = time.time()
    try:
        await c.fetch(1, "global")
        ok = False
    except StateUnavailable:
        ok = True
    ck(ok and time.time() - t0 < 4, "redis: a dead Redis is StateUnavailable within 4 s (the server answers 503 busy and the client retries)", time.time() - t0)


async def main():
    await t_config()
    t_text()
    try:
        await start_redis()
    except Exception as e:  # noqa: BLE001
        ck(False, "redis: could not start redis-server", e)
    for fn in (t_rate, t_channels, t_block, t_report, t_buffers):
        await both(fn)
    await t_memory_bound()
    await t_redis_down()
    await t_http()


try:
    asyncio.run(main())
finally:
    if _proc:
        _proc.terminate()
    shutil.rmtree(TMP, ignore_errors=True)
print("CH1 SERVER OK" if not bad else "CH1 SERVER FAILED (%d)" % bad)
sys.exit(1 if bad else 0)
