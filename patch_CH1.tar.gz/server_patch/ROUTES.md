# CH1 — server_patch (chat) — ROUTES

Merge: copy `NEW/chat.py` and `NEW/chat_defaults.json` into `bluewall/` (the JSON must sit **next to** chat.py and ship in the package), then
`cd bluewall && patch -p1 < server.py.diff` (2 lines marked `# CH1:` in `server.py`: one import, one `CH.register(...)` call in `make_app`).
No change to `state.py`. Test: `python3 dev/ch1_server_test.py` → `CH1 SERVER OK` (builds a merged copy of the kit in /tmp, touches nothing).

Everything is under `bearer` auth (same as the other `/api/*`): no / bad token → `403 {"ok":false,"reason":"locked"}`; too many calls → `429 {"ok":false,"reason":"slow"}`;
malformed → `400 {"ok":false,"reason":"bad"}`; store trouble → `503 {"reason":"busy"}` (the existing `_store_guard`).  A refusal that is the player's business is
`200 {"ok":false,"why":"<code>"}` — except `why:"rate"` which is `429` with `wait` (seconds).

## Channels
`global` · `clan` (= my clan) or `clan:<cid>` · `dm:<peer>` (canonical name in answers: `dm:<low>:<high>`).  Server decides who may read / write:
global = everybody (write needs castle ≥ `chat.channels.global.min_keep`, default 3) · clan = members only · dm = the two players, and only if `friends.are_friends` (config `friends_only`).

## Public message  `{i, u, n, e, k, t, x, q?}`
`i` id (rises per channel, never reused inside a channel) · `u` sender uid (same exposure as the rank / clan rows) · `n` name · `e` emblem · `k` castle level · `t` unix seconds · `x` text · `q` quick-chat id if it was one.

## GET /api/chat?ch=<channel>&after=<id>&n=40[&dm=1]
- `after=0` (first load): the newest `n` (≤ 60) oldest→newest, plus `cfg {max_len, quick:[{id,t}…12], poll:{open_s,idle_s}, gap_s}`.  `after=<id>`: messages newer than `id` (≤ n), `more:true` when there are more (poll again at once).
- `after` bigger than the channel's last id (channel was reset / expired): newest page + `reset:true` — the client forgets its cursor.
- Answer: `{ok, ch, msgs[], last, more, peer?(dm), reset?, me:{u,k,mute(secs left),need_k,on:{global,clan,dm}}, unread:{g,c,dm[,dmp:[{u,n,e,k,un,t,x}]]}}`.
- **No `ch`**: counters only (`me` + `unread`) — the cheap badge poll (every `poll.idle_s`, 20 s).  `dm=1` adds `dmp` (the Friends tab list: peers with unread count and last text).
- Messages of a player the viewer blocked (either direction, `friends.is_blocked`) are removed from the list and from every unread counter.
- Refusals (200): `no_clan`, `forbidden`, `dm_no` (not friends), `off` (channel switched off), `bad` (400).

## POST /api/chat/send   `{ch, t}` or `{ch, q}`  (q = quick-chat id; the server maps it to its own text)
- ok: `{ok:true, msg:{…}, cleaned?:true}` (`cleaned` = links / @names / phone numbers were cut out; the rest was sent).
- refusals: `off`, `level {need}`, `muted {left}`, `rate {wait}`(429), `long`, `empty`, `link` (a link written to dodge the filter), `banned` (+ `muted` when this attempt triggered the strike mute), `dup`, `no_clan`, `dm_no`, `forbidden`, `bad`(400).
- Order of checks: channel → on/off → castle level → mute → rate → text (≤140, cut links/@/numbers, banned words) → duplicate (same text, same player, 30 s).
- Rate: ≥ 2 s between messages and ≤ 15 per minute per player (`chat.rate`).  HTTP-level `_limited` 40 / min on top.

## POST /api/chat/report   `{ch, id, why?}`  (why ∈ spam|abuse|link|other)
`{ok:true}` (also `{ok:true,dup:true}` for a repeated report) · `level` (reporter castle < min_keep) · `self` · `gone` · `rate` (`chat.report.max_per_10min`) · `no_clan`/`forbidden`.
Each report is logged for the owner.  **N different reporters inside `report.window_h` (default 3 in 24 h) mute the author for `report.auto_mute_s` (30 min)** automatically; the same reporter twice counts once; the owner is never auto-muted.  The reporter is not told whether a mute followed.
Strikes: `strikes.n` (5) refused-for-banned-word messages inside `strikes.window_s` (10 min) → mute `strikes.mute_s` (10 min).

## POST /api/chat/read   `{ch, upto}` → `{ok, unread}`   (moves my read pointer; clamped to the channel's last id)
First visit to Global / my clan starts "from now" (a new player does not see 300 unread).  A DM thread starts from 0.

## Owner only (`_is_owner`, else 403)
- `POST /api/chat/mute {uid, secs, why}` → `{ok, left}`; `secs: 0` lifts it; max 30 days.  Python: `await CHAT.mute(uid, secs, why)`.
- `GET /api/chat/reports` → `{ok, reports:[{t, ch, id, by, au, an, x, why}]}` newest first (last 200: the reported text, author, reporter).

## Retention (memory, or Redis when the Store has it: `bluewall:chat:*` keys)
global 300 messages / 48 h · clan 200 / 7 d · DM 100 / 14 d.  Hard ceiling 1000 per room whatever liveops says.  Read pointers 30 d.  Memory mode is bounded (≤ 4000 rooms, ≤ 20 000 per-player records).
Single server process assumed (one writer lock per room orders ids); a multi-process deployment needs a Lua INCR+ZADD — say so before scaling out.

## liveops section `chat`  (OC1 contract: `liveops.get("chat")`, `liveops.flag("chat_global" | "chat_clan" | "chat_dm")`, `liveops.register("chat", defaults, validate)`)
`chat_defaults.json` = the defaults; `chat.validate(d) -> list[str]` = the validator; `chat.py` calls `register` at import when the `liveops` module exists and works without it (defaults, flags on).
Keys: `channels.{global,clan,dm}.{on, cap, ttl_h|ttl_d, min_keep (global), friends_only (dm)}` · `rate.{gap_s, per_min, dup_s}` · `max_len` · `poll.{open_s, idle_s}` · `report.{auto_n, window_h, auto_mute_s, max_per_10min}` · `strikes.{n, window_s, mute_s}` · `quick` (12 × {id, t}) · **`banned`** (list; `word` = whole word, `~word` = also inside a word; Persian + English; matching ignores case, Arabic/Persian letter variants, diacritics, ZWNJ, repeated letters, `f u c k`, `f.u.c.k`, leet `sh!t`).
Every value is clamped by `chat.sane()` at read time, so a bad edit can never open the room or crash it.  A change applies within the liveops cache time (≤ 30 s).

## Wiring other chats' pieces (mother, after FR1 / CN1 are merged)
`from . import chat as CH` is already in the diff; add where the Store / FR1 / CN1 objects exist:
`CH.CHAT.bind(friends=<object with are_friends(a,b), is_blocked(a,b) — sync or async>, clans=<object with clan_of(uid)>)`.
Until then chat uses today's meanings: friends = invite-link relation (`frs` of either player), clan = `st["clan"]`, nobody is blocked.
`CH.CHAT.forget(uid)` drops the 30-second profile cache (call it after a clan join / leave if you want the room to switch at once; chat also re-reads by itself every 30 s).
