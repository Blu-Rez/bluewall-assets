"""Chat (CH1): one global room, one room per clan, private messages between friends.  Polling only (no sockets).

Channels (the string the client sends as `ch`):
    global             everybody; sending needs a castle of chat.channels.global.min_keep (default 3)
    clan | clan:<cid>  the player's own clan only ("clan" = "my clan"; the answer carries the real id)
    dm:<peer>          a private thread with <peer> (canonical name dm:<a>:<b>, a < b); friends only unless liveops says otherwise

Routes (registered by `register(app, ...)`, see ROUTES.md):
    GET  /api/chat?ch=&after=<id>&n=40[&dm=1]   new messages after <id> + the unread counters (no `ch` = counters only: the badge poll)
    POST /api/chat/send     {ch, t}  or  {ch, q}  (quick-chat id)  ->  {ok, msg, cleaned?}
    POST /api/chat/report   {ch, id, why?}
    POST /api/chat/read     {ch, upto}
    POST /api/chat/mute     OWNER ONLY {uid, secs, why}  (secs 0 = unmute)         GET /api/chat/reports   OWNER ONLY (the last 200 reports)

Safety (the part that matters most), all of it server side:
    1 message / 2 s and 15 / min per player · text <= 140 characters · links, @usernames and phone numbers are cut out · the same text from the
    same player inside 30 s is dropped · a banned-word list (Persian + English, editable in liveops `chat.banned`) · a minimum castle level for
    the global room · DMs only between friends · messages of a player you blocked are never shown to you · every message can be reported ·
    N reports from N DIFFERENT players mute the author automatically · the owner can mute by hand (chat.mute).
Retention: global 300 messages / 48 h, clan 200 / 7 days, DM 100 / 14 days (memory, or Redis when the Store has one).

Everything this module needs from the rest of the game goes through `CHAT.deps` (profile, clan_of, are_friends, is_blocked); the defaults read
the real Store, the mother wires FR1 / CN1 with `CHAT.bind(friends=..., clans=...)`.  Config lives in liveops section "chat" (chat_defaults.json).
"""
from __future__ import annotations

import asyncio
import importlib
import inspect
import json
import logging
import re
import time
import unicodedata
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("bluewall.chat")
_now = time.time                                                   # (tests replace this with a fake clock)

# ====================================================================== config
_MIN_DEFAULTS: Dict[str, Any] = {
    "v": 1,
    "channels": {"global": {"on": True, "min_keep": 3, "cap": 300, "ttl_h": 48}, "clan": {"on": True, "cap": 200, "ttl_d": 7},
                 "dm": {"on": True, "cap": 100, "ttl_d": 14, "friends_only": True}},
    "rate": {"gap_s": 2, "per_min": 15, "dup_s": 30}, "max_len": 140, "poll": {"open_s": 3, "idle_s": 20},
    "report": {"auto_n": 3, "window_h": 24, "auto_mute_s": 1800, "max_per_10min": 10},
    "strikes": {"n": 5, "window_s": 600, "mute_s": 600}, "quick": [], "banned": [],
}
try:
    DEFAULTS: Dict[str, Any] = json.loads((Path(__file__).with_name("chat_defaults.json")).read_text(encoding="utf-8"))
except Exception as _e:  # noqa: BLE001
    log.error("chat_defaults.json unreadable (%s): built-in minimal defaults, NO banned words", _e)
    DEFAULTS = _MIN_DEFAULTS

HARD_CAP = 1000                      # (no channel ever keeps more than this, whatever liveops says)
MAX_PEERS = 20                       # DM threads listed / counted per player


def _num(v: Any, lo: float, hi: float, d: Any, kind=int) -> Any:
    try:
        x = kind(v)
        if x != x:                   # NaN
            return d
    except Exception:  # noqa: BLE001
        return d
    return max(lo, min(hi, x))


def _dict(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}


def sane(d: Any) -> Dict[str, Any]:
    """The liveops section, clamped to safe ranges and merged onto the defaults (a bad edit can never crash or open the room)."""
    d, D = _dict(d), DEFAULTS
    ch, out = _dict(d.get("channels")), {"channels": {}}
    for k in ("global", "clan", "dm"):
        s, dd = _dict(ch.get(k)), _dict(_dict(D.get("channels")).get(k))
        o = {"on": bool(s.get("on", dd.get("on", True))), "cap": _num(s.get("cap"), 20, HARD_CAP, _num(dd.get("cap"), 20, HARD_CAP, 100))}
        if k == "global":
            o["min_keep"] = _num(s.get("min_keep"), 1, 60, _num(dd.get("min_keep"), 1, 60, 3))
            o["ttl"] = _num(s.get("ttl_h"), 1, 24 * 30, _num(dd.get("ttl_h"), 1, 24 * 30, 48)) * 3600
        else:
            o["ttl"] = _num(s.get("ttl_d"), 1, 90, _num(dd.get("ttl_d"), 1, 90, 7)) * 86400
        if k == "dm":
            o["friends_only"] = bool(s.get("friends_only", dd.get("friends_only", True)))
        out["channels"][k] = o
    r, rd = _dict(d.get("rate")), _dict(D.get("rate"))
    out["rate"] = {"gap_s": _num(r.get("gap_s"), 0.2, 60.0, _num(rd.get("gap_s"), 0.2, 60.0, 2.0, float), float),
                   "per_min": _num(r.get("per_min"), 1, 120, _num(rd.get("per_min"), 1, 120, 15)),
                   "dup_s": _num(r.get("dup_s"), 0, 3600, _num(rd.get("dup_s"), 0, 3600, 30))}
    out["max_len"] = _num(d.get("max_len"), 10, 300, _num(D.get("max_len"), 10, 300, 140))
    p, pd = _dict(d.get("poll")), _dict(D.get("poll"))
    out["poll"] = {"open_s": _num(p.get("open_s"), 1, 30, _num(pd.get("open_s"), 1, 30, 3)), "idle_s": _num(p.get("idle_s"), 5, 300, _num(pd.get("idle_s"), 5, 300, 20))}
    rp, rpd = _dict(d.get("report")), _dict(D.get("report"))
    out["report"] = {"auto_n": _num(rp.get("auto_n"), 2, 50, _num(rpd.get("auto_n"), 2, 50, 3)),
                     "window": _num(rp.get("window_h"), 1, 720, _num(rpd.get("window_h"), 1, 720, 24)) * 3600,
                     "auto_mute_s": _num(rp.get("auto_mute_s"), 60, 30 * 86400, _num(rpd.get("auto_mute_s"), 60, 30 * 86400, 1800)),
                     "max_per_10min": _num(rp.get("max_per_10min"), 1, 100, _num(rpd.get("max_per_10min"), 1, 100, 10))}
    sk, skd = _dict(d.get("strikes")), _dict(D.get("strikes"))
    out["strikes"] = {"n": _num(sk.get("n"), 2, 50, _num(skd.get("n"), 2, 50, 5)), "window_s": _num(sk.get("window_s"), 30, 86400, _num(skd.get("window_s"), 30, 86400, 600)),
                      "mute_s": _num(sk.get("mute_s"), 30, 7 * 86400, _num(skd.get("mute_s"), 30, 7 * 86400, 600))}
    ban = d.get("banned", D.get("banned", []))
    out["banned"] = [w for w in ban if isinstance(w, str) and 0 < len(w) <= 60][:3000] if isinstance(ban, list) else []
    q = d.get("quick", D.get("quick", []))
    qs, seen = [], set()
    for e in (q if isinstance(q, list) else [])[:24]:
        if isinstance(e, dict) and isinstance(e.get("t"), str) and e["t"].strip() and len(e["t"]) <= 24 and isinstance(e.get("id"), int) and 0 < e["id"] < 100 and e["id"] not in seen:
            seen.add(e["id"])
            qs.append({"id": e["id"], "t": e["t"].strip()})
    out["quick"] = qs
    return out


def validate(d: Any) -> List[str]:
    """liveops validator for the section: the list of problems (empty = fine)."""
    bad: List[str] = []
    if not isinstance(d, dict):
        return ["chat: must be an object"]

    def rng(path: str, v: Any, lo: float, hi: float) -> None:
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not lo <= v <= hi:
            bad.append("%s must be a number in %s..%s" % (path, lo, hi))

    ch = d.get("channels")
    if not isinstance(ch, dict):
        bad.append("channels must be an object")
    else:
        for k, keys in (("global", {"on": None, "min_keep": (1, 60), "cap": (20, HARD_CAP), "ttl_h": (1, 720)}), ("clan", {"on": None, "cap": (20, HARD_CAP), "ttl_d": (1, 90)}),
                        ("dm", {"on": None, "cap": (20, HARD_CAP), "ttl_d": (1, 90), "friends_only": None})):
            s = ch.get(k)
            if not isinstance(s, dict):
                bad.append("channels.%s must be an object" % k)
                continue
            for f, r in keys.items():
                if f not in s:
                    bad.append("channels.%s.%s missing" % (k, f))
                elif r is None:
                    if not isinstance(s[f], bool):
                        bad.append("channels.%s.%s must be true or false" % (k, f))
                else:
                    rng("channels.%s.%s" % (k, f), s[f], *r)
    for sec, keys in (("rate", {"gap_s": (0.2, 60), "per_min": (1, 120), "dup_s": (0, 3600)}), ("poll", {"open_s": (1, 30), "idle_s": (5, 300)}),
                      ("report", {"auto_n": (2, 50), "window_h": (1, 720), "auto_mute_s": (60, 30 * 86400), "max_per_10min": (1, 100)}),
                      ("strikes", {"n": (2, 50), "window_s": (30, 86400), "mute_s": (30, 7 * 86400)})):
        s = d.get(sec)
        if not isinstance(s, dict):
            bad.append("%s must be an object" % sec)
            continue
        for f, r in keys.items():
            if f not in s:
                bad.append("%s.%s missing" % (sec, f))
            else:
                rng("%s.%s" % (sec, f), s[f], *r)
    rng("max_len", d.get("max_len"), 10, 300)
    ban = d.get("banned")
    if not isinstance(ban, list) or len(ban) > 3000:
        bad.append("banned must be a list of at most 3000 words")
    else:
        for i, w in enumerate(ban):
            if not isinstance(w, str) or not 0 < len(w.strip("~")) <= 40 or len(w) > 41:
                bad.append("banned[%d] must be a word of 1..40 characters (prefix ~ = match inside a word)" % i)
                break
    q = d.get("quick")
    if not isinstance(q, list) or not 1 <= len(q) <= 24:
        bad.append("quick must be a list of 1..24 entries")
    else:
        ids = set()
        for i, e in enumerate(q):
            if not isinstance(e, dict) or not isinstance(e.get("id"), int) or isinstance(e.get("id"), bool) or not 0 < e["id"] < 100 or e["id"] in ids:
                bad.append("quick[%d].id must be a unique integer 1..99" % i)
                break
            ids.add(e["id"])
            t = e.get("t")
            if not isinstance(t, str) or not t.strip() or len(t) > 24:
                bad.append("quick[%d].t must be 1..24 characters" % i)
                break
            if _URL.search(t) or _DOM.search(t) or _AT.search(t):
                bad.append("quick[%d].t must not contain a link" % i)
                break
    return bad


_lo_cache: Tuple[float, Any] = (0.0, None)


def _liveops() -> Any:
    """the liveops module (OC1) when it exists; looked up at most every 30 s"""
    global _lo_cache
    t = time.monotonic()
    if t - _lo_cache[0] < 30 and _lo_cache[0]:
        return _lo_cache[1]
    try:
        m = importlib.import_module((__package__ or "bluewall") + ".liveops")
    except Exception:  # noqa: BLE001
        m = None
    _lo_cache = (t, m)
    return m


def reset_liveops_cache() -> None:
    global _lo_cache
    _lo_cache = (0.0, None)


_cfg_memo: Dict[str, Any] = {"key": None, "cfg": None, "words": None}


def cfg() -> Dict[str, Any]:
    LO, raw = _liveops(), None
    if LO is not None:
        try:
            raw = LO.get("chat")
        except Exception as e:  # noqa: BLE001
            log.warning("liveops.get('chat') failed: %s", e)
    c = sane(raw if isinstance(raw, dict) else DEFAULTS)
    return c


def flag(name: str) -> bool:
    LO = _liveops()
    if LO is None:
        return True
    try:
        return bool(LO.flag(name))
    except Exception:  # noqa: BLE001
        return True


# ====================================================================== text pipeline
_D = "0-9۰-۹٠-٩"
_URL = re.compile(r"(?i)(?:(?:https?|ftp|tg|ws)://|www\.)\S+|\b(?:t|telegram|wa|bit|goo|tinyurl|instagram|youtu)\.(?:me|dog|gl|ly|com|be)\b\S*")
_DOM = re.compile(r"(?i)(?<![\w@])(?:[a-z0-9][a-z0-9-]*\.)+(?:com|net|org|ir|io|me|co|info|biz|xyz|app|ly|gl|cc|tv|ru|top|site|online|shop|link|click|vip|pro|dev|cloud|store|live|cn|de|uk|us|eu|in|tk|ml|ga|cf|gq|icu|ws|to|fm|im|gg|sh|run|bid|win|work|fun|space|tech|club|today|news)\b(?:/\S*)?")
_AT = re.compile(r"(?<!\w)@[\w.]{2,}")
_NUMRUN = re.compile(r"\+?[%s](?:[\s\-.()]*[%s])+" % (_D, _D))
_DIGIT = re.compile("[%s]" % _D)
_SEPDOT = re.compile(r"(?i)\s*(?:\(\s*dot\s*\)|\[\s*dot\s*\]|\bdot\b)\s*")
_RUNS = re.compile(r"([^\d])\1{5,}")                              # (runs of one character; digits excluded: 1000000 must stay 1000000)


def _strip_chars(s: str) -> str:
    """no control / invisible / bidi-override characters (ZWNJ and ZWJ stay: Persian and emoji need them), newlines become spaces, at most 2 stacked
    combining marks (zalgo)"""
    out: List[str] = []
    marks = 0
    for ch in s:
        if ch in "\n\r\t\v\f":
            out.append(" ")
            marks = 0
            continue
        cat = unicodedata.category(ch)
        if cat in ("Cc", "Cs", "Co", "Cn", "Zl", "Zp") or (cat == "Cf" and ch not in "‌‍"):
            continue
        if cat in ("Mn", "Me"):
            marks += 1
            if marks > 2:
                continue
        else:
            marks = 0
        out.append(ch)
    return "".join(out)


def _phone_sub(m: "re.Match[str]") -> str:
    run = m.group(0)
    n = len(_DIGIT.findall(run))
    sep = n != len(run.replace("+", ""))
    d0 = "".join(_DIGIT.findall(run)).translate(_DIG)
    if n >= 9 or (n >= 7 and sep) or (n >= 7 and (run.startswith("+") or d0.startswith(("00", "09")))):
        return " "
    return run


def _cut(s: str) -> str:
    s = _URL.sub(" ", s)
    s = _DOM.sub(" ", s)
    s = _AT.sub(" ", s)
    s = _NUMRUN.sub(_phone_sub, s)
    return s


def clean_text(raw: str, max_len: int) -> Tuple[Optional[str], str, bool]:
    """-> (text, why, cut).  text None = refused with `why` (long | empty | link).  A message whose links / @names / numbers were cut keeps the rest (cut = True)."""
    if len(raw) > max(500, max_len * 4):
        return None, "long", False
    s = unicodedata.normalize("NFKC", raw)
    s = _strip_chars(s)
    s = " ".join(s.split())
    s = _RUNS.sub(lambda m: m.group(1) * 5, s)
    if len(s) > max_len:
        return None, "long", False
    t = " ".join(_cut(s).split())
    if not re.sub(r"[\s‌‍]+", "", t):
        return None, "empty", False
    # a link written so that the first pass does not see it ("t . me / x", "site(dot)com"): refuse the whole message
    sq = _SEPDOT.sub(".", t.lower())
    sq = re.sub(r"\s*([./:])\s*", r"\1", sq)
    if _URL.search(sq) or _DOM.search(sq) or _AT.search(sq):
        return None, "link", False
    return t, "", t != s


_AR = str.maketrans({"ي": "ی", "ى": "ی", "ئ": "ی", "ك": "ک", "ة": "ه", "ۀ": "ه", "أ": "ا", "إ": "ا", "آ": "ا", "ؤ": "و", "ـ": None, "‌": None, "‍": None})
_HARAKAT = re.compile("[ً-ٰٟۖ-ۭ]")
_DIG = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_LEET_D = str.maketrans("013457", "oieast")
_LEET_S = str.maketrans({"@": "a", "$": "s", "!": "i", "+": "t"})
_REP = re.compile(r"(.)\1+")
_TOK = re.compile(r"[^\W_]+")


def _probe(s: str, symbols: bool) -> str:
    s = unicodedata.normalize("NFKC", s).lower().translate(_AR)
    s = _HARAKAT.sub("", s).translate(_DIG).translate(_LEET_D)
    return s.translate(_LEET_S) if symbols else s


def _squeeze(t: str) -> str:
    return _REP.sub(r"\1", t)


class _Words:
    """the compiled banned list: whole-word entries (set) and `~entries` (match inside a word)"""

    def __init__(self, banned: List[str]) -> None:
        self.exact, self.subs = set(), []
        for w in banned:
            sub = w.startswith("~")
            n = _squeeze(_probe(w.lstrip("~"), False).replace(" ", ""))
            if not n:
                continue
            if sub:
                self.subs.append(n)
            else:
                self.exact.add(n)

    def hit(self, text: str) -> Optional[str]:
        for symbols in (True, False):
            toks = _TOK.findall(_probe(text, symbols))
            cand = list(toks)
            run: List[str] = []
            for t in toks + [""]:
                if len(t) == 1:
                    run.append(t)
                    continue
                if len(run) >= 3:
                    cand.append("".join(run))                   # ("f u c k", "ک س ک ش")
                run = []
            for t in cand:
                st = _squeeze(t)
                if st in self.exact:
                    return st
                for s in self.subs:
                    if s in st:
                        return s
        return None


def _words(banned: List[str]) -> _Words:
    key = tuple(banned)
    if _cfg_memo.get("key") != key:
        _cfg_memo["key"], _cfg_memo["words"] = key, _Words(banned)
    return _cfg_memo["words"]


def bad_word(text: str, banned: List[str]) -> Optional[str]:
    return _words(banned).hit(text)


# ====================================================================== storage helpers
class Refuse(Exception):
    def __init__(self, out: Dict[str, Any]) -> None:
        super().__init__(out.get("why"))
        self.out = out


async def _w(aw: Any) -> Any:
    """a Redis call: 2 s, and any Redis trouble is the Store's own `StateUnavailable` (the server answers 503 busy and the client retries)"""
    try:
        return await asyncio.wait_for(aw, 2.0)
    except Exception as e:  # noqa: BLE001
        if isinstance(e, asyncio.TimeoutError) or type(e).__module__.split(".")[0] in ("redis", "fakeredis"):
            from .state import StateUnavailable
            raise StateUnavailable("chat store: %r" % (e,)) from e
        raise


async def _aw(v: Any) -> Any:
    return await v if inspect.isawaitable(v) else v


K = "bluewall:chat:"


class _Backend:
    """messages, read pointers, mutes, reports.  Redis when the Store has one, plain memory otherwise (BLUEWALL_STATE=memory / no Redis)."""

    def __init__(self, store_fn) -> None:
        self._store_fn = store_fn
        self.ch: Dict[str, Dict[str, Any]] = {}                          # name -> {"seq", "q": deque, "touch"}
        self.ptr: Dict[int, Dict[str, int]] = {}
        self.dmp: Dict[int, Dict[int, float]] = {}
        self.mute_: Dict[int, Dict[str, Any]] = {}
        self.strike_: Dict[int, List[float]] = {}
        self.rep_: Dict[str, set] = {}
        self.ra_: Dict[int, Dict[int, float]] = {}
        self.rlog_: deque = deque(maxlen=200)
        self._gc_at = 0.0

    async def r(self):
        s = self._store_fn()
        return await s._redis() if s is not None else None

    # ---------------------------------------------------------------- memory housekeeping (bounded whatever happens)
    def _gc(self, now: float, ttls: Dict[str, int]) -> None:
        if now - self._gc_at < 60:
            return
        self._gc_at = now
        for name in list(self.ch):
            c = self.ch[name]
            ttl = ttls.get(name.split(":")[0], 7 * 86400)
            while c["q"] and c["q"][0]["t"] < now - ttl:
                c["q"].popleft()
            if not c["q"] and now - c["touch"] > 30 * 86400:                 # (an empty room keeps its id counter for 30 days, so ids never go backwards)
                del self.ch[name]
        if len(self.ch) > 4000:
            for name in sorted(self.ch, key=lambda n: self.ch[n]["touch"])[: len(self.ch) - 3000]:
                del self.ch[name]
        for d in (self.ptr, self.dmp, self.mute_, self.strike_, self.ra_):
            if len(d) > 20000:
                for k in list(d)[: len(d) // 2]:
                    del d[k]
        for k in [k for k, v in self.mute_.items() if v["until"] < now]:
            del self.mute_[k]
        if len(self.rep_) > 20000:
            self.rep_.clear()

    # ---------------------------------------------------------------- messages
    async def append(self, ch: str, m: Dict[str, Any], cap: int, ttl: int, now: float, ttls: Dict[str, int]) -> int:
        r = await self.r()
        if r is None:
            self._gc(now, ttls)
            c = self.ch.setdefault(ch, {"seq": 0, "q": deque(), "touch": now})
            c["seq"] += 1
            m["i"] = c["seq"]
            c["q"].append(m)
            c["touch"] = now
            while len(c["q"]) > cap:
                c["q"].popleft()
            while c["q"] and c["q"][0]["t"] < now - ttl:
                c["q"].popleft()
            return m["i"]
        mid = int(await _w(r.incr(K + "s:" + ch)))
        m["i"] = mid
        key = K + "m:" + ch
        await _w(r.zadd(key, {json.dumps(m, separators=(",", ":"), ensure_ascii=False): mid}))
        await _w(r.zremrangebyrank(key, 0, -(cap + 1)))
        for _ in range(HARD_CAP // 50 + 1):                                # (the oldest entries that outlived the retention, 50 at a time)
            old = await _w(r.zrange(key, 0, 49))
            dead = []
            for x in old:
                try:
                    if json.loads(x)["t"] >= now - ttl:
                        break
                except Exception:  # noqa: BLE001
                    pass
                dead.append(x)
            if dead:
                await _w(r.zrem(key, *dead))
            if len(dead) < 50:
                break
        await _w(r.expire(key, int(ttl) + 3600))
        await _w(r.expire(K + "s:" + ch, 30 * 86400))
        return mid

    async def last_id(self, ch: str) -> int:
        r = await self.r()
        if r is None:
            c = self.ch.get(ch)
            return c["seq"] if c else 0
        return int((await _w(r.get(K + "s:" + ch))) or 0)

    @staticmethod
    def _live(ms: List[Dict[str, Any]], min_t: float) -> List[Dict[str, Any]]:
        return [m for m in ms if m["t"] >= min_t]

    async def window(self, ch: str, after: int, n: int, min_t: float) -> Tuple[List[Dict[str, Any]], int, bool, bool]:
        """-> (messages oldest first, last id, more, reset).  after = 0: the newest n.  after > last id (the channel was reset): the newest n + reset."""
        last = await self.last_id(ch)
        reset = after > last
        if reset:
            after = 0
        r = await self.r()
        if r is None:
            c = self.ch.get(ch)
            q = [m for m in (c["q"] if c else ()) if m["t"] >= min_t]
            if after == 0:
                return [dict(m) for m in q[-n:]], last, False, reset
            ms = [m for m in q if m["i"] > after]
            return [dict(m) for m in ms[:n]], last, len(ms) > n, reset
        key = K + "m:" + ch
        if after == 0:
            raw = list(reversed(await _w(r.zrevrange(key, 0, n - 1))))
            more = False
        else:
            raw = await _w(r.zrangebyscore(key, "(%d" % after, "+inf", start=0, num=n + 1))
            more = len(raw) > n
            raw = raw[:n]
        return self._live([json.loads(x) for x in raw], min_t), last, more, reset

    async def get(self, ch: str, mid: int, min_t: float) -> Optional[Dict[str, Any]]:
        r = await self.r()
        if r is None:
            c = self.ch.get(ch)
            for m in (c["q"] if c else ()):
                if m["i"] == mid:
                    return dict(m) if m["t"] >= min_t else None
            return None
        raw = await _w(r.zrangebyscore(K + "m:" + ch, mid, mid))
        m = json.loads(raw[0]) if raw else None
        return m if m and m["t"] >= min_t else None

    async def count_after(self, ch: str, ptr: int, min_t: float) -> int:
        r = await self.r()
        if r is None:
            c = self.ch.get(ch)
            return sum(1 for m in (c["q"] if c else ()) if m["i"] > ptr and m["t"] >= min_t)
        return int(await _w(r.zcount(K + "m:" + ch, "(%d" % ptr, "+inf")))

    # ---------------------------------------------------------------- read pointers
    async def ptr_all(self, uid: int) -> Dict[str, int]:
        r = await self.r()
        if r is None:
            return dict(self.ptr.get(uid, {}))
        return {k: int(v) for k, v in (await _w(r.hgetall(K + "p:%d" % uid))).items()}

    async def ptr_set(self, uid: int, ch: str, mid: int) -> None:
        r = await self.r()
        if r is None:
            d = self.ptr.setdefault(uid, {})
            if mid > d.get(ch, -1):
                d[ch] = mid
            return
        key = K + "p:%d" % uid
        cur = await _w(r.hget(key, ch))
        if cur is None or int(cur) < mid:
            await _w(r.hset(key, ch, mid))
        await _w(r.expire(key, 30 * 86400))

    # ---------------------------------------------------------------- DM threads of a player
    async def dm_touch(self, uid: int, peer: int, now: float, ttl: int) -> None:
        r = await self.r()
        if r is None:
            d = self.dmp.setdefault(uid, {})
            d[peer] = now
            if len(d) > 60:
                for k in sorted(d, key=d.get)[: len(d) - 40]:
                    del d[k]
            return
        key = K + "d:%d" % uid
        await _w(r.zadd(key, {str(peer): now}))
        await _w(r.zremrangebyrank(key, 0, -61))
        await _w(r.expire(key, int(ttl)))

    async def dm_peers(self, uid: int, now: float, ttl: int) -> List[int]:
        r = await self.r()
        if r is None:
            d = self.dmp.get(uid, {})
            return [p for p, t in sorted(d.items(), key=lambda x: -x[1]) if t >= now - ttl][:MAX_PEERS]
        raw = await _w(r.zrevrange(K + "d:%d" % uid, 0, MAX_PEERS - 1, withscores=True))
        return [int(p) for p, t in raw if float(t) >= now - ttl]

    # ---------------------------------------------------------------- mutes and strikes
    async def mute_get(self, uid: int, now: float) -> int:
        r = await self.r()
        if r is None:
            m = self.mute_.get(uid)
            if not m:
                return 0
            if m["until"] <= now:
                self.mute_.pop(uid, None)
                return 0
            return int(m["until"] - now + 0.999)
        raw = await _w(r.get(K + "x:%d" % uid))
        if not raw:
            return 0
        try:
            return max(0, int(json.loads(raw)["until"] - now + 0.999))
        except Exception:  # noqa: BLE001
            return 0

    async def mute_set(self, uid: int, secs: int, why: str, by: int, now: float) -> None:
        r = await self.r()
        if secs <= 0:
            if r is None:
                self.mute_.pop(uid, None)
            else:
                await _w(r.delete(K + "x:%d" % uid))
            return
        rec = {"until": now + secs, "why": str(why)[:60], "by": int(by)}
        if r is None:
            self.mute_[uid] = rec
        else:
            await _w(r.set(K + "x:%d" % uid, json.dumps(rec), ex=int(secs) + 5))

    async def strike(self, uid: int, now: float, window: int) -> int:
        """one more refused-for-banned-words message; -> how many in the window"""
        r = await self.r()
        if r is None:
            q = [t for t in self.strike_.get(uid, []) if t > now - window] + [now]
            self.strike_[uid] = q
            return len(q)
        key = K + "k:%d" % uid
        await _w(r.zadd(key, {"%f" % now: now}))
        await _w(r.zremrangebyscore(key, 0, now - window))
        await _w(r.expire(key, int(window) + 5))
        return int(await _w(r.zcard(key)))

    async def strike_clear(self, uid: int) -> None:
        r = await self.r()
        if r is None:
            self.strike_.pop(uid, None)
        else:
            await _w(r.delete(K + "k:%d" % uid))

    # ---------------------------------------------------------------- reports
    async def rep_add(self, ch: str, mid: int, by: int, ttl: int) -> bool:
        """True = the first report of this message by this player"""
        r = await self.r()
        if r is None:
            s = self.rep_.setdefault("%s|%d" % (ch, mid), set())
            if by in s:
                return False
            s.add(by)
            return True
        key = K + "r:%s:%d" % (ch, mid)
        n = int(await _w(r.sadd(key, by)))
        await _w(r.expire(key, int(ttl) + 3600))
        return n == 1

    async def ra_add(self, author: int, by: int, now: float, window: int) -> int:
        """a distinct reporter of this author -> how many distinct reporters inside the window"""
        r = await self.r()
        if r is None:
            d = self.ra_.setdefault(author, {})
            d[by] = now
            for k in [k for k, t in d.items() if t < now - window]:
                del d[k]
            return len(d)
        key = K + "ra:%d" % author
        await _w(r.zadd(key, {str(by): now}))
        await _w(r.zremrangebyscore(key, 0, now - window))
        await _w(r.expire(key, int(window) + 5))
        return int(await _w(r.zcard(key)))

    async def ra_clear(self, author: int) -> None:
        r = await self.r()
        if r is None:
            self.ra_.pop(author, None)
        else:
            await _w(r.delete(K + "ra:%d" % author))

    async def rlog_add(self, rec: Dict[str, Any]) -> None:
        r = await self.r()
        if r is None:
            self.rlog_.appendleft(rec)
            return
        await _w(r.lpush(K + "rl", json.dumps(rec, separators=(",", ":"), ensure_ascii=False)))
        await _w(r.ltrim(K + "rl", 0, 199))

    async def rlog(self, n: int) -> List[Dict[str, Any]]:
        r = await self.r()
        if r is None:
            return list(self.rlog_)[:n]
        return [json.loads(x) for x in await _w(r.lrange(K + "rl", 0, n - 1))]


# ====================================================================== the chat
def pub(m: Dict[str, Any]) -> Dict[str, Any]:
    """what other players may see of a message"""
    o = {"i": m["i"], "u": m["u"], "n": m["n"], "e": m.get("e"), "k": m.get("k", 1), "t": int(m["t"]), "x": m["x"]}
    if m.get("q"):
        o["q"] = m["q"]
    return o


def _int(v: Any, lo: int = 1, hi: int = 2 ** 53) -> int:
    if isinstance(v, bool):
        raise ValueError("bool")
    x = int(v)
    if not lo <= x <= hi:
        raise ValueError("range")
    return x


class Chat:
    def __init__(self) -> None:
        self.store: Any = None                         # None = the real STORE (tests pass a stand-in with `_redis()`)
        self.prof_fn: Any = None                       # async (uid) -> {"n","e","k","clan"}   (default: the real Store)
        self.friends: Any = None                       # FR1: object with are_friends(a, b) / is_blocked(a, b), sync or async
        self.clans: Any = None                         # CN1: object with clan_of(uid)
        self.is_owner: Any = lambda uid: False
        self.be = _Backend(self._store)
        self._locks: Dict[str, asyncio.Lock] = {}
        self._sent: Dict[int, deque] = {}
        self._dup: Dict[int, Dict[str, float]] = {}
        self._rep_rate: Dict[int, deque] = {}
        self._pc: Dict[int, Tuple[float, Dict[str, Any]]] = {}
        self._fc: Dict[Tuple[int, int], Tuple[float, bool]] = {}

    def bind(self, friends: Any = None, clans: Any = None) -> None:
        """the mother's wiring: CHAT.bind(friends=<FR1 object>, clans=<CN1 object>)"""
        if friends is not None:
            self.friends = friends
        if clans is not None:
            self.clans = clans

    def _store(self) -> Any:
        if self.store is not None:
            return self.store
        from .state import STORE
        return STORE

    def _lock(self, key: str) -> asyncio.Lock:
        if len(self._locks) > 3000:
            for k in [k for k, v in self._locks.items() if not v.locked() and not getattr(v, "_waiters", None)]:
                del self._locks[k]
        return self._locks.setdefault(key, asyncio.Lock())

    # ---------------------------------------------------------------- what the rest of the game says
    async def prof(self, uid: int) -> Dict[str, Any]:
        now = time.monotonic()
        hit = self._pc.get(uid)
        if hit and now - hit[0] < 30:
            return hit[1]
        if self.prof_fn is not None:
            p = await _aw(self.prof_fn(uid))
        else:
            from . import military as MI
            from . import progress as PR
            st = await self._store().load(uid)
            p = {"n": str(st.get("name") or "Kingdom")[:24], "e": MI.emblem_of(st, uid), "k": int(PR.keep_level(st)), "clan": int(st.get("clan") or 0)}
        if len(self._pc) > 5000:
            self._pc.clear()
        self._pc[uid] = (now, p)
        return p

    def forget(self, uid: int) -> None:
        self._pc.pop(uid, None)

    async def clan_of(self, uid: int) -> int:
        if self.clans is not None and hasattr(self.clans, "clan_of"):
            return int(await _aw(self.clans.clan_of(uid)) or 0)
        return int((await self.prof(uid)).get("clan") or 0)

    async def are_friends(self, a: int, b: int) -> bool:
        if self.friends is not None and hasattr(self.friends, "are_friends"):
            return bool(await _aw(self.friends.are_friends(a, b)))
        key, now = (min(a, b), max(a, b)), time.monotonic()
        hit = self._fc.get(key)
        if hit and now - hit[0] < 60:
            return hit[1]
        ok = False
        try:                                                           # (today's friends = the ones who opened the game from your invite link)
            st = self._store()
            ok = b in [int(x) for x in (await st.load(a)).get("frs", [])] or a in [int(x) for x in (await st.load(b)).get("frs", [])]
        except Exception as e:  # noqa: BLE001
            log.warning("friends lookup failed: %s", e)
        if len(self._fc) > 5000:
            self._fc.clear()
        self._fc[key] = (now, ok)
        return ok

    async def is_blocked(self, a: int, b: int) -> bool:
        if self.friends is not None and hasattr(self.friends, "is_blocked"):
            return bool(await _aw(self.friends.is_blocked(a, b)))
        return False

    async def _hidden(self, viewer: int, sender: int, memo: Dict[int, bool]) -> bool:
        if sender == viewer:
            return False
        if sender not in memo:
            memo[sender] = await self.is_blocked(viewer, sender) or await self.is_blocked(sender, viewer)
        return memo[sender]

    # ---------------------------------------------------------------- channels
    @staticmethod
    def _ttls(c: Dict[str, Any]) -> Dict[str, int]:
        return {k: c["channels"][k]["ttl"] for k in ("global", "clan", "dm")}

    async def _resolve(self, uid: int, ch: Any, c: Dict[str, Any]) -> Tuple[str, str, int]:
        """-> (kind, canonical key, peer).  Raises Refuse."""
        s = str(ch or "")[:48]
        try:
            if s == "global":
                return "global", "global", 0
            if s == "clan" or s.startswith("clan:"):
                cid = await self.clan_of(uid)
                if not cid:
                    raise Refuse({"ok": False, "why": "no_clan"})
                if s != "clan" and _int(s[5:]) != cid:
                    raise Refuse({"ok": False, "why": "forbidden"})
                return "clan", "clan:%d" % cid, 0
            if s.startswith("dm:"):
                parts = [_int(p) for p in s[3:].split(":")]
                if len(parts) > 2:
                    raise ValueError("dm parts")
                if len(parts) == 1:
                    peer = parts[0]
                elif len(parts) == 2 and uid in parts and parts[0] != parts[1]:
                    peer = parts[1] if parts[0] == uid else parts[0]
                else:
                    raise Refuse({"ok": False, "why": "forbidden"})
                if peer == uid:
                    raise Refuse({"ok": False, "why": "forbidden"})
                if c["channels"]["dm"]["friends_only"] and not await self.are_friends(uid, peer):
                    raise Refuse({"ok": False, "why": "dm_no"})
                return "dm", "dm:%d:%d" % (min(uid, peer), max(uid, peer)), peer
        except (ValueError, TypeError):
            raise Refuse({"ok": False, "reason": "bad", "why": "bad"})
        raise Refuse({"ok": False, "reason": "bad", "why": "bad"})

    def _on(self, kind: str, c: Dict[str, Any]) -> bool:
        return bool(c["channels"][kind]["on"]) and flag("chat_" + kind)

    # ---------------------------------------------------------------- read
    async def fetch(self, uid: int, ch: Any = "", after: int = 0, n: int = 40, dm: bool = False) -> Dict[str, Any]:
        c, now = cfg(), _now()
        out: Dict[str, Any] = {"ok": True}
        p = await self.prof(uid)
        mute = await self.be.mute_get(uid, now)
        out["me"] = {"u": uid, "k": p["k"], "mute": mute, "need_k": c["channels"]["global"]["min_keep"],
                     "on": {k: self._on(k, c) for k in ("global", "clan", "dm")}}
        if ch:
            try:
                kind, key, peer = await self._resolve(uid, ch, c)
            except Refuse as e:
                return dict(e.out)
            if not self._on(kind, c):
                return {"ok": False, "why": "off"}
            ttl = c["channels"][kind]["ttl"]
            ms, last, more, reset = await self.be.window(key, max(0, int(after)), max(1, min(60, int(n))), now - ttl)
            memo: Dict[int, bool] = {}
            out["msgs"] = [pub(m) for m in ms if not await self._hidden(uid, m["u"], memo)]
            out.update({"ch": key, "last": last, "more": more})
            if reset:
                out["reset"] = True
            if kind == "dm":
                out["peer"] = peer
            if not after:
                out["cfg"] = {"max_len": c["max_len"], "quick": c["quick"], "poll": c["poll"], "gap_s": c["rate"]["gap_s"]}
        out["unread"] = await self.unread(uid, c, now, dm_list=dm)
        return out

    async def _unread_in(self, uid: int, key: str, ptr: int, ttl: int, now: float, memo: Dict[int, bool]) -> int:
        n = await self.be.count_after(key, ptr, now - ttl)
        if n == 0:
            return 0
        if n > 30:
            return min(n, 99)
        ms, _l, _m, _r = await self.be.window(key, ptr, 30, now - ttl)
        cnt = 0
        for m in ms:
            if m["u"] != uid and not await self._hidden(uid, m["u"], memo):
                cnt += 1
        return cnt

    async def unread(self, uid: int, c: Optional[Dict[str, Any]] = None, now: Optional[float] = None, dm_list: bool = False) -> Dict[str, Any]:
        c, now = c or cfg(), now or _now()
        ptrs, memo = await self.be.ptr_all(uid), {}
        out: Dict[str, Any] = {"g": 0, "c": 0, "dm": 0}
        if self._on("global", c):
            if "global" not in ptrs:                                   # (first visit: everything before now counts as seen)
                ptrs["global"] = await self.be.last_id("global")
                await self.be.ptr_set(uid, "global", ptrs["global"])
            out["g"] = await self._unread_in(uid, "global", ptrs["global"], c["channels"]["global"]["ttl"], now, memo)
        cid = await self.clan_of(uid) if self._on("clan", c) else 0
        if cid:
            key = "clan:%d" % cid
            if key not in ptrs:
                ptrs[key] = await self.be.last_id(key)
                await self.be.ptr_set(uid, key, ptrs[key])
            out["c"] = await self._unread_in(uid, key, ptrs[key], c["channels"]["clan"]["ttl"], now, memo)
        if self._on("dm", c):
            dmttl, rows = c["channels"]["dm"]["ttl"], []
            for peer in await self.be.dm_peers(uid, now, dmttl):
                key = "dm:%d:%d" % (min(uid, peer), max(uid, peer))
                un = await self._unread_in(uid, key, ptrs.get(key, 0), dmttl, now, memo)
                out["dm"] += un
                if dm_list:
                    last = await self.be.window(key, 0, 1, now - dmttl)
                    pr = await self.prof(peer)
                    lm = last[0][0] if last[0] else None
                    rows.append({"u": peer, "n": pr["n"], "e": pr.get("e"), "k": pr.get("k", 1), "un": un, "t": int(lm["t"]) if lm else 0, "x": (lm["x"][:40] if lm else "")})
            if dm_list:
                out["dmp"] = rows
        return out

    async def read(self, uid: int, ch: Any, upto: Any) -> Dict[str, Any]:
        c = cfg()
        try:
            kind, key, _p = await self._resolve(uid, ch, c)
            up = _int(upto, 0)
        except Refuse as e:
            return dict(e.out)
        except (ValueError, TypeError):
            return {"ok": False, "reason": "bad", "why": "bad"}
        await self.be.ptr_set(uid, key, min(up, await self.be.last_id(key)))
        return {"ok": True, "unread": await self.unread(uid, c)}

    # ---------------------------------------------------------------- write
    def _rate_wait(self, uid: int, now: float, c: Dict[str, Any]) -> float:
        q = self._sent.get(uid)
        if not q:
            return 0.0
        while q and q[0] < now - 60:
            q.popleft()
        w = 0.0
        if q and now - q[-1] < c["rate"]["gap_s"]:
            w = c["rate"]["gap_s"] - (now - q[-1])
        if len(q) >= c["rate"]["per_min"]:
            w = max(w, q[0] + 60 - now)
        return w

    def _rate_note(self, uid: int, now: float) -> None:
        if len(self._sent) > 20000:
            for k in list(self._sent)[:10000]:
                del self._sent[k]
        self._sent.setdefault(uid, deque()).append(now)

    async def send(self, uid: int, ch: Any, text: Any = None, q: Any = None, owner: bool = False) -> Dict[str, Any]:
        c, now = cfg(), _now()
        try:
            kind, key, peer = await self._resolve(uid, ch, c)
        except Refuse as e:
            return dict(e.out)
        if not self._on(kind, c):
            return {"ok": False, "why": "off"}
        p = await self.prof(uid)
        need = c["channels"]["global"]["min_keep"]
        if kind == "global" and not owner and p["k"] < need:
            return {"ok": False, "why": "level", "need": need}
        left = 0 if owner else await self.be.mute_get(uid, now)
        if left:
            return {"ok": False, "why": "muted", "left": left}
        w = self._rate_wait(uid, now, c)
        if w > 0:
            return {"ok": False, "why": "rate", "wait": round(w, 1)}
        cleaned, qid = False, 0
        if q is not None:                                                 # (a quick-chat id: the text comes from our own list, no filters needed)
            try:
                qid = _int(q)
            except (ValueError, TypeError):
                return {"ok": False, "reason": "bad", "why": "bad"}
            tx = next((e["t"] for e in c["quick"] if e["id"] == qid), None)
            if tx is None:
                return {"ok": False, "reason": "bad", "why": "bad"}
        else:
            if not isinstance(text, str):
                return {"ok": False, "reason": "bad", "why": "bad"}
            tx, why, cleaned = clean_text(text, c["max_len"])
            if tx is None:
                return {"ok": False, "why": why}
            if not owner and bad_word(tx, c["banned"]):
                n = await self.be.strike(uid, now, c["strikes"]["window_s"])
                out = {"ok": False, "why": "banned"}
                if n >= c["strikes"]["n"]:
                    await self.be.mute_set(uid, c["strikes"]["mute_s"], "banned words", 0, now)
                    await self.be.strike_clear(uid)
                    out["muted"] = c["strikes"]["mute_s"]
                return out
        norm = " ".join(tx.lower().split())
        dq = self._dup.setdefault(uid, {})
        dup_s = c["rate"]["dup_s"]
        if dup_s and now - dq.get(norm, -1e9) < dup_s:
            return {"ok": False, "why": "dup"}
        m = {"u": uid, "n": p["n"], "e": p.get("e"), "k": p["k"], "t": now, "x": tx}
        if qid:
            m["q"] = qid
        async with self._lock(key):                                        # (one writer per channel: ids and storage order always agree)
            await self.be.append(key, m, c["channels"][kind]["cap"], c["channels"][kind]["ttl"], now, self._ttls(c))
        self._rate_note(uid, now)
        if len(dq) > 30:
            for k in [k for k, t in dq.items() if now - t >= dup_s]:
                del dq[k]
        if len(self._dup) > 20000:
            self._dup.clear()
        dq[norm] = now
        await self.be.ptr_set(uid, key, m["i"])
        if kind == "dm":
            await self.be.dm_touch(uid, peer, now, c["channels"]["dm"]["ttl"])
            await self.be.dm_touch(peer, uid, now, c["channels"]["dm"]["ttl"])
        out = {"ok": True, "msg": pub(m)}
        if cleaned:
            out["cleaned"] = True
        return out

    # ---------------------------------------------------------------- reports and mutes
    async def report(self, uid: int, ch: Any, mid: Any, why: Any = "") -> Dict[str, Any]:
        c, now = cfg(), _now()
        try:
            kind, key, _peer = await self._resolve(uid, ch, c)
            mid = _int(mid)
        except Refuse as e:
            return dict(e.out)
        except (ValueError, TypeError):
            return {"ok": False, "reason": "bad", "why": "bad"}
        rq = self._rep_rate.setdefault(uid, deque())
        while rq and rq[0] < now - 600:
            rq.popleft()
        if len(rq) >= c["report"]["max_per_10min"]:
            return {"ok": False, "why": "rate"}
        if len(self._rep_rate) > 20000:
            self._rep_rate.clear()
        p = await self.prof(uid)
        if p["k"] < c["channels"]["global"]["min_keep"]:
            return {"ok": False, "why": "level", "need": c["channels"]["global"]["min_keep"]}
        ttl = c["channels"][kind]["ttl"]
        m = await self.be.get(key, mid, now - ttl)
        if m is None:
            return {"ok": False, "why": "gone"}
        if m["u"] == uid:
            return {"ok": False, "why": "self"}
        rq.append(now)
        if not await self.be.rep_add(key, mid, uid, ttl):
            return {"ok": True, "dup": True}
        author = int(m["u"])
        reason = str(why or "")[:16] if str(why or "") in ("spam", "abuse", "link", "other") else "other"
        await self.be.rlog_add({"t": int(now), "ch": key, "id": mid, "by": uid, "au": author, "an": m["n"], "x": m["x"], "why": reason})
        distinct = await self.be.ra_add(author, uid, now, c["report"]["window"])
        if distinct >= c["report"]["auto_n"] and not self.is_owner(author):
            await self.be.mute_set(author, c["report"]["auto_mute_s"], "reports", 0, now)
            await self.be.ra_clear(author)
            log.warning("chat: uid=%s auto-muted for %ss (%d reporters), last report ch=%s id=%s", author, c["report"]["auto_mute_s"], distinct, key, mid)
        return {"ok": True}

    async def mute(self, uid: int, secs: int, why: str = "", by: int = 0) -> Dict[str, Any]:
        """the owner's hand: mute `uid` for `secs` seconds (<= 0 lifts it)"""
        secs = max(0, min(int(secs), 30 * 86400))
        now = _now()
        await self.be.mute_set(int(uid), secs, why, by, now)
        log.warning("chat: owner mute uid=%s secs=%s why=%s", uid, secs, str(why)[:60])
        return {"ok": True, "left": secs}

    async def muted_left(self, uid: int) -> int:
        return await self.be.mute_get(uid, _now())

    async def reports(self, n: int = 50) -> List[Dict[str, Any]]:
        return await self.be.rlog(max(1, min(200, n)))


CHAT = Chat()


# ====================================================================== liveops + routes
def _register_liveops() -> None:
    LO = _liveops()
    if LO is not None:
        try:
            LO.register("chat", DEFAULTS, validate)
        except Exception as e:  # noqa: BLE001
            log.warning("liveops.register('chat') failed: %s", e)


_register_liveops()


def register(app: Any, *, bearer, limited, nocache, is_owner) -> None:
    """add the chat routes to the aiohttp app (server.py: one call in make_app).  bearer(req) -> uid | None, limited(key, max) -> bool, nocache(resp), is_owner(uid)"""
    from aiohttp import web
    CHAT.is_owner = is_owner

    def J(obj: Dict[str, Any], status: int = 200) -> Any:
        if status == 200 and not obj.get("ok"):
            status = 429 if obj.get("why") == "rate" else 400 if obj.get("reason") == "bad" else 200
        return nocache(web.json_response(obj, status=status))

    def locked() -> Any:
        return nocache(web.json_response({"ok": False, "reason": "locked"}, status=403))

    def slow() -> Any:
        return nocache(web.json_response({"ok": False, "reason": "slow"}, status=429))

    async def body(req: Any) -> Dict[str, Any]:
        try:
            b = await req.json()
        except Exception:  # noqa: BLE001
            return {}
        return b if isinstance(b, dict) else {}

    async def h_get(req: Any) -> Any:
        uid = bearer(req)
        if uid is None:
            return locked()
        if limited("chg:%d" % uid, 120):
            return slow()
        q = req.query
        try:
            after, n = max(0, int(q.get("after") or 0)), int(q.get("n") or 40)
        except ValueError:
            return J({"ok": False, "reason": "bad"})
        return J(await CHAT.fetch(uid, str(q.get("ch") or "")[:48], after, n, dm=bool(q.get("dm"))))

    async def h_send(req: Any) -> Any:
        uid = bearer(req)
        if uid is None:
            return locked()
        if limited("chs:%d" % uid, 40):
            return slow()
        b = await body(req)
        return J(await CHAT.send(uid, b.get("ch"), b.get("t"), b.get("q"), owner=bool(is_owner(uid))))

    async def h_report(req: Any) -> Any:
        uid = bearer(req)
        if uid is None:
            return locked()
        if limited("chr:%d" % uid, 20):
            return slow()
        b = await body(req)
        return J(await CHAT.report(uid, b.get("ch"), b.get("id"), b.get("why")))

    async def h_read(req: Any) -> Any:
        uid = bearer(req)
        if uid is None:
            return locked()
        if limited("chd:%d" % uid, 90):
            return slow()
        b = await body(req)
        return J(await CHAT.read(uid, b.get("ch"), b.get("upto")))

    async def h_mute(req: Any) -> Any:
        uid = bearer(req)
        if uid is None or not is_owner(uid):
            return locked()
        b = await body(req)
        try:
            return J(await CHAT.mute(_int(b.get("uid")), int(b.get("secs") or 0), str(b.get("why") or ""), by=uid))
        except (ValueError, TypeError):
            return J({"ok": False, "reason": "bad"})

    async def h_reports(req: Any) -> Any:
        uid = bearer(req)
        if uid is None or not is_owner(uid):
            return locked()
        return J({"ok": True, "reports": await CHAT.reports(50)})

    app.router.add_get("/api/chat", h_get)
    app.router.add_post("/api/chat/send", h_send)
    app.router.add_post("/api/chat/report", h_report)
    app.router.add_post("/api/chat/read", h_read)
    app.router.add_post("/api/chat/mute", h_mute)
    app.router.add_get("/api/chat/reports", h_reports)
