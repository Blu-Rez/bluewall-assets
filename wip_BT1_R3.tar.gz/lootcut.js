// BT1_R3 (PL1-01): the loot the soldiers carried out minus the loot the server booked = what had no room in the vault.
// Pure (no DOM, no three): dev/bt1r3_vaultfull_test.mjs runs it in node.  The server (military.py settle_battle) books min(loot, room); the room is read BEFORE the answer is applied (it moves the gems).
//   simLoot / booked / room: { ruby, emerald, turq } numbers (room may be Infinity).  Returns { cut, vault }:
//   cut   = { gem: lost } for every gem that was cut because the vault lacked the room (lost >= 1), or null;
//   vault = { all } when anything was cut — all: every gem booked 0 — or null.
export const GEMS3 = ['ruby', 'emerald', 'turq'];
export function lootCut(simLoot, booked, room) {
  let cut = null;
  for (const g of GEMS3) {
    const sim = simLoot && simLoot[g] > 0 ? simLoot[g] : 0, got = booked && booked[g] > 0 ? booked[g] : 0, rm = room && room[g] != null ? room[g] : Infinity;
    const d = Math.floor(sim - got);
    if (d > 0 && rm < sim) (cut || (cut = {}))[g] = d;                 // (only «vault full» where the vault really lacked the room: any other cut is the server's plausibility clamp and is not this card's message)
  }
  return { cut, vault: cut ? { all: GEMS3.every((g) => !(booked && booked[g] > 0)) } : null };
}
