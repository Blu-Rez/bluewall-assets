# APPLY GR1_R2 (کوه‌ها / افق)
1. فایل‌های `bluewall/client/src/*.js` (backdrop.js و skyhaze.js جدید؛ sky/terrain/tod/world تغییر کرده) روی kit کپی بشن، یا `git apply patch.diff` (پایه: HEAD شاخهٔ kit).
2. `bash client/build.sh` (web/app/wall.js از اینجا ساخته می‌شه؛ در این پچ نیست).
3. تست‌ها: `workers/dev/gr1r2_test.*` را به `/home/claude/dev/` ببر و `bash dev/gr1r2_test.sh` → «GR1_R2 TEST OK». (من به gate_w.sh دست نزدم؛ اگر خواستی یک خط به gate اضافه کن.)
4. `bash dev/gate_w.sh` → «GATE_W: ALL OK»، noRoute = 647.
5. مارکرها: tod.js ۳ خط `// GR1:`، world.js ۴ خط.
بودجه: برنامهٔ شیدر +۰، draw call −۱، مثلث برابر (۸۴۰۰)، نور جدید ۰.
ابزار فریم (software GL) در workers/dev: gr1r2_daemon.py + gr1r2_cmd.py + gr1r2_grab.py + gr1r2_sheet.py.
