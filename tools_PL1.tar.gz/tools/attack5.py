# attack.py: play one attack from the Army panel to the result card and back home (dev page).  env ADV=1 -> use battle.advance() to skip render slowness (sandbox only)
import asyncio, json, os, sys, time
from lib import *
ADV = os.environ.get('ADV') == '1'; TAG = sys.argv[1] if len(sys.argv) > 1 else 'att'
async def st(pg):
    return await pg.evaluate("() => { const b = __bw.battle, s = b.session; return [b.active, b.loading, s ? [!!s.started, !!s.over, !!s.done, !!s.scout] : null, !!document.querySelector('.bwb-res.on'), document.querySelector('.bwb-load') ? (document.querySelector('.bwb-load').textContent || '').trim().replace(/\\s+/g,' ').slice(0,60) : null, __bw.frames] }")
async def main():
    t0 = time.time(); T = lambda: round(time.time() - t0)
    async with async_playwright() as p:
        b, pg = await cdp_page(p, fresh=False); rec = Rec(); rec.attach(pg)
        await pg.evaluate("() => __bw.pause(false)")
        print(T(), 'gems before', await pg.evaluate("() => JSON.stringify(__bw.econ.st.gems)+' tro '+__bw.econ.st.tro"), flush=True)
        # open Army if it is not open
        if not await pg.evaluate("() => !!document.querySelector('.bwa.on')"):
            await pg.evaluate("() => { document.querySelector('.bwh-btn').click(); }"); await asyncio.sleep(1.5)
            await pg.evaluate("() => document.querySelector('.bwh-t[data-a=army]').click()"); await asyncio.sleep(2)
        await shot(pg, TAG + '_0_army')
        print(T(), 'click FIND A TARGET', await pg.evaluate("() => { const b = document.querySelector('.bwa button[data-a=attack], button[data-a=attack]'); if (!b) return 'no button'; b.click(); return 'clicked' }"), flush=True)
        n = 0; last = None
        while T() < 900:
            await asyncio.sleep(4); s = await st(pg)
            if s != last or n % 8 == 0: print(T(), s, flush=True)
            last = s; n += 1
            if n % 10 == 0: await shot(pg, f'{TAG}_load_{T()}')
            if s[0] and not s[1]: break
        await asyncio.sleep(3); await shot(pg, TAG + '_1_battle_start')
        print(T(), 'cam before', await pg.evaluate("() => JSON.stringify(__bw.battle.session.cam)"), flush=True)
        await pg.evaluate("() => { __bw.battle.session.cam.intro = 0; }"); await asyncio.sleep(10)
        print(T(), 'cam after', await pg.evaluate("() => JSON.stringify(__bw.battle.session.cam)"), flush=True); await shot(pg, TAG + '_1a_after_intro')
        dom = await pg.evaluate("() => [...document.querySelectorAll('.bwb-sq, .bwb-sp, .bwb-top, .bwb-sqt, .bwb-ab, .bwch, [class*=bwb-] button')].filter(e=>e.offsetParent!==null).map(e=>{const r=e.getBoundingClientRect();return [e.tagName+'.'+e.className.toString().slice(0,26),(e.textContent||'').trim().replace(/\\s+/g,' ').slice(0,22),Math.round(r.left),Math.round(r.top),Math.round(r.width),Math.round(r.height)]}).slice(0,40)")
        for d in dom: print('  ', d)
        print(T(), 'coach battle tour:', await pg.evaluate("() => [!!document.querySelector('.bwch'), __bw.coach.running()]"))
        if await pg.evaluate("() => !!document.querySelector('.bwch')"):
            for i in range(4):
                await shot(pg, f'{TAG}_coach_{i}'); await pg.mouse.click(420, 200); await asyncio.sleep(1.2)
        disc = await pg.evaluate("""() => { const s = __bw.battle.session; const out = {keys: Object.keys(s).slice(0, 60)}; const types = s.types || null; out.types = types;
          try { const THREE = __bw.THREE; const cam = s.camera; cam.updateMatrixWorld(); const r = {};
            for (const t of (types || [])) { const i = s.rings.info ? s.rings.info(t) : null; if (!i) continue; const y0 = (s.H ? s.H(i.cx, i.cz) : 0) + 0.5; const v = new THREE.Vector3(i.cx, y0, i.cz).project(cam); const e = new THREE.Vector3(i.cx + i.r, y0, i.cz).project(cam);
              const rect = s.hud.pad.getBoundingClientRect(); r[t] = { info: i, rpx: Math.round(Math.abs(e.x - v.x) / 2 * rect.width), sx: Math.round((v.x + 1) / 2 * rect.width + rect.left), sy: Math.round((1 - v.y) / 2 * rect.height + rect.top), padW: rect.width, padH: rect.height }; }
            out.rings = r; } catch (e) { out.err = String(e).slice(0, 200); }
          return out; }""")
        print(T(), 'DISCOVERY', json.dumps(disc, ensure_ascii=False)[:1800], flush=True)
        rings = disc.get('rings') or {}
        print(T(), 'ring on screen?', {t: (r['sx'], r['sy'], r['rpx']) for t, r in rings.items()}, flush=True)
        await pg.evaluate("(p) => { const d = document.createElement('div'); d.style.cssText = 'position:fixed;z-index:99999;pointer-events:none;border:3px solid red;border-radius:50%;left:' + (p[0]-p[2]) + 'px;top:' + (p[1]-p[2]) + 'px;width:' + (2*p[2]) + 'px;height:' + (2*p[2]) + 'px'; d.id='ringmark'; document.body.appendChild(d); }", [list(rings.values())[0]['sx'], list(rings.values())[0]['sy'], max(6, list(rings.values())[0]['rpx'])]) if rings else None
        await shot(pg, TAG + '_1b_ringmark'); await pg.evaluate("() => { const d = document.getElementById('ringmark'); d && d.remove(); }")
        # HOLD-ALL gesture: press a ring, hold 0.9 s without moving, then drag: every squad goes together
        first = list(rings.items())[0]; sx, sy = first[1]['sx'], first[1]['sy']; print(T(), 'hold-all on', first[0], sx, sy, flush=True)
        await pg.mouse.move(sx, sy); await pg.mouse.down(); await asyncio.sleep(1.2)
        await shot(pg, TAG + '_1c_hold')
        for k in range(1, 9): await pg.mouse.move(sx + (430 - sx) * k / 8, sy + (140 - sy) * k / 8); await asyncio.sleep(0.2)
        await shot(pg, TAG + '_1d_drag_all')
        await pg.mouse.up(); await asyncio.sleep(3); print(T(), 'after hold-all drag', await st(pg), flush=True)
        await shot(pg, TAG + '_2_sent')
        t1 = time.time()
        while T() < 900:
            if ADV: await pg.evaluate("() => __bw.battle.advance(20)")
            await asyncio.sleep(4); s = await st(pg)
            if (int(time.time() - t1) % 20) < 5: print(T(), s, flush=True)
            if s[3] or (s[2] and s[2][2]): break
        await asyncio.sleep(6); await shot(pg, TAG + '_3_result')
        res = await pg.evaluate("() => { const r = document.querySelector('.bwb-res.on'); return r ? r.textContent.trim().replace(/\\s+/g,' ').slice(0,400) : null }"); print(T(), 'RESULT', res, flush=True)
        btn = await pg.evaluate("() => [...document.querySelectorAll('.bwb-res button')].map(b => [b.dataset.b, b.disabled])"); print('buttons', btn)
        await pg.evaluate("() => document.querySelector('.bwb-res button[data-b=home]').click()"); await asyncio.sleep(8)
        for k in range(10):
            s = await st(pg); print(T(), 'after home', s, flush=True)
            if not s[0]: break
            await asyncio.sleep(5)
        await asyncio.sleep(4); await shot(pg, TAG + '_4_home')
        print(T(), 'gems after', await pg.evaluate("() => JSON.stringify(__bw.econ.st.gems)+' tro '+__bw.econ.st.tro+' army '+JSON.stringify(__bw.econ.st.army.army)"))
        print('ERR', json.dumps(rec.err[:20], ensure_ascii=False)); print('HTTP', rec.http[:20])
        await b.close()
asyncio.run(main())
