# PL1 persist.py — leave and return (server side, real logic): queues keep running while away, mines cap at 12 h, vault caps, rush allowance, reserve queue starts on its own
import os, sys, asyncio, time, json
os.environ['BLUEWALL_STATE']='memory'
sys.path[:0]=['/home/claude/dev/stubcfg','/home/claude/bot/bluebot_v2']
_real=time.time; OFF=[0.0]; time.time=lambda:_real()+OFF[0]
from bluewall.state import STORE
from bluewall import progress as PR
U=7001
def ent(st): return {k:v['lv'] for k,v in st['prog']['structs'].items()}
async def main():
    await STORE.touch(U,'Returner')
    await STORE.dev(U,{'reset':1,'all':10,'army':{}})
    await STORE.dev(U,{'fill':1}); 
    print('start', {k:v for k,v in (await STORE.get(U))['gems'].items()}, 'vault', (await STORE.get(U))['vault'])
    # take every gem out so mines have room: spend via upgrades of 3 things (2 active + 1 reserved)
    r=[(e,(await STORE.upgrade(U,'start',e)).get('why')) for e in ('keep','mine_ruby','wall','towers','forge')]
    print('upgrade starts', r)
    await STORE.dev(U,{'gems':0})
    st=await STORE.get(U); print('after spend gems', st['gems'], 'q', [(i.get('e') if isinstance(i,dict) else i) for i in (st['prog'].get('q') or [])])
    r=await STORE.army(U,'train',{'u':'spear','n':20}); print('train spear', r.get('why'))
    r=await STORE.army(U,'train',{'u':'archer','n':10}); print('train archer', r.get('why'))
    for h in (1,6,12,13,30,72,24*14):
        OFF[0]+=0 if h==1 else 0
    t0=OFF[0]
    for h in (1,6,12,24,72):
        OFF[0]=t0+h*3600
        st=await STORE.get(U); m=st['mines']
        a=st['army']
        print(f'+{h:3d} h  gems {st["gems"]}  mines {json.dumps(m)[:160]}  army spear {a["army"].get("spear",0)} archer {a["army"].get("archer",0)}  keep {st["prog"]["structs"]["keep"]["lv"]} mine_ruby {st["prog"]["structs"]["mine_ruby"]["lv"]} wall {st["prog"]["structs"]["wall"]["lv"]} forge {st["prog"]["structs"]["forge"]["lv"]}  q {len(st["prog"].get("q") or [])}')
    # collect everything
    for g in ('ruby','emerald','turq'):
        c=await STORE.collect(U,g); print('collect',g, None if c is None else (c.get('got') or c.get('ok') or list(c.keys())[:4]))
    st=await STORE.get(U); print('after collect', st['gems'], 'vault', st['vault'])
asyncio.run(main())
