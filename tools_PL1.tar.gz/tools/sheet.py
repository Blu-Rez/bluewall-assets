# sheet.py <pickid> [dist] [shot-name]: open a building's sheet by a real tap on the map (dev page). List picks with: sheet.py list
import asyncio, json, sys
from lib import *
from tapjs import *
async def rerender(pg, need=6):
    await pg.evaluate(KEEP); f0 = await pg.evaluate('() => __bw.frames'); await pg.evaluate('() => __bw.pause(false)')
    for _ in range(240):
        await asyncio.sleep(0.5)
        if (await pg.evaluate('() => __bw.frames')) - f0 >= need: break
    await asyncio.sleep(0.5); await pg.evaluate('() => __bw.pause(true)'); await asyncio.sleep(0.4)
async def open_sheet(pg, pid, dist=120):
    for az in (0.9, 2.4, 3.9, 5.4, 1.6, 3.1, 4.6, 0.0):
        r = await pg.evaluate(POSE, [pid, dist, az])
        if r is None: return 'no pick'
        await rerender(pg, 5); f = await pg.evaluate(FIND, [pid])
        if f.get('ok'): break
    if not f.get('ok'): return 'cannot hit (az sweep failed) ' + json.dumps(f)
    await pg.evaluate("([x, y]) => { __bw.ctl.onTap(x, y); }", [f['x'], f['y']])
    for _ in range(50):
        if await pg.evaluate("() => { const s = document.querySelector('.bsh.on'); if (!s) return false; const r = s.getBoundingClientRect(); return getComputedStyle(s).transform === 'none' && r.top < innerHeight - 20; }"): return 'ok'
        await asyncio.sleep(0.3)
    return 'no sheet'
async def main():
    async with async_playwright() as p:
        b, pg = await cdp_page(p, fresh=False)
        if sys.argv[1] == 'list':
            print(await pg.evaluate("() => __bw.world.picks.map(q => q.id).join(' ')"))
        else:
            r = await open_sheet(pg, sys.argv[1], float(sys.argv[2]) if len(sys.argv) > 2 else 120); print('sheet', sys.argv[1], r)
            await asyncio.sleep(1.0); await rerender(pg, 4)
            await shot(pg, sys.argv[3] if len(sys.argv) > 3 else 'sheet_' + sys.argv[1].replace(':', '_'))
        await b.close()
asyncio.run(main())
