# queue_load.py — L10 owner kingdom with 3 active upgrades + 1 reserved + an army queue, then a FRESH page load: do the queues come back?
import asyncio, json, sys, time
from lib import *
async def main():
    tok = token(OWNER)
    print(req('/api/dev', {'reset': 1, 'all': 10, 'fill': 1, 'army': {}, 'noboost': 1}, tok)[0])
    for e in ('keep', 'wall', 'towers', 'forge', 'mine_ruby'):
        s, j = req('/api/upgrade/start', {'ent': e}, tok); print('upgrade', e, s, j.get('why'), j.get('info'))
    for u, n in (('spear', 30), ('archer', 20)):
        s, j = req('/api/army/train', {'u': u, 'n': n}, tok); print('train', u, n, s, j.get('why'))
    s, j = req('/api/army/brew', {'u': 'lightning', 'n': 2}, tok); print('brew', s, j.get('why'))
    s, j = req('/api/state', None, tok); print('server q', [(i['e'], i['to'], round(i['end'] - j['now']) if i.get('end') else 'reserved') for i in j['prog'].get('q', [])] if 'q' in j['prog'] else j['prog'].keys())
    print('server tq', json.dumps(j['army']['fam']['barracks']['q'])[:200], json.dumps(j['army']['fam']['training']['q'])[:200])
    async with async_playwright() as p:
        b, pg = await cdp_page(p, 844, 390); rec = Rec(); rec.attach(pg)
        await dev_route(pg); t0 = time.time()
        frag = urllib.parse.urlencode({"tgWebAppData": init_data(OWNER), "tgWebAppVersion": "8.0", "tgWebAppPlatform": "android"})
        await pg.goto(BASE + '/#' + frag, wait_until='domcontentloaded', timeout=120000)
        for i in range(2400):
            await asyncio.sleep(0.5)
            try: st = await pg.evaluate("() => [!!document.getElementById('bw-load'), !!document.querySelector('canvas')]")
            except Exception: continue
            if not st[0] and st[1]: break
        print('loaded', round(time.time() - t0), flush=True)
        await asyncio.sleep(5)
        await pg.evaluate("() => { try { if (__bw.ctl.intro) __bw.ctl.intro.t = (__bw.ctl.intro.dur || 99); } catch (e) {} }")
        print('CLIENT q', await pg.evaluate("() => JSON.stringify((__bw.econ.st.prog.q || []).map(i => [i.e, i.to, i.end ? Math.round(i.end - __bw.econ.st.now) : 'reserved']))"))
        print('CLIENT army fam q', await pg.evaluate("() => JSON.stringify(Object.fromEntries(Object.entries(__bw.econ.st.army.fam).map(([k, v]) => [k, v.q.length])))"))
        print('ERR', json.dumps(rec.err[:20], ensure_ascii=False), 'HTTP', rec.http[:10], flush=True); print('LOADED', flush=True)
        await b.close()
asyncio.run(main())
