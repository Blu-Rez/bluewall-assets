# x.py cmd cmd ... : drive the ALREADY LOADED real game page (last tab on CDP :9222)
#   click:<css>[#n]   js-click an element        tap:<x>,<y>   real mouse click      js:<expr>   evaluate, print
#   wait:<sec>        shot:<name>               dom             list visible buttons/overlays      size:<w>x<h>
import asyncio, json, sys, time
from lib import *
JS_DOM = """() => { const vis = (e) => { const r = e.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; let n = e; while (n && n !== document.body) { const s = getComputedStyle(n); if (s.display === 'none' || s.visibility === 'hidden' || +s.opacity < 0.05) return false; n = n.parentElement; } return r.right > 0 && r.bottom > 0 && r.left < innerWidth && r.top < innerHeight; };
  const out = []; for (const e of document.querySelectorAll('button,[data-a],[data-t],[data-b],.bwh-btn,.bwa-btn,.bw-lvl,.bw-gems,.bw-pm,[class*=-x],input,select,.bwch,.bw-wel')) { if (!vis(e)) continue; const r = e.getBoundingClientRect();
    out.push([(e.tagName + '.' + (typeof e.className === 'string' ? e.className : '')).slice(0, 38), e.getAttribute('data-a') || e.getAttribute('data-t') || e.getAttribute('data-b') || '', (e.textContent || '').trim().replace(/\\s+/g, ' ').slice(0, 30), Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)]); }
  return out.slice(0, 90); }"""
async def main():
    async with async_playwright() as p:
        b, pg = await cdp_page(p, fresh=False)
        for c in sys.argv[1:]:
            k, _, v = c.partition(':')
            if k == 'click':
                sel, _, n = v.partition('#'); r = await pg.evaluate("([s,n]) => { const e = document.querySelectorAll(s)[n]; if (!e) return false; e.click(); return true; }", [sel, int(n or 0)]); print('click', v, r)
            elif k == 'tap':
                x, y = map(float, v.split(',')); await pg.mouse.click(x, y); print('tap', v)
            elif k == 'js': print('js ->', json.dumps(await pg.evaluate(v), ensure_ascii=False)[:1500])
            elif k == 'wait': await asyncio.sleep(float(v))
            elif k == 'shot': print('shot', await shot(pg, v))
            elif k == 'dom':
                for d in await pg.evaluate(JS_DOM): print(d)
            elif k == 'size':
                w, h = map(int, v.split('x')); await pg.set_viewport_size({'width': w, 'height': h}); await asyncio.sleep(1.5)
        await b.close()
asyncio.run(main())
