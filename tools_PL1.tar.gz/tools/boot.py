# boot timeline of a fresh account: welcome card -> intro -> tutorial?  python3 boot.py <uid> <w> <h>
import asyncio, json, sys, time
from lib import *
UID = int(sys.argv[1]); W = int(sys.argv[2]); H = int(sys.argv[3]); DEV = len(sys.argv) > 4 and sys.argv[4] == 'dev'
async def main():
    async with async_playwright() as p:
        b, pg = await cdp_page(p, W, H); rec = Rec()
        logs = []; pg.on('console', lambda m: logs.append((round(time.time() - rec.t0), m.type, m.text[:160])))
        t0 = time.time(); rec.attach(pg)
        if DEV: await dev_route(pg)
        frag = urllib.parse.urlencode({"tgWebAppData": init_data(UID), "tgWebAppVersion": "8.0", "tgWebAppPlatform": "android"})
        await pg.goto(BASE + '/#' + frag, wait_until='domcontentloaded', timeout=120000)
        seen_load = False
        for i in range(2400):
            await asyncio.sleep(0.25)
            try:
                st = await pg.evaluate("() => [!!document.getElementById('bw-load'), !!document.querySelector('.bw-wel'), !!document.querySelector('.bwch'), !!document.querySelector('canvas'), localStorage.getItem('bw_coach_home')]")
            except Exception: continue
            if i % 8 == 0: print(round(time.time() - t0), st, flush=True)
            if not st[0] and st[3]: break
        t1 = time.time(); print('loader gone', round(t1 - t0), flush=True)
        shots = 0
        for k in range(14):
            st = await pg.evaluate("() => [!!document.querySelector('.bw-wel'), !!document.querySelector('.bwch'), document.querySelector('.bw-ui') && document.querySelector('.bw-ui').className, localStorage.getItem('bw_coach_home'), window.__bw ? [!!__bw.ctl.intro, __bw.ctl.intro && __bw.ctl.intro.hold, __bw.coach.isNew(), __bw.coach.running(), __bw.econ.st.level, typeof __bw.ctl.onIntroEnd] : null]")
            print('t+%d' % round(time.time() - t1), st, flush=True)
            if k in (0, 2, 5, 9, 14, 20, 29): await shot(pg, f'boot_{UID}_{W}_{k}')
            await asyncio.sleep(3)
        print('LOGS', json.dumps(logs[-25:], ensure_ascii=False)); print('ERR', json.dumps(rec.err[:20], ensure_ascii=False)); print('HTTP', rec.http[:20])
        await b.close()
asyncio.run(main())
