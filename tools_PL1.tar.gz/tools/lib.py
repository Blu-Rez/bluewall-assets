# PL1 helper: drive the REAL game (real server on :8591, memory state) in the long-lived chromium on CDP :9222
import asyncio, hmac, hashlib, json, time, urllib.parse, urllib.request, os, sys
from playwright.async_api import async_playwright
TOK = os.environ.get("PL1_TOK", "0:TEST")   # the TEST bot token of the stub config used to start the server (set PL1_TOK to the same value; nothing real); BASE = 'http://127.0.0.1:8591'; OUT = '/home/claude/work/pl1/out'
OWNER = 777
def init_data(uid, name='Blue'):
    d = {"auth_date": str(int(time.time())), "query_id": "AAE", "user": json.dumps({"id": uid, "first_name": name}, separators=(',', ':'))}
    dcs = "\n".join(f"{k}={v}" for k, v in sorted(d.items()))
    sk = hmac.new(b"WebAppData", TOK.encode(), hashlib.sha256).digest()
    d["hash"] = hmac.new(sk, dcs.encode(), hashlib.sha256).hexdigest()
    return urllib.parse.urlencode(d)
def req(path, body=None, tok=None):
    h = {'Content-Type': 'application/json'}
    if tok: h['Authorization'] = 'Bearer ' + tok
    r = urllib.request.Request(BASE + path, data=json.dumps(body).encode() if body is not None else None, headers=h, method='POST' if body is not None else 'GET')
    try:
        with urllib.request.urlopen(r, timeout=30) as f: return f.status, json.loads(f.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read() or b'{}')
def token(uid):
    s, a = req('/api/auth', {'init_data': init_data(uid)}); assert s == 200, (s, a); return a['token']
class Rec:
    """collects console errors / page errors / failed requests / bad HTTP statuses of one page"""
    def __init__(s): s.err = []; s.http = []; s.t0 = time.time()
    def attach(s, pg):
        pg.on('pageerror', lambda e: s.err.append(('PAGEERR', round(time.time() - s.t0), str(e)[:300])))
        pg.on('console', lambda m: s.err.append(('console.' + m.type, round(time.time() - s.t0), m.text[:300])) if m.type in ('error',) and '404' not in m.text else None)
        pg.on('response', lambda r: s.http.append((r.status, r.request.method, r.url[:120])) if r.status >= 400 and 'google' not in r.url else None)
        pg.on('requestfailed', lambda r: s.http.append(('FAIL', r.method, r.url[:120])) if 'google' not in r.url else None)
async def cdp_page(p, w=844, h=390, fresh=True):
    b = await p.chromium.connect_over_cdp('http://127.0.0.1:9222'); ctx = b.contexts[0]
    if fresh:
        for pg in list(ctx.pages):
            try: await pg.close()
            except Exception: pass
        pg = await ctx.new_page()
    else: pg = ctx.pages[-1]
    await pg.set_viewport_size({'width': w, 'height': h}); return b, pg
async def dev_route(pg):
    # same page, same real bundle, same real server - only BlueWall.start gets dev:true so window.__bw exists (diagnosis mode)
    async def h(route):
        r = await route.fetch(); body = (await r.text()).replace('owner: !!j.owner,', 'owner: !!j.owner, dev: true,' + (' welcomeAuto: ' + os.environ['PL1_WEL'] + ',' if os.environ.get('PL1_WEL') else ''))
        await route.fulfill(response=r, body=body, headers={**r.headers, 'content-length': str(len(body.encode()))})
    await pg.route(BASE + '/', h)
async def open_game(pg, uid, rec, wait_loader=600, extra='', dev=False):
    if dev: await dev_route(pg)
    frag = urllib.parse.urlencode({"tgWebAppData": init_data(uid), "tgWebAppVersion": "8.0", "tgWebAppPlatform": "android"})
    t0 = time.time(); rec.attach(pg)
    await pg.goto(BASE + '/' + extra + '#' + frag, wait_until='domcontentloaded', timeout=120000)
    gone = None
    for i in range(wait_loader * 2):
        await asyncio.sleep(0.5)
        try:
            if await pg.evaluate("!document.getElementById('bw-load') && !!document.querySelector('canvas')"): gone = round(time.time() - t0); break
        except Exception: pass
    return gone
async def shot(pg, name, **kw):
    path = f'{OUT}/{name}.png'
    try: await pg.screenshot(path=path, timeout=240000, **kw)
    except Exception as e: print('SHOT FAIL', name, str(e)[:100]); return None
    return path
