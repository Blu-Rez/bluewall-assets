# census_real.py <out-tag> [scene-regex] [sizes]  — UI1's menu census on the REAL server data (no PREP fakes, no stubs) at 3 sizes with Telegram margins.
import asyncio, json, os, re, sys, time
sys.path.insert(0, '/home/claude/dev')
from playwright.async_api import async_playwright
from lib import cdp_page, Rec
from ui1r4_common import *
import ui1r4_scenes as S
# real openers for the social menus (UI1's own versions swap the network calls for stubs)
def real(name, group, root, pan, close, fn): return dict(name=name, group=group, fn=fn, root=root, pan=pan, close=close)
RK = dict(root='.bwk.on', pan='.bwk-pan', close='.bwk-x')
async def o_rank(tab):
    async def f(pg): await via_hub(pg, 'rank'); await js_click(pg, S.RT(tab)); await settle(pg, 1.0)
    return f
async def o_hub(tile, sub=None):
    async def f(pg):
        await via_hub(pg, tile); await settle(pg, 1.0)
    return f
async def build():
    sc = [s for s in S.SC if s['name'] in ('hub', 'kingdom_owned', 'kingdom_town', 'kingdom_reserve', 'kingdom_new', 'army_troops', 'army_spells', 'army_unit_info_common', 'army_unit_info_mythic', 'army_spell_info', 'army_emblem_picker',
          'shop_boosts', 'shop_defense', 'shop_gems', 'settings_sound', 'settings_graphics', 'settings_controls', 'settings_about', 'settings_graphics_owner_tools', 'hero_picker', 'old_info_card') or s['name'].startswith('sheet_')]
    async def kb(pg): await S.king(pg, 'buy')
    sc.append(real('kingdom_buy_real', 'Kingdom', '.bwu.on', '.bwu-pan', '.bwu-x', kb))
    for tab, nm in (('lb', 'rank_leaderboard'), ('lg', 'rank_leagues'), ('inv', 'rank_invite')): sc.append(real(nm + '_real', 'Rank', RK['root'], RK['pan'], RK['close'], await o_rank(tab)))
    for tile in ('clan', 'friends', 'log'): sc.append(real(tile + '_real', 'Rank', RK['root'], RK['pan'], RK['close'], await o_hub(tile)))
    async def banner(pg): await via_hub(pg, 'banner'); await settle(pg, 1.0)
    sc.append(real('banner_real', 'Banner', '.bwa-ov.on, .bwh.on, .bw-sheet.on', None, '.bwh-x', banner))
    return sc
