# PL1 defend.py — A attacks B (both normal players, in-process real STORE logic); then what B sees on coming back.
import os, sys, asyncio, time, json
os.environ['BLUEWALL_STATE']='memory'
sys.path[:0]=['/home/claude/dev/stubcfg','/home/claude/bot/bluebot_v2']
_real=time.time; OFF=[0.0]; time.time=lambda:_real()+OFF[0]
from bluewall.state import STORE
from bluewall import military as MI
A,B=6001,6002
async def prep(u,name,lvl):
    await STORE.touch(u,name)
    await STORE.dev(u,{'reset':1,'all':lvl,'fill':1,'army':'fill'})
async def main():
    await prep(A,'Attacker',10); await prep(B,'Defender',10)
    st=await STORE.get(B); print('B before: gems',st['gems'],'tro',st['tro'],'shield',st.get('shield'),'army',st['army']['space'],'/',st['army']['cap'])
    OFF[0]+=1200   # B offline > 10 min
    tgt=None
    for i in range(30):
        r=await STORE.scout(A); 
        if not r['ok']:
            print('scout',i,r.get('why'),r.get('wait'))
            OFF[0]+=25; continue
        tgt=r['target']; 
        if (tgt.get('kind') or tgt.get('k'))=='player': break
        OFF[0]+=25
    print('target', json.dumps(tgt, ensure_ascii=False)[:700] if tgt else None)
    if not tgt: return
    stA=await STORE.get(A); sent={u:n for u,n in stA['army']['army'].items() if u in MI.UNITS}
    tid=(await STORE.load(A))['atk']['id']
    rep={'sent':sent,'lost':{u:max(0,n//2) for u,n in sent.items()},'destruction':64,'stars':1,'loot':tgt['loot'],'spells':{}}
    r=await STORE.battle_end(A,tid,rep); print('battle_end ok',r.get('ok'),r.get('why'),json.dumps(r.get('info'),ensure_ascii=False)[:500])
    OFF[0]+=3600*3
    st=await STORE.get(B)
    print('B after: gems',st['gems'],'tro',st['tro'],'shield',st.get('shield'))
    print('B keys', [k for k in st.keys()])
    for k in ('hits','reports','gift','vis','lg'):
        if k in st: print(k, json.dumps(st[k],ensure_ascii=False)[:600])
    print('B army reports', json.dumps(st['army'].get('reports'),ensure_ascii=False)[:600])
    h=await STORE.history(B); print('history', json.dumps(h,ensure_ascii=False)[:600])
asyncio.run(main())
