# persona_load.py <level> <w> <h> [hits]  — owner uid 777 (dev ops) -> a real kingdom at castle <level> with a full army, then a FRESH page load (dev page); screenshots the welcome card (+ raid report) and the first map frame
import asyncio, json, sys, time
from lib import *
LV = int(sys.argv[1]); W = int(sys.argv[2]); H = int(sys.argv[3]); HITS = len(sys.argv) > 4 and sys.argv[4] == 'hits'
async def main():
    tok = token(OWNER)
    body = {'reset': 1, 'all': LV, 'fill': 1, 'army': 'fill', 'noboost': 1}
    s, j = req('/api/dev', body, tok); print('dev', s, j.get('ok'), j.get('level'), flush=True)
    s, j = req('/api/dev', {'army': 'fill', 'fill': 1}, tok)
    if HITS:
        s, j = req('/api/dev', {'hits': [{'by': 'Raider One', 'ago': 25, 'lost': {'ruby': 420, 'emerald': 610, 'turq': 90}, 'tro': -14, 'stars': 2, 'pct': 71},
                                          {'by': 'A very long raider name here', 'ago': 20, 'lost': {'ruby': 0, 'emerald': 0, 'turq': 0}, 'tro': 6, 'stars': 0, 'pct': 12},
                                          {'by': 'Third', 'ago': 15, 'lost': {'ruby': 120}, 'tro': -3, 'stars': 1, 'pct': 52},
                                          {'by': 'Fourth', 'ago': 10, 'lost': {'emerald': 33}, 'tro': -1, 'stars': 1, 'pct': 50}]}, tok); print('hits', s, flush=True)
    async with async_playwright() as p:
        b, pg = await cdp_page(p, W, H); rec = Rec(); rec.attach(pg)
        await dev_route(pg); t0 = time.time()
        frag = urllib.parse.urlencode({"tgWebAppData": init_data(OWNER), "tgWebAppVersion": "8.0", "tgWebAppPlatform": "android"})
        await pg.goto(BASE + '/#' + frag, wait_until='domcontentloaded', timeout=120000)
        got_wel = False
        for i in range(2400):
            await asyncio.sleep(0.5)
            try: st = await pg.evaluate("() => [!!document.getElementById('bw-load'), !!document.querySelector('.bw-wel'), !!document.querySelector('canvas'), window.__bw ? __bw.econ.st.level : null]")
            except Exception: continue
            if st[1] and not got_wel:
                got_wel = True; await asyncio.sleep(1.0); print(round(time.time() - t0), 'welcome card up', flush=True); await shot(pg, f'persona{LV}_{W}_welcome')
                try: print('WELCOME TEXT', await pg.evaluate("() => { const e = document.querySelector('.bw-wel'); return e ? e.innerText.replace(/\\s+/g,' ').slice(0,600) : null }"), flush=True)
                except Exception as ex: print('welcome text fail', ex)
                try: print('WELCOME RECT', await pg.evaluate("() => { const w = document.querySelector('.bw-wel'); if (!w) return null; const r = w.getBoundingClientRect(); const rp = w.querySelector('.rp, [class*=rp]'); const q = rp ? rp.getBoundingClientRect() : null; return [r.left,r.top,r.width,r.height, innerWidth, innerHeight, w.scrollHeight, q ? [q.left,q.top,q.width,q.height] : null] }"), flush=True)
                except Exception as ex: print('welcome rect fail', ex)
            if not st[0] and st[2]: break
        print('loader gone', round(time.time() - t0), 'level', st[3], flush=True)
        for k in range(6):
            await asyncio.sleep(3)
        await pg.evaluate("() => { try { if (__bw.ctl.intro) { __bw.ctl.intro.t = (__bw.ctl.intro.dur || 99); } } catch (e) {} }"); await asyncio.sleep(6)
        await shot(pg, f'persona{LV}_{W}_map')
        print('ERR', json.dumps(rec.err[:20], ensure_ascii=False)); print('HTTP', rec.http[:20]); print('LOADED', flush=True)
        await b.close()
asyncio.run(main())
