#!/bin/bash
# PL1: real server (memory state, stub config) on 8591 + long-lived chromium on CDP 9222. Idempotent.
curl -s -m 2 http://127.0.0.1:8591/healthz >/dev/null || {
  cd /home/claude/bot/bluebot_v2
  PYTHONPATH=/home/claude/dev/stubcfg BLUEWALL_STATE=memory setsid nohup python3 -m bluewall > /tmp/bw8591.log 2>&1 < /dev/null &
  sleep 4; }
curl -s -m 2 http://127.0.0.1:9222/json/version >/dev/null || {
  setsid nohup /opt/pw-browsers/chromium-1194/chrome-linux/chrome --headless=new --no-sandbox --use-gl=angle --use-angle=swiftshader --enable-unsafe-swiftshader --ignore-gpu-blocklist \
    --remote-debugging-port=9222 --user-data-dir=/tmp/pl1_prof --window-size=844,390 --force-device-scale-factor=1 about:blank > /tmp/pl1_chrome.log 2>&1 < /dev/null &
  sleep 4; }
echo "server: $(curl -s -m 2 http://127.0.0.1:8591/healthz)  chrome: $(curl -s -m 2 http://127.0.0.1:9222/json/version | head -c 60)"
