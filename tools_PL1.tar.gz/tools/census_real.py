# census_real.py <out-tag> [scene-regex] [sizes]  — UI1's menu census on the REAL server data (no PREP fakes, no stubs) at 3 sizes with Telegram margins.
import asyncio, json, os, re, sys, time
sys.path.insert(0, '/home/claude/dev')
from playwright.async_api import async_playwright
from lib import cdp_page, Rec
from ui1r4_common import *
import ui1r4_scenes as S
OUTTAG = sys.argv[1]; ONLY = re.compile(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2] else None
SZ = [tuple(map(int, s.split('x'))) for s in sys.argv[3].split(',')] if len(sys.argv) > 3 else SIZES
OUT = '/home/claude/work/pl1/out/census_' + OUTTAG + '/'; os.makedirs(OUT, exist_ok=True)
# real openers for the social menus (UI1's own versions swap the network calls for stubs)
def real(name, group, root, pan, close, fn): return dict(name=name, group=group, fn=fn, root=root, pan=pan, close=close)
RK = dict(root='.bwk.on', pan='.bwk-pan', close='.bwk-x')
async def o_rank(tab):
    async def f(pg): await via_hub(pg, 'rank'); await js_click(pg, S.RT(tab)); await settle(pg, 1.0)
    return f
async def o_hub(tile, sub=None):
    async def f(pg):
        await via_hub(pg, tile); await settle(pg, 1.0)
    return f
async def build():
    sc = [s for s in S.SC if s['name'] in ('hub', 'kingdom_owned', 'kingdom_town', 'kingdom_reserve', 'kingdom_new', 'army_troops', 'army_spells', 'army_unit_info_common', 'army_unit_info_mythic', 'army_spell_info', 'army_emblem_picker',
          'shop_boosts', 'shop_defense', 'shop_gems', 'settings_sound', 'settings_graphics', 'settings_controls', 'settings_about', 'settings_graphics_owner_tools', 'hero_picker', 'old_info_card') or s['name'].startswith('sheet_')]
    async def kb(pg): await S.king(pg, 'buy')
    sc.append(real('kingdom_buy_real', 'Kingdom', '.bwu.on', '.bwu-pan', '.bwu-x', kb))
    for tab, nm in (('lb', 'rank_leaderboard'), ('lg', 'rank_leagues'), ('inv', 'rank_invite')): sc.append(real(nm + '_real', 'Rank', RK['root'], RK['pan'], RK['close'], await o_rank(tab)))
    for tile in ('clan', 'friends', 'log'): sc.append(real(tile + '_real', 'Rank', RK['root'], RK['pan'], RK['close'], await o_hub(tile)))
    async def banner(pg): await via_hub(pg, 'banner'); await settle(pg, 1.0)
    sc.append(real('banner_real', 'Banner', '.bwa-ov.on, .bwh.on, .bw-sheet.on', None, '.bwh-x', banner))
    return sc
async def main():
    res = {}; rec = Rec()
    async with async_playwright() as p:
        b, pg = await cdp_page(p, fresh=False); rec.attach(pg)
        b.contexts[0].on('page', lambda q: asyncio.ensure_future(q.close()))
        scenes = await build()
        for (W, H) in SZ:
            await set_size(pg, W, H, True); await close_all(pg)
            safe = {'t': TG['top'], 'r': TG['side'], 'b': TG['bottom'], 'l': TG['side']}
            for sc in scenes:
                if ONLY and not ONLY.search(sc['name']): continue
                key = f"{sc['name']}|{W}x{H}"; t0 = time.time()
                r = await S.run_scene(pg, sc, W, H, safe, f"{OUT}{sc['name']}_{W}x{H}.png")
                r['group'] = sc['group']; r['t'] = round(time.time() - t0, 1); res[key] = r
                st = 'SKIP ' + r['skip'] if 'skip' in r else ('ERR ' + r['error'] if 'error' in r else ('ok' if r.get('ok') else 'FAIL ' + ' | '.join(r['fail'])[:230]))
                print(f"{key:44s} {st}", flush=True); json.dump(res, open(OUT + 'results.json', 'w'), indent=0)
            await S.ensure_clean(pg); await close_all(pg)
        print('PAGEERR/ERR', json.dumps(rec.err[:30], ensure_ascii=False)); print('HTTP', rec.http[:30]); print('DONE')
        await b.close()
asyncio.run(main())
