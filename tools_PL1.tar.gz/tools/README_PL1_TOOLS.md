# PL1 tools (read-only on the game)
Needs: the kit (bluebot_v2) built as usual, a stub `config.py` (owner uid 777, any fake bot token) in `PYTHONPATH`, the same fake token in `PL1_TOK`, `/home/claude/dev/ui1r4_*.py` (UI1's census modules), Playwright + the pre-installed Chromium.
1. `bash up.sh` — real server :8591 (memory state) + chromium on CDP :9222 (idempotent).
2. `python3 persona_load.py <level> 844 390 [hits]` — owner uid 777 -> kingdom at castle <level>, full army, fresh page load (dev page, `window.__bw`). `PL1_WEL=900` keeps the welcome card up 15 min.
3. `python3 census_real.py <tag> '<scene-regex>' 844x390,800x360,932x430` — UI1's menu census on the REAL page (no stubs). `arr_overlap.py <tag>` — overlap of the floating Arrange button (NOTE: only meaningful with the render loop running; the census pauses it).
4. `ADV=1 python3 attack4.py <tag>` (drag each ring) / `attack5.py` (hold-all gesture) — one attack from Army to the result card and home.
5. `python3 climb.py`, `defend.py`, `persist.py` — in-process STORE logic with a shifted clock (no browser).
Results of the PL1 run: `results_census_*.json`, `climb.json`, `arr_overlap_L10.json`.
