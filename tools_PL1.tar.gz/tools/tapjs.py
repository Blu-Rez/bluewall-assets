POSE = """([id, dist, az]) => { const w = __bw.world, THREE = __bw.THREE, c = __bw.ctl, cam = __bw.camera; const pk = w.picks.find((q) => q.id === id); if (!pk) return null;
  if (!window.__cam0) window.__cam0 = { t: c.target.clone(), d: c.dist, p: c.polar, a: c.azim };
  const ctr = pk.box.getCenter(new THREE.Vector3()); c.target.set(ctr.x, 0, ctr.z); c.dist = dist; c.polar = 1.0; c.azim = az; c.intro = null;
  const W = innerWidth, H = innerHeight; cam.setViewOffset(W, H, 0, Math.round(H * (W < H ? 0.2 : 0.0)), W, H); return [ctr.x, ctr.y, ctr.z]; }"""
FIND = """([want]) => { const w = __bw.world, THREE = __bw.THREE, cam = __bw.camera, ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), hit = new THREE.Vector3();
  const pk = w.picks.find((q) => q.id === want); const bx = pk.box, ctr = bx.getCenter(new THREE.Vector3());
  const pts = [ctr, new THREE.Vector3(ctr.x, bx.max.y - 0.5, ctr.z), new THREE.Vector3(ctr.x, bx.min.y + 1.2, ctr.z), new THREE.Vector3(bx.min.x + 1, ctr.y, ctr.z), new THREE.Vector3(bx.max.x - 1, ctr.y, ctr.z), new THREE.Vector3(ctr.x, ctr.y, bx.min.z + 1), new THREE.Vector3(ctr.x, ctr.y, bx.max.z - 1)];
  cam.updateMatrixWorld(); let first = null;
  for (const p of pts) { const v = p.clone().project(cam); if (Math.abs(v.x) > 0.9 || v.y > 0.55 || v.y < -0.9) continue; const x = (v.x + 1) / 2 * innerWidth, y = (1 - v.y) / 2 * innerHeight;
    ndc.set((x / innerWidth) * 2 - 1, -(y / innerHeight) * 2 + 1); ray.setFromCamera(ndc, cam); let best = null, bd = 1e9;
    for (const q of w.picks) if (ray.ray.intersectBox(q.box, hit)) { const d = hit.distanceTo(cam.position); if (d < bd) { bd = d; best = q.id; } }
    if (!first) first = { x, y, hit: best }; if (best === want) return { x, y, hit: best, ok: true }; }
  return first ? { ...first, ok: false } : { ok: false }; }"""
CAMBACK = "() => { const c = __bw.ctl, o = window.__cam0; __bw.camera.clearViewOffset && __bw.camera.clearViewOffset(); if (o) { c.target.copy(o.t); c.dist = o.d; c.polar = o.p; c.azim = o.a; window.__cam0 = null; } }"
KEEP = """() => { if (document.getElementById('x-keep')) return; const s = document.createElement('style'); s.id = 'x-keep'; s.textContent = '@keyframes xk{from{transform:translateX(0)}to{transform:translateX(2px)}}#xk{position:fixed;left:0;top:0;width:2px;height:2px;opacity:.01;pointer-events:none;z-index:1;animation:xk .5s linear infinite alternate}'; document.head.appendChild(s); const d = document.createElement('div'); d.id = 'xk'; document.body.appendChild(d); }"""
