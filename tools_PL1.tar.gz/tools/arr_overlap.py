# arr_overlap.py <tag> [sizes] — for every menu scene, which interactive element does the floating «Arrange» button cover (and is Arrange on top)?
import asyncio, json, os, re, sys
sys.path.insert(0, '/home/claude/dev')
from scenes_real import *
from lib import cdp_page
TAGX = sys.argv[1]; SZ2 = [tuple(map(int, s.split('x'))) for s in sys.argv[2].split(',')] if len(sys.argv) > 2 else SIZES
JS = """() => {
  const vis = (e) => { const r = e.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; let n = e; while (n && n !== document.body) { const s = getComputedStyle(n); if (s.display === 'none' || s.visibility === 'hidden' || +s.opacity < 0.05) return false; n = n.parentElement; } return true; };
  const A = [...document.querySelectorAll('button')].find((b) => /Arrange/.test(b.textContent || '') && vis(b)); if (!A) return {noArrange: true};
  const a = A.getBoundingClientRect(), out = [];
  for (const e of document.querySelectorAll('button,[data-a],[data-t],[data-b],.inf,[class*=-x],input,select,a')) {
    if (e === A || A.contains(e) || e.contains(A) || !vis(e)) continue; const r = e.getBoundingClientRect();
    const w = Math.min(a.right, r.right) - Math.max(a.left, r.left), h = Math.min(a.bottom, r.bottom) - Math.max(a.top, r.top); if (w <= 2 || h <= 2) continue;
    const cx = Math.max(a.left, r.left) + w / 2, cy = Math.max(a.top, r.top) + h / 2, top = document.elementFromPoint(cx, cy);
    out.push({el: (e.tagName + '.' + (typeof e.className === 'string' ? e.className : '')).slice(0, 30), txt: (e.textContent || '').trim().replace(/\\s+/g, ' ').slice(0, 24), data: e.getAttribute('data-a') || e.getAttribute('data-t') || '', overlapPx: Math.round(w * h), pctOfEl: Math.round(100 * w * h / (r.width * r.height)), arrangeOnTop: top === A || A.contains(top), r: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)]});
  }
  return {arrange: [Math.round(a.left), Math.round(a.top), Math.round(a.width), Math.round(a.height)], over: out};
}"""
async def main():
    res = {}
    async with async_playwright() as p:
        b, pg = await cdp_page(p, fresh=False)
        b.contexts[0].on('page', lambda q: asyncio.ensure_future(q.close()))
        scenes = await build()
        for (W, H) in SZ2:
            await set_size(pg, W, H, True); await close_all(pg)
            for sc in scenes:
                key = f"{sc['name']}|{W}x{H}"
                try: await pg.evaluate(S.RESTORE); await sc['fn'](pg)
                except Exception as ex: res[key] = {'skip': str(ex)[:80]}; continue
                await settle(pg, .4); r = await pg.evaluate(JS); res[key] = r
                hit = [o for o in r.get('over', []) if o['pctOfEl'] >= 10]
                desc = 'NO-ARRANGE' if r.get('noArrange') else ('OVER ' + '; '.join("%s«%s»%d%%%s" % (o['el'], o['txt'], o['pctOfEl'], '^' if o['arrangeOnTop'] else '') for o in hit) if hit else 'clear')
                print("%-44s %s" % (key, desc), flush=True)
                json.dump(res, open(f'/home/claude/work/pl1/out/arr_overlap_{TAGX}.json', 'w'), indent=0)
            await S.ensure_clean(pg); await close_all(pg)
        print('DONE'); await b.close()
asyncio.run(main())
