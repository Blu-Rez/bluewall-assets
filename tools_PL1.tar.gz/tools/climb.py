# PL1 climb.py — plays the REAL server logic (bluewall.state.STORE, memory) in-process, with a shifted clock, from a fresh account to keep 50.
# Each round: owner-dev fill vaults (gems = what a patient player would have), start every upgrade the rules allow, jump the clock to the next finish.
# Records every refusal reason per (struct, level), looks for dead ends (nothing can start but not everything is maxed), cost > vault, view() crashes, JSON problems.
import os, sys, asyncio, time, json, math, collections
os.environ['BLUEWALL_STATE'] = 'memory'
sys.path[:0] = ['/home/claude/dev/stubcfg', '/home/claude/bot/bluebot_v2']
_real = time.time; OFF = [0.0]
time.time = lambda: _real() + OFF[0]
from bluewall.state import STORE
from bluewall import progress as PR, military as MI
UID = 777
OUT = '/home/claude/work/pl1/out/climb.json'
rep = dict(whys=collections.Counter(), dead=[], snaps={}, crashes=[], vault_blocks=[], notes=[], rounds=0)
def chk_json(tag, v):
    try: json.dumps(v, allow_nan=False)
    except Exception as e: rep['crashes'].append(f'{tag}: view not JSON-safe: {str(e)[:120]}')
async def snap(label):
    st = await STORE.get(UID); chk_json('snap ' + label, st)
    a = st['army']; keep = st['prog']['b']['keep']
    out = dict(keep=keep, units={}, spells={}, fam={k: dict(lv=v['lv'], cap=v['cap']) for k, v in a['fam'].items()}, space=a['space'], gems=st['gems'], vault=st['vault'], builders=st['prog'].get('builders'))
    # try to train 1 of every unit
    await STORE.dev(UID, {'fill': 1, 'army': {}})
    for u, d in MI.UNITS.items():
        r = await STORE.army(UID, 'train', {'u': u, 'n': 1})
        out['units'][u] = r.get('why') or 'ok'
        if r.get('ok'): await STORE.army(UID, 'cancel', {'fam': MI.UNITS[u]['fam']})
        chk_json('train ' + u, r)
    for s in (a['spell']['spells'] or {}):
        r = await STORE.army(UID, 'brew', {'u': s, 'n': 1}); out['spells'][s] = r.get('why') or 'ok'
        if r.get('ok'): await STORE.army(UID, 'brewcancel', {})
    rep['snaps'][label] = out
async def main():
    await STORE.touch(UID, 'Owner')
    await STORE.dev(UID, {'reset': 1, 'army': {}})
    st = await STORE.get(UID); keep0 = st['prog']['b']['keep']
    await snap('L1')
    seen_snap = {1}; SN = (3, 5, 7, 10, 15, 20, 25, 30, 40, 50)
    stuck = 0
    for rnd in range(4000):
        rep['rounds'] = rnd
        await STORE.dev(UID, {'fill': 1})
        started = 0; whys = {}
        for e in list(PR.ORDER):
            r = await STORE.upgrade(UID, 'start', e)
            chk_json('upgrade ' + e, r)
            w = r.get('why') or 'ok'
            lv = r['prog']['b'].get(e) if 'prog' in r else '?'
            rep['whys'][f'{e}:{w}'] += 1; whys[e] = w
            if w == 'ok': started += 1
            if w == 'vault': rep['vault_blocks'].append(dict(e=e, lv=lv, info=r.get('info')))
        st = await STORE.get(UID); q = st['prog'].get('q') or st['prog'].get('queue') or []
        b = st['prog']['b']; keep = b['keep']
        # jump to next finish
        ends = [it['end'] for it in (await _q()) if it.get('end')]
        if ends:
            OFF[0] += max(1.0, min(ends) - time.time() + 1); await STORE.dev(UID, {'finish': 0})   # just settles
            await STORE.get(UID)
        st = await STORE.get(UID); b2 = st['prog']['b']
        for lvl in SN:
            if b2['keep'] >= lvl and lvl not in seen_snap: seen_snap.add(lvl); await snap(f'L{lvl}')
        done = all(v >= PR.MAX_LEVEL for v in b2.values())
        if done: rep['notes'].append(f'ALL 50 after {rnd} rounds, clock +{OFF[0]/86400:.1f} d'); break
        if not ends and started == 0:
            stuck += 1
            if stuck >= 2: rep['dead'].append(dict(b=b2, whys=whys, gems=st['gems'], vault=st['vault'])); break
        else: stuck = 0
    json.dump(rep, open(OUT, 'w'), indent=1, default=lambda o: dict(o))
async def _q():
    stt = await STORE.load(UID); return stt['q']
asyncio.run(main())
print('rounds', rep['rounds'], rep['notes']); print('dead', json.dumps(rep['dead'])[:900]); print('crashes', rep['crashes'][:10]); print('vault blocks', rep['vault_blocks'][:8])
print({k: v for k, v in rep['whys'].items() if not k.endswith(':ok')})
