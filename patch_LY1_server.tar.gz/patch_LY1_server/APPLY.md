# patch_LY1_server — apply on kit 0e75919 (the mother's files)
cd bluewall && for f in layout server state; do patch -p1 < ../shared/$f.py.diff; done      # (from the unpacked directory: patch -p1 -d bluewall < shared/layout.py.diff …)
workers/dev/layout_server_test.py and workers/docs/layout_api.md: shared_workers/*/*.diff   (patch -p1 -d workers/dev < …)
What it does: POST /api/layout answers `reasons: {id: [rule codes]}` for every dropped id (only when something was dropped; a clean record is answered byte for byte as before) + the same in the INFO log.
Test: python3 workers/dev/layout_server_test.py -> LAYOUT SERVER OK.  The client works without it (it just cannot say WHY).
